import type { Property } from '@/types';

/** Live catalogue of published listings, loaded from the shared backend (see store.loadCatalog). */
export let PROPERTIES: Property[] = [];
let MAP: Record<string, Property> = {};
export function setCatalog(list: Property[]) {
  PROPERTIES = list;
  MAP = Object.fromEntries(list.map((p) => [p.id, p]));
}
export const getProperty = (id: string): Property | undefined => MAP[id];
