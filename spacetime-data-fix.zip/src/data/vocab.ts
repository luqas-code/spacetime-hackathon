import type { LucideIcon } from 'lucide-react';
import {
  Wifi, ShowerHead, BedDouble, Sofa, CookingPot, ChefHat, Microwave, Coffee, Monitor, Presentation, Tv,
  Projector, Speaker, Piano, Sun, Trees, Flame, Snowflake, WashingMachine, Bath, Briefcase, Baby, Armchair,
  ToyBrick, Moon, VolumeX, ArrowUpDown, Car, Utensils, Laptop, Users, PartyPopper, Palette, Music, Leaf,
  Luggage, Camera, Sparkles, Accessibility as AccessIcon, DoorOpen, Layers, EarOff, Shirt, Home, Building2,
  Building, House, Grid2x2, Thermometer, Hotel, ConciergeBell,
} from 'lucide-react';
import type { Activity, Amenity, Accessibility, PropertyType } from '@/types';

export const AMENITIES: Record<Amenity, { label: string; icon: LucideIcon; group: string }> = {
  wifi: { label: 'Fast Wi‑Fi', icon: Wifi, group: 'Essentials' },
  shower: { label: 'Shower', icon: ShowerHead, group: 'Bathroom' },
  bathtub: { label: 'Bathtub', icon: Bath, group: 'Bathroom' },
  towels: { label: 'Fresh towels', icon: Shirt, group: 'Bathroom' },
  toiletries: { label: 'Toiletries', icon: Sparkles, group: 'Bathroom' },
  bed: { label: 'Bed', icon: BedDouble, group: 'Rest' },
  sofa_bed: { label: 'Sofa bed', icon: Sofa, group: 'Rest' },
  sofa: { label: 'Sofa', icon: Armchair, group: 'Rest' },
  blackout: { label: 'Blackout blinds', icon: Moon, group: 'Rest' },
  soundproof: { label: 'Soundproofed', icon: VolumeX, group: 'Rest' },
  kitchen: { label: 'Kitchen', icon: CookingPot, group: 'Kitchen' },
  pro_kitchen: { label: 'Chef-grade kitchen', icon: ChefHat, group: 'Kitchen' },
  oven: { label: 'Oven', icon: Microwave, group: 'Kitchen' },
  coffee: { label: 'Coffee machine', icon: Coffee, group: 'Kitchen' },
  dining_table: { label: 'Dining table', icon: Utensils, group: 'Kitchen' },
  desk: { label: 'Dedicated desk', icon: Laptop, group: 'Work' },
  monitor: { label: 'External monitor', icon: Monitor, group: 'Work' },
  whiteboard: { label: 'Whiteboard', icon: Presentation, group: 'Work' },
  projector: { label: 'Projector / screen', icon: Projector, group: 'Work' },
  tv: { label: 'Smart TV', icon: Tv, group: 'Entertainment' },
  speakers: { label: 'Sound system', icon: Speaker, group: 'Entertainment' },
  piano: { label: 'Upright piano', icon: Piano, group: 'Entertainment' },
  terrace: { label: 'Terrace', icon: Sun, group: 'Outdoors' },
  balcony: { label: 'Balcony', icon: Sun, group: 'Outdoors' },
  garden: { label: 'Private garden', icon: Trees, group: 'Outdoors' },
  bbq_grill: { label: 'BBQ grill', icon: Flame, group: 'Outdoors' },
  ac: { label: 'Air conditioning', icon: Snowflake, group: 'Comfort' },
  heating: { label: 'Heating', icon: Thermometer, group: 'Comfort' },
  washer: { label: 'Washing machine', icon: WashingMachine, group: 'Comfort' },
  luggage: { label: 'Luggage storage', icon: Briefcase, group: 'Comfort' },
  elevator: { label: 'Lift', icon: ArrowUpDown, group: 'Comfort' },
  parking: { label: 'Parking', icon: Car, group: 'Comfort' },
  crib: { label: 'Travel cot', icon: Baby, group: 'Family' },
  high_chair: { label: 'High chair', icon: Armchair, group: 'Family' },
  toys: { label: 'Toys & games', icon: ToyBrick, group: 'Family' },
  baby_bath: { label: 'Baby bath', icon: Bath, group: 'Family' },
};

export const ACTIVITIES: Record<Activity, { label: string; verb: string; icon: LucideIcon; tint: string }> = {
  rest: { label: 'Rest & nap', verb: 'Take a nap', icon: Moon, tint: 'bg-ice-200 text-ink' },
  work: { label: 'Remote work', verb: 'Work in quiet', icon: Laptop, tint: 'bg-electric-100 text-electric-600' },
  meeting: { label: 'Meetings', verb: 'Hold a meeting', icon: Users, tint: 'bg-ice-100 text-ink-600' },
  party: { label: 'Small gatherings', verb: 'Host friends', icon: PartyPopper, tint: 'bg-electric-100 text-electric-600' },
  bbq: { label: 'Barbecue', verb: 'Have a barbecue', icon: Flame, tint: 'bg-electric-100 text-electric-600' },
  cooking: { label: 'Cooking & baking', verb: 'Cook or bake', icon: ChefHat, tint: 'bg-electric-50 text-electric-600' },
  creative: { label: 'Creative projects', verb: 'Create', icon: Palette, tint: 'bg-ice-200 text-ink-700' },
  rehearsal: { label: 'Rehearsal', verb: 'Rehearse', icon: Music, tint: 'bg-electric-100 text-ink-700' },
  family: { label: 'Family time', verb: 'Bring the kids', icon: Baby, tint: 'bg-electric-50 text-electric-600' },
  relax: { label: 'Relax', verb: 'Unwind', icon: Leaf, tint: 'bg-ice-100 text-ink-600' },
  layover: { label: 'Between journeys', verb: 'Refresh between trains', icon: Luggage, tint: 'bg-electric-100 text-electric-600' },
  photo: { label: 'Photo & video', verb: 'Shoot content', icon: Camera, tint: 'bg-ice-200 text-ink' },
  wellness: { label: 'Wellness', verb: 'Recharge', icon: Sparkles, tint: 'bg-ice-100 text-ink-600' },
};

export const ACCESSIBILITY: Record<Accessibility, { label: string; icon: LucideIcon }> = {
  step_free: { label: 'Step-free entrance', icon: AccessIcon },
  elevator: { label: 'Lift access', icon: ArrowUpDown },
  wide_doors: { label: 'Wide doorways (80cm+)', icon: DoorOpen },
  accessible_bathroom: { label: 'Accessible bathroom', icon: Bath },
  ground_floor: { label: 'Ground floor', icon: Layers },
  low_sensory: { label: 'Quiet, low-sensory', icon: EarOff },
};

export const PROPERTY_TYPES: Record<PropertyType, { label: string; icon: LucideIcon }> = {
  apartment: { label: 'Apartment', icon: Building2 },
  studio: { label: 'Studio', icon: Grid2x2 },
  loft: { label: 'Loft', icon: Building },
  house: { label: 'House', icon: House },
  room: { label: 'Private room', icon: Home },
  serviced: { label: 'Serviced apartment', icon: ConciergeBell },
  aparthotel: { label: 'Aparthotel', icon: Hotel },
};

export const CANCELLATION = {
  label: 'Free cancellation up to 2 hours before',
  detail: 'Cancel for free until 2 hours before your start time. After that, the full booking amount is due.',
};

/** Discover taxonomy: purpose-first groups. */
export const PURPOSE_GROUPS: { id: string; title: string; items: { id: string; label: string; activity: Activity; need?: Amenity }[] }[] = [
  { id: 'rest', title: 'Rest & Recharge', items: [
    { id: 'nap', label: 'Take a nap', activity: 'rest', need: 'bed' },
    { id: 'shower', label: 'Shower between journeys', activity: 'layover', need: 'shower' },
    { id: 'family-stop', label: 'Family stopovers', activity: 'family' },
    { id: 'pre-checkin', label: 'Relax before check-in', activity: 'relax' },
  ] },
  { id: 'work', title: 'Work & Focus', items: [
    { id: 'remote', label: 'Remote work', activity: 'work', need: 'desk' },
    { id: 'meetings', label: 'Private meetings', activity: 'meeting' },
    { id: 'quiet', label: 'Quiet workspaces', activity: 'work' },
    { id: 'calls', label: 'Video-call friendly', activity: 'work', need: 'wifi' },
  ] },
  { id: 'create', title: 'Create & Gather', items: [
    { id: 'cook', label: 'Cooking & baking', activity: 'cooking', need: 'kitchen' },
    { id: 'creative', label: 'Creative activities', activity: 'creative' },
    { id: 'rehearse', label: 'Rehearsals', activity: 'rehearsal' },
    { id: 'gather', label: 'Permitted gatherings', activity: 'party' },
  ] },
];
