import type { ServerResponse } from 'node:http';

/** Server-Sent Events hub: every connected device gets pushed a lightweight "something changed" signal. */
const clients = new Map<string, Set<ServerResponse>>();

export function addClient(userId: string, res: ServerResponse) {
  if (!clients.has(userId)) clients.set(userId, new Set());
  clients.get(userId)!.add(res);
  res.on('close', () => clients.get(userId)?.delete(res));
}

function send(res: ServerResponse, payload: unknown) {
  try {
    res.write(`data: ${JSON.stringify(payload)}\n\n`);
  } catch {
    /* connection gone */
  }
}

export function pushTo(userIds: (string | null | undefined)[], payload: Record<string, unknown>) {
  for (const id of new Set(userIds.filter(Boolean) as string[])) for (const res of clients.get(id) ?? []) send(res, payload);
}

/** Catalogue changes (new listing, slot approved, booking made) must reach every guest device. */
export function broadcast(payload: Record<string, unknown>) {
  for (const set of clients.values()) for (const res of set) send(res, payload);
}

setInterval(() => broadcast({ type: 'ping', at: Date.now() }), 25000).unref();
