import { all, one, run, tx, uid } from './db.ts';
import * as R from './repo.ts';
import type { UserRecord } from './repo.ts';
import { pushTo, broadcast } from './realtime.ts';
import { sendEmail, emailLayout } from './email.ts';
import type { Booking, CleaningTask, Conversation, Message, Property, Role, User } from '../shared/types.ts';
import { buildSchedule, daySchedule, fitsFree, type ScheduleInput } from '../shared/schedule.ts';
import { addDays, isoDate, minutesOf, parseISO, toHHMM, toMin } from '../shared/time.ts';
import { calcEconomics, cancellationFee, RATES } from '../shared/economics.ts';

export class HttpError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string, message?: string) {
    super(message ?? code);
    this.status = status;
    this.code = code;
  }
}

export const now = () => new Date();
export const todayISO = () => isoDate(now());
export const nowMin = () => minutesOf(now());
export const CATALOG_DAYS = 14;
const L = (u: { lang?: string } | undefined, en: string, fr: string) => (u?.lang === 'fr' ? fr : en);
export const Lu = (userId: string | null | undefined, en: string, fr: string) => L(userId ? R.getUser(userId) : undefined, en, fr);
const eur = (n: number, lang = 'en') => new Intl.NumberFormat(lang === 'fr' ? 'fr-FR' : 'en-IE', { style: 'currency', currency: 'EUR' }).format(n);
const fmtDate = (iso: string, lang = 'en') => parseISO(iso).toLocaleDateString(lang === 'fr' ? 'fr-FR' : 'en-GB', { weekday: 'long', day: 'numeric', month: 'long' });

// ------------------------------------------------------------------ schedule & catalogue
export function scheduleInput(p: Property): ScheduleInput {
  return { property: p, slots: R.slotsFor(p.id), blocks: R.blocksFor(p.id), stays: R.staysFor(p.id), bookings: R.activeBookingsFor(p.id) };
}

/** Attach live Space Partner (manager) details from the users table. */
export function hydrate(p: Property): Property {
  const m = p.managerId ? R.getUser(p.managerId) : undefined;
  const o = R.getUser(p.ownerId);
  return {
    ...p,
    ownerName: o?.name, managerName: m?.name, managerCompany: m?.company,
    partner: m ? { ...p.partner, name: m.name, company: m.company, avatar: m.avatarUrl, since: m.memberSince } : p.partner,
  };
}

export function withSchedule(p: Property): Property {
  return { ...hydrate(p), schedule: buildSchedule(scheduleInput(p), todayISO(), CATALOG_DAYS, nowMin()) };
}

/** Guest-facing projection: no compliance documents, owner envelope, delegation or exact address. */
export function publicListing(p: Property): Property {
  const x = withSchedule(p);
  return {
    ...x,
    address: '',
    compliance: { ...x.compliance, documents: [], registrationNumber: x.compliance.registrationNumber ? x.compliance.registrationNumber.replace(/\d(?=\d{2})/g, '•') : '', insurancePolicy: '', changeOfUseRef: '', buildingNotes: '' },
    delegation: { ...x.delegation, priceFloor: 0 },
  };
}

export function catalog() {
  return R.propertiesWhere("status = 'published'").map(publicListing);
}

// ------------------------------------------------------------------ notifications
export function notify(userId: string | null | undefined, kind: string, text: string, link: string) {
  if (!userId) return;
  R.saveNotification({ id: uid('nt'), userId, kind, text, link, at: Date.now(), read: false });
  pushTo([userId], { type: 'notification', kind, text, link });
}
export function changed(userIds: (string | null | undefined)[], scope: string) {
  pushTo(userIds, { type: 'changed', scope });
}

// ------------------------------------------------------------------ permissions
export function managerProperty(user: User, id: string): Property {
  const p = R.getProperty(id);
  if (!p) throw new HttpError(404, 'not_found');
  if (user.role !== 'manager' || p.managerId !== user.id) throw new HttpError(403, 'not_assigned', 'This property is not assigned to you.');
  return p;
}
export function ownerProperty(user: User, id: string): Property {
  const p = R.getProperty(id);
  if (!p) throw new HttpError(404, 'not_found');
  if (user.role !== 'owner' || p.ownerId !== user.id) throw new HttpError(403, 'not_owner');
  return p;
}
export function requireDelegation(p: Property, key: 'availability' | 'pricing' | 'approveBookings' | 'cleaning' | 'messaging') {
  if (!p.delegation[key]) throw new HttpError(403, 'not_delegated', `The owner has not delegated "${key}" for this property.`);
}

// ------------------------------------------------------------------ bookings
export interface BookingRequest {
  propertyId: string;
  dates: string[];
  start: string;
  hours: number;
  guests: Booking['guests'];
  purpose?: Booking['purpose'];
  note?: string;
  recurring?: Booking['recurring'];
}

/**
 * Atomic booking creation. All availability checks and inserts happen inside one IMMEDIATE
 * transaction, so two devices booking the same slot at the same moment cannot both succeed.
 */
export function createBookings(guest: UserRecord, req: BookingRequest): Booking[] {
  if (guest.role !== 'guest') throw new HttpError(403, 'guests_only');
  const created = tx(() => {
    const p = R.getProperty(req.propertyId);
    if (!p || p.status !== 'published') throw new HttpError(404, 'not_bookable');
    const hours = Number(req.hours);
    if (!(hours >= p.minHours && hours <= p.maxHours)) throw new HttpError(400, 'bad_duration');
    const g = req.guests;
    if (g.adults < 1 || g.adults + g.children > p.capacity.guests) throw new HttpError(400, 'over_capacity');
    if ((g.children || g.infants) && !p.childrenAllowed) throw new HttpError(400, 'no_children');
    if (g.pets && !p.petsAllowed) throw new HttpError(400, 'no_pets');
    if (req.purpose && !p.activities.includes(req.purpose)) throw new HttpError(400, 'activity_not_permitted');
    const s = toMin(req.start);
    const e = s + hours * 60;
    const input = scheduleInput(p);
    const today = todayISO();
    const dates = [...new Set(req.dates)].slice(0, 12);
    const ok = dates.filter((d) => d >= today && fitsFree(daySchedule(input, d, today, nowMin()), s, e));
    if (!ok.length) throw new HttpError(409, 'slot_unavailable', 'That time is no longer available.');
    const price = calcEconomics(p, hours, ok.length);
    const seriesId = ok.length > 1 ? uid('ser') : undefined;
    const status = p.instantBook ? 'confirmed' : 'pending';
    const ts = Date.now();
    return ok.map((date) => {
      const b: Booking = {
        id: uid('bk'), propertyId: p.id, guestId: guest.id, guestName: guest.name, guestAvatar: guest.avatarUrl,
        date, start: toHHMM(s), end: toHHMM(e), hours, guests: g, purpose: req.purpose, note: req.note?.slice(0, 500),
        price: { ...price, occurrences: ok.length }, accessCode: String(Math.floor(100000 + Math.random() * 899999)),
        status, opsStatus: 'awaiting', createdAt: ts, updatedAt: ts, seriesId, recurring: ok.length > 1 ? req.recurring ?? null : null,
      };
      R.saveBooking(b);
      return b;
    });
  });
  const p = R.getProperty(req.propertyId)!;
  afterBookingCreated(created, p, guest);
  return created;
}

function afterBookingCreated(list: Booking[], p: Property, guest: UserRecord) {
  const b = list[0];
  const manager = p.managerId ? R.getUser(p.managerId) : undefined;
  const owner = R.getUser(p.ownerId);
  const conv = getOrCreateConversation('guest', p.id, guest.id, b.id);
  const when = `${b.date} ${b.start}–${b.end}${list.length > 1 ? ` (×${list.length})` : ''}`;
  postSystem(conv.id, b.status === 'confirmed' ? `Booking confirmed · ${p.shortTitle} · ${when}` : `Booking request · ${p.shortTitle} · ${when} — awaiting approval`);
  if (b.note) postMessage(conv.id, guest, b.note);
  if (b.status === 'confirmed') for (const x of list) onConfirmed(x, p);
  notify(manager?.id, b.status === 'confirmed' ? 'booking_new' : 'booking_request',
    L(manager, `${b.status === 'confirmed' ? 'New booking' : 'Booking request'}: ${guest.name} · ${p.shortTitle} · ${when}`, `${b.status === 'confirmed' ? 'Nouvelle réservation' : 'Demande de réservation'} : ${guest.name} · ${p.shortTitle} · ${when}`),
    `/manager/booking/${b.id}`);
  if (b.status === 'confirmed') notify(owner?.id, 'booking_new', L(owner, `New booking at ${p.shortTitle} · ${when} · ${eur(b.price.ownerProceeds * list.length)} est. proceeds`, `Nouvelle réservation à ${p.shortTitle} · ${when} · ${eur(b.price.ownerProceeds * list.length, 'fr')} de revenus estimés`), `/owner/property/${p.id}`);
  void bookingEmails(list, p, guest, manager, owner);
  changed([guest.id, manager?.id, owner?.id], 'bookings');
  broadcast({ type: 'changed', scope: 'catalog' });
}

/** Side effects once a booking is confirmed: cleaning task. */
function onConfirmed(b: Booking, p: Property) {
  if (!R.taskForBooking(b.id)) {
    const t: CleaningTask = {
      id: uid('cl'), bookingId: b.id, propertyId: p.id, providerId: p.cleaningProviderId, date: b.date,
      start: b.end, deadline: toHHMM(toMin(b.end) + p.bufferMins), durationMins: Math.max(30, p.bufferMins - 15),
      status: p.cleaningProviderId ? 'scheduled' : 'unassigned', notes: '', updatedAt: Date.now(),
    };
    R.saveTask(t);
  }
}

async function bookingEmails(list: Booking[], p: Property, guest: UserRecord, manager?: UserRecord, owner?: UserRecord) {
  const b = list[0];
  const n = list.length;
  const confirmed = b.status === 'confirmed';
  const rows = (pairs: [string, string][]) => `<table style="width:100%;border-collapse:collapse">${pairs.map(([k, v]) => `<tr><td style="padding:4px 0;color:#5C6690">${k}</td><td style="padding:4px 0;text-align:right;font-weight:600">${v}</td></tr>`).join('')}</table>`;
  const gl = guest.lang;
  await sendEmail(guest.id, guest.email,
    L(guest, confirmed ? `Your SpaceTime booking is confirmed — ${p.shortTitle}` : `Booking request sent — ${p.shortTitle}`, confirmed ? `Votre réservation SpaceTime est confirmée — ${p.shortTitle}` : `Demande envoyée — ${p.shortTitle}`),
    emailLayout(L(guest, confirmed ? 'Booking confirmed' : 'Request received', confirmed ? 'Réservation confirmée' : 'Demande reçue'),
      rows([[L(guest, 'Space', 'Espace'), p.title], [L(guest, 'When', 'Quand'), `${fmtDate(b.date, gl)}, ${b.start}–${b.end}${n > 1 ? ` (×${n})` : ''}`], [L(guest, 'Total', 'Total'), eur(b.price.grandTotal, gl)], ...(confirmed ? [[L(guest, 'Address', 'Adresse'), p.address] as [string, string], [L(guest, 'Door code', "Code d'accès"), b.accessCode] as [string, string]] : [])]) +
      `<p>${L(guest, 'Free cancellation until 2 hours before your start time.', "Annulation gratuite jusqu'à 2 heures avant le début.")}</p>`));
  if (manager) await sendEmail(manager.id, manager.email, L(manager, `New ${confirmed ? 'booking' : 'request'}: ${p.shortTitle} · ${b.date} ${b.start}`, `Nouvelle ${confirmed ? 'réservation' : 'demande'} : ${p.shortTitle} · ${b.date} ${b.start}`),
    emailLayout(L(manager, 'New daytime booking', 'Nouvelle réservation en journée'), rows([[L(manager, 'Guest', 'Voyageur'), guest.name], [L(manager, 'When', 'Quand'), `${b.date} ${b.start}–${b.end}`], [L(manager, 'Guests', 'Personnes'), String(b.guests.adults + b.guests.children)], [L(manager, 'Gross booking value', 'Valeur brute'), eur(b.price.gross * n, manager.lang)], [L(manager, 'Cleaning', 'Ménage'), `${b.end} → ${toHHMM(toMin(b.end) + p.bufferMins)}`]])));
  if (owner && confirmed) await sendEmail(owner.id, owner.email, L(owner, `Booking & revenue update — ${p.shortTitle}`, `Réservation et revenus — ${p.shortTitle}`),
    emailLayout(L(owner, 'A daytime booking was confirmed', 'Une réservation en journée est confirmée'), rows([[L(owner, 'When', 'Quand'), `${b.date} ${b.start}–${b.end}${n > 1 ? ` ×${n}` : ''}`], [L(owner, 'Gross booking value', 'Valeur brute'), eur(b.price.gross * n, owner.lang)], [L(owner, `SpaceTime platform fee (${RATES.commissionPct}%)`, `Frais de plateforme SpaceTime (${RATES.commissionPct} %)`), `−${eur(b.price.commission * n, owner.lang)}`], [L(owner, 'Management fee', 'Frais de gestion'), `−${eur(b.price.mgmtFee * n, owner.lang)}`], [L(owner, 'Estimated owner proceeds', 'Revenus propriétaire estimés'), eur(b.price.ownerProceeds * n, owner.lang)]])));
}

export function decideBooking(manager: User, bookingId: string, decision: 'approve' | 'decline') {
  const b = R.getBooking(bookingId);
  if (!b) throw new HttpError(404, 'not_found');
  const p = managerProperty(manager, b.propertyId);
  requireDelegation(p, 'approveBookings');
  if (b.status !== 'pending') throw new HttpError(409, 'not_pending');
  const series = b.seriesId ? R.bookingsWhere("json_extract(data,'$.seriesId') = ? AND status = 'pending'", b.seriesId) : [b];
  for (const x of series) {
    x.status = decision === 'approve' ? 'confirmed' : 'declined';
    x.updatedAt = Date.now();
    R.saveBooking(x);
    if (x.status === 'confirmed') onConfirmed(x, p);
  }
  const guest = R.getUser(b.guestId);
  const conv = getOrCreateConversation('guest', p.id, b.guestId, b.id);
  postSystem(conv.id, decision === 'approve' ? `Booking approved by ${manager.name} · ${b.date} ${b.start}–${b.end}` : `Booking request declined · ${b.date} ${b.start}–${b.end}`);
  notify(guest?.id, 'booking_status', L(guest, decision === 'approve' ? `Your booking at ${p.shortTitle} is confirmed` : `Your request for ${p.shortTitle} was declined`, decision === 'approve' ? `Votre réservation à ${p.shortTitle} est confirmée` : `Votre demande pour ${p.shortTitle} a été refusée`), `/confirmed/${b.id}`);
  if (decision === 'approve') {
    const owner = R.getUser(p.ownerId);
    notify(owner?.id, 'booking_new', L(owner, `Booking confirmed at ${p.shortTitle} · ${b.date} ${b.start}`, `Réservation confirmée à ${p.shortTitle} · ${b.date} ${b.start}`), `/owner/property/${p.id}`);
  }
  changed([b.guestId, manager.id, p.ownerId], 'bookings');
  broadcast({ type: 'changed', scope: 'catalog' });
  return R.getBooking(bookingId)!;
}

export function cancelBooking(user: User, bookingId: string) {
  const b = R.getBooking(bookingId);
  if (!b) throw new HttpError(404, 'not_found');
  const p = R.getProperty(b.propertyId)!;
  const isGuest = user.role === 'guest' && b.guestId === user.id;
  const isManager = user.role === 'manager' && p.managerId === user.id;
  if (!isGuest && !isManager) throw new HttpError(403, 'forbidden');
  if (b.status !== 'confirmed' && b.status !== 'pending') throw new HttpError(409, 'not_active');
  const startAt = parseISO(b.date);
  startAt.setMinutes(toMin(b.start));
  b.cancelFee = isGuest && b.status === 'confirmed' ? cancellationFee(b.price.guestTotal, startAt, now()) : 0;
  b.status = 'cancelled';
  b.updatedAt = Date.now();
  R.saveBooking(b);
  const t = R.taskForBooking(b.id);
  if (t && t.status !== 'completed') run('DELETE FROM tasks WHERE id = ?', t.id);
  const conv = getOrCreateConversation('guest', p.id, b.guestId, b.id);
  postSystem(conv.id, `Booking cancelled by ${isGuest ? 'guest' : 'manager'} · ${b.date} ${b.start}–${b.end}${b.cancelFee ? ` · late cancellation, ${eur(b.cancelFee)} due` : ' · no charge'}`);
  notify(isGuest ? p.managerId : b.guestId, 'booking_cancelled', Lu(isGuest ? p.managerId : b.guestId, `${p.shortTitle}: booking ${b.date} ${b.start} cancelled`, `${p.shortTitle} : réservation du ${b.date} ${b.start} annulée`), isGuest ? `/manager/booking/${b.id}` : `/bookings`);
  changed([b.guestId, p.managerId, p.ownerId], 'bookings');
  broadcast({ type: 'changed', scope: 'catalog' });
  return b;
}

export function bookingForGuest(b: Booking) {
  const p = R.getProperty(b.propertyId);
  const showAddress = b.status === 'confirmed' || b.status === 'completed';
  return { ...b, status: effectiveStatus(b), property: p ? { ...hydrate(p), address: showAddress ? p.address : '', compliance: undefined, delegation: undefined } : null };
}

export function effectiveStatus(b: Booking): Booking['status'] {
  if (b.status === 'confirmed') {
    const end = parseISO(b.date);
    end.setMinutes(toMin(b.end));
    if (end < now()) return 'completed';
  }
  return b.status;
}

// ------------------------------------------------------------------ cleaning
export function taskView(t: CleaningTask, all: CleaningTask[]) {
  const p = R.getProperty(t.propertyId);
  const b = R.getBooking(t.bookingId);
  const provider = t.providerId ? R.getProvider(t.providerId) : null;
  const conflicts: string[] = [];
  const window = toMin(t.deadline) - toMin(t.start);
  if (window < t.durationMins) conflicts.push('buffer_too_short');
  // next arrival on the same day
  if (p) {
    const next = R.bookingsWhere("property_id = ? AND date = ? AND status IN ('pending','confirmed') AND start_min >= ?", p.id, t.date, toMin(t.start)).find((x) => x.id !== t.bookingId);
    if (next && toMin(next.start) < toMin(t.start) + t.durationMins) conflicts.push('next_arrival_too_soon');
    const stay = R.staysFor(p.id).find((s) => s.checkinDate === t.date);
    if (stay && toMin(p.overnight.checkin) < toMin(t.start) + t.durationMins) conflicts.push('overnight_checkin_too_soon');
  }
  if (provider) {
    const s = toMin(t.start);
    const e = s + t.durationMins;
    if (s < toMin(provider.workStart) || e > toMin(provider.workEnd)) conflicts.push('outside_provider_hours');
    if (all.some((o) => o.id !== t.id && o.providerId === t.providerId && o.date === t.date && o.status !== 'completed' && toMin(o.start) < e && s < toMin(o.start) + o.durationMins)) conflicts.push('provider_double_booked');
  } else if (t.status !== 'completed') conflicts.push('unassigned');
  return { ...t, property: p ? { id: p.id, shortTitle: p.shortTitle, images: p.images.slice(0, 1), neighbourhood: p.neighbourhood } : null, booking: b ? { id: b.id, guestName: b.guestName, start: b.start, end: b.end, status: effectiveStatus(b) } : null, provider, conflicts };
}

// ------------------------------------------------------------------ messaging
export function getOrCreateConversation(kind: 'guest' | 'owner', propertyId: string, guestId: string | null, bookingId?: string) {
  const ex = kind === 'guest'
    ? one('SELECT id FROM conversations WHERE kind = ? AND property_id = ? AND guest_id = ?', kind, propertyId, guestId)
    : one('SELECT id FROM conversations WHERE kind = ? AND property_id = ?', kind, propertyId);
  if (ex) {
    if (bookingId) run('UPDATE conversations SET booking_id = ? WHERE id = ?', bookingId, ex.id);
    return { id: ex.id as string };
  }
  const id = uid('cv');
  run('INSERT INTO conversations (id, kind, property_id, guest_id, booking_id, created_at) VALUES (?, ?, ?, ?, ?, ?)', id, kind, propertyId, guestId, bookingId ?? null, Date.now());
  return { id };
}

type ConvRow = { id: string; kind: 'guest' | 'owner'; property_id: string; guest_id: string | null; booking_id: string | null };

export function participants(c: ConvRow): string[] {
  const p = R.getProperty(c.property_id);
  if (!p) return [];
  return c.kind === 'guest' ? [c.guest_id!, p.managerId!].filter(Boolean) : [p.ownerId, p.managerId!].filter(Boolean);
}

export function canAccessConversation(user: User, c: ConvRow) {
  const p = R.getProperty(c.property_id);
  if (!p) return false;
  if (c.kind === 'guest') return (user.role === 'guest' && c.guest_id === user.id) || (user.role === 'manager' && p.managerId === user.id);
  return (user.role === 'owner' && p.ownerId === user.id) || (user.role === 'manager' && p.managerId === user.id);
}

export function getConv(id: string) {
  return one('SELECT * FROM conversations WHERE id = ?', id) as unknown as ConvRow | undefined;
}

export function postMessage(convId: string, sender: User, body: string): Message {
  const m: Message = { id: uid('m'), conversationId: convId, senderId: sender.id, senderRole: sender.role, senderName: sender.name, body: body.slice(0, 2000), at: Date.now() };
  run('INSERT INTO messages (id, conversation_id, sender_id, sender_role, body, created_at) VALUES (?, ?, ?, ?, ?, ?)', m.id, convId, m.senderId, m.senderRole, m.body, m.at);
  run('INSERT OR REPLACE INTO reads (conversation_id, user_id, at) VALUES (?, ?, ?)', convId, sender.id, m.at);
  const c = getConv(convId)!;
  const others = participants(c).filter((x) => x !== sender.id);
  for (const o of others) {
    const u = R.getUser(o);
    const link = u?.role === 'guest' ? `/messages/${convId}` : u?.role === 'owner' ? `/owner/messages/${convId}` : `/manager/messages/${convId}`;
    pushTo([o], { type: 'message', conversationId: convId, text: `${sender.name}: ${m.body.slice(0, 80)}`, link });
  }
  changed(others, 'messages');
  return m;
}

export function postSystem(convId: string, body: string) {
  const ts = Date.now();
  run('INSERT INTO messages (id, conversation_id, sender_id, sender_role, body, created_at) VALUES (?, ?, ?, ?, ?, ?)', uid('m'), convId, 'system', 'system', body, ts);
  const c = getConv(convId);
  if (c) changed(participants(c), 'messages');
}

export function listConversations(user: User): Conversation[] {
  let rows: ConvRow[] = [];
  if (user.role === 'guest') rows = all("SELECT * FROM conversations WHERE kind = 'guest' AND guest_id = ?", user.id) as unknown as ConvRow[];
  else if (user.role === 'manager') rows = all('SELECT c.* FROM conversations c JOIN properties p ON p.id = c.property_id WHERE p.manager_id = ?', user.id) as unknown as ConvRow[];
  else if (user.role === 'owner') rows = all("SELECT c.* FROM conversations c JOIN properties p ON p.id = c.property_id WHERE c.kind = 'owner' AND p.owner_id = ?", user.id) as unknown as ConvRow[];
  const out: Conversation[] = rows.map((c) => {
    const p = R.getProperty(c.property_id)!;
    const lastRow = one('SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at DESC LIMIT 1', c.id);
    const read = one('SELECT at FROM reads WHERE conversation_id = ? AND user_id = ?', c.id, user.id);
    const unread = (one('SELECT COUNT(*) n FROM messages WHERE conversation_id = ? AND created_at > ? AND sender_id != ?', c.id, (read?.at as number) ?? 0, user.id)?.n as number) ?? 0;
    let counterpart: UserRecord | undefined;
    if (user.role === 'guest') counterpart = p.managerId ? R.getUser(p.managerId) : undefined;
    else if (user.role === 'owner') counterpart = p.managerId ? R.getUser(p.managerId) : undefined;
    else counterpart = c.kind === 'guest' ? R.getUser(c.guest_id!) : R.getUser(p.ownerId);
    return {
      id: c.id, kind: c.kind, propertyId: p.id, guestId: c.guest_id, bookingId: c.booking_id,
      title: counterpart?.name ?? '—', subtitle: p.shortTitle, counterpartAvatar: counterpart?.avatarUrl,
      last: lastRow ? rowToMessage(lastRow) : undefined, unread,
    };
  });
  return out.sort((a, b) => (b.last?.at ?? 0) - (a.last?.at ?? 0));
}

export function rowToMessage(r: Record<string, unknown>): Message {
  const sender = r.sender_id === 'system' ? undefined : R.getUser(r.sender_id as string);
  return { id: r.id as string, conversationId: r.conversation_id as string, senderId: r.sender_id as string, senderRole: r.sender_role as Role | 'system', senderName: sender?.name, body: r.body as string, at: r.created_at as number };
}

// ------------------------------------------------------------------ dashboards
const monthKey = (iso: string) => iso.slice(0, 7);

export function managerOverview(user: User) {
  const props = R.propertiesWhere('manager_id = ?', user.id).map(withSchedule);
  const ids = props.map((p) => p.id);
  const today = todayISO();
  const bookings = ids.length ? R.bookingsWhere(`property_id IN (${ids.map(() => '?').join(',')})`, ...ids).map((b) => ({ ...b, status: effectiveStatus(b) })) : [];
  const tasks = R.tasksForProperties(ids);
  const upcoming = bookings.filter((b) => (b.status === 'confirmed' || b.status === 'pending') && b.date >= today);
  const freeHours7 = props.reduce((s, p) => s + Object.entries(p.schedule ?? {}).filter(([d]) => d < addDays(today, 7)).reduce((x, [, day]) => x + day.free.reduce((y, [a, b]) => y + (b - a) / 60, 0), 0), 0);
  const month = monthKey(today);
  const monthBookings = bookings.filter((b) => monthKey(b.date) === month && (b.status === 'confirmed' || b.status === 'completed'));
  const sum = (k: 'gross' | 'mgmtFee' | 'ownerProceeds' | 'commission') => monthBookings.reduce((s, b) => s + b.price[k], 0);
  const taskViews = tasks.map((t) => taskView(t, tasks));
  const openTasks = taskViews.filter((t) => t.status !== 'completed' && t.date >= today);
  const alerts: { kind: string; text: string; link: string; severity: 'high' | 'medium' | 'info' }[] = [];
  for (const t of openTasks) for (const c of t.conflicts) alerts.push({ kind: 'cleaning', text: `${c}|${t.property?.shortTitle}|${t.date} ${t.start}`, link: '/manager/cleaning', severity: c === 'unassigned' ? 'medium' : 'high' });
  for (const b of upcoming.filter((x) => x.status === 'pending')) alerts.push({ kind: 'pending', text: `pending|${props.find((p) => p.id === b.propertyId)?.shortTitle}|${b.date} ${b.start}`, link: `/manager/booking/${b.id}`, severity: 'high' });
  for (const p of props) {
    const missing = readinessGaps(p);
    if (missing.length) alerts.push({ kind: 'readiness', text: `readiness|${p.shortTitle}|${missing.join(',')}`, link: `/manager/property/${p.id}`, severity: 'medium' });
    if (p.status === 'published' && !p.availability.length && !R.slotsFor(p.id).some((s) => s.date >= today)) alerts.push({ kind: 'opportunity', text: `no_availability|${p.shortTitle}|`, link: `/manager/property/${p.id}?tab=smart`, severity: 'info' });
  }
  const unreadMsgs = listConversations(user).reduce((s, c) => s + c.unread, 0);
  if (unreadMsgs) alerts.push({ kind: 'messages', text: `messages|${unreadMsgs}|`, link: '/manager/messages', severity: 'info' });
  const newAssignments = props.filter((p) => R.slotsFor(p.id).length === 0 && !p.availability.length);
  return {
    period: { month, basis: 'scheduled_date' as const },
    metrics: {
      properties: props.length, active: props.filter((p) => p.status === 'published').length,
      upcoming: upcoming.length, pending: upcoming.filter((b) => b.status === 'pending').length,
      freeHours7: Math.round(freeHours7), openTasks: openTasks.length,
      monthGross: Math.round(sum('gross') * 100) / 100, monthMgmtFee: Math.round(sum('mgmtFee') * 100) / 100, monthOwner: Math.round(sum('ownerProceeds') * 100) / 100,
    },
    upcoming: upcoming.slice(0, 12).map((b) => ({ ...b, property: { id: b.propertyId, shortTitle: props.find((p) => p.id === b.propertyId)?.shortTitle, image: props.find((p) => p.id === b.propertyId)?.images[0] }, cleaning: taskViews.find((t) => t.bookingId === b.id) ?? null })),
    alerts,
    newAssignments: newAssignments.map((p) => ({ id: p.id, shortTitle: p.shortTitle, ownerName: p.ownerName, image: p.images[0], status: p.status })),
    properties: props.map((p) => ({
      ...p,
      stats: {
        upcoming: upcoming.filter((b) => b.propertyId === p.id).length,
        monthGross: Math.round(monthBookings.filter((b) => b.propertyId === p.id).reduce((s, b) => s + b.price.gross, 0) * 100) / 100,
        freeHours7: Math.round(Object.entries(p.schedule ?? {}).filter(([d]) => d < addDays(today, 7)).reduce((x, [, day]) => x + day.free.reduce((y, [a, b]) => y + (b - a) / 60, 0), 0)),
        openTasks: openTasks.filter((t) => t.propertyId === p.id).length,
        readiness: readinessGaps(p),
      },
    })),
  };
}

export function readinessGaps(p: Property) {
  const gaps: string[] = [];
  if (p.images.length < 3) gaps.push('photos');
  if (!p.checkinInstructions) gaps.push('checkin');
  if (!p.cleaningProviderId) gaps.push('cleaner');
  if (!p.rules.length) gaps.push('rules');
  return gaps;
}

export type OwnerPeriod = 'this_month' | 'last_month' | 'all';
const prevMonth = (ym: string) => { const [y, m] = ym.split('-').map(Number); return m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, '0')}`; };
type Priced = Pick<Booking, 'price'>;
/** Sums booking economics. Same per-booking figures the guest, manager and owner see — never recomputed. */
function sumEconomics(list: Priced[]) {
  const t = (k: 'gross' | 'commission' | 'guestFee' | 'cleaning' | 'mgmtFee' | 'ownerProceeds') => Math.round(list.reduce((s, b) => s + b.price[k], 0) * 100) / 100;
  const pcts = [...new Set(list.map((b) => b.price.mgmtFeePct))];
  return { gross: t('gross'), commission: t('commission'), guestFees: t('guestFee'), cleaning: t('cleaning'), mgmtFee: t('mgmtFee'), ownerProceeds: t('ownerProceeds'), bookings: list.length, mgmtFeePct: pcts.length === 1 ? pcts[0] : null };
}

/**
 * Owner dashboard. Financial totals cover confirmed + completed bookings whose *scheduled date* falls in the
 * selected period (this month / last month / all time). Pending requests are reported separately and never
 * counted in proceeds; declined and cancelled bookings are excluded.
 */
export function ownerOverview(user: User, period: OwnerPeriod = 'this_month') {
  const props = R.propertiesWhere('owner_id = ?', user.id).map(withSchedule);
  const ids = props.map((p) => p.id);
  const bookings = ids.length ? R.bookingsWhere(`property_id IN (${ids.map(() => '?').join(',')})`, ...ids).map((b) => ({ ...b, status: effectiveStatus(b) })) : [];
  const today = todayISO();
  const thisMonth = monthKey(today);
  const month = period === 'this_month' ? thisMonth : period === 'last_month' ? prevMonth(thisMonth) : null;
  const inPeriod = (b: Booking) => !month || monthKey(b.date) === month;
  const isCounted = (b: Booking) => b.status === 'confirmed' || b.status === 'completed';
  const counted = bookings.filter((b) => isCounted(b) && inPeriod(b));
  const pending = bookings.filter((b) => b.status === 'pending' && inPeriod(b));
  // Comparison only when the previous month actually has bookings to compare with.
  const compareMonth = month ? prevMonth(month) : null;
  const compareList = compareMonth ? bookings.filter((b) => isCounted(b) && monthKey(b.date) === compareMonth) : [];
  const occ = props.map((p) => {
    let open = 0;
    let booked = 0;
    for (const [d, day] of Object.entries(p.schedule ?? {})) {
      if (d < today) continue;
      open += day.open.reduce((s, [a, b]) => s + (b - a), 0);
      booked += day.booked.reduce((s, [a, b]) => s + (b - a), 0);
    }
    return { id: p.id, openHours: Math.round(open / 60), bookedHours: Math.round(booked / 60), occupancy: open ? Math.round((booked / open) * 100) : 0 };
  });
  const allCounted = bookings.filter(isCounted);
  const managers = [...new Set(props.map((p) => p.managerId).filter(Boolean) as string[])].map((mid) => {
    const m = R.getUser(mid)!;
    const mProps = props.filter((p) => p.managerId === mid);
    const mBookings = allCounted.filter((b) => mProps.some((p) => p.id === b.propertyId));
    const tasks = R.tasksForProperties(mProps.map((p) => p.id));
    const done = tasks.filter((t) => t.status === 'completed').length;
    const slots = mProps.reduce((s, p) => s + R.slotsFor(p.id).length, 0);
    return { id: m.id, name: m.name, company: m.company, avatarUrl: m.avatarUrl, properties: mProps.length, bookings: mBookings.length, cleaningDone: done, cleaningTotal: tasks.length, slotsApproved: slots, responseMins: avgResponse(mid) };
  });
  return {
    period: { key: period, month, today, basis: 'scheduled_date' as const },
    totals: { ...sumEconomics(counted), upcoming: counted.filter((b) => b.status === 'confirmed' && b.date >= today).length, completed: counted.filter((b) => b.status === 'completed' || b.date < today).length },
    pending: { bookings: pending.length, gross: sumEconomics(pending).gross },
    comparison: compareMonth && compareList.length ? { month: compareMonth, ...sumEconomics(compareList) } : null,
    properties: props.map((p) => ({ ...p, occupancy: occ.find((o) => o.id === p.id) })),
    bookings: bookings.sort((a, b) => b.createdAt - a.createdAt).slice(0, 30).map((b) => ({ ...b, property: { id: b.propertyId, shortTitle: props.find((p) => p.id === b.propertyId)?.shortTitle, image: props.find((p) => p.id === b.propertyId)?.images[0], managerName: props.find((p) => p.id === b.propertyId)?.managerName } })),
    managers,
    updates: R.notificationsFor(user.id, 15),
  };
}

function avgResponse(managerId: string) {
  const rows = all("SELECT m.conversation_id c, m.sender_id s, m.created_at t FROM messages m JOIN conversations cv ON cv.id = m.conversation_id JOIN properties p ON p.id = cv.property_id WHERE p.manager_id = ? AND m.sender_role != 'system' ORDER BY m.conversation_id, m.created_at", managerId);
  const deltas: number[] = [];
  let pendingAt: number | null = null;
  let conv = '';
  for (const r of rows) {
    if (r.c !== conv) { conv = r.c as string; pendingAt = null; }
    if (r.s !== managerId) { if (pendingAt === null) pendingAt = r.t as number; }
    else if (pendingAt !== null) { deltas.push(((r.t as number) - pendingAt) / 60000); pendingAt = null; }
  }
  return deltas.length ? Math.round(deltas.reduce((a, b) => a + b, 0) / deltas.length) : null;
}
