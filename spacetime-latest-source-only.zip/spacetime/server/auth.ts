import crypto from 'node:crypto';
import { one, run } from './db.ts';
import { getUser, type UserRecord } from './repo.ts';

export function hashPassword(pw: string) {
  const salt = crypto.randomBytes(16).toString('hex');
  return `${salt}:${crypto.scryptSync(pw, salt, 32).toString('hex')}`;
}
export function verifyPassword(pw: string, stored: string) {
  const [salt, hash] = stored.split(':');
  const test = crypto.scryptSync(pw, salt, 32);
  return crypto.timingSafeEqual(test, Buffer.from(hash, 'hex'));
}
export function createSession(userId: string) {
  const token = crypto.randomBytes(24).toString('base64url');
  run('INSERT INTO sessions (token, user_id, created_at) VALUES (?, ?, ?)', token, userId, Date.now());
  return token;
}
export function userForToken(token: string | null | undefined): UserRecord | undefined {
  if (!token) return undefined;
  const r = one('SELECT user_id FROM sessions WHERE token = ?', token);
  return r ? getUser(r.user_id as string) : undefined;
}
export const deleteSession = (token: string) => run('DELETE FROM sessions WHERE token = ?', token);

/** What the client may see about the current user (never the operator file's internals beyond the list). */
export function selfView(u: UserRecord) {
  return { ...u, operatorFile: u.operatorFile ? { company: u.operatorFile.company, registrationScope: u.operatorFile.registrationScope, permittedUses: u.operatorFile.permittedUses, documents: u.operatorFile.documents } : undefined };
}
