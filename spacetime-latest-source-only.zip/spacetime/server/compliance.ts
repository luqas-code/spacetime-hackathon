import type { Property, ComplianceReview } from '../shared/types.ts';
import type { UserRecord } from './repo.ts';

/**
 * Deterministic completeness checks. These never certify legality: a listing is approved either by a
 * human reviewer, or because every supporting document is one SpaceTime Compliance has already
 * verified for this operator (recorded as the approval basis).
 */
export function precheck(p: Property, owner: UserRecord): { review: ComplianceReview; verifiedFileEligible: boolean } {
  const c = p.compliance;
  const docTypes = new Set(c.documents.map((d) => d.type));
  const needsReg = c.usage !== 'commercial';
  const checks: ComplianceReview['checks'] = [
    { key: 'usage', ok: !!c.usage },
    { key: 'registration', ok: !needsReg || (c.registrationNumber.replace(/\s/g, '').length >= 8 && docTypes.has('registration')) },
    { key: 'change_of_use', ok: c.changeOfUse === 'granted' || c.changeOfUse === 'not_required' },
    { key: 'owner_authorisation', ok: c.ownerAuthorised },
    { key: 'building', ok: c.buildingAllowsDaytime === 'yes' },
    { key: 'insurance', ok: !!c.insurer && !!c.insurancePolicy && c.insuranceCoversDaytime && docTypes.has('insurance') },
    { key: 'dpe', ok: /^[A-E]$/i.test(c.dpeGrade.trim()) },
    { key: 'attestation', ok: c.attestation },
    { key: 'manager', ok: !!p.managerId },
    { key: 'photos', ok: p.images.length >= 1 },
  ];
  const file = owner.operatorFile;
  const allOnFile = c.documents.length > 0 && c.documents.every((d) => d.source === 'on_file' && file?.documents.some((f) => f.id === d.id));
  const usesInScope = !!file && p.activities.every((a) => file.permittedUses.includes(a));
  const regInScope = !!file && c.registrationNumber.trim() === file.registrationScope;
  checks.push({ key: 'uses_in_verified_scope', ok: usesInScope });
  const complete = checks.filter((x) => x.key !== 'uses_in_verified_scope').every((x) => x.ok);
  return {
    review: { status: 'pending', checks },
    verifiedFileEligible: complete && allOnFile && usesInScope && regInScope,
  };
}
