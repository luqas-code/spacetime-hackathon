import './env.ts';
import { resetDatabase } from './seed.ts';
resetDatabase();
console.log('SpaceTime demo database reset and re-seeded.');
