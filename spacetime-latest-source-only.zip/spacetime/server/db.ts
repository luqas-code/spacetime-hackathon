import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

export const DATA_DIR = process.env.DATA_DIR || path.resolve('data');
export const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

export const db = new DatabaseSync(path.join(DATA_DIR, 'spacetime.db'));
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');

db.exec(`
CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, role TEXT NOT NULL, email TEXT UNIQUE NOT NULL, pw TEXT NOT NULL, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS properties (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, manager_id TEXT, status TEXT NOT NULL, data TEXT NOT NULL, updated_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS ix_prop_owner ON properties(owner_id);
CREATE INDEX IF NOT EXISTS ix_prop_manager ON properties(manager_id);
CREATE TABLE IF NOT EXISTS bookings (id TEXT PRIMARY KEY, property_id TEXT NOT NULL, guest_id TEXT NOT NULL, date TEXT NOT NULL, start_min INTEGER NOT NULL, end_min INTEGER NOT NULL, status TEXT NOT NULL, data TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS ix_book_prop ON bookings(property_id, date);
CREATE INDEX IF NOT EXISTS ix_book_guest ON bookings(guest_id);
CREATE TABLE IF NOT EXISTS slots (id TEXT PRIMARY KEY, property_id TEXT NOT NULL, date TEXT NOT NULL, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS blocks (id TEXT PRIMARY KEY, property_id TEXT NOT NULL, date TEXT NOT NULL, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS stays (id TEXT PRIMARY KEY, property_id TEXT NOT NULL, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS providers (id TEXT PRIMARY KEY, manager_id TEXT NOT NULL, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY, booking_id TEXT NOT NULL, property_id TEXT NOT NULL, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS conversations (id TEXT PRIMARY KEY, kind TEXT NOT NULL, property_id TEXT NOT NULL, guest_id TEXT, booking_id TEXT, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS messages (id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, sender_id TEXT NOT NULL, sender_role TEXT NOT NULL, body TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS ix_msg_conv ON messages(conversation_id, created_at);
CREATE TABLE IF NOT EXISTS reads (conversation_id TEXT NOT NULL, user_id TEXT NOT NULL, at INTEGER NOT NULL, PRIMARY KEY (conversation_id, user_id));
CREATE TABLE IF NOT EXISTS notifications (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, data TEXT NOT NULL, created_at INTEGER NOT NULL, read INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS emails (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, data TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT NOT NULL);
`);

export const uid = (p: string) => `${p}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;

type Row = Record<string, unknown>;
export const all = (sql: string, ...args: unknown[]) => db.prepare(sql).all(...(args as never[])) as Row[];
export const one = (sql: string, ...args: unknown[]) => db.prepare(sql).get(...(args as never[])) as Row | undefined;
export const run = (sql: string, ...args: unknown[]) => db.prepare(sql).run(...(args as never[]));
export const parse = <T>(r: Row | undefined): T | undefined => (r ? (JSON.parse(r.data as string) as T) : undefined);
export const parseAll = <T>(rows: Row[]): T[] => rows.map((r) => JSON.parse(r.data as string) as T);

/** Run fn inside an IMMEDIATE transaction (serialises writers — used for booking/slot conflict checks). */
export function tx<T>(fn: () => T): T {
  db.exec('BEGIN IMMEDIATE');
  try {
    const out = fn();
    db.exec('COMMIT');
    return out;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
}
