import './env.ts';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { URL } from 'node:url';
import { all, run, tx, uid, UPLOAD_DIR } from './db.ts';
import * as R from './repo.ts';
import type { UserRecord } from './repo.ts';
import * as S from './services.ts';
import { HttpError } from './services.ts';
import { createSession, deleteSession, selfView, userForToken, verifyPassword } from './auth.ts';
import { seed, DEMO_PASSWORD, resetDatabase } from './seed.ts';
import { addClient, broadcast, pushTo } from './realtime.ts';
import { precheck } from './compliance.ts';
import { aiStatus, explainWithAI, parseWithAI } from './ai.ts';
import type { Block, Booking, CleaningTask, Delegation, Property, Slot, Stay, WeeklyWindow } from '../shared/types.ts';
import { addDays, dow, overlaps, toHHMM, toMin } from '../shared/time.ts';
import { overnightRanges } from '../shared/schedule.ts';

const PORT = Number(process.env.PORT || 8787);
const DIST = path.resolve('dist');

if (process.argv.includes('--reset')) {
  resetDatabase();
  console.log('Database reset and re-seeded.');
} else if (seed()) console.log('Seeded demo data.');

// ------------------------------------------------------------------ tiny router
type Ctx = { req: http.IncomingMessage; res: http.ServerResponse; params: Record<string, string>; query: URLSearchParams; body: any; user?: UserRecord; token?: string };
type Handler = (c: Ctx) => unknown | Promise<unknown>;
const routes: { method: string; re: RegExp; keys: string[]; auth: boolean | string[]; h: Handler }[] = [];
function route(method: string, pattern: string, auth: boolean | string[], h: Handler) {
  const keys: string[] = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => (keys.push(k), '([^/]+)')) + '$');
  routes.push({ method, re, keys, auth, h });
}
const need = (c: Ctx) => c.user!;
const str = (v: unknown, max = 500) => (typeof v === 'string' ? v.slice(0, max) : '');

// ------------------------------------------------------------------ public & auth
route('GET', '/api/health', false, () => ({ ok: true, time: new Date().toString(), ai: aiStatus() }));
route('GET', '/api/demo-accounts', false, () =>
  ['sophie@spacetime.demo', 'malik@spacetime.demo', 'isaac@spacetime.demo', 'review@spacetime.demo'].map((e) => {
    const u = R.getUserByEmail(e)?.user;
    return u && { email: u.email, role: u.role, name: u.name, company: u.company, avatarUrl: u.avatarUrl, password: DEMO_PASSWORD };
  }).filter(Boolean));
route('POST', '/api/login', false, (c) => {
  const found = R.getUserByEmail(str(c.body?.email));
  if (!found || !verifyPassword(str(c.body?.password), found.pw)) throw new HttpError(401, 'bad_credentials', 'Email or password is incorrect.');
  return { token: createSession(found.user.id), user: selfView(found.user) };
});
route('POST', '/api/logout', true, (c) => (deleteSession(c.token!), { ok: true }));
route('GET', '/api/me', true, (c) => selfView(need(c)));
route('PATCH', '/api/me', true, (c) => {
  const u = need(c);
  const b = c.body ?? {};
  if (typeof b.name === 'string' && b.name.trim()) u.name = str(b.name, 80);
  for (const k of ['phone', 'bio', 'company'] as const) if (typeof b[k] === 'string') u[k] = str(b[k], 400);
  if (b.lang === 'en' || b.lang === 'fr') u.lang = b.lang;
  if (typeof b.avatarUrl === 'string' && (b.avatarUrl.startsWith('/uploads/') || b.avatarUrl.startsWith('/avatars/') || b.avatarUrl === '')) u.avatarUrl = b.avatarUrl;
  if (b.prefs && typeof b.prefs === 'object') u.prefs = { ...u.prefs, ...b.prefs };
  R.saveUser(u);
  return selfView(u);
});
route('POST', '/api/uploads', true, (c) => {
  const m = /^data:((?:image|application)\/(jpeg|png|webp|pdf));base64,(.+)$/.exec(str(c.body?.dataUrl, 12_000_000));
  if (!m) throw new HttpError(400, 'bad_file', 'Please upload a JPEG, PNG, WebP image or a PDF.');
  const buf = Buffer.from(m[3], 'base64');
  if (buf.length > 8_000_000) throw new HttpError(413, 'too_large');
  const name = `${uid(m[2] === 'pdf' ? 'doc' : 'img')}.${m[2] === 'jpeg' ? 'jpg' : m[2]}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, name), buf);
  return { url: `/uploads/${name}` };
});
route('GET', '/api/notifications', true, (c) => R.notificationsFor(need(c).id));
route('POST', '/api/notifications/read', true, (c) => (run('UPDATE notifications SET read = 1 WHERE user_id = ?', need(c).id), { ok: true }));
route('GET', '/api/emails', true, (c) => R.emailsFor(need(c).id));

// ------------------------------------------------------------------ catalogue, geo & AI
route('GET', '/api/catalog', false, () => ({ today: S.todayISO(), nowMin: S.nowMin(), listings: S.catalog() }));
route('GET', '/api/listing/:id', false, (c) => {
  const p = R.getProperty(c.params.id);
  if (!p) throw new HttpError(404, 'not_found');
  const viewer = c.user;
  const privileged = viewer && ((viewer.role === 'owner' && p.ownerId === viewer.id) || (viewer.role === 'manager' && p.managerId === viewer.id));
  if (p.status !== 'published' && !privileged) throw new HttpError(404, 'not_found');
  return S.publicListing(p);
});
route('GET', '/api/geo', false, async (c) => {
  const q = str(c.query.get('q'), 120).trim();
  if (q.length < 3) return { provider: 'none', results: [] };
  const key = process.env.GEOAPIFY_API_KEY;
  try {
    if (key) {
      const r = await fetch(`https://api.geoapify.com/v1/geocode/autocomplete?text=${encodeURIComponent(q)}&filter=rect:2.20,48.80,2.48,48.92&bias=proximity:2.3476,48.8606&limit=6&lang=fr&apiKey=${key}`);
      const j = (await r.json()) as { features?: { properties: { place_id: string; address_line1: string; address_line2: string; lat: number; lon: number } }[] };
      return { provider: 'geoapify', results: (j.features ?? []).map((f) => ({ id: 'geo-' + f.properties.place_id, label: f.properties.address_line1, sub: f.properties.address_line2, lat: f.properties.lat, lng: f.properties.lon, kind: 'address' })) };
    }
    const r = await fetch(`https://nominatim.openstreetmap.org/search?format=json&limit=5&countrycodes=fr&viewbox=2.22,48.92,2.47,48.80&bounded=1&q=${encodeURIComponent(q)}`, { headers: { 'User-Agent': 'SpaceTime-prototype/1.0', 'Accept-Language': 'fr,en' } });
    const j = (await r.json()) as { place_id: number; display_name: string; lat: string; lon: string }[];
    return { provider: 'osm', results: j.map((x) => { const parts = x.display_name.split(',').map((s) => s.trim()); return { id: 'osm-' + x.place_id, label: parts.slice(0, 2).join(', '), sub: parts.slice(2, 4).join(', '), lat: +x.lat, lng: +x.lon, kind: 'address' }; }) };
  } catch {
    return { provider: 'offline', results: [] };
  }
});
route('GET', '/api/ai/status', false, () => aiStatus());
route('POST', '/api/ai/parse', false, async (c) => parseWithAI(str(c.body?.text, 2000), c.body?.previous, c.body?.lang === 'fr' ? 'fr' : 'en'));
route('POST', '/api/ai/explain', ['manager', 'owner'], async (c) => explainWithAI(c.body.candidate, c.body.assumptions, c.body?.lang === 'fr' ? 'fr' : 'en'));

// ------------------------------------------------------------------ bookings
route('POST', '/api/bookings', ['guest'], (c) => {
  const b = c.body ?? {};
  const list = S.createBookings(need(c), {
    propertyId: str(b.propertyId), dates: Array.isArray(b.dates) ? b.dates.map(String) : [str(b.date)], start: str(b.start), hours: Number(b.hours),
    guests: { adults: Number(b.guests?.adults) || 1, children: Number(b.guests?.children) || 0, infants: Number(b.guests?.infants) || 0, pets: Number(b.guests?.pets) || 0 },
    purpose: b.purpose, note: str(b.note), recurring: b.recurring ?? null,
  });
  return { bookings: list.map(S.bookingForGuest) };
});
route('GET', '/api/bookings/mine', ['guest'], (c) => R.bookingsWhere('guest_id = ?', need(c).id).sort((a, b) => b.createdAt - a.createdAt).map(S.bookingForGuest));
route('GET', '/api/bookings/:id', true, (c) => {
  const u = need(c);
  const b = R.getBooking(c.params.id);
  if (!b) throw new HttpError(404, 'not_found');
  const p = R.getProperty(b.propertyId)!;
  if (u.role === 'guest' && b.guestId === u.id) return S.bookingForGuest(b);
  if ((u.role === 'manager' && p.managerId === u.id) || (u.role === 'owner' && p.ownerId === u.id)) {
    const guest = R.getUser(b.guestId);
    const task = R.taskForBooking(b.id);
    const tasks = R.tasksForProperties([p.id]);
    const conv = S.getOrCreateConversation('guest', p.id, b.guestId);
    return { ...b, status: S.effectiveStatus(b), property: S.hydrate(p), guest: guest ? { id: guest.id, name: guest.name, avatarUrl: guest.avatarUrl, phone: u.role === 'manager' ? guest.phone : '', email: u.role === 'manager' ? guest.email : '' } : null, cleaning: task ? S.taskView(task, tasks) : null, providers: u.role === 'manager' ? R.providersFor(u.id) : [], conversationId: u.role === 'manager' ? conv.id : null };
  }
  throw new HttpError(403, 'forbidden');
});
route('POST', '/api/bookings/:id/cancel', true, (c) => S.bookingForGuest(S.cancelBooking(need(c), c.params.id)));

// ------------------------------------------------------------------ messages
route('GET', '/api/conversations', true, (c) => S.listConversations(need(c)));
route('POST', '/api/conversations', true, (c) => {
  const u = need(c);
  const p = R.getProperty(str(c.body?.propertyId));
  if (!p) throw new HttpError(404, 'not_found');
  if (u.role === 'guest') return S.getOrCreateConversation('guest', p.id, u.id);
  if (u.role === 'owner' && p.ownerId === u.id && p.managerId) return S.getOrCreateConversation('owner', p.id, null);
  if (u.role === 'manager' && p.managerId === u.id) return S.getOrCreateConversation(c.body?.kind === 'guest' ? 'guest' : 'owner', p.id, c.body?.kind === 'guest' ? str(c.body?.guestId) : null);
  throw new HttpError(403, 'forbidden');
});
route('GET', '/api/conversations/:id', true, (c) => {
  const u = need(c);
  const conv = S.getConv(c.params.id);
  if (!conv || !S.canAccessConversation(u, conv)) throw new HttpError(403, 'forbidden');
  const meta = S.listConversations(u).find((x) => x.id === conv.id);
  const p = R.getProperty(conv.property_id)!;
  const booking = conv.booking_id ? R.getBooking(conv.booking_id) : undefined;
  return { conversation: meta, property: { id: p.id, shortTitle: p.shortTitle, images: p.images.slice(0, 1), neighbourhood: p.neighbourhood }, booking: booking ? { ...booking, status: S.effectiveStatus(booking) } : null, messages: all('SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at', conv.id).map(S.rowToMessage) };
});
route('POST', '/api/conversations/:id/messages', true, (c) => {
  const u = need(c);
  const conv = S.getConv(c.params.id);
  if (!conv || !S.canAccessConversation(u, conv)) throw new HttpError(403, 'forbidden');
  const body = str(c.body?.body, 2000).trim();
  if (!body) throw new HttpError(400, 'empty');
  if (u.role === 'manager' && conv.kind === 'guest') S.requireDelegation(R.getProperty(conv.property_id)!, 'messaging');
  return S.postMessage(conv.id, u, body);
});
route('POST', '/api/conversations/:id/read', true, (c) => {
  const u = need(c);
  const conv = S.getConv(c.params.id);
  if (!conv || !S.canAccessConversation(u, conv)) throw new HttpError(403, 'forbidden');
  run('INSERT OR REPLACE INTO reads (conversation_id, user_id, at) VALUES (?, ?, ?)', conv.id, u.id, Date.now());
  return { ok: true };
});

// ------------------------------------------------------------------ owner
route('GET', '/api/owner/overview', ['owner'], (c) => {
  const p = c.query.get('period');
  return S.ownerOverview(need(c), p === 'last_month' || p === 'all' ? p : 'this_month');
});
route('GET', '/api/owner/managers', ['owner'], () =>
  R.usersByRole('manager').map((m) => ({ id: m.id, name: m.name, company: m.company, avatarUrl: m.avatarUrl, properties: R.propertiesWhere('manager_id = ?', m.id).length })));
route('GET', '/api/owner/properties/:id', ['owner'], (c) => {
  const p = S.ownerProperty(need(c), c.params.id);
  return { property: S.withSchedule(p), bookings: R.bookingsWhere('property_id = ?', p.id).map((b) => ({ ...b, status: S.effectiveStatus(b) })).reverse(), stays: R.staysFor(p.id) };
});

const EDITABLE: (keyof Property)[] = ['title', 'shortTitle', 'type', 'neighbourhood', 'arrondissement', 'address', 'lat', 'lng', 'images', 'description', 'highlights', 'amenities', 'accessibility', 'activities', 'capacity', 'sizeM2', 'floor', 'pricePerHour', 'minBookingPrice', 'cleaningFee', 'otherCharges', 'minHours', 'maxHours', 'bufferMins', 'petsAllowed', 'childrenAllowed', 'rules', 'checkout', 'checkinInstructions', 'ownerWindows', 'overnight', 'instantBook', 'compliance', 'delegation', 'managerId', 'cleaningProviderId', 'cleaningNotes'];
const LIVE_EDITABLE: (keyof Property)[] = ['description', 'highlights', 'rules', 'checkout', 'checkinInstructions', 'ownerWindows', 'delegation', 'managerId', 'images', 'pricePerHour', 'minBookingPrice', 'otherCharges'];

function applyOwnerEdits(p: Property, body: Partial<Property>, fields: (keyof Property)[]) {
  for (const k of fields) if (k in body) (p as any)[k] = (body as any)[k];
  if (p.managerId && R.getUser(p.managerId)?.role !== 'manager') throw new HttpError(400, 'bad_manager');
  p.pricePerHour = Math.max(1, Number(p.pricePerHour) || 1);
  p.minHours = Math.max(1, Math.min(12, Number(p.minHours) || 2));
  p.maxHours = Math.max(p.minHours, Math.min(12, Number(p.maxHours) || 8));
  p.bufferMins = Math.max(15, Math.min(240, Number(p.bufferMins) || 60));
  p.shortTitle = p.shortTitle || `${p.title.split(' ').slice(0, 3).join(' ')} · ${p.neighbourhood}`;
}

route('POST', '/api/owner/properties', ['owner'], (c) => {
  const u = need(c);
  const now = Date.now();
  const p: Property = {
    id: uid('pr'), title: 'Untitled space', shortTitle: '', type: 'apartment', neighbourhood: '', arrondissement: '', address: '', lat: 48.8606, lng: 2.3476,
    images: [], description: '', highlights: [], amenities: [], accessibility: [], activities: [], capacity: { guests: 2, beds: 1, bathrooms: 1 }, sizeM2: 40, floor: '',
    pricePerHour: 20, minBookingPrice: 40, cleaningFee: 20, otherCharges: [], minHours: 2, maxHours: 8, bufferMins: 60, petsAllowed: false, childrenAllowed: true,
    rules: [], checkout: [], checkinInstructions: '', availability: [], ownerWindows: [{ days: [0, 1, 2, 3, 4, 5, 6], start: '08:00', end: '20:00' }],
    overnight: { enabled: false, channel: '', checkin: '16:00', checkout: '11:00', nightlyRate: 0, channelFeePct: 15 },
    partner: { name: '', company: '', since: 2026, responseMins: 15, superPartner: false, languages: ['English', 'French'] },
    instantBook: true, status: 'draft', ownerId: u.id, managerId: null,
    compliance: { usage: 'tourist_furnished', registrationNumber: '', changeOfUse: 'unknown', changeOfUseRef: '', ownerAuthorised: false, buildingAllowsDaytime: 'unknown', buildingNotes: '', insurer: '', insurancePolicy: '', insuranceCoversDaytime: false, dpeGrade: '', restrictions: '', documents: [], attestation: false },
    delegation: { availability: true, pricing: true, priceFloor: 0, approveBookings: true, cleaning: true, messaging: true, mgmtFeePct: 20 } as Delegation,
    cleaningProviderId: null, createdAt: now,
  };
  applyOwnerEdits(p, c.body ?? {}, EDITABLE);
  R.saveProperty(p);
  return p;
});
route('PUT', '/api/owner/properties/:id', ['owner'], (c) => {
  const p = S.ownerProperty(need(c), c.params.id);
  const editable = p.status === 'draft' || p.status === 'changes_requested';
  const prevManager = p.managerId;
  if (!editable && Array.isArray(c.body?.activities)) {
    const added = (c.body.activities as string[]).filter((a) => !p.activities.includes(a as never));
    if (added.length) throw new HttpError(409, 'requires_review', 'Adding a permitted use requires a new compliance review.');
    if (!c.body.activities.length) throw new HttpError(400, 'need_one_use');
    p.activities = c.body.activities;
  }
  applyOwnerEdits(p, c.body ?? {}, editable ? EDITABLE : LIVE_EDITABLE);
  R.saveProperty(p);
  if (p.managerId !== prevManager && p.status !== 'draft') {
    S.notify(p.managerId, 'assignment', S.Lu(p.managerId, `${need(c).name} assigned you ${p.shortTitle}`, `${need(c).name} vous a confié ${p.shortTitle}`), `/manager/property/${p.id}`);
    S.changed([p.managerId, prevManager], 'portfolio');
  }
  S.changed([p.managerId], 'portfolio');
  if (p.status === 'published') broadcast({ type: 'changed', scope: 'catalog' });
  return S.withSchedule(p);
});
route('POST', '/api/owner/properties/:id/import-calendar', ['owner', 'manager'], (c) => {
  const u = need(c);
  const p = u.role === 'owner' ? S.ownerProperty(u, c.params.id) : S.managerProperty(u, c.params.id);
  run('DELETE FROM stays WHERE property_id = ?', p.id);
  const today = S.todayISO();
  const pattern: [number, number, string][] = [[-1, 1, 'L. Moreau (2)'], [2, 3, 'S. Patel (3)'], [6, 2, 'D. Weber (2)'], [10, 3, 'A. Costa (4)']];
  const channel = p.overnight.channel || 'Airbnb';
  for (const [from, nights, label] of pattern) R.saveStay({ id: uid('st'), propertyId: p.id, checkinDate: addDays(today, from), checkoutDate: addDays(today, from + nights), channel, guestLabel: label, nightlyRate: p.overnight.nightlyRate || 140 } as Stay);
  p.overnight.enabled = true;
  p.overnight.channel = channel;
  R.saveProperty(p);
  S.changed([p.managerId, p.ownerId], 'portfolio');
  return { stays: R.staysFor(p.id) };
});
route('POST', '/api/owner/properties/:id/submit', ['owner'], (c) => {
  const u = need(c);
  const p = S.ownerProperty(u, c.params.id);
  if (!['draft', 'changes_requested'].includes(p.status)) throw new HttpError(409, 'already_submitted');
  if (!p.title.trim() || !p.address.trim() || !p.activities.length) throw new HttpError(400, 'incomplete', 'Name, address and at least one permitted activity are required.');
  const { review, verifiedFileEligible } = precheck(p, u);
  if (verifiedFileEligible) {
    const by = p.compliance.documents[0]?.verifiedBy ?? 'SpaceTime Compliance';
    p.compliance.review = { ...review, status: 'approved', basis: 'verified_file', reviewer: by, at: new Date().toISOString(), notes: 'All supporting documents match the operator file previously verified by SpaceTime Compliance; permitted uses within verified scope.' };
    p.status = 'approved';
  } else {
    p.compliance.review = review;
    p.status = 'in_review';
    for (const r of R.usersByRole('reviewer')) S.notify(r.id, 'review', S.Lu(r.id, `New listing to review: ${p.title}`, `Nouvelle annonce à contrôler : ${p.title}`), '/review');
    S.changed(R.usersByRole('reviewer').map((r) => r.id), 'review');
  }
  R.saveProperty(p);
  if (p.managerId) {
    S.notify(p.managerId, 'assignment', S.Lu(p.managerId, `${u.name} assigned you a new property: ${p.shortTitle}`, `${u.name} vous a confié un nouveau bien : ${p.shortTitle}`), `/manager/property/${p.id}`);
    S.changed([p.managerId], 'portfolio');
  }
  S.notify(u.id, 'listing', p.status === 'approved' ? S.Lu(u.id, `${p.shortTitle} is approved and ready to publish`, `${p.shortTitle} est approuvée et prête à publier`) : S.Lu(u.id, `${p.shortTitle} submitted for compliance review`, `${p.shortTitle} soumise au contrôle de conformité`), `/owner/property/${p.id}`);
  return S.withSchedule(p);
});
route('POST', '/api/owner/properties/:id/publish', ['owner'], (c) => {
  const p = S.ownerProperty(need(c), c.params.id);
  if (p.status !== 'approved' && p.status !== 'paused') throw new HttpError(409, 'not_approved', 'Only approved listings can be published.');
  if (!p.managerId) throw new HttpError(400, 'no_manager');
  p.status = 'published';
  p.publishedAt = Date.now();
  R.saveProperty(p);
  S.notify(p.managerId, 'published', S.Lu(p.managerId, `${p.shortTitle} is now live on SpaceTime — approve daytime windows to make it bookable`, `${p.shortTitle} est en ligne — approuvez des créneaux de jour pour la rendre réservable`), `/manager/property/${p.id}?tab=smart`);
  S.changed([p.managerId, p.ownerId], 'portfolio');
  broadcast({ type: 'changed', scope: 'catalog' });
  return S.withSchedule(p);
});
route('POST', '/api/owner/properties/:id/pause', ['owner'], (c) => {
  const p = S.ownerProperty(need(c), c.params.id);
  if (p.status !== 'published') throw new HttpError(409, 'not_published');
  p.status = 'paused';
  R.saveProperty(p);
  S.changed([p.managerId, p.ownerId], 'portfolio');
  broadcast({ type: 'changed', scope: 'catalog' });
  return S.withSchedule(p);
});

// ------------------------------------------------------------------ manager
route('GET', '/api/manager/overview', ['manager'], (c) => S.managerOverview(need(c)));
route('GET', '/api/manager/properties/:id', ['manager'], (c) => {
  const u = need(c);
  const p = S.managerProperty(u, c.params.id);
  const tasks = R.tasksForProperties([p.id]);
  return {
    property: S.withSchedule(p), stays: R.staysFor(p.id), slots: R.slotsFor(p.id), blocks: R.blocksFor(p.id),
    bookings: R.bookingsWhere('property_id = ?', p.id).map((b) => ({ ...b, status: S.effectiveStatus(b) })),
    tasks: tasks.map((t) => S.taskView(t, tasks)), providers: R.providersFor(u.id), readiness: S.readinessGaps(p),
    today: S.todayISO(), nowMin: S.nowMin(),
  };
});
route('PATCH', '/api/manager/properties/:id', ['manager'], (c) => {
  const p = S.managerProperty(need(c), c.params.id);
  const b = c.body ?? {};
  if ('pricePerHour' in b || 'minHours' in b || 'maxHours' in b || 'minBookingPrice' in b) {
    S.requireDelegation(p, 'pricing');
    if ('pricePerHour' in b) {
      if (Number(b.pricePerHour) < p.delegation.priceFloor) throw new HttpError(403, 'below_floor', `The owner's minimum is €${p.delegation.priceFloor}/h.`);
      p.pricePerHour = Number(b.pricePerHour);
    }
    if ('minHours' in b) p.minHours = Math.max(1, Math.min(12, Number(b.minHours)));
    if ('maxHours' in b) p.maxHours = Math.max(p.minHours, Math.min(12, Number(b.maxHours)));
    if ('minBookingPrice' in b) p.minBookingPrice = Math.max(0, Number(b.minBookingPrice));
  }
  if ('bufferMins' in b || 'instantBook' in b) {
    S.requireDelegation(p, 'availability');
    if ('bufferMins' in b) p.bufferMins = Math.max(15, Math.min(240, Number(b.bufferMins)));
    if ('instantBook' in b) p.instantBook = !!b.instantBook;
  }
  if ('cleaningProviderId' in b) {
    S.requireDelegation(p, 'cleaning');
    p.cleaningProviderId = b.cleaningProviderId || null;
  }
  if ('checkinInstructions' in b) p.checkinInstructions = str(b.checkinInstructions, 1000);
  // Managers can never change ownership, permitted uses, compliance or publication status.
  R.saveProperty(p);
  S.changed([p.ownerId, p.managerId], 'portfolio');
  if (p.status === 'published') broadcast({ type: 'changed', scope: 'catalog' });
  return S.withSchedule(p);
});

function validateWindow(p: Property, date: string, s: number, e: number, kind: 'slot' | 'block') {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date < S.todayISO() || date > addDays(S.todayISO(), 60)) throw new HttpError(400, 'bad_date');
  if (!(e > s && s >= 0 && e <= 1440)) throw new HttpError(400, 'bad_time');
  if (kind === 'block') return;
  const env = p.ownerWindows.filter((w) => w.days.includes(dow(date)));
  if (!env.some((w) => s >= toMin(w.start) && e <= toMin(w.end))) throw new HttpError(409, 'outside_owner_hours', "Outside the hours the owner allows for daytime use.");
  const { occupied, buffers } = overnightRanges(p, R.staysFor(p.id), date);
  if ([...occupied, ...buffers].some((r) => overlaps([s, e], r))) throw new HttpError(409, 'overlaps_overnight', 'Overlaps an overnight stay or its cleaning buffer.');
}
route('POST', '/api/manager/properties/:id/slots', ['manager'], (c) => {
  const u = need(c);
  const slot = tx(() => {
    const p = S.managerProperty(u, c.params.id);
    S.requireDelegation(p, 'availability');
    const date = str(c.body?.date);
    const s = toMin(str(c.body?.start));
    const e = toMin(str(c.body?.end));
    validateWindow(p, date, s, e, 'slot');
    const x: Slot = { id: uid('sl'), propertyId: p.id, date, start: toHHMM(s), end: toHHMM(e), status: 'approved', source: c.body?.source === 'optimiser' ? 'optimiser' : 'manual', createdBy: u.id, createdAt: Date.now() };
    R.saveSlot(x);
    return x;
  });
  const p = R.getProperty(c.params.id)!;
  S.notify(p.ownerId, 'slot', S.Lu(p.ownerId, `${u.name} opened ${slot.date} ${slot.start}–${slot.end} at ${p.shortTitle} for daytime bookings`, `${u.name} a ouvert le ${slot.date} ${slot.start}–${slot.end} à ${p.shortTitle} aux réservations de jour`), `/owner/property/${p.id}`);
  S.changed([p.ownerId, u.id], 'portfolio');
  broadcast({ type: 'changed', scope: 'catalog' });
  return slot;
});
route('DELETE', '/api/manager/properties/:id/slots/:slotId', ['manager'], (c) => {
  const p = S.managerProperty(need(c), c.params.id);
  S.requireDelegation(p, 'availability');
  R.deleteSlot(c.params.slotId);
  broadcast({ type: 'changed', scope: 'catalog' });
  return { ok: true };
});
route('POST', '/api/manager/properties/:id/blocks', ['manager'], (c) => {
  const p = S.managerProperty(need(c), c.params.id);
  S.requireDelegation(p, 'availability');
  const date = str(c.body?.date);
  const s = toMin(str(c.body?.start));
  const e = toMin(str(c.body?.end));
  validateWindow(p, date, s, e, 'block');
  const b: Block = { id: uid('bl'), propertyId: p.id, date, start: toHHMM(s), end: toHHMM(e), reason: str(c.body?.reason, 120) || 'Blocked' };
  R.saveBlock(b);
  broadcast({ type: 'changed', scope: 'catalog' });
  S.changed([p.ownerId], 'portfolio');
  return b;
});
route('DELETE', '/api/manager/properties/:id/blocks/:blockId', ['manager'], (c) => {
  const p = S.managerProperty(need(c), c.params.id);
  S.requireDelegation(p, 'availability');
  R.deleteBlock(c.params.blockId);
  broadcast({ type: 'changed', scope: 'catalog' });
  return { ok: true };
});
route('POST', '/api/manager/properties/:id/weekly', ['manager'], (c) => {
  const p = S.managerProperty(need(c), c.params.id);
  S.requireDelegation(p, 'availability');
  const windows = (Array.isArray(c.body?.availability) ? c.body.availability : []) as WeeklyWindow[];
  for (const w of windows) for (const d of w.days) if (!p.ownerWindows.some((o) => o.days.includes(d) && toMin(w.start) >= toMin(o.start) && toMin(w.end) <= toMin(o.end))) throw new HttpError(409, 'outside_owner_hours');
  p.availability = windows;
  R.saveProperty(p);
  broadcast({ type: 'changed', scope: 'catalog' });
  return S.withSchedule(p);
});
route('POST', '/api/manager/bookings/:id/decision', ['manager'], (c) => S.decideBooking(need(c), c.params.id, c.body?.decision === 'decline' ? 'decline' : 'approve'));
route('POST', '/api/manager/bookings/:id/ops', ['manager'], (c) => {
  const b = R.getBooking(c.params.id);
  if (!b) throw new HttpError(404, 'not_found');
  const p = S.managerProperty(need(c), b.propertyId);
  const ops = str(c.body?.opsStatus) as Booking['opsStatus'];
  if (!['awaiting', 'ready', 'checked_in', 'checked_out'].includes(ops)) throw new HttpError(400, 'bad_status');
  b.opsStatus = ops;
  b.updatedAt = Date.now();
  R.saveBooking(b);
  const guest = R.getUser(b.guestId);
  if (ops === 'ready') S.notify(b.guestId, 'ops', guest?.lang === 'fr' ? `${p.shortTitle} est prêt pour votre arrivée` : `${p.shortTitle} is ready for your arrival`, `/confirmed/${b.id}`);
  S.changed([b.guestId, p.ownerId, p.managerId], 'bookings');
  return b;
});
route('POST', '/api/manager/bookings/:id/cancel', ['manager'], (c) => S.cancelBooking(need(c), c.params.id));
route('GET', '/api/manager/cleaning', ['manager'], (c) => {
  const u = need(c);
  const ids = R.propertiesWhere('manager_id = ?', u.id).map((p) => p.id);
  const tasks = R.tasksForProperties(ids);
  return { tasks: tasks.map((t) => S.taskView(t, tasks)).sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start)), providers: R.providersFor(u.id), today: S.todayISO() };
});
route('PATCH', '/api/manager/cleaning/:id', ['manager'], (c) => {
  const u = need(c);
  const t = R.getTask(c.params.id);
  if (!t) throw new HttpError(404, 'not_found');
  const p = S.managerProperty(u, t.propertyId);
  S.requireDelegation(p, 'cleaning');
  const b = c.body ?? {};
  if ('providerId' in b) {
    if (b.providerId && R.getProvider(b.providerId)?.managerId !== u.id) throw new HttpError(400, 'bad_provider');
    t.providerId = b.providerId || null;
    if (t.providerId && t.status === 'unassigned') t.status = 'scheduled';
    if (!t.providerId && t.status === 'scheduled') t.status = 'unassigned';
  }
  if (typeof b.deadline === 'string' && /^\d{2}:\d{2}$/.test(b.deadline)) t.deadline = b.deadline;
  if (typeof b.start === 'string' && /^\d{2}:\d{2}$/.test(b.start)) t.start = b.start;
  if (['unassigned', 'scheduled', 'in_progress', 'completed'].includes(b.status)) t.status = b.status as CleaningTask['status'];
  if (typeof b.notes === 'string') t.notes = str(b.notes, 500);
  t.updatedAt = Date.now();
  R.saveTask(t);
  if (t.status === 'completed') S.notify(p.ownerId, 'cleaning', S.Lu(p.ownerId, `Cleaning completed at ${p.shortTitle} (${t.date} ${t.start})`, `Ménage terminé à ${p.shortTitle} (${t.date} ${t.start})`), `/owner/property/${p.id}`);
  S.changed([u.id, p.ownerId], 'cleaning');
  return S.taskView(t, R.tasksForProperties([p.id]));
});

// ------------------------------------------------------------------ compliance review
route('GET', '/api/review/queue', ['reviewer'], () => ({
  pending: R.propertiesWhere("status = 'in_review'").map((p) => ({ ...S.hydrate(p) })),
  recent: R.propertiesWhere("status IN ('approved','published','changes_requested')").slice(0, 12).map((p) => ({ id: p.id, title: p.title, status: p.status, ownerName: R.getUser(p.ownerId)?.name, review: p.compliance.review })),
}));
route('POST', '/api/review/:id', ['reviewer'], (c) => {
  const u = need(c);
  const p = R.getProperty(c.params.id);
  if (!p || p.status !== 'in_review') throw new HttpError(409, 'not_in_review');
  const approve = c.body?.decision === 'approve';
  p.compliance.review = { ...(p.compliance.review ?? { checks: [] }), status: approve ? 'approved' : 'changes_requested', basis: 'manual_review', reviewer: `${u.name} — ${u.company}`, at: new Date().toISOString(), notes: str(c.body?.notes, 1000) };
  for (const d of p.compliance.documents) if (approve && !d.verifiedAt) { d.verifiedAt = new Date().toISOString().slice(0, 10); d.verifiedBy = u.name; }
  p.status = approve ? 'approved' : 'changes_requested';
  R.saveProperty(p);
  S.notify(p.ownerId, 'review', approve ? S.Lu(p.ownerId, `${p.shortTitle} passed compliance review — you can publish it`, `${p.shortTitle} a passé le contrôle de conformité — vous pouvez la publier`) : S.Lu(p.ownerId, `${p.shortTitle}: changes requested by compliance`, `${p.shortTitle} : modifications demandées par la conformité`), `/owner/property/${p.id}`);
  S.changed([p.ownerId, p.managerId], 'portfolio');
  return p;
});

// ------------------------------------------------------------------ server
const MIME: Record<string, string> = { '.pdf': 'application/pdf', '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.json': 'application/json', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };

function serveFile(res: http.ServerResponse, file: string, cache: boolean) {
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404).end('Not found'); return; }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] ?? 'application/octet-stream', 'Cache-Control': cache ? 'public, max-age=31536000, immutable' : 'no-cache' });
    res.end(data);
  });
}

async function readBody(req: http.IncomingMessage): Promise<any> {
  if (req.method === 'GET' || req.method === 'HEAD') return undefined;
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const ch of req) {
    size += (ch as Buffer).length;
    if (size > 12_000_000) throw new HttpError(413, 'too_large');
    chunks.push(ch as Buffer);
  }
  const raw = Buffer.concat(chunks).toString('utf8');
  if (!raw) return {};
  try { return JSON.parse(raw); } catch { throw new HttpError(400, 'bad_json'); }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url ?? '/', 'http://localhost');
  const p = decodeURIComponent(url.pathname);
  if (p === '/api/events') {
    const user = userForToken(url.searchParams.get('token'));
    if (!user) { res.writeHead(401).end(); return; }
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    res.write(`data: ${JSON.stringify({ type: 'hello' })}\n\n`);
    addClient(user.id, res);
    return;
  }
  if (p.startsWith('/api/')) {
    const r = routes.find((x) => x.method === req.method && x.re.test(p));
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    if (!r) { res.writeHead(404).end(JSON.stringify({ error: 'not_found' })); return; }
    try {
      const m = r.re.exec(p)!;
      const params = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
      const token = (req.headers.authorization ?? '').replace(/^Bearer\s+/i, '') || undefined;
      const user = userForToken(token);
      if (r.auth && !user) throw new HttpError(401, 'unauthenticated');
      if (Array.isArray(r.auth) && !r.auth.includes(user!.role)) throw new HttpError(403, 'wrong_role');
      const body = await readBody(req);
      const out = await r.h({ req, res, params, query: url.searchParams, body, user, token });
      res.writeHead(200).end(JSON.stringify(out ?? { ok: true }));
    } catch (e) {
      const he = e instanceof HttpError ? e : null;
      if (!he) console.error(e);
      res.writeHead(he?.status ?? 500).end(JSON.stringify({ error: he?.code ?? 'server_error', message: he?.message ?? 'Unexpected error' }));
    }
    return;
  }
  if (p.startsWith('/uploads/')) return serveFile(res, path.join(UPLOAD_DIR, path.basename(p)), true);
  const file = path.join(DIST, path.normalize(p).replace(/^(\.\.[/\\])+/, ''));
  if (p !== '/' && file.startsWith(DIST) && fs.existsSync(file) && fs.statSync(file).isFile()) return serveFile(res, file, p.startsWith('/assets/') || p.startsWith('/photos/'));
  serveFile(res, path.join(DIST, 'index.html'), false);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`SpaceTime server on http://localhost:${PORT}  (AI: ${aiStatus().engine}, email: ${process.env.RESEND_API_KEY ? 'resend' : 'preview only'}, geocoding: ${process.env.GEOAPIFY_API_KEY ? 'geoapify' : 'osm/offline'})`);
});
void pushTo;
