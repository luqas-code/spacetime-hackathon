import { all, one, parse, parseAll, run } from './db.ts';
import { localPhoto } from '../shared/samplePhotos.ts';
import type { Block, Booking, CleaningProvider, CleaningTask, EmailRecord, Notification, Property, Slot, Stay, User, ComplianceDoc, Activity } from '../shared/types.ts';
import { toMin } from '../shared/time.ts';

export interface OperatorFile {
  company: string;
  registrationScope: string;
  permittedUses: Activity[];
  documents: ComplianceDoc[];
}
export type UserRecord = User & { operatorFile?: OperatorFile };

// ---------- users
export const getUser = (id: string) => parse<UserRecord>(one('SELECT data FROM users WHERE id = ?', id));
export const getUserByEmail = (email: string) => {
  const r = one('SELECT id, pw, data FROM users WHERE email = ?', email.toLowerCase().trim());
  return r ? { user: JSON.parse(r.data as string) as UserRecord, pw: r.pw as string } : undefined;
};
export const saveUser = (u: UserRecord, pw?: string) => {
  if (pw) run('INSERT OR REPLACE INTO users (id, role, email, pw, data) VALUES (?, ?, ?, ?, ?)', u.id, u.role, u.email.toLowerCase(), pw, JSON.stringify(u));
  else run('UPDATE users SET data = ?, email = ? WHERE id = ?', JSON.stringify(u), u.email.toLowerCase(), u.id);
};
export const usersByRole = (role: string) => parseAll<UserRecord>(all('SELECT data FROM users WHERE role = ?', role));
export const publicUser = (u: UserRecord | undefined) => (u ? { id: u.id, name: u.name, role: u.role, company: u.company, avatarUrl: u.avatarUrl } : null);

// ---------- properties
// Older databases may hold Unsplash URLs for sample photos; serve the local copies instead (read-time only).
const withLocalPhotos = (p: Property | undefined) => (p ? { ...p, images: p.images.map(localPhoto) } : p);
export const getProperty = (id: string) => withLocalPhotos(parse<Property>(one('SELECT data FROM properties WHERE id = ?', id)));
export const saveProperty = (p: Property) =>
  run('INSERT OR REPLACE INTO properties (id, owner_id, manager_id, status, data, updated_at) VALUES (?, ?, ?, ?, ?, ?)', p.id, p.ownerId, p.managerId, p.status, JSON.stringify(p), Date.now());
export const propertiesWhere = (where: string, ...args: unknown[]) => parseAll<Property>(all(`SELECT data FROM properties WHERE ${where} ORDER BY updated_at DESC`, ...args)).map((p) => withLocalPhotos(p)!);

// ---------- bookings
export const getBooking = (id: string) => parse<Booking>(one('SELECT data FROM bookings WHERE id = ?', id));
export const saveBooking = (b: Booking) =>
  run('INSERT OR REPLACE INTO bookings (id, property_id, guest_id, date, start_min, end_min, status, data, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    b.id, b.propertyId, b.guestId, b.date, toMin(b.start), toMin(b.end), b.status, JSON.stringify(b), b.createdAt, b.updatedAt);
export const bookingsWhere = (where: string, ...args: unknown[]) => parseAll<Booking>(all(`SELECT data FROM bookings WHERE ${where} ORDER BY date, start_min`, ...args));
export const activeBookingsFor = (propertyId: string) => bookingsWhere("property_id = ? AND status IN ('pending','confirmed')", propertyId);

// ---------- calendar objects
export const slotsFor = (propertyId: string) => parseAll<Slot>(all('SELECT data FROM slots WHERE property_id = ? ORDER BY date', propertyId));
export const saveSlot = (s: Slot) => run('INSERT OR REPLACE INTO slots (id, property_id, date, data) VALUES (?, ?, ?, ?)', s.id, s.propertyId, s.date, JSON.stringify(s));
export const deleteSlot = (id: string) => run('DELETE FROM slots WHERE id = ?', id);
export const blocksFor = (propertyId: string) => parseAll<Block>(all('SELECT data FROM blocks WHERE property_id = ? ORDER BY date', propertyId));
export const saveBlock = (b: Block) => run('INSERT OR REPLACE INTO blocks (id, property_id, date, data) VALUES (?, ?, ?, ?)', b.id, b.propertyId, b.date, JSON.stringify(b));
export const deleteBlock = (id: string) => run('DELETE FROM blocks WHERE id = ?', id);
export const staysFor = (propertyId: string) => parseAll<Stay>(all('SELECT data FROM stays WHERE property_id = ?', propertyId));
export const saveStay = (s: Stay) => run('INSERT OR REPLACE INTO stays (id, property_id, data) VALUES (?, ?, ?)', s.id, s.propertyId, JSON.stringify(s));

// ---------- cleaning
export const providersFor = (managerId: string) => parseAll<CleaningProvider>(all('SELECT data FROM providers WHERE manager_id = ?', managerId));
export const getProvider = (id: string) => parse<CleaningProvider>(one('SELECT data FROM providers WHERE id = ?', id));
export const saveProvider = (p: CleaningProvider) => run('INSERT OR REPLACE INTO providers (id, manager_id, data) VALUES (?, ?, ?)', p.id, p.managerId, JSON.stringify(p));
export const getTask = (id: string) => parse<CleaningTask>(one('SELECT data FROM tasks WHERE id = ?', id));
export const taskForBooking = (bookingId: string) => parse<CleaningTask>(one('SELECT data FROM tasks WHERE booking_id = ?', bookingId));
export const saveTask = (t: CleaningTask) => run('INSERT OR REPLACE INTO tasks (id, booking_id, property_id, data) VALUES (?, ?, ?, ?)', t.id, t.bookingId, t.propertyId, JSON.stringify(t));
export const tasksForProperties = (ids: string[]) =>
  ids.length ? parseAll<CleaningTask>(all(`SELECT data FROM tasks WHERE property_id IN (${ids.map(() => '?').join(',')})`, ...ids)) : [];

// ---------- notifications & email outbox
export const saveNotification = (n: Notification) => run('INSERT INTO notifications (id, user_id, data, created_at, read) VALUES (?, ?, ?, ?, 0)', n.id, n.userId, JSON.stringify(n), n.at);
export const notificationsFor = (userId: string, limit = 40) =>
  all('SELECT data, read FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?', userId, limit).map((r) => ({ ...(JSON.parse(r.data as string) as Notification), read: !!r.read }));
export const saveEmail = (e: EmailRecord) => run('INSERT OR REPLACE INTO emails (id, user_id, data, created_at) VALUES (?, ?, ?, ?)', e.id, e.userId, JSON.stringify(e), e.at);
export const emailsFor = (userId: string) => parseAll<EmailRecord>(all('SELECT data FROM emails WHERE user_id = ? ORDER BY created_at DESC LIMIT 30', userId));
