import { uid } from './db.ts';
import { saveEmail } from './repo.ts';
import type { EmailRecord } from '../shared/types.ts';

/**
 * Transactional email. With RESEND_API_KEY + EMAIL_FROM set, emails are sent through Resend.
 * EMAIL_TEST_RECIPIENT redirects every message to one authorised test inbox (sandbox mode).
 * Without credentials, emails are stored as previews and shown in-app as "not sent".
 */
export async function sendEmail(userId: string, to: string, subject: string, html: string) {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  const testTo = process.env.EMAIL_TEST_RECIPIENT;
  const rec: EmailRecord = { id: uid('em'), userId, to, subject, html, status: 'preview', provider: 'none', at: Date.now() };
  const target = testTo || (to.endsWith('.demo') ? '' : to);
  if (key && from && target) {
    try {
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from, to: [target], subject, html }),
      });
      rec.provider = 'resend';
      rec.status = res.ok ? 'sent' : 'failed';
      if (testTo) rec.to = `${to} → ${testTo} (test inbox)`;
      if (!res.ok) rec.error = (await res.text()).slice(0, 300);
    } catch (e) {
      rec.provider = 'resend';
      rec.status = 'failed';
      rec.error = String(e).slice(0, 300);
    }
  }
  saveEmail(rec);
  return rec;
}

export const emailLayout = (title: string, body: string) => `<!doctype html><html><body style="margin:0;background:#F8F6F0;font-family:Space Grotesk,Arial,sans-serif;color:#161D35">
<div style="max-width:520px;margin:0 auto;padding:24px">
<div style="font-weight:700;font-style:italic;font-size:20px;letter-spacing:-.01em;text-transform:uppercase">Space<span style="color:#4062E8">Time</span></div>
<h1 style="font-size:22px;margin:18px 0 8px">${title}</h1>
<div style="background:#fff;border-radius:14px;padding:18px;font-size:14px;line-height:1.55">${body}</div>
<p style="font-size:11px;color:#5C6690;margin-top:16px">SpaceTime — Your space. Your time.</p></div></body></html>`;
