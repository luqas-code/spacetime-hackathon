import { db, run, uid } from './db.ts';
import * as R from './repo.ts';
import type { UserRecord } from './repo.ts';
import { LEGACY } from './seedProperties.ts';
import { hashPassword } from './auth.ts';
import type { Booking, CleaningProvider, Compliance, ComplianceDoc, Delegation, Property, Stay, User, UserPrefs } from '../shared/types.ts';
import { addDays, isoDate, toHHMM, toMin } from '../shared/time.ts';
import { calcEconomics } from '../shared/economics.ts';

export const DEMO_PASSWORD = 'spacetime';

const basePrefs = (): UserPrefs => ({
  onboarded: true, favourites: [], savedSearches: [], locations: [], interests: [], household: { kids: false, pets: false },
  accessibility: [], budgetMax: 40, walkingMins: 15, quiet: false, instantBookOnly: false, pushNotifications: true, emailUpdates: true,
});

function user(id: string, role: User['role'], name: string, email: string, extra: Partial<UserRecord> = {}): UserRecord {
  return { id, role, name, email, phone: '', company: '', bio: '', avatarUrl: '', lang: 'en', memberSince: 2025, prefs: basePrefs(), ...extra };
}

const VERIFIED = { verifiedAt: '2026-11-12', verifiedBy: 'R. Lefèvre — SpaceTime Compliance' };
const S_FILE: ComplianceDoc[] = [
  { id: 'doc_s_reg', type: 'registration', name: 'Déclaration meublé de tourisme — n° 75112 000 123 AB (Ville de Paris)', source: 'on_file', ...VERIFIED },
  { id: 'doc_s_cu', type: 'change_of_use', name: "Autorisation de changement d'usage CU-2024-0412 (avec compensation)", source: 'on_file', ...VERIFIED },
  { id: 'doc_s_ins', type: 'insurance', name: 'Assurance PNO & RC exploitation — couvre location en journée (police 4410 7782)', source: 'on_file', ...VERIFIED },
  { id: 'doc_s_build', type: 'building_rules', name: 'Règlement de copropriété — usage professionnel & courte durée autorisés', source: 'on_file', ...VERIFIED },
  { id: 'doc_s_own', type: 'owner_authorisation', name: 'Mandat de gestion — Laurent Résidences SAS / Nestwell Conciergerie', source: 'on_file', ...VERIFIED },
  { id: 'doc_s_dpe', type: 'dpe', name: 'DPE — classe C (valide jusqu’en 2033)', source: 'on_file', ...VERIFIED },
];

export function approvedCompliance(docs: ComplianceDoc[], reg: string, basis: 'verified_file' | 'manual_review'): Compliance {
  return {
    usage: 'tourist_furnished', registrationNumber: reg, changeOfUse: 'granted', changeOfUseRef: 'CU-2024-0412', ownerAuthorised: true,
    buildingAllowsDaytime: 'yes', buildingNotes: '', insurer: 'AXA France', insurancePolicy: '4410 7782', insuranceCoversDaytime: true, dpeGrade: 'C',
    restrictions: '', documents: docs, attestation: true,
    review: { status: 'approved', basis, reviewer: 'R. Lefèvre — SpaceTime Compliance', at: '2026-11-12', checks: [] },
  };
}

const ADDRESSES: Record<string, string> = {
  'st-republique-canal': '14 rue Léon Jouhaux, 75010 Paris', 'st-gare-lyon-family': '9 rue de Chalon, 75012 Paris',
  'st-bastille-studio': '31 rue de la Roquette, 75011 Paris', 'st-opera-haussmann': '22 rue de la Chaussée-d’Antin, 75009 Paris',
  'st-marais-chef': '7 rue Charlot, 75003 Paris', 'st-gare-nord-layover': '18 rue de Dunkerque, 75010 Paris',
  'st-montmartre-atelier': '11 rue Lepic, 75018 Paris', 'st-belleville-terrace': '40 rue de Belleville, 75020 Paris',
  'st-canal-garden-house': '5 rue de Lancry, 75010 Paris', 'st-saint-germain-library': '16 rue de Tournon, 75006 Paris',
  'st-bercy-rehearsal': '3 cour Saint-Émilion, 75012 Paris', 'st-oberkampf-social': '52 rue Oberkampf, 75011 Paris',
  'st-montparnasse-nap': '6 rue du Départ, 75014 Paris', 'st-batignolles-family-house': '24 rue des Batignolles, 75017 Paris',
  'st-latin-spa': '12 rue Monge, 75005 Paris', 'st-station-f-work': '8 rue Eugène Freyssinet, 75013 Paris',
  'st-chatelet-focus': '15 rue Saint-Denis, 75001 Paris', 'st-nation-baking': '4 avenue de Taillebourg, 75011 Paris',
};

export function seed() {
  const already = db.prepare("SELECT v FROM meta WHERE k = 'seeded'").get();
  if (already) return false;
  const pw = hashPassword(DEMO_PASSWORD);
  const S = user('u_owner_s', 'owner', 'Sophie Laurent', 'sophie@spacetime.demo', {
    company: 'Laurent Résidences SAS', avatarUrl: '/avatars/owner-s.svg', phone: '+33 6 12 00 00 01', memberSince: 2025,
    bio: 'Professional operator of furnished tourist apartments in the 10e, 11e and 12e.',
    operatorFile: { company: 'Laurent Résidences SAS', registrationScope: '75112 000 123 AB', permittedUses: ['rest', 'work', 'meeting', 'cooking', 'family', 'relax', 'layover', 'creative', 'wellness', 'photo'], documents: S_FILE },
  });
  const H = user('u_owner_h', 'owner', 'Henri Duval', 'henri@spacetime.demo', { company: 'Duval Patrimoine', avatarUrl: '' });
  const C = user('u_owner_c', 'owner', 'Clara Nguyen', 'clara@spacetime.demo', { company: 'Nguyen Studios', avatarUrl: '' });
  const M = user('u_mgr_m', 'manager', 'Malik Benali', 'malik@spacetime.demo', { company: 'Nestwell Conciergerie', avatarUrl: '/avatars/manager-m.svg', phone: '+33 6 12 00 00 02', memberSince: 2024, bio: 'Portfolio manager — guest experience, cleaning and pricing for furnished apartments across Paris.' });
  const M2 = user('u_mgr_2', 'manager', 'Léa Fontaine', 'lea@spacetime.demo', { company: 'Rive Hosting', avatarUrl: '' });
  const I = user('u_guest_i', 'guest', 'Isaac Bernard', 'isaac@spacetime.demo', {
    avatarUrl: '/avatars/guest-i.svg', phone: '+33 6 12 00 00 03', memberSince: 2026, bio: 'Product consultant, often between trains.',
    prefs: { ...basePrefs(), interests: ['work', 'rest', 'layover', 'family'], household: { kids: true, pets: false },
      locations: [
        { id: 'loc-home', tag: 'home', name: 'Home', label: 'Oberkampf', sub: 'Area · 11e', lat: 48.8650, lng: 2.3775, kind: 'area' },
        { id: 'loc-work', tag: 'work', name: 'Work', label: 'Grands Boulevards', sub: 'Area · 2e / 9e', lat: 48.8715, lng: 2.3430, kind: 'area' },
      ], favourites: ['st-saint-germain-library'] },
  });
  const P = user('u_guest_p', 'guest', 'Priya Shah', 'priya@spacetime.demo');
  const T = user('u_guest_t', 'guest', 'Tom Walker', 'tom@spacetime.demo');
  const RV = user('u_rev_r', 'reviewer', 'Romane Lefèvre', 'review@spacetime.demo', { company: 'SpaceTime Trust & Compliance', avatarUrl: '/avatars/reviewer-r.svg' });
  for (const u of [S, H, C, M, M2, I, P, T, RV]) R.saveUser(u, pw);

  const providers: CleaningProvider[] = [
    { id: 'cp_eclat', managerId: M.id, name: 'Éclat Ménage Paris', phone: '+33 1 40 00 00 11', email: 'planning@eclat.example', ratePerHour: 28, workStart: '07:00', workEnd: '20:00' },
    { id: 'cp_pronet', managerId: M.id, name: 'ProNet Services 11e', phone: '+33 1 40 00 00 12', email: 'ops@pronet.example', ratePerHour: 26, workStart: '08:00', workEnd: '19:00' },
    { id: 'cp_cleango', managerId: M.id, name: 'Clean&Go Rive Droite', phone: '+33 1 40 00 00 13', email: 'hello@cleango.example', ratePerHour: 30, workStart: '06:00', workEnd: '22:00' },
    { id: 'cp_rive', managerId: M2.id, name: 'Rive Propreté', phone: '+33 1 40 00 00 14', email: 'contact@rive.example', ratePerHour: 27, workStart: '08:00', workEnd: '20:00' },
  ];
  providers.forEach(R.saveProvider);

  const assign: Record<string, [string, string]> = {
    'st-republique-canal': [S.id, M.id], 'st-gare-lyon-family': [S.id, M.id], 'st-marais-chef': [S.id, M.id], 'st-gare-nord-layover': [S.id, M.id],
    'st-opera-haussmann': [H.id, M.id], 'st-latin-spa': [H.id, M.id], 'st-bastille-studio': [H.id, M.id],
  };
  const overnight: Record<string, number> = { 'st-republique-canal': 135, 'st-gare-lyon-family': 165, 'st-gare-nord-layover': 120, 'st-latin-spa': 150 };
  const now = Date.now();
  const props: Property[] = LEGACY.map((l, i) => {
    const [ownerId, managerId] = assign[l.id] ?? [i % 2 ? H.id : C.id, M2.id];
    const delegation: Delegation = { availability: true, pricing: true, priceFloor: Math.round(l.pricePerHour * 0.8), approveBookings: true, cleaning: true, messaging: true, mgmtFeePct: 20 };
    const isS = ownerId === S.id;
    const p: Property = {
      id: l.id, title: l.title, shortTitle: l.shortTitle, type: l.type, neighbourhood: l.neighbourhood, arrondissement: l.arrondissement,
      address: ADDRESSES[l.id] ?? 'Paris', lat: l.lat, lng: l.lng, images: l.images, description: l.description, highlights: l.highlights,
      amenities: [...l.amenities, ...(l.amenities.includes('ac') ? [] : ['heating'])], accessibility: l.accessibility, activities: l.activities,
      capacity: l.capacity, sizeM2: l.sizeM2, floor: l.floor, pricePerHour: l.pricePerHour, minBookingPrice: l.pricePerHour * Math.max(2, l.minHours),
      cleaningFee: l.cleaningFee, otherCharges: [], minHours: Math.max(1, l.minHours), maxHours: l.maxHours, bufferMins: l.cleaningFee >= 25 ? 90 : 60,
      petsAllowed: l.petsAllowed, childrenAllowed: l.childrenAllowed, rules: l.rules, checkout: l.checkout,
      checkinInstructions: 'Self check-in: enter the door code at the street keypad, then use the same code on the key box beside the apartment door.',
      availability: l.availability, ownerWindows: l.availability,
      overnight: { enabled: !!overnight[l.id], channel: overnight[l.id] ? (i % 2 ? 'Booking.com' : 'Airbnb') : '', checkin: '16:00', checkout: '11:00', nightlyRate: overnight[l.id] ?? 0, channelFeePct: 15 },
      rating: l.rating, reviewCount: l.reviewCount, reviews: l.reviews,
      partner: { name: '', company: '', since: 2024, responseMins: l.partner.responseMins, superPartner: l.partner.superPartner, languages: l.partner.languages },
      instantBook: l.instantBook, status: 'published', ownerId, managerId,
      compliance: isS ? approvedCompliance(S_FILE, '75112 000 123 AB', 'verified_file') : approvedCompliance([{ id: uid('doc'), type: 'registration', name: 'Registration certificate', source: 'upload', ...VERIFIED }], `75${100 + i} 000 ${400 + i} XY`, 'manual_review'),
      delegation, cleaningProviderId: managerId === M.id ? (i % 2 ? 'cp_eclat' : 'cp_pronet') : 'cp_rive', createdAt: now - 60 * 86400000, publishedAt: now - 50 * 86400000,
    };
    R.saveProperty(p);
    return p;
  });

  // Overnight stays imported from the property's other channel (sample calendar)
  const today = isoDate(new Date());
  const stay = (pid: string, from: number, nights: number, channel: string, label: string, rate: number) => {
    const s: Stay = { id: uid('st'), propertyId: pid, checkinDate: addDays(today, from), checkoutDate: addDays(today, from + nights), channel, guestLabel: label, nightlyRate: rate };
    R.saveStay(s);
  };
  stay('st-republique-canal', -2, 2, 'Airbnb', 'A. Rossi (2 guests)', 135);
  stay('st-republique-canal', 3, 3, 'Airbnb', 'K. Tanaka (1 guest)', 135);
  stay('st-gare-lyon-family', 0, 1, 'Booking.com', 'Famille Martin (4)', 165);
  stay('st-gare-lyon-family', 4, 2, 'Booking.com', 'J. Okafor (3)', 165);
  stay('st-gare-nord-layover', 1, 2, 'Airbnb', 'E. Novak (1)', 120);
  stay('st-latin-spa', 2, 4, 'Booking.com', 'M. García (2)', 150);

  // Bookings
  const mk = (pid: string, guest: UserRecord, dayOffset: number, start: string, hours: number, status: Booking['status'], adults = 1, purpose?: Booking['purpose'], note?: string) => {
    const p = props.find((x) => x.id === pid)!;
    const date = addDays(today, dayOffset);
    const b: Booking = {
      id: uid('bk'), propertyId: pid, guestId: guest.id, guestName: guest.name, guestAvatar: guest.avatarUrl, date, start, end: toHHMM(toMin(start) + hours * 60), hours,
      guests: { adults, children: 0, infants: 0, pets: 0 }, purpose: purpose ?? p.activities[0], note, price: calcEconomics(p, hours),
      accessCode: String(100000 + Math.floor(Math.random() * 899999)), status, opsStatus: dayOffset < 0 ? 'checked_out' : 'awaiting',
      createdAt: now - (dayOffset < 0 ? 10 : 1) * 86400000, updatedAt: now,
    };
    R.saveBooking(b);
    if (status === 'confirmed') {
      R.saveTask({ id: uid('cl'), bookingId: b.id, propertyId: pid, providerId: dayOffset === 2 ? null : p.cleaningProviderId, date, start: b.end, deadline: toHHMM(toMin(b.end) + p.bufferMins), durationMins: Math.max(30, p.bufferMins - 15), status: dayOffset < 0 ? 'completed' : dayOffset === 2 ? 'unassigned' : 'scheduled', notes: '', updatedAt: now });
    }
    return b;
  };
  // Previous month — gives the owner dashboard's "Last month" period real figures to report.
  const dom = Number(today.slice(8, 10));
  mk('st-marais-chef', P, -(dom + 6), '11:00', 4, 'confirmed', 4, 'cooking');
  mk('st-republique-canal', T, -(dom + 13), '09:00', 6, 'confirmed', 1, 'work');
  mk('st-gare-nord-layover', I, -9, '06:00', 4, 'confirmed', 1, 'layover');
  mk('st-opera-haussmann', I, -23, '09:00', 4, 'confirmed', 6, 'meeting');
  mk('st-republique-canal', P, -3, '13:00', 3, 'confirmed', 1, 'work');
  mk('st-marais-chef', T, -2, '10:00', 5, 'confirmed', 6, 'cooking');
  mk('st-latin-spa', P, -6, '14:00', 3, 'confirmed', 1, 'wellness');
  mk('st-bastille-studio', T, -1, '15:00', 2, 'confirmed', 1, 'rest');
  const b1 = mk('st-republique-canal', P, 1, '10:00', 3, 'confirmed', 1, 'work', 'I may arrive with a small suitcase.');
  mk('st-opera-haussmann', T, 2, '09:00', 4, 'confirmed', 6, 'meeting', 'Team workshop — we will bring pastries.');
  const pend = mk('st-opera-haussmann', P, 3, '14:00', 3, 'pending', 4, 'meeting', 'Client meeting, could we use the screen?');

  // Conversations
  const conv = (kind: 'guest' | 'owner', pid: string, guestId: string | null, bookingId: string | null, msgs: [string, string, number][]) => {
    const id = uid('cv');
    run('INSERT INTO conversations (id, kind, property_id, guest_id, booking_id, created_at) VALUES (?, ?, ?, ?, ?, ?)', id, kind, pid, guestId, bookingId, now - 30 * 86400000);
    for (const [sender, body, ago] of msgs) {
      const role = sender === 'system' ? 'system' : sender.startsWith('u_mgr') ? 'manager' : sender.startsWith('u_owner') ? 'owner' : 'guest';
      run('INSERT INTO messages (id, conversation_id, sender_id, sender_role, body, created_at) VALUES (?, ?, ?, ?, ?, ?)', uid('m'), id, sender, role, body, now - ago);
    }
    // participants have read everything except the last message
    return id;
  };
  const Hh = 3600000;
  const cvI = conv('guest', 'st-gare-nord-layover', I.id, null, [
    ['system', 'Booking confirmed · Layover suite · Gare du Nord', 10 * 24 * Hh],
    [M.id, 'Bonjour Isaac! Your code works from 05:45. Coffee pods are in the top drawer ☕', 9.6 * 24 * Hh],
    [I.id, 'Merci! Is it ok if I leave my suitcase until 10:30?', 9.5 * 24 * Hh],
    [M.id, 'Of course, no extra charge. Bon voyage!', 9.45 * 24 * Hh],
  ]);
  conv('guest', 'st-republique-canal', P.id, b1.id, [
    ['system', 'Booking confirmed · Quiet flat by République', 20 * Hh],
    [P.id, 'Hello! Is there somewhere I can leave a small suitcase during my booking tomorrow?', 2 * Hh],
  ]);
  conv('guest', 'st-opera-haussmann', P.id, pend.id, [
    ['system', 'Booking request · Haussmann meeting salon · awaiting approval', 5 * Hh],
    [P.id, 'Client meeting, could we use the screen?', 5 * Hh],
  ]);
  const cvS = conv('owner', 'st-republique-canal', null, null, [
    [S.id, 'Hi Malik — happy for République to run daytime slots on weekdays when there is no overnight check-in.', 6 * 24 * Hh],
    [M.id, 'Perfect. I will keep a 60-minute turnover buffer and only open windows that end before the 16:00 check-in.', 5.9 * 24 * Hh],
    [S.id, 'Great, thanks. Please keep me posted on the monthly numbers.', 5.8 * 24 * Hh],
  ]);
  const markRead = (convId: string, userIds: string[]) => userIds.forEach((u) => run('INSERT OR REPLACE INTO reads (conversation_id, user_id, at) VALUES (?, ?, ?)', convId, u, now));
  markRead(cvI, [I.id, M.id]);
  markRead(cvS, [S.id, M.id]);

  run("INSERT OR REPLACE INTO meta (k, v) VALUES ('seeded', ?)", new Date().toISOString());
  return true;
}

export function resetDatabase() {
  for (const t of ['sessions', 'users', 'properties', 'bookings', 'slots', 'blocks', 'stays', 'providers', 'tasks', 'conversations', 'messages', 'reads', 'notifications', 'emails', 'meta']) run(`DELETE FROM ${t}`);
  return seed();
}
