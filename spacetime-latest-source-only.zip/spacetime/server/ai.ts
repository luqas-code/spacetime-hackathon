import Anthropic from '@anthropic-ai/sdk';
import { betaZodOutputFormat } from '@anthropic-ai/sdk/helpers/beta/zod';
import { z } from 'zod';
import { parseIntent, type ParsedIntent } from '../shared/nlu.ts';
import { findPlaceInText, PLACES } from '../shared/places.ts';
import { explainCandidate, type Assumptions, type Candidate } from '../shared/optimiser.ts';
import { isoDate } from '../shared/time.ts';

/** Claude is used only when ANTHROPIC_API_KEY is set on the server; the key never reaches the browser. */
const enabled = () => !!process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.ANTHROPIC_MODEL || 'claude-opus-5-5';
let client: Anthropic | null = null;
const getClient = () => (client ??= new Anthropic());

export const aiStatus = () => ({ engine: enabled() ? 'claude' : 'rules', model: enabled() ? MODEL : null });

const AMENITY_IDS = ['wifi', 'shower', 'bed', 'sofa_bed', 'kitchen', 'oven', 'desk', 'monitor', 'whiteboard', 'projector', 'tv', 'terrace', 'garden', 'bbq_grill', 'bathtub', 'towels', 'luggage', 'crib', 'high_chair', 'toys', 'blackout', 'soundproof', 'elevator', 'parking', 'piano', 'ac', 'heating'] as const;
const ACTIVITY_IDS = ['rest', 'work', 'meeting', 'party', 'bbq', 'cooking', 'creative', 'rehearsal', 'family', 'relax', 'layover', 'photo', 'wellness'] as const;
const ACCESS_IDS = ['step_free', 'elevator', 'wide_doors', 'accessible_bathroom', 'ground_floor', 'low_sensory'] as const;

const IntentSchema = z.object({
  locationText: z.string().nullable().describe('Place, station, landmark, neighbourhood or arrondissement in Paris mentioned by the user, or "home"/"work" if they refer to those; null if none.'),
  date: z.string().nullable().describe('YYYY-MM-DD of the booking day, resolved relative to "now"; null if the user did not say.'),
  start: z.string().nullable().describe('HH:MM 24h start time; null if not stated.'),
  end: z.string().nullable().describe('HH:MM 24h end time; null if not stated.'),
  durationHours: z.number().nullable(),
  adults: z.number().int(),
  children: z.number().int(),
  infants: z.number().int(),
  pets: z.number().int(),
  needs: z.array(z.enum(AMENITY_IDS)).describe('Only amenities the user actually needs.'),
  activities: z.array(z.enum(ACTIVITY_IDS)),
  accessibility: z.array(z.enum(ACCESS_IDS)),
  budgetMaxPerHour: z.number().nullable(),
  quiet: z.boolean(),
  assumptions: z.array(z.string()).describe('Short notes on anything you had to assume (e.g. "Assumed 1 adult").'),
});

export async function parseWithAI(text: string, previous: ParsedIntent | undefined, lang: 'en' | 'fr'): Promise<{ intent: ParsedIntent; engine: 'claude' | 'rules' }> {
  const now = new Date();
  if (!enabled()) return { intent: parseIntent(text, now, previous), engine: 'rules' };
  try {
    // Server-side refusal fallbacks are enabled (routes a declined request to a fallback model).
    const response = await getClient().beta.messages.parse({
      model: MODEL,
      max_tokens: 4000,
      betas: ['server-side-fallback-2026-07-01'],
      fallbacks: 'default',
      output_config: { effort: 'low', format: betaZodOutputFormat(IntentSchema) },
      system: `You extract booking requirements for SpaceTime, a Paris app for booking private apartments by the hour. Extract only what the user said or clearly implied; never invent requirements. Known Paris places include: ${PLACES.filter((p) => p.kind !== 'arrondissement').map((p) => p.label).join(', ')}. Count the speaker as one adult unless they say otherwise. Write assumptions in ${lang === 'fr' ? 'French' : 'English'}.`,
      messages: [
        { role: 'user', content: `Now: ${now.toString()} (today is ${isoDate(now)}, Europe/Paris).\n${previous ? `Earlier extracted requirements (merge, the new message refines them): ${JSON.stringify({ ...previous, location: undefined })}\n` : ''}User message: ${text}` },
      ],
    });
    const o = response.parsed_output;
    if (response.stop_reason === 'refusal' || !o) return { intent: parseIntent(text, now, previous), engine: 'rules' };
    const place = o.locationText && !['home', 'work'].includes(o.locationText) ? findPlaceInText(o.locationText) : undefined;
    const it: ParsedIntent = {
      location: place, locationText: o.locationText ?? undefined, date: o.date ?? undefined, start: o.start ?? undefined, end: o.end ?? undefined,
      durationHours: o.durationHours ?? undefined, adults: Math.max(1, o.adults), children: o.children, infants: o.infants, pets: o.pets,
      needs: [...o.needs], activities: [...o.activities], accessibility: [...o.accessibility], budgetMax: o.budgetMaxPerHour ?? undefined, quiet: o.quiet,
      assumptions: o.assumptions, missing: [],
    };
    if (it.start && it.end && !it.durationHours) it.durationHours = Math.max(1, (toM(it.end) - toM(it.start)) / 60);
    if (!it.date) it.missing.push('date');
    if (!it.start) it.missing.push('time');
    if (!it.location && !it.locationText) it.missing.push('location');
    return { intent: it, engine: 'claude' };
  } catch (e) {
    console.warn('[ai] parse failed, using rules:', e instanceof Anthropic.APIError ? `${e.status} ${e.message}` : e);
    return { intent: parseIntent(text, now, previous), engine: 'rules' };
  }
}
const toM = (t: string) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5));

export async function explainWithAI(c: Candidate, a: Assumptions, lang: 'en' | 'fr'): Promise<{ text: string; engine: 'claude' | 'rules' }> {
  const facts = explainCandidate(c, a, lang);
  if (!enabled()) return { text: facts, engine: 'rules' };
  try {
    const response = await getClient().beta.messages.create({
      model: MODEL,
      max_tokens: 2000,
      betas: ['server-side-fallback-2026-07-01'],
      fallbacks: 'default',
      output_config: { effort: 'low' },
      system: `You explain daytime-rental recommendations to a professional property manager in ${lang === 'fr' ? 'French' : 'English'}. Use only the numbers provided. Never invent probabilities, demand data or figures. Mention that likelihoods are scenario assumptions. 2–3 short sentences, no headings.`,
      messages: [{ role: 'user', content: `Computed analysis (JSON): ${JSON.stringify({ candidate: c, assumptions: a })}\nDeterministic summary: ${facts}` }],
    });
    if (response.stop_reason === 'refusal') return { text: facts, engine: 'rules' };
    const text = response.content.map((b) => (b.type === 'text' ? b.text : '')).join('').trim();
    return { text: text || facts, engine: text ? 'claude' : 'rules' };
  } catch (e) {
    console.warn('[ai] explain failed, using rules:', e instanceof Anthropic.APIError ? `${e.status} ${e.message}` : e);
    return { text: facts, engine: 'rules' };
  }
}
