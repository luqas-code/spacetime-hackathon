// Imported first: all server-side dates are Paris local time.
process.env.TZ = process.env.TZ || 'Europe/Paris';
export {};
