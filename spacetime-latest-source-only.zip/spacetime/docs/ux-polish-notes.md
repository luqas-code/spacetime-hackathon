# UX polish — what changed (21 Nov 2026)

Screenshots of the main changes: `docs/screenshots/after/`. Brand assets and a preview page: `public/brand/` (open `/brand/index.html` on a running server).

## Where to change things
| What | Where |
|---|---|
| Commission / guest-fee rates (single source) | `shared/economics.ts` → `RATES`. The proposed 15 % / no guest fee is documented there; a guest fee of 0 hides the guest-fee row everywhere. |
| Logo (white for dark backgrounds, navy for light) | `public/brand/spacetime-wordmark-white.png` / `-navy.png`, used via `src/components/Logo.tsx`; icon + favicon built from its “s” (`public/brand/icon-*.png`, `public/favicon.png`, `public/apple-touch-icon.png`) |
| Short bottom-nav labels | `nav:` keys in `src/components/BottomNav.tsx`; French overrides in `src/i18n.fr.ts` (fall back to the normal translation) |
| Sample photos | `public/photos/<id>.jpg`, referenced via `shared/samplePhotos.ts` |
| Map of Paris (illustration: river, parks, avenues, stations, labels) | `src/components/parisMap.ts`; rendering in `src/components/MapView.tsx` |
| Carousel behaviour | `.rail` in `src/index.css` |

## Behaviour changes
- **Owner earnings**: `GET /api/owner/overview?period=this_month|last_month|all` filters confirmed + completed bookings by *scheduled date*. Pending requests are reported separately and never counted; declined/cancelled are excluded. A month-on-month comparison is shown only when the previous month has bookings. Seed data now includes two October bookings so “Last month” has real figures.
- **Language**: chosen on first-run onboarding (all roles; demo accounts are already onboarded and keep their saved language) and in Profile → Settings → Language. Saved to the account (`lang`, `prefs.langChosen`); the account’s language wins at sign-in on any device. The sign-in screen keeps a small English/Français link for reading that screen only.
- **AI match**: when children are mentioned without a number of adults (including “we …”), the assistant asks. Confirmed guests, date, time and purpose are copied into the search state, so results, listing, booking form, confirmation and the manager’s reservation all show the same details. Cards show “Meets X of Y must-haves”, “Why this matches” and “Missing” instead of a match percentage.
- **Smart Availability**: same optimiser maths; the card now answers “safe?”, “worthwhile?” and “next step” first, with the full breakdown under “Why this recommendation?”. “Scenario assumptions” is now “Adjust assumptions”.
- **Manager navigation**: Smart → Opportunities, Inbox → Messages; property screen uses four fixed tabs + a settings gear (no sideways scrolling).
- **Photos**: the 43 sample photos (Unsplash licence) are stored in `public/photos/` (≈7 MB) and served by the app, so demo listings no longer depend on an external image host. Older databases that still hold Unsplash URLs are mapped to the local copies when listings are read (`shared/samplePhotos.ts` → `localPhoto`); owner uploads under `/uploads/` are untouched. Images retry once and otherwise show a branded placeholder.
- **Map**: the Leaflet/CARTO tile map was replaced by a self-contained illustrated map of Paris (no tiles, no API, works offline). Listing markers, search radius and pins use real coordinates; the basemap is a simplified illustration and is labelled “Illustrative map”. Drag, zoom buttons, fit-to-results and marker taps still work. `leaflet`/`react-leaflet` are no longer imported (still listed in package.json; safe to remove).
- **Toasts** appear at the top, can be dismissed, and errors stay ~9 s.

## Deferred / not done
- Language changed on one device applies to an already-open session on another device after its next reload/sign-in, not instantly.
- Bookings keep the fee figures stored when they were made; changing `RATES` affects new bookings only.
