export const pad = (n: number) => String(n).padStart(2, '0');
export const toMin = (hhmm: string) => {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + (m || 0);
};
export const toHHMM = (min: number) => {
  const m = Math.max(0, Math.min(24 * 60, Math.round(min)));
  return m === 24 * 60 ? '24:00' : `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
};
export const isoDate = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const parseISO = (s: string) => {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
};
export const addDays = (iso: string, n: number) => {
  const d = parseISO(iso);
  d.setDate(d.getDate() + n);
  return isoDate(d);
};
export const dow = (iso: string) => parseISO(iso).getDay();
export const minutesOf = (d: Date) => d.getHours() * 60 + d.getMinutes();
export const rangeDays = (from: string, n: number) => Array.from({ length: n }, (_, i) => addDays(from, i));

/** Subtract a list of ranges from a list of ranges. */
export function subtract(base: [number, number][], cut: [number, number][]): [number, number][] {
  let out = base.map((r) => [...r] as [number, number]);
  for (const [cs, ce] of cut) {
    const next: [number, number][] = [];
    for (const [s, e] of out) {
      if (ce <= s || cs >= e) next.push([s, e]);
      else {
        if (cs > s) next.push([s, cs]);
        if (ce < e) next.push([ce, e]);
      }
    }
    out = next;
  }
  return out;
}

export function merge(ranges: [number, number][]): [number, number][] {
  const sorted = [...ranges].filter(([s, e]) => e > s).sort((a, b) => a[0] - b[0]);
  const out: [number, number][] = [];
  for (const r of sorted) {
    const last = out[out.length - 1];
    if (last && r[0] <= last[1]) last[1] = Math.max(last[1], r[1]);
    else out.push([r[0], r[1]]);
  }
  return out;
}

export const overlaps = (a: [number, number], b: [number, number]) => a[0] < b[1] && b[0] < a[1];
