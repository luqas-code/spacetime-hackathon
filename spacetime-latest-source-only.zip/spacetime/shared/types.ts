// Shared domain model — used by the server (Node, type-stripped) and the web app.

export type Role = 'owner' | 'manager' | 'guest' | 'reviewer';
export type Lang = 'en' | 'fr';

export type PropertyType = 'apartment' | 'studio' | 'loft' | 'house' | 'room' | 'serviced' | 'aparthotel';

export type Activity =
  | 'rest' | 'work' | 'meeting' | 'party' | 'bbq' | 'cooking' | 'creative'
  | 'rehearsal' | 'family' | 'relax' | 'layover' | 'photo' | 'wellness';

export type Amenity =
  | 'wifi' | 'shower' | 'bed' | 'sofa_bed' | 'sofa' | 'kitchen' | 'pro_kitchen' | 'oven' | 'coffee'
  | 'desk' | 'monitor' | 'whiteboard' | 'tv' | 'projector' | 'speakers' | 'piano'
  | 'terrace' | 'garden' | 'bbq_grill' | 'balcony' | 'ac' | 'heating' | 'washer' | 'towels' | 'toiletries'
  | 'luggage' | 'crib' | 'high_chair' | 'toys' | 'baby_bath' | 'blackout' | 'soundproof'
  | 'elevator' | 'parking' | 'bathtub' | 'dining_table';

export type Accessibility =
  | 'step_free' | 'elevator' | 'wide_doors' | 'accessible_bathroom' | 'ground_floor' | 'low_sensory';

export interface WeeklyWindow {
  /** 0 = Sunday … 6 = Saturday */
  days: number[];
  start: string; // "08:00"
  end: string; // "22:00"
}

export type ListingStatus = 'draft' | 'in_review' | 'changes_requested' | 'approved' | 'published' | 'paused';

export interface ComplianceDoc {
  id: string;
  type: 'registration' | 'change_of_use' | 'owner_authorisation' | 'building_rules' | 'insurance' | 'dpe' | 'other';
  name: string;
  url?: string;
  /** 'on_file' = an operator document SpaceTime Compliance has already verified */
  source: 'upload' | 'on_file';
  verifiedAt?: string;
  verifiedBy?: string;
}

export interface Compliance {
  usage: 'tourist_furnished' | 'serviced_apartment' | 'aparthotel' | 'commercial' | 'residential_other';
  registrationNumber: string;
  changeOfUse: 'granted' | 'not_required' | 'pending' | 'unknown';
  changeOfUseRef: string;
  ownerAuthorised: boolean;
  buildingAllowsDaytime: 'yes' | 'no' | 'unknown';
  buildingNotes: string;
  insurer: string;
  insurancePolicy: string;
  insuranceCoversDaytime: boolean;
  dpeGrade: string;
  restrictions: string;
  documents: ComplianceDoc[];
  attestation: boolean;
  review?: ComplianceReview;
}

export interface ComplianceReview {
  status: 'pending' | 'approved' | 'changes_requested';
  basis?: 'verified_file' | 'manual_review';
  reviewer?: string;
  notes?: string;
  at?: string;
  checks: { key: string; ok: boolean; note?: string }[];
}

export interface Delegation {
  availability: boolean;
  pricing: boolean;
  priceFloor: number; // manager may not set hourly price below this
  approveBookings: boolean;
  cleaning: boolean;
  messaging: boolean;
  mgmtFeePct: number; // % of (gross − SpaceTime commission)
}

export interface OvernightSettings {
  /** Property is also let overnight through another channel (Airbnb, Booking.com…) */
  enabled: boolean;
  channel: string;
  checkin: string; // "16:00"
  checkout: string; // "11:00"
  nightlyRate: number;
  channelFeePct: number;
}

export interface Property {
  id: string;
  title: string;
  shortTitle: string;
  type: PropertyType;
  neighbourhood: string;
  arrondissement: string;
  /** full street address — shown to guests only after booking */
  address: string;
  lat: number;
  lng: number;
  images: string[];
  description: string;
  highlights: string[];
  amenities: Amenity[];
  accessibility: Accessibility[];
  activities: Activity[];
  capacity: { guests: number; beds: number; bathrooms: number };
  sizeM2: number;
  floor: string;
  pricePerHour: number;
  minBookingPrice: number;
  cleaningFee: number; // charged to guest at cost
  otherCharges: { label: string; amount: number }[];
  minHours: number;
  maxHours: number;
  bufferMins: number; // cleaning & turnover buffer after each daytime booking
  petsAllowed: boolean;
  childrenAllowed: boolean;
  rules: string[];
  checkout: string[];
  checkinInstructions: string;
  /** Standing, manager-approved weekly daytime windows */
  availability: WeeklyWindow[];
  /** Owner's allowed envelope for daytime use */
  ownerWindows: WeeklyWindow[];
  overnight: OvernightSettings;
  rating?: number;
  reviewCount?: number;
  reviews?: { name: string; text: string; rating: number; date: string; purpose: string }[];
  partner: { name: string; company: string; since: number; responseMins: number; superPartner: boolean; languages: string[]; avatar?: string };
  instantBook: boolean;
  status: ListingStatus;
  ownerId: string;
  managerId: string | null;
  ownerName?: string;
  managerName?: string;
  managerCompany?: string;
  compliance: Compliance;
  delegation: Delegation;
  cleaningProviderId: string | null;
  cleaningNotes?: string;
  createdAt: number;
  publishedAt?: number;
  /** Catalog-only: per-date schedule for the next N days */
  schedule?: Record<string, DaySchedule>;
}

export type Range = [number, number];

export interface DaySchedule {
  open: Range[]; // approved daytime windows
  overnight: Range[]; // occupied by overnight stays
  booked: Range[]; // SpaceTime bookings (pending + confirmed)
  pending: Range[];
  buffers: Range[]; // cleaning/turnover buffers
  blocked: Range[];
  free: Range[]; // bookable right now
}

export interface Place {
  id: string;
  label: string;
  sub?: string;
  lat: number;
  lng: number;
  kind?: 'station' | 'area' | 'landmark' | 'airport' | 'address' | 'arrondissement';
  hub?: boolean;
}

export interface SavedLocation extends Place {
  tag: 'home' | 'work' | 'other';
  name: string;
}

export type WhereMode = 'place' | 'map' | 'city';

export interface SearchQuery {
  where: { mode: WhereMode; label: string; lat: number; lng: number; radiusKm: number; city?: string };
  when: {
    date: string;
    start: string;
    durationHours: number;
    flex: 0 | 1 | 2;
    recurring: null | { freq: 'daily' | 'weekdays' | 'weekly'; count: number };
  };
  who: { adults: number; children: number; infants: number; pets: number; accessibility: Accessibility[] };
  activity?: Activity;
}

export interface Filters {
  priceMin: number;
  priceMax: number;
  minDuration: number;
  capacity: number;
  radiusKm: number;
  amenities: Amenity[];
  types: PropertyType[];
  accessibility: Accessibility[];
  petsAllowed: boolean;
  activities: Activity[];
  instantOnly: boolean;
  sort: 'recommended' | 'distance' | 'price' | 'rating';
}

export interface SavedSearch {
  id: string;
  name: string;
  query: SearchQuery;
  filters?: Filters;
  createdAt: number;
}

/** One consistent economics model used by guest, manager and owner views. */
export interface Economics {
  hours: number;
  hourly: number;
  rental: number; // hourly × hours (or minimum booking price)
  minApplied: boolean;
  otherCharges: number;
  gross: number; // gross booking value = rental + other charges
  guestFee: number; // guest service fee (RATES.guestFeePct)
  cleaning: number; // at cost
  guestTotal: number; // what the guest pays per occurrence
  commission: number; // host-side SpaceTime commission on gross (RATES.commissionPct)
  mgmtFeePct: number;
  mgmtFee: number;
  ownerProceeds: number;
  spacetimeRevenue: number; // commission + guest fee
  occurrences: number;
  grandTotal: number; // guestTotal × occurrences
}

export type BookingStatus = 'pending' | 'confirmed' | 'declined' | 'cancelled' | 'completed';
export type OpsStatus = 'awaiting' | 'ready' | 'checked_in' | 'checked_out';

export interface Booking {
  id: string;
  propertyId: string;
  guestId: string;
  guestName?: string;
  guestAvatar?: string;
  date: string;
  start: string;
  end: string;
  hours: number;
  guests: { adults: number; children: number; infants: number; pets: number };
  purpose?: Activity;
  note?: string;
  price: Economics;
  accessCode: string;
  status: BookingStatus;
  opsStatus: OpsStatus;
  cancelFee?: number;
  createdAt: number;
  updatedAt: number;
  seriesId?: string;
  recurring?: { freq: 'daily' | 'weekdays' | 'weekly'; count: number } | null;
  cleaning?: CleaningTask | null;
}

export type CleaningStatus = 'unassigned' | 'scheduled' | 'in_progress' | 'completed';

export interface CleaningProvider {
  id: string;
  managerId: string;
  name: string;
  phone: string;
  email: string;
  ratePerHour: number;
  workStart: string;
  workEnd: string;
}

export interface CleaningTask {
  id: string;
  bookingId: string;
  propertyId: string;
  providerId: string | null;
  date: string;
  start: string; // earliest start (booking end)
  deadline: string; // must be done by (next arrival or end+buffer)
  durationMins: number;
  status: CleaningStatus;
  notes: string;
  updatedAt: number;
}

export interface Stay {
  id: string;
  propertyId: string;
  checkinDate: string;
  checkoutDate: string;
  channel: string;
  guestLabel: string;
  nightlyRate: number;
}

export interface Slot {
  id: string;
  propertyId: string;
  date: string;
  start: string;
  end: string;
  status: 'approved';
  source: 'optimiser' | 'manual';
  createdBy: string;
  createdAt: number;
}

export interface Block {
  id: string;
  propertyId: string;
  date: string;
  start: string;
  end: string;
  reason: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderRole: Role | 'system';
  senderName?: string;
  body: string;
  at: number;
}

export interface Conversation {
  id: string;
  kind: 'guest' | 'owner';
  propertyId: string;
  guestId: string | null;
  bookingId?: string | null;
  title: string; // counterpart name
  subtitle: string; // property
  counterpartAvatar?: string;
  last?: Message;
  unread: number;
}

export interface UserPrefs {
  onboarded: boolean;
  /** Set once the user has explicitly picked a language (first-run onboarding or Settings). */
  langChosen?: boolean;
  favourites: string[];
  savedSearches: SavedSearch[];
  locations: SavedLocation[];
  interests: Activity[];
  household: { kids: boolean; pets: boolean };
  accessibility: Accessibility[];
  budgetMax: number;
  walkingMins: number;
  quiet: boolean;
  instantBookOnly: boolean;
  pushNotifications: boolean;
  emailUpdates: boolean;
}

export interface User {
  id: string;
  role: Role;
  name: string;
  email: string;
  phone: string;
  company: string;
  bio: string;
  avatarUrl: string;
  lang: Lang;
  memberSince: number;
  prefs: UserPrefs;
}

export interface Notification {
  id: string;
  userId: string;
  kind: string;
  text: string;
  link: string;
  at: number;
  read: boolean;
}

export interface EmailRecord {
  id: string;
  userId: string;
  to: string;
  subject: string;
  html: string;
  status: 'preview' | 'sent' | 'failed';
  provider: string;
  error?: string;
  at: number;
}
