/**
 * Sample photography (Unsplash licence), stored locally in public/photos/<id>.jpg so demo listings
 * never depend on an external image host. `localPhoto` also maps older Unsplash URLs saved in a
 * database to the local copy; any other URL (e.g. owner uploads under /uploads/) is returned unchanged.
 */
export const photo = (id: string) => `/photos/${id}.jpg`;
export const localPhoto = (url: string) => {
  const m = /^https:\/\/images\.unsplash\.com\/photo-([0-9]+-[0-9a-f]+)\?/.exec(url);
  return m ? photo(m[1]) : url;
};

/** A small photo library owners can pick from in the listing wizard. */
export const SAMPLE_PHOTOS: { url: string; tag: string }[] = [
  ['1502672260266-1c1ef2d93688', 'living'], ['1522708323590-d24dbb6b0267', 'living'], ['1505691938895-1758d7feb511', 'bedroom'],
  ['1540518614846-7eded433c457', 'bedroom'], ['1552321554-5fefe8c9ef14', 'bathroom'], ['1584622650111-993a426fbf0a', 'bathroom'],
  ['1484154218962-a197022b5858', 'kitchen'], ['1556909114-f6e7ad7d3136', 'kitchen'], ['1513694203232-719a280e022f', 'workspace'],
  ['1524758631624-e2822e304c36', 'workspace'], ['1586023492125-27b2c045efd7', 'living'], ['1631049307264-da0ec9d70304', 'bedroom'],
].map(([id, tag]) => ({ url: photo(id), tag }));
