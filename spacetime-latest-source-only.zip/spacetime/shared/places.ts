import type { Place } from './types.ts';

/** A small offline gazetteer of Paris places so the prototype works without a geocoding API. */
export const PARIS_CENTER = { lat: 48.8606, lng: 2.3476, label: 'Central Paris' };

const ARR_CENTROIDS: [number, number][] = [
  [48.8625, 2.3364], [48.8683, 2.3428], [48.8630, 2.3601], [48.8543, 2.3576], [48.8445, 2.3497],
  [48.8491, 2.3329], [48.8562, 2.3122], [48.8727, 2.3125], [48.8771, 2.3375], [48.8762, 2.3606],
  [48.8590, 2.3800], [48.8350, 2.4213], [48.8283, 2.3622], [48.8292, 2.3266], [48.8401, 2.2928],
  [48.8604, 2.2620], [48.8873, 2.3067], [48.8925, 2.3484], [48.8871, 2.3848], [48.8634, 2.4011],
];
const ARRONDISSEMENTS: Place[] = ARR_CENTROIDS.map(([lat, lng], i) => ({
  id: `arr-${i + 1}`, label: `Paris ${i + 1}${i === 0 ? 'er' : 'e'}`, sub: `Arrondissement · 750${String(i + 1).padStart(2, '0')}`, lat, lng, kind: 'arrondissement' as const,
}));

export const PLACES: Place[] = [
  { id: 'gare-de-lyon', label: 'Gare de Lyon', sub: 'TGV · Italy & Switzerland · 12e', lat: 48.8443, lng: 2.3744, kind: 'station', hub: true },
  { id: 'gare-du-nord', label: 'Gare du Nord', sub: 'Eurostar · RER B to CDG · 10e', lat: 48.8809, lng: 2.3553, kind: 'station', hub: true },
  { id: 'gare-de-lest', label: "Gare de l'Est", sub: 'Station · 10e', lat: 48.8768, lng: 2.3592, kind: 'station', hub: true },
  { id: 'montparnasse', label: 'Gare Montparnasse', sub: 'Station · 15e', lat: 48.8412, lng: 2.3209, kind: 'station', hub: true },
  { id: 'saint-lazare', label: 'Gare Saint-Lazare', sub: 'Station · 8e', lat: 48.8763, lng: 2.3253, kind: 'station' },
  { id: 'austerlitz', label: "Gare d'Austerlitz", sub: 'Station · 13e', lat: 48.8420, lng: 2.3655, kind: 'station', hub: true },
  { id: 'chatelet', label: 'Châtelet – Les Halles', sub: 'Metro & RER · 1er', lat: 48.8622, lng: 2.3470, kind: 'station' },
  { id: 'republique', label: 'République', sub: 'Area · 3e / 10e / 11e', lat: 48.8674, lng: 2.3636, kind: 'area' },
  { id: 'bastille', label: 'Bastille', sub: 'Area · 11e / 12e', lat: 48.8532, lng: 2.3692, kind: 'area' },
  { id: 'marais', label: 'Le Marais', sub: 'Area · 3e / 4e', lat: 48.8590, lng: 2.3600, kind: 'area' },
  { id: 'oberkampf', label: 'Oberkampf', sub: 'Area · 11e', lat: 48.8650, lng: 2.3775, kind: 'area' },
  { id: 'canal', label: 'Canal Saint-Martin', sub: 'Area · 10e', lat: 48.8718, lng: 2.3650, kind: 'area' },
  { id: 'belleville', label: 'Belleville', sub: 'Area · 19e / 20e', lat: 48.8722, lng: 2.3770, kind: 'area' },
  { id: 'montmartre', label: 'Montmartre', sub: 'Area · 18e', lat: 48.8867, lng: 2.3431, kind: 'area' },
  { id: 'pigalle', label: 'Pigalle', sub: 'Area · 9e / 18e', lat: 48.8820, lng: 2.3375, kind: 'area' },
  { id: 'opera', label: 'Opéra', sub: 'Area · 9e', lat: 48.8709, lng: 2.3320, kind: 'area' },
  { id: 'grands-boulevards', label: 'Grands Boulevards', sub: 'Area · 2e / 9e', lat: 48.8715, lng: 2.3430, kind: 'area' },
  { id: 'sentier', label: 'Sentier', sub: 'Area · 2e', lat: 48.8680, lng: 2.3470, kind: 'area' },
  { id: 'saint-germain', label: 'Saint-Germain-des-Prés', sub: 'Area · 6e', lat: 48.8539, lng: 2.3338, kind: 'area' },
  { id: 'latin-quarter', label: 'Latin Quarter', sub: 'Area · 5e', lat: 48.8493, lng: 2.3470, kind: 'area' },
  { id: 'batignolles', label: 'Batignolles', sub: 'Area · 17e', lat: 48.8853, lng: 2.3185, kind: 'area' },
  { id: 'bercy', label: 'Bercy', sub: 'Area · 12e', lat: 48.8378, lng: 2.3825, kind: 'area' },
  { id: 'nation', label: 'Nation', sub: 'Area · 11e / 12e', lat: 48.8483, lng: 2.3958, kind: 'area' },
  { id: 'station-f', label: 'Station F', sub: 'Landmark · 13e', lat: 48.8340, lng: 2.3708, kind: 'landmark' },
  { id: 'la-defense', label: 'La Défense', sub: 'Business district', lat: 48.8919, lng: 2.2384, kind: 'area' },
  { id: 'louvre', label: 'Louvre', sub: 'Landmark · 1er', lat: 48.8606, lng: 2.3376, kind: 'landmark' },
  { id: 'eiffel', label: 'Eiffel Tower', sub: 'Landmark · 7e', lat: 48.8584, lng: 2.2945, kind: 'landmark' },
  { id: 'notre-dame', label: 'Notre-Dame', sub: 'Landmark · 4e', lat: 48.8530, lng: 2.3499, kind: 'landmark' },
  { id: 'champs', label: 'Champs-Élysées', sub: 'Area · 8e', lat: 48.8698, lng: 2.3078, kind: 'area' },
  { id: 'cdg', label: 'Charles de Gaulle Airport (CDG)', sub: 'Airport · RER B to Gare du Nord', lat: 49.0097, lng: 2.5479, kind: 'airport', hub: true },
  { id: 'orly', label: 'Orly Airport (ORY)', sub: 'Airport', lat: 48.7262, lng: 2.3652, kind: 'airport', hub: true },
  { id: 'bvs', label: 'Beauvais Airport (BVA)', sub: 'Airport · shuttle to Porte Maillot', lat: 49.4544, lng: 2.1128, kind: 'airport', hub: true },
  { id: 'chessy', label: 'Marne-la-Vallée – Chessy', sub: 'TGV & Eurostar · Disneyland', lat: 48.8701, lng: 2.7826, kind: 'station', hub: true },
  ...ARRONDISSEMENTS,
];

export const CITIES = [
  { id: 'paris', label: 'Paris', lat: 48.8606, lng: 2.3476, live: true, count: 18 },
  { id: 'lyon', label: 'Lyon', lat: 45.764, lng: 4.8357, live: false, count: 0 },
  { id: 'london', label: 'London', lat: 51.5072, lng: -0.1276, live: false, count: 0 },
  { id: 'barcelona', label: 'Barcelona', lat: 41.3874, lng: 2.1686, live: false, count: 0 },
];

const norm = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

export function searchPlaces(q: string, limit = 8): Place[] {
  const n = norm(q.trim());
  if (!n) return PLACES.filter((p) => p.hub).slice(0, limit);
  const arr = n.match(/^(?:paris\s*)?(\d{1,2})(?:e|er|eme|ème)?$|^750(\d{2})$/);
  if (arr) {
    const num = Number(arr[1] ?? arr[2]);
    const hit = PLACES.find((p) => p.id === `arr-${num}`);
    if (hit) return [hit, ...PLACES.filter((p) => p !== hit && norm(p.sub ?? '').includes(`${num}e`)).slice(0, limit - 1)];
  }
  const scored = PLACES.map((p) => {
    const hay = norm(p.label + ' ' + (p.sub ?? '') + ' ' + p.id);
    const idx = hay.indexOf(n);
    return { p, s: idx < 0 ? -1 : (norm(p.label).startsWith(n) ? 3 : 1) + (p.hub ? 1 : 0) };
  }).filter((x) => x.s > 0);
  return scored.sort((a, b) => b.s - a.s).slice(0, limit).map((x) => x.p);
}

export function findPlaceInText(text: string): Place | undefined {
  const n = norm(text);
  // prefer longest label match
  const aliases: Record<string, string> = {
    'lyon station': 'gare-de-lyon', 'gare lyon': 'gare-de-lyon', 'north station': 'gare-du-nord', 'eurostar': 'gare-du-nord',
    'les halles': 'chatelet', 'chatelet': 'chatelet', 'marais': 'marais', 'canal': 'canal', 'cdg': 'cdg', 'roissy': 'cdg', 'orly': 'orly',
    'eiffel': 'eiffel', 'defense': 'la-defense', 'latin quarter': 'latin-quarter', 'quartier latin': 'latin-quarter', 'montparnasse': 'montparnasse',
    'saint germain': 'saint-germain', 'st germain': 'saint-germain', 'opera': 'opera',
  };
  const sorted = [...PLACES].sort((a, b) => b.label.length - a.label.length);
  for (const p of sorted) if (n.includes(norm(p.label))) return p;
  for (const [k, id] of Object.entries(aliases)) if (n.includes(k)) return PLACES.find((p) => p.id === id);
  for (const p of sorted) {
    const core = norm(p.label).replace(/^gare (de |du |d')?/, '');
    if (core.length > 4 && n.includes(core)) return p;
  }
  return undefined;
}

