/**
 * Rule-based natural-language intent extraction (deterministic). Used directly when no LLM is
 * configured, and as the schema/fallback for the server-side Claude parser.
 */
import type { Accessibility, Activity, Amenity, Place } from './types.ts';
import { findPlaceInText } from './places.ts';
import { addDays, isoDate, toHHMM, toMin } from './time.ts';

export interface ParsedIntent {
  location?: Place;
  locationText?: string;
  date?: string;
  start?: string;
  end?: string;
  durationHours?: number;
  adults: number;
  children: number;
  infants: number;
  pets: number;
  needs: Amenity[];
  activities: Activity[];
  accessibility: Accessibility[];
  budgetMax?: number;
  quiet?: boolean;
  assumptions: string[];
  /** Client-side flag: children were mentioned but the number of adults was not, so we ask. */
  adultsUnconfirmed?: boolean;
  missing: ('date' | 'time' | 'location')[];
}

const NUM: Record<string, number> = { a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12, couple: 2, pair: 2, few: 3, several: 4 };
const numRe = '(\\d+|a|an|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|couple of|few|several)';
const toNum = (s: string) => (/^\d+$/.test(s) ? +s : NUM[s.replace(' of', '')] ?? 1);

const DOW = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
const MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];

function parseTimeToken(h: string, m: string | undefined, ap: string | undefined): number | null {
  let hh = +h;
  const mm = m ? +m : 0;
  if (hh > 24 || mm > 59) return null;
  if (ap) {
    const a = ap.toLowerCase();
    if (a.startsWith('p') && hh < 12) hh += 12;
    if (a.startsWith('a') && hh === 12) hh = 0;
  } else if (hh >= 1 && hh <= 7) {
    hh += 12; // "at 4" without am/pm most likely means 16:00
  }
  return hh * 60 + mm;
}

interface TimeHit { min: number; idx: number; role: 'start' | 'end' | 'unknown' }

function extractTimes(t: string): TimeHit[] {
  const hits: TimeHit[] = [];
  const re = /\b(\d{1,2})(?:[:h.](\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?(?=\b|\s|$)/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(t))) {
    const before = t.slice(Math.max(0, m.index - 28), m.index).toLowerCase();
    const after = t.slice(m.index + m[0].length, m.index + m[0].length + 12).toLowerCase();
    const hasMarker = !!m[2] || !!m[3] || /\b(at|from|until|till|til|by|to|before|after|around|-|–)\s*$/.test(before) || /h\b/.test(m[0]);
    if (!hasMarker) continue;
    if (/^\s*(hours?|hrs?|h\b|people|adults|kids|children|guests|min|€|euros?|km|m\b)/.test(after)) continue;
    if (/€\s*$/.test(before)) continue;
    const min = parseTimeToken(m[1], m[2], m[3]);
    if (min === null) continue;
    let role: TimeHit['role'] = 'unknown';
    if (/(until|till|til|by|before|to|-|–|check-?in( is)?( at)?|leave( at)?|depart\w*( at)?|train( is| leaves)?( at)?|flight( is)?( at)?|meeting( is)?( at)?|back( at)?)\s*$/.test(before)) role = 'end';
    if (/(from|arriv\w*( at)?|land\w*( at)?|start\w*( at)?|after|get in( at)?|gets in( at)?)\s*$/.test(before) || /arriv|land/.test(before)) role = 'start';
    hits.push({ min, idx: m.index, role });
  }
  if (/\bnoon|midday\b/.test(t)) hits.push({ min: 12 * 60, idx: t.search(/noon|midday/), role: /(until|till|by)\s+(noon|midday)/.test(t) ? 'end' : 'unknown' });
  return hits.sort((a, b) => a.idx - b.idx);
}

function extractDate(t: string, now: Date): string | undefined {
  const today = isoDate(now);
  if (/\b(today|tonight|this (morning|afternoon|evening)|right now|now|asap)\b/.test(t)) return today;
  if (/\btomorrow\b/.test(t)) return addDays(today, 1);
  if (/\bday after tomorrow\b/.test(t)) return addDays(today, 2);
  for (let i = 0; i < 7; i++) {
    const re = new RegExp(`\\b(next |this |on )?${DOW[i]}s?\\b`);
    const mm = t.match(re);
    if (mm) {
      let diff = (i - now.getDay() + 7) % 7;
      if (diff === 0) diff = 7;
      if (mm[1] === 'next ' && diff < 7) diff += 0;
      return addDays(today, diff);
    }
  }
  if (/\bweekend\b/.test(t)) return addDays(today, (6 - now.getDay() + 7) % 7 || 0);
  const dm = t.match(new RegExp(`\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?(${MONTHS.join('|')}|${MONTHS.map((x) => x.slice(0, 3)).join('|')})\\b`));
  if (dm) {
    const month = MONTHS.findIndex((x) => x.startsWith(dm[2].slice(0, 3)));
    const d = new Date(now.getFullYear(), month, +dm[1]);
    if (d < new Date(now.getFullYear(), now.getMonth(), now.getDate())) d.setFullYear(d.getFullYear() + 1);
    return isoDate(d);
  }
  const sl = t.match(/\b(\d{1,2})\/(\d{1,2})\b/);
  if (sl) {
    const d = new Date(now.getFullYear(), +sl[2] - 1, +sl[1]);
    if (d < now) d.setFullYear(d.getFullYear() + 1);
    return isoDate(d);
  }
  return undefined;
}

export function parseIntent(raw: string, now: Date, previous?: ParsedIntent): ParsedIntent {
  {
    const t = ' ' + raw.toLowerCase().replace(/’/g, "'") + ' ';
    const it: ParsedIntent = previous
      ? { ...previous, needs: [...previous.needs], activities: [...previous.activities], accessibility: [...previous.accessibility], assumptions: [], missing: [] }
      : { adults: 0, children: 0, infants: 0, pets: 0, needs: [], activities: [], accessibility: [], assumptions: [], missing: [] };
    const addNeed = (...a: Amenity[]) => a.forEach((x) => !it.needs.includes(x) && it.needs.push(x));
    const addAct = (...a: Activity[]) => a.forEach((x) => !it.activities.includes(x) && it.activities.push(x));
    const addAcc = (...a: Accessibility[]) => a.forEach((x) => !it.accessibility.includes(x) && it.accessibility.push(x));

    // Location
    const place = findPlaceInText(t);
    if (place) { it.location = place; it.locationText = place.label; }
    if (/\b(near|close to) (my )?home\b/.test(t)) it.locationText = 'home';
    if (/\b(near|close to) (my )?(work|office)\b/.test(t)) it.locationText = 'work';
    if (!place && /\b(anywhere|central paris|city cent(re|er)|doesn't matter|dont mind|don't mind)\b/.test(t)) it.locationText = 'central Paris';

    // Date & time
    const date = extractDate(t, now);
    if (date) it.date = date;
    const times = extractTimes(t);
    if (times.length) {
      const start = times.find((x) => x.role === 'start') ?? times.find((x) => x.role === 'unknown') ?? (times.length > 1 ? times[0] : undefined);
      const end = times.find((x) => x.role === 'end' && x !== start) ?? times.find((x) => x !== start && x.idx > (start?.idx ?? -1));
      if (start) it.start = toHHMM(start.min);
      if (end && (!start || end.min > start.min)) it.end = toHHMM(end.min);
      if (!start && end) it.end = toHHMM(end.min);
    }
    const dur = t.match(new RegExp(`\\b(?:for\\s+)?${numRe}\\s*(?:-\\s*)?(hours?|hrs?|h)\\b`));
    if (dur) it.durationHours = toNum(dur[1]);
    if (/\b(half an hour|30 min)/.test(t)) it.durationHours = 1;
    if (/\b(all day|whole day|full day)\b/.test(t)) { it.start ??= '09:00'; it.end ??= '18:00'; }
    if (!it.start) {
      if (/\bthis morning|in the morning|\bmorning\b/.test(t)) { it.start = '09:00'; it.assumptions.push('“Morning” read as from 09:00'); }
      else if (/\bafternoon\b/.test(t)) { it.start = '13:00'; it.assumptions.push('“Afternoon” read as from 13:00'); }
      else if (/\bevening|tonight\b/.test(t)) { it.start = '18:00'; it.assumptions.push('“Evening” read as from 18:00'); }
      else if (/\blunch( ?time)?\b/.test(t)) { it.start = '12:00'; it.durationHours ??= 2; it.assumptions.push('Lunchtime read as 12:00–14:00'); }
    }
    if (/\b(now|right now|asap)\b/.test(t) && !it.start) {
      it.start = toHHMM(Math.ceil((now.getHours() * 60 + now.getMinutes()) / 30) * 30);
    }

    // Guests
    const kids = t.match(new RegExp(`\\b${numRe}\\s+(kids|children|child|boys|girls|sons|daughters|toddlers?)\\b`));
    if (kids) it.children = toNum(kids[1]);
    else if (/\b(my|the|with) (kids|children)\b/.test(t)) { it.children = 2; it.assumptions.push('Assumed 2 children'); }
    else if (/\b(my|a|our) (son|daughter|kid|child|toddler)\b/.test(t)) it.children = 1;
    let adults = 0;
    const a1 = t.match(new RegExp(`\\b${numRe}\\s+(adults?|people|persons|guests|of us|grown-?ups)\\b`));
    if (a1) adults = toNum(a1[1]);
    const fr = t.match(new RegExp(`\\b(?:with|and|for)\\s+${numRe}\\s+(friends|colleagues|coworkers|teammates|people|guests)\\b`));
    if (fr) adults = Math.max(adults, toNum(fr[1]) + (/people|guests/.test(fr[2]) ? 0 : 1));
    const grp = t.match(/\b(?:band|group|team|party|family) of (\d+|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\b/);
    if (grp) adults = Math.max(adults, toNum(grp[1]) - (it.children || 0));
    if (!adults && /\b(we|we're|we are|us|our)\b/.test(t)) { adults = 2; if (!previous) it.assumptions.push('Assumed 2 adults'); }
    if (!adults && /\bmy (wife|husband|partner|girlfriend|boyfriend|friend|colleague|mum|mom|dad|mother|father|sister|brother)\b/.test(t)) adults = 2;
    const baby = t.match(new RegExp(`\\b${numRe}\\s+(babies|baby|infants?)\\b`));
    if (baby) it.infants = toNum(baby[1]);
    else if (/\b(a|my|our|the) (baby|infant|newborn)\b/.test(t)) it.infants = 1;
    if (/\b(dog|puppy|cat|pet)s?\b/.test(t)) it.pets = Math.max(1, it.pets);
    if (adults) it.adults = adults;
    if (!it.adults) { it.adults = 1; if (!previous) it.assumptions.push('Assumed 1 adult'); }

    // Needs & activities (ignore "near work" / "after work" etc. so they don't imply remote work)
    const ta = t.replace(/\b(near|close to|by|from|after|before|around) (my )?(work|office|home)\b/g, ' ');
    if (/\b(shower|freshen up|wash|clean up)\b/.test(t)) addNeed('shower');
    if (/\b(bath|bathtub|soak)\b/.test(t)) addNeed('bathtub');
    if (/\b(rest|nap|sleep|lie down|bed|tired|jet ?lag|recharge)\b/.test(t)) { addNeed('bed'); addAct('rest'); }
    if (/\b(arriv\w*|train|tgv|eurostar|flight|plane|airport|layover|connection|check-?in|hotel|between (?:trains|flights|journeys|connections))\b/.test(t)) addAct('layover');
    if (/\b(luggage|suitcases?|bags|backpacks?)\b/.test(t) || it.activities.includes('layover')) addNeed('luggage');
    if (it.children || it.infants) addAct('family');
    if (it.infants || /\b(toddler|baby)\b/.test(t)) addNeed('crib');
    if (/\b(work|working|laptop|focus|zoom|teams|calls?|emails?|between meetings)\b/.test(ta)) { addNeed('wifi', 'desk'); addAct('work'); }
    if (/\b(meeting|workshop|offsite|interview|client|presentation)\b/.test(t)) { addNeed('wifi'); addAct('meeting'); }
    if (/\b(screen|projector|present)\b/.test(t)) addNeed('projector');
    if (/\b(cook|cooking|bake|baking|kitchen|dinner|lunch for|meal)\b/.test(t)) { addNeed('kitchen'); addAct('cooking'); }
    if (/\b(bake|baking|oven|cake|bread)\b/.test(t)) addNeed('oven');
    if (/\b(party|birthday|celebrat\w*|drinks|gathering|get-?together|hang out|friends over)\b/.test(t)) addAct('party');
    if (/\b(bbq|barbecue|grill)\b/.test(t)) { addNeed('bbq_grill'); addAct('bbq'); }
    if (/\b(rehears\w*|band|practi[cs]e|music|sing|piano|podcast|dance)\b/.test(t)) addAct('rehearsal');
    if (/\bpiano\b/.test(t)) addNeed('piano');
    if (/\b(paint|draw|write|writing|create|creative|art)\b/.test(t)) addAct('creative');
    if (/\b(photo|shoot|film|video|content)\b/.test(t)) addAct('photo');
    if (/\b(relax|unwind|chill|calm|read)\b/.test(t)) addAct('relax');
    if (/\b(quiet|calm|silent|peaceful|focus)\b/.test(t)) it.quiet = true;
    if (/\b(wi-?fi|internet)\b/.test(t)) addNeed('wifi');
    if (/\b(video[- ]?call|zoom|teams|meet call)\b/.test(t)) addNeed('wifi');
    if (/\b(garden|outdoor|outside)\b/.test(t)) addNeed('garden');
    if (/\b(terrace|rooftop)\b/.test(t)) addNeed('terrace');
    if (/\b(wheelchair|step-?free|no stairs|mobility|accessible)\b/.test(t)) addAcc('step_free', 'wide_doors');
    if (/\b(lift|elevator|pushchair|stroller|pram)\b/.test(t)) addAcc('elevator');
    if (/\b(autis\w*|sensory|very quiet|noise)\b/.test(t)) addAcc('low_sensory');
    const bud = t.match(/(?:under|below|less than|max|up to|budget( of)?)\s*€?\s*(\d+)\s*(?:€|euros?)?(?:\s*(?:an|per|\/)\s*h(?:ou)?r)?/);
    if (bud) it.budgetMax = +bud[2];

    // Derive duration/end
    if (it.start && it.end) it.durationHours = Math.max(1, Math.round((toMin(it.end) - toMin(it.start)) / 30) / 2);
    else if (it.start && it.durationHours) it.end = toHHMM(toMin(it.start) + it.durationHours * 60);
    else if (!it.start && it.end && it.durationHours) it.start = toHHMM(toMin(it.end) - it.durationHours * 60);

    if (!it.date) it.missing.push('date');
    if (!it.start) it.missing.push('time');
    if (!it.location && !it.locationText) it.missing.push('location');
    return it;
  }
}

export const EXAMPLE_PROMPTS = [
  "I'm arriving at Gare de Lyon at 9 am with two kids. My hotel check-in is at 4 pm, and I need somewhere to shower and rest.",
  'Quiet place to work near Châtelet tomorrow from 10 to 2, under €20 an hour',
  'Birthday BBQ for 10 friends on Saturday afternoon, our dog is coming',
  'Somewhere to bake a cake with my daughter on Sunday morning near Nation',
  'Rehearsal space for my band of 4, Friday 6pm for 3 hours',
];
