/**
 * Smart Availability — deterministic daytime revenue analysis.
 * All money figures are computed here; explanations are generated from these numbers.
 * Demand likelihoods are explicit, adjustable scenario assumptions — not predictions.
 */
import type { Booking, Block, Property, Slot, Stay } from './types.ts';
import { calcEconomics, RATES } from './economics.ts';
import { addDays, dow, overlaps, toHHMM, toMin } from './time.ts';

export interface Assumptions {
  hourlyPrice: number;
  durationHours: number;
  cleaningCost: number; // actual cost of the extra turnover clean
  consumables: number; // linen, utilities & supplies per daytime booking
  mgmtFeePct: number;
  overnightRate: number;
  channelFeePct: number;
  overnightLikelihood: number; // % — scenario: chance the night still sells last-minute
  daytimeLikelihood: number; // % — scenario: chance the opened window gets booked
  bufferMins: number;
  staffStart: string;
  staffEnd: string;
  dayStart: string;
  dayEnd: string;
}

export function defaultAssumptions(p: Property): Assumptions {
  return {
    hourlyPrice: p.pricePerHour,
    durationHours: Math.min(p.maxHours, Math.max(p.minHours, 4)),
    cleaningCost: p.cleaningFee,
    consumables: 6,
    mgmtFeePct: p.delegation.mgmtFeePct,
    overnightRate: p.overnight.nightlyRate || 140,
    channelFeePct: p.overnight.channelFeePct || 15,
    overnightLikelihood: 30,
    daytimeLikelihood: 60,
    bufferMins: p.bufferMins,
    staffStart: '08:00',
    staffEnd: '20:00',
    dayStart: '08:00',
    dayEnd: '19:00',
  };
}

export type ReasonCode = 'occupied_all_day' | 'owner_not_allowed' | 'overlaps_stay' | 'overlaps_booking' | 'blocked' | 'no_cleaner' | 'window_too_short' | 'past';

export interface Candidate {
  id: string;
  date: string;
  start: string;
  end: string;
  hours: number;
  feasible: boolean;
  reasons: ReasonCode[];
  nightBefore: Stay | null;
  nightAfter: Stay | null;
  blocksOvernight: boolean;
  alreadyOpen: boolean;
  daytime: { gross: number; commission: number; mgmtFee: number; cleaningRecovered: number; cleaningCost: number; consumables: number; net: number };
  overnight: { gross: number; channelFee: number; mgmtFee: number; net: number };
  expectedDaytime: number;
  opportunityCost: number;
  expectedGain: number;
  minViableHourly: number | null;
  recommendation: 'open' | 'hold' | 'infeasible';
}

export interface DayAnalysis {
  date: string;
  window: [number, number] | null;
  reasons: ReasonCode[];
  nightBefore: Stay | null;
  nightAfter: Stay | null;
  candidates: Candidate[];
}

export interface OptimiserInput {
  property: Property;
  stays: Stay[];
  bookings: Booking[];
  slots: Slot[];
  blocks: Block[];
  today: string;
  nowMin: number;
}

const r2 = (n: number) => Math.round(n * 100) / 100;

function daytimeNet(p: Property, a: Assumptions, hourly: number, hours: number) {
  const e = calcEconomics({ ...p, delegation: { mgmtFeePct: a.mgmtFeePct } }, hours, 1, hourly);
  const net = e.ownerProceeds + e.cleaning - a.cleaningCost - a.consumables;
  return { gross: e.gross, commission: e.commission, mgmtFee: e.mgmtFee, cleaningRecovered: e.cleaning, cleaningCost: a.cleaningCost, consumables: a.consumables, net: r2(net) };
}

export function overnightNet(a: Assumptions) {
  const channelFee = a.overnightRate * (a.channelFeePct / 100);
  const mgmtFee = (a.overnightRate - channelFee) * (a.mgmtFeePct / 100);
  return { gross: a.overnightRate, channelFee: r2(channelFee), mgmtFee: r2(mgmtFee), net: r2(a.overnightRate - channelFee - mgmtFee) };
}


function candidateFor(inp: OptimiserInput, date: string, s: number, e: number, a: Assumptions, nightBefore: Stay | null, nightAfter: Stay | null): Candidate {
  const p = inp.property;
  const buf = a.bufferMins;
  const ci = toMin(p.overnight.checkin || '16:00');
  const co = toMin(p.overnight.checkout || '11:00');
  const reasons: ReasonCode[] = [];
  const dayBookings = inp.bookings.filter((b) => b.date === date && (b.status === 'pending' || b.status === 'confirmed'));
  const dayBlocks = inp.blocks.filter((b) => b.date === date);
  const daySlots = inp.slots.filter((x) => x.date === date);
  const weekly = p.availability.filter((w) => w.days.includes(dow(date))).map((w) => [toMin(w.start), toMin(w.end)] as [number, number]);
  const env = p.ownerWindows.filter((w) => w.days.includes(dow(date)));
  if (!env.some((w) => s >= toMin(w.start) && e <= toMin(w.end))) reasons.push('owner_not_allowed');
  if ((nightBefore && s < co + buf) || (nightAfter && e > ci - buf) || inp.stays.some((x) => x.checkinDate < date && x.checkoutDate > date)) reasons.push('overlaps_stay');
  if (dayBookings.some((b) => overlaps([s - buf, e + buf], [toMin(b.start), toMin(b.end)]))) reasons.push('overlaps_booking');
  if (dayBlocks.some((b) => overlaps([s, e], [toMin(b.start), toMin(b.end)]))) reasons.push('blocked');
  if (e + buf > toMin(a.staffEnd) || s < toMin(a.staffStart) - 60) reasons.push('no_cleaner');
  if (date === inp.today && s < inp.nowMin) reasons.push('past');
  if (e - s < p.minHours * 60) reasons.push('window_too_short');
  const on = overnightNet(a);
  const blocksOvernight = p.overnight.enabled && !nightAfter && e + buf > ci;
  const hours = Math.min(p.maxHours, (e - s) / 60);
  const dt = daytimeNet(p, a, a.hourlyPrice, hours);
  const expectedDaytime = r2(dt.net * (a.daytimeLikelihood / 100));
  const opportunityCost = blocksOvernight ? r2(on.net * (a.overnightLikelihood / 100)) : 0;
  const expectedGain = r2(expectedDaytime - opportunityCost);
  let minViableHourly: number | null = null;
  for (let h = 1; h <= 400; h++) {
    const n = daytimeNet(p, a, h, hours).net;
    if (n > 0 && n * (a.daytimeLikelihood / 100) >= opportunityCost) { minViableHourly = h; break; }
  }
  const alreadyOpen = [...weekly, ...daySlots.map((x) => [toMin(x.start), toMin(x.end)] as [number, number])].some(([os, oe]) => s >= os && e <= oe);
  const feasible = reasons.length === 0;
  const recommendation = !feasible ? 'infeasible' : dt.net > 0 && expectedGain >= 10 ? 'open' : 'hold';
  return { id: `${date}_${toHHMM(s)}_${toHHMM(e)}`, date, start: toHHMM(s), end: toHHMM(e), hours, feasible, reasons, nightBefore, nightAfter, blocksOvernight, alreadyOpen, daytime: dt, overnight: on, expectedDaytime, opportunityCost, expectedGain, minViableHourly, recommendation };
}

/** Evaluate any manager-chosen window with the same rules. */
export function evaluateWindow(inp: OptimiserInput, date: string, start: string, end: string, a: Assumptions): Candidate {
  const nightBefore = inp.stays.find((s) => s.checkinDate < date && s.checkoutDate === date) ?? null;
  const nightAfter = inp.stays.find((s) => s.checkinDate === date) ?? null;
  return candidateFor(inp, date, toMin(start), toMin(end), a, nightBefore, nightAfter);
}

export function analyseDay(inp: OptimiserInput, date: string, a: Assumptions): DayAnalysis {
  const p = inp.property;
  const buf = a.bufferMins;
  const D = a.durationHours * 60;
  const nightBefore = inp.stays.find((s) => s.checkinDate < date && s.checkoutDate === date) ?? null;
  const nightAfter = inp.stays.find((s) => s.checkinDate === date) ?? null;
  const through = inp.stays.find((s) => s.checkinDate < date && s.checkoutDate > date);
  const base: DayAnalysis = { date, window: null, reasons: [], nightBefore, nightAfter, candidates: [] };
  if (through) return { ...base, reasons: ['occupied_all_day'] };

  const env = p.ownerWindows.filter((w) => w.days.includes(dow(date)));
  if (!env.length) return { ...base, reasons: ['owner_not_allowed'] };
  const envStart = Math.min(...env.map((w) => toMin(w.start)));
  const envEnd = Math.max(...env.map((w) => toMin(w.end)));

  const co = toMin(p.overnight.checkout || '11:00');
  const ci = toMin(p.overnight.checkin || '16:00');
  let ws = Math.max(toMin(a.dayStart), envStart, nightBefore ? co + buf : 0);
  let we = Math.min(toMin(a.dayEnd), envEnd, nightAfter ? ci - buf : 24 * 60);
  if (date === inp.today) ws = Math.max(ws, Math.ceil((inp.nowMin + 30) / 30) * 30);
  if (we - ws < Math.max(60, p.minHours * 60)) return { ...base, window: we > ws ? [ws, we] : null, reasons: [date === inp.today && we > toMin(a.dayStart) ? 'past' : 'window_too_short'] };

  const dur = Math.min(D, we - ws);
  const ciSafeFull = p.overnight.enabled && !nightAfter ? Math.min(we, ci - buf) : we;
  const ciSafe = p.overnight.enabled && !nightAfter ? ci - buf : we; // ending later would block an overnight check-in
  const starts = new Set<number>([ws]);
  if (ciSafe - dur > ws + 30 && ciSafe <= we) starts.add(ciSafe - dur);
  if (p.overnight.enabled && !nightAfter && we - dur > ciSafe - dur + 30) starts.add(we - dur);
  if (!p.overnight.enabled && we - dur > ws + 60) starts.add(we - dur);


  const list = [...starts].sort((x, y) => x - y).map((st) => candidateFor(inp, date, st, st + dur, a, nightBefore, nightAfter));
  // the longest window that keeps a same-day overnight check-in possible
  const fullEnd = Math.min(ciSafeFull, ws + p.maxHours * 60);
  if (fullEnd - ws > dur + 30) list.unshift(candidateFor(inp, date, ws, fullEnd, a, nightBefore, nightAfter));
  const candidates = list;
  return { ...base, window: [ws, we], candidates };
}

export function analyseWeek(inp: OptimiserInput, a: Assumptions, days = 7): DayAnalysis[] {
  return Array.from({ length: days }, (_, i) => analyseDay(inp, addDays(inp.today, i), a));
}

export const COMMISSION_PCT = RATES.commissionPct;

/** Deterministic, number-grounded explanation (used when no LLM is configured, and as the LLM's facts). */
export function explainCandidate(c: Candidate, a: Assumptions, lang: 'en' | 'fr'): string {
  const eur = (n: number) => new Intl.NumberFormat(lang === 'fr' ? 'fr-FR' : 'en-IE', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(n);
  const fr = lang === 'fr';
  if (!c.feasible) {
    const map: Record<ReasonCode, [string, string]> = {
      occupied_all_day: ['an overnight stay occupies the whole day', 'un séjour de nuit occupe toute la journée'],
      owner_not_allowed: ["the owner hasn't authorised daytime use on this day", "le propriétaire n'a pas autorisé l'usage en journée ce jour-là"],
      overlaps_stay: ['it overlaps an overnight stay', 'il chevauche un séjour de nuit'],
      overlaps_booking: ['it overlaps an existing booking or its cleaning buffer', 'il chevauche une réservation existante ou son ménage'],
      blocked: ['the period is blocked', 'la période est bloquée'],
      no_cleaner: ['the turnover clean would fall outside cleaning-staff hours', "le ménage tomberait en dehors des horaires de l'équipe"],
      window_too_short: ['the free window is shorter than the minimum booking', 'la fenêtre libre est plus courte que la durée minimale'],
      past: ['this time has already passed', 'ce créneau est déjà passé'],
    };
    const r = c.reasons.map((x) => map[x][fr ? 1 : 0]).join(fr ? ' ; ' : '; ');
    return fr ? `Créneau non viable : ${r}.` : `Not viable: ${r}.`;
  }
  const parts: string[] = [];
  parts.push(fr
    ? `Une réservation de ${c.hours} h à ${eur(a.hourlyPrice)}/h rapporterait environ ${eur(c.daytime.net)} net au propriétaire, après commission SpaceTime (${COMMISSION_PCT} %), frais de gestion (${a.mgmtFeePct} %), ménage et consommables.`
    : `A ${c.hours}-hour booking at ${eur(a.hourlyPrice)}/h would leave the owner about ${eur(c.daytime.net)} net, after SpaceTime's ${COMMISSION_PCT}% commission, the ${a.mgmtFeePct}% management fee, cleaning and supplies.`);
  if (c.nightAfter) parts.push(fr ? `La nuit est déjà réservée (${c.nightAfter.channel}) : le créneau se termine avant l'arrivée et le ménage, sans coût d'opportunité.` : `Tonight is already booked (${c.nightAfter.channel}); this window ends before check-in and the turnover clean, so there is no opportunity cost.`);
  else if (c.blocksOvernight) parts.push(fr
    ? `Il empiéterait sur une arrivée de nuit. Avec l'hypothèse de ${a.overnightLikelihood} % de vendre la nuit (${eur(c.overnight.net)} net), le coût d'opportunité attendu est de ${eur(c.opportunityCost)}.`
    : `It would block a same-day overnight check-in. Assuming a ${a.overnightLikelihood}% chance the night sells (${eur(c.overnight.net)} net), the expected opportunity cost is ${eur(c.opportunityCost)}.`);
  else parts.push(fr ? `Il se termine avant l'heure d'arrivée de nuit : la nuit reste vendable.` : `It finishes before the overnight check-in time, so the night stays sellable.`);
  parts.push(c.recommendation === 'open'
    ? (fr ? `Avec ${a.daytimeLikelihood} % de chances d'être réservé, le gain attendu est de ${eur(c.expectedGain)} : ouverture recommandée.` : `With a ${a.daytimeLikelihood}% booking likelihood the expected gain is ${eur(c.expectedGain)} — recommended to open.`)
    : (fr ? `Le gain attendu (${eur(c.expectedGain)}) ne justifie pas l'ouverture${c.minViableHourly ? ` en dessous de ${eur(c.minViableHourly)}/h` : ''}.` : `The expected gain (${eur(c.expectedGain)}) doesn't justify opening${c.minViableHourly ? ` below ${eur(c.minViableHourly)}/h` : ''}.`));
  return parts.join(' ');
}
