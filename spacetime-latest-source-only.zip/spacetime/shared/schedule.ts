import type { Block, Booking, DaySchedule, Property, Range, Slot, Stay } from './types.ts';
import { addDays, dow, merge, subtract, toMin } from './time.ts';

export interface ScheduleInput {
  property: Property;
  slots: Slot[];
  blocks: Block[];
  stays: Stay[];
  bookings: Booking[]; // active (pending/confirmed) bookings for the property
}

/** Times occupied by overnight stays on a date (+ turnover cleaning on the daytime side). */
export function overnightRanges(p: Property, stays: Stay[], date: string): { occupied: Range[]; buffers: Range[] } {
  const occupied: Range[] = [];
  const buffers: Range[] = [];
  const ci = toMin(p.overnight.checkin || '16:00');
  const co = toMin(p.overnight.checkout || '11:00');
  const clean = p.bufferMins;
  for (const s of stays) {
    // night before: guest leaves at checkout on `date`
    if (s.checkinDate < date && s.checkoutDate === date) {
      occupied.push([0, co]);
      buffers.push([co, co + clean]);
    }
    // stay spans the whole day
    if (s.checkinDate < date && s.checkoutDate > date) occupied.push([0, 1440]);
    // night after: guest arrives at checkin on `date`
    if (s.checkinDate === date) {
      occupied.push([ci, 1440]);
      buffers.push([ci - clean, ci]);
    }
  }
  return { occupied: merge(occupied), buffers: merge(buffers) };
}

export function daySchedule(inp: ScheduleInput, date: string, nowISO: string, nowMin: number, excludeBookingId?: string): DaySchedule {
  const p = inp.property;
  const d = dow(date);
  const weekly: Range[] = p.availability.filter((w) => w.days.includes(d)).map((w) => [toMin(w.start), toMin(w.end)]);
  const dated: Range[] = inp.slots.filter((s) => s.date === date).map((s) => [toMin(s.start), toMin(s.end)]);
  const open = merge([...weekly, ...dated]);
  const { occupied, buffers: onBuf } = overnightRanges(p, inp.stays, date);
  const dayBookings = inp.bookings.filter((b) => b.date === date && b.id !== excludeBookingId && (b.status === 'pending' || b.status === 'confirmed'));
  const booked: Range[] = dayBookings.map((b) => [toMin(b.start), toMin(b.end)]);
  const pending: Range[] = dayBookings.filter((b) => b.status === 'pending').map((b) => [toMin(b.start), toMin(b.end)]);
  const bookBuf: Range[] = booked.flatMap(([s, e]) => [[s - p.bufferMins, s] as Range, [e, e + p.bufferMins] as Range]);
  const blocked: Range[] = inp.blocks.filter((b) => b.date === date).map((b) => [toMin(b.start), toMin(b.end)]);
  const buffers = merge([...onBuf, ...bookBuf]);
  let free = subtract(open, [...occupied, ...booked, ...buffers, ...blocked]);
  if (date === nowISO) free = subtract(free, [[0, Math.ceil(nowMin / 30) * 30]]);
  free = free.filter(([s, e]) => e - s >= 60);
  return { open, overnight: occupied, booked: merge(booked), pending: merge(pending), buffers, blocked: merge(blocked), free };
}

export function buildSchedule(inp: ScheduleInput, fromISO: string, days: number, nowMin: number): Record<string, DaySchedule> {
  const out: Record<string, DaySchedule> = {};
  for (let i = 0; i < days; i++) {
    const date = addDays(fromISO, i);
    out[date] = daySchedule(inp, date, fromISO, nowMin);
  }
  return out;
}

/** Is [start,end) fully inside a free range? */
export function fitsFree(day: DaySchedule, start: number, end: number) {
  return day.free.some(([s, e]) => start >= s && end <= e);
}
