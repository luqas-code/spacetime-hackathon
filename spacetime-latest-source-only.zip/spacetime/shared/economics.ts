import type { Economics, Property } from './types.ts';

/**
 * Proposed commercial assumptions (shown as such in the UI) — the ONLY place fee rates are defined.
 * Everything else derives from these: guest checkout & property page (src/lib/pricing.ts, PriceRows),
 * owner/manager finance breakdowns (src/components/dash.tsx), owner dashboard & manager overview totals
 * (server/services.ts sums the per-booking figures), owner booking emails, and Smart Availability
 * (shared/optimiser.ts via calcEconomics). A guest fee of 0 hides the guest-fee row everywhere.
 *
 * Pending decision: 15% host-side commission with no guest service fee would be
 *   export const RATES = { commissionPct: 15, guestFeePct: 0 };
 * Existing bookings keep the figures stored when they were made; only new bookings use new rates.
 */
export const RATES = { commissionPct: 18, guestFeePct: 5 };

const r2 = (n: number) => Math.round(n * 100) / 100;

/**
 * Single source of truth for booking economics, used by the guest checkout,
 * the manager dashboard and the owner dashboard.
 *  gross       = max(hourly × hours, minimum booking price) + other disclosed charges
 *  guest pays  = gross + RATES.guestFeePct guest service fee + cleaning (at cost)
 *  commission  = RATES.commissionPct of gross (host side)
 *  mgmt fee    = manager's % of (gross − commission)
 *  owner gets  = gross − commission − mgmt fee   (cleaning passes through to the cleaner)
 */
export function calcEconomics(
  p: Pick<Property, 'pricePerHour' | 'minBookingPrice' | 'cleaningFee' | 'otherCharges'> & { delegation?: { mgmtFeePct: number } },
  hours: number,
  occurrences = 1,
  overrideHourly?: number,
): Economics {
  const hourly = overrideHourly ?? p.pricePerHour;
  const raw = hourly * hours;
  const minApplied = (p.minBookingPrice || 0) > raw;
  const rental = minApplied ? p.minBookingPrice : raw;
  const otherCharges = (p.otherCharges || []).reduce((s, c) => s + c.amount, 0);
  const gross = rental + otherCharges;
  const guestFee = gross * (RATES.guestFeePct / 100);
  const cleaning = p.cleaningFee || 0;
  const guestTotal = gross + guestFee + cleaning;
  const commission = gross * (RATES.commissionPct / 100);
  const mgmtFeePct = p.delegation?.mgmtFeePct ?? 0;
  const mgmtFee = (gross - commission) * (mgmtFeePct / 100);
  const ownerProceeds = gross - commission - mgmtFee;
  return {
    hours, hourly, rental: r2(rental), minApplied, otherCharges: r2(otherCharges), gross: r2(gross),
    guestFee: r2(guestFee), cleaning: r2(cleaning), guestTotal: r2(guestTotal),
    commission: r2(commission), mgmtFeePct, mgmtFee: r2(mgmtFee), ownerProceeds: r2(ownerProceeds),
    spacetimeRevenue: r2(commission + guestFee), occurrences, grandTotal: r2(guestTotal * occurrences),
  };
}

/** Cancellation policy: free until 2 hours before start; afterwards the full amount is due. */
export const FREE_CANCEL_HOURS = 2;
export function cancellationFee(totalForBooking: number, startsAt: Date, now: Date) {
  const hoursLeft = (startsAt.getTime() - now.getTime()) / 3600000;
  return hoursLeft >= FREE_CANCEL_HOURS ? 0 : totalForBooking;
}
