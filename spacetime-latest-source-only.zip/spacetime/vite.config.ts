import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';

export default defineConfig({
  base: './',
  plugins: [react()],
  build: { chunkSizeWarningLimit: 1200 },
  // API_PORT lets the dev proxy target an API server on another port (default 8787).
  server: { proxy: { '/api': { target: `http://localhost:${process.env.API_PORT || 8787}`, changeOrigin: true }, '/uploads': `http://localhost:${process.env.API_PORT || 8787}` } },
  resolve: { alias: { '@': path.resolve(__dirname, 'src') } },
});
