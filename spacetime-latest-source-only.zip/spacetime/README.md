# SpaceTime — *Your space. Your time.*

A three-sided marketplace prototype for booking private apartments by the hour in Paris:
**Space Owners** list and authorise spaces, **Space Managers** (existing property-management companies) run daytime
availability, bookings and cleaning, and **Guests** book by purpose. All three interfaces share one live backend.

---

## Screenshots

| Owner lists a space | Manager · Smart Availability | Guest matches & books | Booking reaches manager & owner |
|---|---|---|---|
| ![](docs/screenshots/1-owner-lists-a-space.png) | ![](docs/screenshots/2-manager-smart-availability.png) | ![](docs/screenshots/3-guest-matches-and-books.png) | ![](docs/screenshots/4-manager-and-owner-see-booking.png) |

## Try it without installing anything — GitHub Codespaces

1. On the GitHub repo page: **Code → Codespaces → Create codespace on main**.
2. Wait ~2 minutes: dependencies install and `npm run demo` starts automatically; a browser tab opens on the app.
3. To use phones: open the **Ports** tab, right-click port **8787 → Port visibility → Public**, and open that
   `https://…-8787.app.github.dev` address on each phone (HTTPS, so native sharing works too).

**If you see a blank page, an error page or “taking too long”:**
- Look at the Codespace **terminal**. The app is ready only when it prints `SpaceTime server on http://localhost:8787`.
  The first start builds the app and takes 1–2 minutes; reload after that line appears.
- Open `<your link>/api/health`. If it shows `{"ok":true,…}`, the server is fine — reload the app page.
- Nothing running? Run `node -v` in the terminal. It must be **22.13+**. If not, the `.devcontainer` folder
  was probably not uploaded (it's hidden on Mac/Windows). Fix: `nvm install 22 && nvm use 22`, then `npm install && npm run demo`.
- Make sure the link is for port **8787**, not 5173.

## Host a permanent link for judges — Render

Render → **New → Blueprint** → select this repo (uses `render.yaml`) → Deploy. You get `https://spacetime-xxxx.onrender.com`.
On the free plan the app sleeps when idle (first load takes ~30 s) and demo data resets on restart.

## 1 · Run it on your computer

Requires **Node.js 22.13+** (uses the built-in `node:sqlite` — no database to install).

```bash
npm install
npm run demo          # builds the app, then serves app + API on http://localhost:8787
```

Open three browser sessions (three phones, or three separate browser profiles / private windows) on that URL and
sign in with a different demo account in each.

**Phones on the same Wi‑Fi:** the server listens on all interfaces, so open `http://<your-laptop-ip>:8787` on each phone.
**For HTTPS** (needed for the native iOS/Android share sheet and clipboard), expose the port with a tunnel, e.g.
`npx cloudflared tunnel --url http://localhost:8787`, and open the `https://…` URL it prints on every phone.

| Command | What it does |
|---|---|
| `npm run demo` | Build + start (production-like, one URL) |
| `npm start` | Start the server (serves `dist/` + API) |
| `npm run dev` + `npm run dev:server` | Vite hot-reload on :5173 (proxies `/api` to :8787) + API with auto-restart |
| `npm run db:reset` | Wipe and re-seed the demo database (stop the server first) |
| `npm run typecheck` | Type-check web app and server |
| `npm run check:i18n` | List UI strings missing a French translation |

Data lives in `data/` (SQLite database + uploaded photos/documents) and survives restarts and refreshes.

## 2 · Demo accounts (password for all: `spacetime`)

| Role | Account | Notes |
|---|---|---|
| **S — Space Owner** | `sophie@spacetime.demo` — Sophie Laurent, Laurent Résidences SAS | Has a compliance file already verified by SpaceTime Compliance |
| **M — Space Manager** | `malik@spacetime.demo` — Malik Benali, Nestwell Conciergerie (fictional) | Manages 7 of the 18 sample spaces |
| **I — Guest** | `isaac@spacetime.demo` — Isaac Bernard | Onboarded, with home/work places |
| R — Compliance reviewer | `review@spacetime.demo` | Optional: approves listings that need human review |
| Second manager | `lea@spacetime.demo` — Léa Fontaine, Rive Hosting | Shows managers can't see each other's properties |
| Other guests | `priya@spacetime.demo`, `tom@spacetime.demo` | Hold sample bookings (one pending approval) |

The sign-in screen has one-tap buttons for S, M, I and R. Each browser keeps its own session.

## 3 · Environment variables (all optional — see `.env.example`)

| Variable | Effect when set | Without it |
|---|---|---|
| `ANTHROPIC_API_KEY` (+ `ANTHROPIC_MODEL`, default `claude-opus-5-5`) | Natural-language requests are parsed by Claude (structured output, French understood), and Smart Availability explanations are written by Claude from the computed figures. Server-side only; server-side refusal fallbacks enabled. | Deterministic rule-based parser (English phrasing) and generated explanations |
| `RESEND_API_KEY`, `EMAIL_FROM`, `EMAIL_TEST_RECIPIENT` | Booking emails to guest, manager and owner are sent through Resend; `EMAIL_TEST_RECIPIENT` redirects everything to one authorised inbox | Emails are stored and shown in-app (Profile → Emails) labelled “Preview — not sent” |
| `GEOAPIFY_API_KEY` | Address autocomplete via Geoapify | OpenStreetMap Nominatim lookup through the server + offline list of Paris stations, airports, areas and arrondissements |
| `PORT`, `DATA_DIR` | Port and data folder | `8787`, `./data` |

Put them in a `.env` file next to `package.json`; `npm start` loads it automatically.

## 4 · Recommended live demo (≈ 6 minutes)

**Phone A — Owner (Sophie)**
1. *List a space* → **Sample details** (pre-fills a family apartment at 27 rue de Lyon — every field is editable).
2. Photos: **Upload photos from this device** (camera roll) and/or tap a few from the sample library.
3. Amenities → Permitted uses (rest, between journeys, family, relax, work) → Hours & pricing:
   tap **Import overnight calendar (sample iCal feed)** to load its Airbnb nights.
4. Compliance: **Use my verified compliance file** → Management: choose **Malik Benali**, keep delegations → Review: tick the attestation → **Submit for review**.
5. “Approved — ready to publish” (basis: documents previously verified by SpaceTime Compliance) → **Publish now**.

**Phone B — Manager (Malik)** — no refresh needed
6. The dashboard shows **New property assigned** → tap it (opens Smart Availability).
7. *Calendar* tab: overnight stays (navy), cleaning buffers, bookable hours. Back to *Smart Availability*.
8. Pick **tomorrow** → the “Longest safe window 08:00–16:00” is *Recommended*: compare daytime net vs. overnight,
   see the turnover clean 16:00–17:00 before the 17:00 check-in. Tap **Explain**, open *Scenario assumptions* and drag a slider to show the maths respond.
9. **Approve slot** → the day turns bookable.

**Phone C — Guest (Isaac)** — Discover → the ✨ banner (or Search → *Describe what you need*)
10. Paste: *“I'm arriving at Gare de Lyon at 9 am with two kids, and my accommodation check-in isn't until 4 pm. We need somewhere to shower and rest.”*
11. It extracts place, 09:00–16:00, 1 adult + 2 children, shower, bed, luggage, family → asks **Which day?** → *Tomorrow*.
12. The new **Family apartment · Gare de Lyon** appears with ✓ reasons → *Details* (photos, amenities, permitted uses, pricing) → **Book 09:00–16:00** → add 2 children → accept house rules → **Confirm booking** → door code, address, calendar links.

**Back to Phone B** — 13. The booking pops up live. Open it: guest requirements, economics, **assign Éclat Ménage** to the cleaning task, mark **Ready**, **Message guest**.
**Phone C** — 14. The message arrives live; reply.
**Back to Phone A** — 15. Dashboard → *Latest booking* with gross value, 18 % commission, 20 % management fee, estimated owner proceeds, and the manager who handled it.

Extra beats: switch **EN/FR** on any phone (top-right); show `Priya`'s pending request at the Opéra salon approved by Malik and the status flipping on Priya's phone; try booking the same slot twice (the second is refused).

## 5 · What was built in this upgrade

**Shared backend (new)** — `server/` (Node + built-in SQLite, no framework):
- Sessions per device, role-based routes, and **server-side permissions**: managers only see assigned properties; they can't publish, change ownership, permitted uses or compliance, or price below the owner's floor; conversations are visible only to their participants.
- **Atomic booking** inside an `IMMEDIATE` transaction with a full availability re-check (overnight stays, cleaning buffers, blocks, other bookings) — simultaneous attempts on one slot produce one booking and `409` for the rest.
- **Live updates** to every device over Server-Sent Events (fallback refresh every 20 s and on focus).
- Persistent photo/document uploads (`/uploads`), notifications, email outbox, address lookup proxy, Claude integration.

**Shared business logic** — `shared/` (used by server *and* app, so every phone shows the same numbers):
- `economics.ts`: gross value, 18 % host commission, 5 % guest fee, cleaning at cost, management fee, owner proceeds.
- `schedule.ts`: availability = owner-authorised, manager-approved windows − overnight stays − bookings − buffers − blocks.
- `optimiser.ts`: **Smart Availability** — vacant windows around the overnight calendar, feasibility (turnover, cleaner hours, owner hours), net contribution, opportunity cost vs. a potential overnight booking under explicit scenario likelihoods, minimum viable price, recommendation; deterministic explanations.
- `nlu.ts`, `places.ts` (transport hubs first, arrondissements), `types.ts`.

**Owner app** — dashboard (earnings split, listings with status and manager, manager performance, operational updates), 8-step listing wizard
(details, real photo upload + sample library, amenities & accessibility, permitted uses & rules, owner-authorised hours / durations / buffers / overnight channel import / pricing & other charges, compliance with verified file or uploads, manager assignment & delegated authority, review & attestation), listing page (status pipeline, publish/pause, compliance review result, 7-day schedule, per-booking economics, edit permitted uses & delegation), messages with managers.

**Manager app** — *Today* dashboard (portfolio metrics, new assignments, alerts for cleaning conflicts, pending approvals, readiness, messages, upcoming bookings with cleaning status), *Portfolio*, per-property workspace (overview & readiness, 14-day calendar with open/block actions, Smart Availability, bookings, settings within delegated authority), *Smart* (portfolio-wide opportunity insights), *Cleaning* (assign providers, deadlines, scheduled → in progress → done, conflict detection), reservation detail (approve/decline, guest requirements, check-in status, cleaning, economics, message guest), *Inbox* (guest + owner threads).

**Guest app** — the existing Discover, Favourites, Search, Messages and Profile, now backed by the server; Discover organised as **Rest & Recharge / Work & Focus / Create & Gather** (only for activities a listing permits); time-first availability; real messaging with the manager; bookings with the 2-hour free-cancellation policy; native Web Share with copy/email/SMS/WhatsApp fallback; profile photo upload.

**Compliance** — automated completeness checks never certify legality. A listing is approved either because every document is from the operator's file already verified by SpaceTime Compliance (and its uses are within that scope), or by a human reviewer (account R). Only approved listings can be published; only published listings with manager-approved hours are bookable.

**Brand** — angular, forward-leaning SpaceTime wordmark and orbit-clock mark, Space Grotesk, ivory / midnight navy / electric blue / ice blue / lavender, geometric clipped cards, distinctive availability timelines. Fictional illustrated avatars for S, M, I and R.

**French** — every UI string (888) has a French translation, dates/currency use the locale, and the language choice is saved to the account. `npm run check:i18n` guards against gaps.

**Removed** — simulated host replies and “demo” banners. Remaining notices are discreet and accurate: preview checkout (no card charged), preview door code (no smart lock), emails labelled “preview — not sent” unless a provider is configured.

## 6 · Preserved from the first prototype

Map-first results with draggable sheet and price markers, filters, saved & recent searches, favourites, property detail
(gallery, amenities, permitted uses, rules, reviews, map, distances from your places), the 3-step booking flow with
recurring bookings, confirmation with calendar export (now also Google/Outlook links), natural-language matching with
follow-up questions, guest onboarding and preference editors, all 18 sample Paris spaces.

## 7 · Tested

Automated browser run with **three independent sessions** (owner, manager, guest) against one server, fresh database:
owner lists (real file upload), imports overnight calendar, uses verified file, assigns manager, submits → approved → publishes ·
manager receives the assignment **live**, reviews calendar, opens Smart Availability for tomorrow, explains, approves 08:00–16:00 ·
guest's natural-language request finds the new property (“Book 09:00–16:00”), books with 2 children ·
manager sees the booking live, assigns cleaning, marks ready, messages the guest · guest receives it live and replies, manager sees the reply live ·
owner sees the booking and economics. Zero client errors.

Also verified: three simultaneous bookings of one slot → one `200`, two `409`; overlapping booking `409`; second manager → `403` on Malik's property and conversations;
guest → manager API `403`; manager publish `403`; price below owner floor `403`; slot over an overnight stay `409`; unauthenticated booking `401`;
non-instant request → manager approves → guest sees *Confirmed* live and after refresh; FR on all three roles persists after reload.

Not verifiable in this build sandbox (no outbound access): Unsplash sample photos and map tiles (they load on a normal connection; broken images fall back to a placeholder), Resend, Geoapify and Claude calls (code paths are typed and fall back safely; enable with the variables above).

## 8 · Known limitations / next steps

- Listing *content* (titles, descriptions, rules) is shown as written by the owner; only the interface is translated. The offline parser understands English phrasing — set `ANTHROPIC_API_KEY` for French requests.
- Payments, real smart locks and cleaner dispatch are out of scope (shown as previews).
- Travel-status integrations (SNCF/Eurostar/flights) were not built; calendar integration is export/links only.
- Overnight calendars use a sample iCal import; a real PMS/iCal sync would replace it.
- Seed data, Space Partners and reviews are fictional. Commission/fee rates are proposed assumptions.
