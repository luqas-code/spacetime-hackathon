import { useEffect, type ReactNode } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { BottomNav } from '@/components/BottomNav';
import { Toast } from '@/components/ui';
import { useStore } from '@/store/useStore';
import { connectLive } from '@/lib/api';
import { setLocaleLang } from '@/lib/locale';
import { todayISO, defaultDate } from '@/lib/time';
import type { Role } from '@/types';
import LoginPage from '@/pages/Login';
import SearchPage from '@/pages/Search';
import ResultsPage from '@/pages/Results';
import DiscoverPage from '@/pages/Discover';
import FavouritesPage from '@/pages/Favourites';
import BookingsPage from '@/pages/Bookings';
import ThreadPage from '@/pages/Inbox';
import ProfilePage from '@/pages/Profile';
import PropertyPage from '@/pages/Property';
import BookPage from '@/pages/Book';
import ConfirmedPage from '@/pages/Confirmed';
import AssistantPage from '@/pages/Assistant';
import OnboardingPage from '@/pages/Onboarding';
import OwnerHome from '@/pages/owner/OwnerHome';
import OwnerListings from '@/pages/owner/OwnerListings';
import ListingWizard from '@/pages/owner/ListingWizard';
import OwnerProperty from '@/pages/owner/OwnerProperty';
import ManagerHome from '@/pages/manager/ManagerHome';
import ManagerPortfolio from '@/pages/manager/ManagerPortfolio';
import ManagerProperty from '@/pages/manager/ManagerProperty';
import ManagerInsights from '@/pages/manager/ManagerInsights';
import ManagerCleaning from '@/pages/manager/ManagerCleaning';
import ManagerBooking from '@/pages/manager/ManagerBooking';
import InboxList from '@/pages/InboxList';
import ReviewPage from '@/pages/Review';

const HOME: Record<Role, string> = { guest: '/search', owner: '/owner', manager: '/manager', reviewer: '/review' };
const NAV_ROUTES: Record<Role, string[]> = {
  guest: ['/search', '/discover', '/favourites', '/bookings', '/profile', '/results'],
  owner: ['/owner', '/owner/listings', '/owner/messages', '/owner/profile'],
  manager: ['/manager', '/manager/portfolio', '/manager/insights', '/manager/cleaning', '/manager/messages'],
  reviewer: ['/review', '/review/profile'],
};

export default function App() {
  const { pathname } = useLocation();
  const token = useStore((s) => s.token);
  const user = useStore((s) => s.user);
  const lang = useStore((s) => s.lang);

  useEffect(() => { setLocaleLang(lang); }, [lang]);
  useEffect(() => {
    void useStore.getState().loadCatalog();
    const q = useStore.getState().query;
    if (q.when.date < todayISO()) useStore.getState().patchQuery((x) => ({ ...x, when: { ...x.when, date: defaultDate() } }));
  }, []);
  useEffect(() => {
    if (!token) return;
    void useStore.getState().refreshMe();
    return connectLive();
  }, [token]);

  if (!token) {
    if (pathname.startsWith('/space/')) return <Shell><Routes><Route path="/space/:id" element={<PropertyPage />} /></Routes></Shell>;
    if (pathname !== '/login') return <Shell><Navigate to={`/login?next=${encodeURIComponent(pathname)}`} replace /></Shell>;
    return <Shell><LoginPage /></Shell>;
  }
  if (!user) return <Shell><Splash /></Shell>;

  const role = user.role;
  const showNav = NAV_ROUTES[role].includes(pathname);
  const guard = (r: Role, el: ReactNode) => (role === r ? el : <Navigate to={HOME[role]} replace />);
  // First-run onboarding (language first) for every marketplace role. Demo accounts are already onboarded.
  if (role !== 'reviewer' && !user.prefs.onboarded && pathname !== '/onboarding') return <Shell><Navigate to="/onboarding" replace /></Shell>;

  return (
    <Shell>
      <Routes>
        <Route path="/" element={<Navigate to={HOME[role]} replace />} />
        <Route path="/login" element={<Navigate to={HOME[role]} replace />} />
        {/* Guest */}
        <Route path="/onboarding" element={role !== 'reviewer' ? <OnboardingPage /> : <Navigate to={HOME[role]} replace />} />
        <Route path="/search" element={guard('guest', <SearchPage />)} />
        <Route path="/results" element={guard('guest', <ResultsPage />)} />
        <Route path="/discover" element={guard('guest', <DiscoverPage />)} />
        <Route path="/favourites" element={guard('guest', <FavouritesPage />)} />
        <Route path="/bookings" element={guard('guest', <BookingsPage />)} />
        {/* old links (emails, notifications) */}
        <Route path="/messages" element={<Navigate to="/bookings" replace />} />
        <Route path="/messages/:convId" element={guard('guest', <ThreadPage />)} />
        <Route path="/profile" element={guard('guest', <ProfilePage />)} />
        <Route path="/space/:id" element={<PropertyPage />} />
        <Route path="/book/:id" element={guard('guest', <BookPage />)} />
        <Route path="/confirmed/:bookingId" element={guard('guest', <ConfirmedPage />)} />
        <Route path="/assistant" element={guard('guest', <AssistantPage />)} />
        {/* Owner */}
        <Route path="/owner" element={guard('owner', <OwnerHome />)} />
        <Route path="/owner/listings" element={guard('owner', <OwnerListings />)} />
        <Route path="/owner/new" element={guard('owner', <ListingWizard />)} />
        <Route path="/owner/edit/:id" element={guard('owner', <ListingWizard />)} />
        <Route path="/owner/property/:id" element={guard('owner', <OwnerProperty />)} />
        <Route path="/owner/messages" element={guard('owner', <InboxList />)} />
        <Route path="/owner/messages/:convId" element={guard('owner', <ThreadPage />)} />
        <Route path="/owner/profile" element={guard('owner', <ProfilePage />)} />
        {/* Manager */}
        <Route path="/manager" element={guard('manager', <ManagerHome />)} />
        <Route path="/manager/portfolio" element={guard('manager', <ManagerPortfolio />)} />
        <Route path="/manager/property/:id" element={guard('manager', <ManagerProperty />)} />
        <Route path="/manager/insights" element={guard('manager', <ManagerInsights />)} />
        <Route path="/manager/cleaning" element={guard('manager', <ManagerCleaning />)} />
        <Route path="/manager/booking/:id" element={guard('manager', <ManagerBooking />)} />
        <Route path="/manager/messages" element={guard('manager', <InboxList />)} />
        <Route path="/manager/messages/:convId" element={guard('manager', <ThreadPage />)} />
        <Route path="/manager/profile" element={guard('manager', <ProfilePage />)} />
        {/* Compliance */}
        <Route path="/review" element={guard('reviewer', <ReviewPage />)} />
        <Route path="/review/profile" element={guard('reviewer', <ProfilePage />)} />
        <Route path="*" element={<Navigate to={HOME[role]} replace />} />
      </Routes>
      {showNav && <BottomNav />}
    </Shell>
  );
}

function Splash() {
  return <div className="grid flex-1 place-items-center"><div className="h-8 w-8 animate-spin rounded-full border-4 border-ice-200 border-t-electric" /></div>;
}

function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="h-full w-full bg-[radial-gradient(ellipse_at_top,#E4E9FC,transparent_60%),linear-gradient(#E6E2D6,#E6E2D6)] sm:py-4">
      <div className="app-shell sm:rounded-[2rem] sm:shadow-float sm:ring-1 sm:ring-ink/5" id="app-shell">
        {children}
        <Toast />
        <div id="sheet-root" />
      </div>
    </div>
  );
}
