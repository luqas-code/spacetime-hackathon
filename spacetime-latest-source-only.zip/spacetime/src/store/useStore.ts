import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Filters, Lang, Property, SavedSearch, SearchQuery, User, UserPrefs } from '@/types';
import { DEFAULT_FILTERS, DEFAULT_QUERY } from '@/lib/search';
import { setCatalog } from '@/data/properties';
import { setLocaleLang } from '@/lib/locale';
import { api } from '@/lib/api';

const uid = (p: string) => `${p}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

interface State {
  // device-local (per phone) — session token & UI state only
  token: string | null;
  lang: Lang;
  query: SearchQuery;
  filters: Filters;
  recentSearches: SearchQuery[];
  discoverAnchor: string;
  // server state mirrors
  user: User | null;
  catalogRev: number;
  catalogLoaded: boolean;
  serverToday: string | null;
  rev: number;
  live: boolean;
  toast: { id: number; text: string; link?: string; tone?: 'info' | 'error' } | null;

  login: (email: string, password: string) => Promise<User>;
  logout: () => Promise<void>;
  signedOut: () => void;
  refreshMe: () => Promise<void>;
  updateMe: (patch: Partial<Pick<User, 'name' | 'phone' | 'bio' | 'company' | 'avatarUrl' | 'lang'>> & { prefs?: Partial<UserPrefs> }) => Promise<void>;
  setLang: (l: Lang) => void;
  loadCatalog: () => Promise<void>;
  bump: () => void;

  toggleFavourite: (id: string) => boolean;
  setQuery: (q: SearchQuery) => void;
  patchQuery: (fn: (q: SearchQuery) => SearchQuery) => void;
  setFilters: (f: Filters) => void;
  commitSearch: () => void;
  saveSearch: (name: string) => void;
  deleteSavedSearch: (id: string) => void;
  setDiscoverAnchor: (id: string) => void;
  showToast: (text: string, link?: string, tone?: 'info' | 'error') => void;
}

let catalogInflight: Promise<void> | null = null;

export const useStore = create<State>()(
  persist(
    (set, get) => ({
      token: null,
      lang: 'en',
      query: DEFAULT_QUERY(),
      filters: DEFAULT_FILTERS,
      recentSearches: [],
      discoverAnchor: 'loc-home',
      user: null,
      catalogRev: 0,
      catalogLoaded: false,
      serverToday: null,
      rev: 0,
      live: false,
      toast: null,

      login: async (email, password) => {
        const out = await api<{ token: string; user: User }>('/api/login', { body: { email, password } });
        // The account's saved language always wins (it follows the user across devices).
        // The sign-in screen's language link only affects reading that screen.
        const lang = out.user.lang;
        set({ token: out.token, user: out.user, lang });
        setLocaleLang(lang);
        return out.user;
      },
      logout: async () => {
        try { await api('/api/logout', { body: {} }); } catch { /* ignore */ }
        get().signedOut();
      },
      signedOut: () => set({ token: null, user: null }),
      refreshMe: async () => {
        if (!get().token) return;
        try {
          const user = await api<User>('/api/me');
          // Language is an account setting: adopt it if it was changed on another device.
          if (user.lang !== get().lang) setLocaleLang(user.lang);
          set({ user, lang: user.lang });
        } catch { /* handled by api() */ }
      },
      updateMe: async (patch) => {
        const user = await api<User>('/api/me', { method: 'PATCH', body: patch });
        set({ user, lang: user.lang });
      },
      setLang: (l) => {
        setLocaleLang(l);
        set({ lang: l });
        if (get().token) void api('/api/me', { method: 'PATCH', body: { lang: l } }).then((u) => set({ user: u as User })).catch(() => {});
      },
      loadCatalog: async () => {
        if (catalogInflight) return catalogInflight;
        catalogInflight = (async () => {
          try {
            const out = await api<{ today: string; listings: Property[] }>('/api/catalog');
            setCatalog(out.listings);
            set((s) => ({ catalogRev: s.catalogRev + 1, catalogLoaded: true, serverToday: out.today }));
          } catch { /* offline — keep last catalogue */ }
          finally { catalogInflight = null; }
        })();
        return catalogInflight;
      },
      bump: () => set((s) => ({ rev: s.rev + 1 })),

      toggleFavourite: (id) => {
        const u = get().user;
        if (!u) return false;
        const has = u.prefs.favourites.includes(id);
        const favourites = has ? u.prefs.favourites.filter((f) => f !== id) : [id, ...u.prefs.favourites];
        set({ user: { ...u, prefs: { ...u.prefs, favourites } } });
        void get().updateMe({ prefs: { favourites } }).catch(() => {});
        get().showToast(has ? 'Removed from Favourites' : 'Saved to Favourites');
        return !has;
      },
      setQuery: (q) => set({ query: q }),
      patchQuery: (fn) => set((s) => ({ query: fn(s.query) })),
      setFilters: (f) => set({ filters: f }),
      commitSearch: () =>
        set((s) => {
          const key = (q: SearchQuery) => JSON.stringify([q.where.label, q.when, q.who]);
          return { recentSearches: [s.query, ...s.recentSearches.filter((r) => key(r) !== key(s.query))].slice(0, 5) };
        }),
      saveSearch: (name) => {
        const u = get().user;
        if (!u) return;
        const savedSearches: SavedSearch[] = [{ id: uid('ss'), name, query: get().query, filters: get().filters, createdAt: Date.now() }, ...u.prefs.savedSearches];
        void get().updateMe({ prefs: { savedSearches } });
        get().showToast('Search saved');
      },
      deleteSavedSearch: (id) => {
        const u = get().user;
        if (!u) return;
        void get().updateMe({ prefs: { savedSearches: u.prefs.savedSearches.filter((x) => x.id !== id) } });
      },
      setDiscoverAnchor: (id) => set({ discoverAnchor: id }),
      showToast: (text, link, tone = 'info') => set({ toast: { id: Date.now(), text, link, tone } }),
    }),
    {
      name: 'spacetime-device-v2',
      partialize: (s) => ({ token: s.token, lang: s.lang, query: s.query, filters: s.filters, recentSearches: s.recentSearches, discoverAnchor: s.discoverAnchor }),
      onRehydrateStorage: () => (s) => {
        if (s) setLocaleLang(s.lang);
      },
    },
  ),
);

export const useIsFav = (id: string) => useStore((s) => !!s.user?.prefs.favourites.includes(id));
export const useUser = () => useStore((s) => s.user);
