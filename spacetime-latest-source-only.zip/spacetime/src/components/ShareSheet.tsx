import { Copy, Mail, MessageSquare, Share2 } from 'lucide-react';
import { Sheet } from './ui';
import { useStore } from '@/store/useStore';
import { useT } from '@/i18n';

/** Shareable deep link to a listing (works with the hash router). */
export const listingUrl = (id: string) => `${window.location.origin}${window.location.pathname}#/space/${id}`;

async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // http:// on a LAN has no Clipboard API — fall back to a hidden textarea
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  }
}

/** Use the native share sheet (iOS/Android) when available, else show our fallback sheet. */
export async function shareListing(title: string, id: string, openFallback: () => void) {
  const url = listingUrl(id);
  if (navigator.share) {
    try {
      await navigator.share({ title: `${title} · SpaceTime`, text: title, url });
      return;
    } catch (e) {
      if ((e as Error).name === 'AbortError') return;
    }
  }
  openFallback();
}

export function ShareFallback({ open, onClose, title, id }: { open: boolean; onClose: () => void; title: string; id: string }) {
  const t = useT();
  const url = listingUrl(id);
  const msg = `${title} — ${url}`;
  return (
    <Sheet open={open} onClose={onClose} title={t('Share this space')}>
      <div className="space-y-2 pb-4">
        <div className="truncate rounded-lg bg-ivory-100 px-3 py-2.5 font-mono text-[12px] text-ink-600">{url}</div>
        <button className="btn-ghost w-full justify-start" onClick={async () => { if (await copyText(url)) useStore.getState().showToast('Link copied'); onClose(); }}><Copy size={17} /> {t('Copy link')}</button>
        <a className="btn-ghost w-full justify-start" href={`mailto:?subject=${encodeURIComponent(`${title} · SpaceTime`)}&body=${encodeURIComponent(msg)}`}><Mail size={17} /> {t('Email link')}</a>
        <a className="btn-ghost w-full justify-start" href={`sms:?&body=${encodeURIComponent(msg)}`}><MessageSquare size={17} /> {t('Text message')}</a>
        <a className="btn-ghost w-full justify-start" href={`https://wa.me/?text=${encodeURIComponent(msg)}`} target="_blank" rel="noreferrer"><Share2 size={17} /> WhatsApp</a>
      </div>
    </Sheet>
  );
}
