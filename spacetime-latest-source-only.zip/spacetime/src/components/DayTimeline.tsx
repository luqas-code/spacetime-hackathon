import type { DaySchedule, Property } from '@/types';
import { dayOf } from '@/lib/availability';
import { toHHMM, todayISO, nowMinutes } from '@/lib/time';
import { useT } from '@/i18n';

type R = [number, number];
const FROM = 6 * 60;
const TO = 24 * 60;
const pct = (m: number) => `${((Math.max(FROM, Math.min(TO, m)) - FROM) / (TO - FROM)) * 100}%`;
const width = (a: number, b: number) => `${(Math.max(0, Math.min(TO, b) - Math.max(FROM, a)) / (TO - FROM)) * 100}%`;

/** Distinctive SpaceTime availability bar: overnight stays, approved daytime windows, bookings, buffers, blocks. */
export function TimelineBar({ day, date, highlight, height = 'h-9', guestView = false }: { day: DaySchedule; date: string; highlight?: R; height?: string; guestView?: boolean }) {
  const isToday = date === todayISO();
  const seg = (rs: R[], cls: string, key: string) => rs.map(([a, b]) => <div key={key + a} className={`absolute inset-y-1 rounded-[5px] ${cls}`} style={{ left: pct(a), width: width(a, b) }} />);
  return (
    <div className={`relative ${height} overflow-hidden rounded-lg bg-ivory-100`}>
      {!guestView && seg(day.overnight, 'bg-ink/85', 'o')}
      {seg(day.open, 'bg-ice-200', 'w')}
      {seg(day.free, 'bg-electric/80', 'f')}
      {seg(day.buffers, 'slot-stripe', 'c')}
      {seg(day.booked, guestView ? 'bg-ivory-300' : 'bg-lavender-600', 'b')}
      {!guestView && seg(day.pending, 'border-2 border-dashed border-lavender-600 bg-lavender-100', 'p')}
      {seg(day.blocked, 'block-stripe', 'x')}
      {highlight && <div className="absolute inset-y-0 rounded-md border-2 border-ink bg-electric/25" style={{ left: pct(highlight[0]), width: width(highlight[0], highlight[1]) }} />}
      {isToday && <div className="absolute inset-y-0 w-0.5 bg-rose-500" style={{ left: pct(nowMinutes()) }} />}
    </div>
  );
}

export function TimelineAxis() {
  return (
    <div className="mt-1 flex justify-between text-[11.5px] font-medium text-ink-500">
      {[6, 9, 12, 15, 18, 21, 24].map((h) => <span key={h}>{toHHMM(h * 60).slice(0, 2)}h</span>)}
    </div>
  );
}

export function TimelineLegend({ guestView = false }: { guestView?: boolean }) {
  const t = useT();
  const items: [string, string][] = guestView
    ? [['bg-electric/80', 'Bookable'], ['bg-ivory-300', 'Booked'], ['slot-stripe', 'Cleaning'], ['bg-ivory-100 ring-1 ring-ivory-300', 'Unavailable']]
    : [['bg-ink/85', 'Overnight stay'], ['bg-electric/80', 'Bookable daytime'], ['bg-lavender-600', 'SpaceTime booking'], ['slot-stripe', 'Cleaning buffer'], ['block-stripe', 'Blocked'], ['bg-ice-200', 'Approved (taken)']];
  return (
    <div className="mt-2 flex flex-wrap gap-x-3.5 gap-y-1 text-[11px] text-ink-500">
      {items.map(([c, l]) => <span key={l} className="inline-flex items-center gap-1.5"><span className={`h-2.5 w-2.5 rounded-sm ${c}`} /> {t(l)}</span>)}
    </div>
  );
}

export function DayTimeline({ p, date, highlight }: { p: Property; date: string; highlight?: R }) {
  const t = useT();
  const day = dayOf(p, date);
  return (
    <div>
      <TimelineBar day={day} date={date} highlight={highlight} guestView />
      <TimelineAxis />
      <TimelineLegend guestView />
      {!day.open.length && <p className="mt-2 text-[13px] font-semibold text-ink-500">{t('No daytime availability on this day.')}</p>}
      {!!day.open.length && !day.free.length && <p className="mt-2 text-[13px] font-semibold text-ink-500">{t('Fully booked on this day.')}</p>}
    </div>
  );
}
