import { useMemo, useState } from 'react';
import { Bot, Check, CheckCircle2, ChevronDown, CircleAlert, Loader2, Moon, SlidersHorizontal, Sparkles, SprayCan, Sun, ThumbsDown, Wand2, X, XCircle } from 'lucide-react';
import type { Block, Booking, Property, Slot, Stay } from '@/types';
import { analyseWeek, defaultAssumptions, evaluateWindow, type Assumptions, type Candidate, type ReasonCode } from '../../../shared/optimiser.ts';
import { TimelineAxis, TimelineBar, TimelineLegend } from '../DayTimeline';
import { StatusPill } from '../ui';
import { eur, RATES } from '@/lib/pricing';
import { dayLabel, longDate, shortDate, TIME_OPTIONS, toHHMM, toMin } from '@/lib/time';
import { api } from '@/lib/api';
import { useStore } from '@/store/useStore';
import { useT, type T } from '@/i18n';

export type MgrPropertyData = { property: Property; stays: Stay[]; slots: Slot[]; blocks: Block[]; bookings: Booking[]; today: string; nowMin: number };

const REASON: Record<ReasonCode, string> = {
  occupied_all_day: 'Overnight stay all day', owner_not_allowed: 'Outside owner-authorised hours', overlaps_stay: 'Overlaps overnight stay or its turnover',
  overlaps_booking: 'Overlaps a booking or its cleaning buffer', blocked: 'Blocked period', no_cleaner: 'Turnover clean outside cleaning-staff hours',
  window_too_short: 'Shorter than minimum booking', past: 'Already passed',
};
const recPill = (c: Candidate, t: T) => c.alreadyOpen ? <StatusPill tone="ok"><Check size={11} /> {t('Open')}</StatusPill> : c.recommendation === 'open' ? <StatusPill tone="info"><Sparkles size={11} /> {t('Recommended')}</StatusPill> : c.recommendation === 'hold' ? <StatusPill tone="warn">{t('Hold')}</StatusPill> : <StatusPill tone="muted">{t('Not viable')}</StatusPill>;

export function SmartAvailability({ data, onChanged, initialDate }: { data: MgrPropertyData; onChanged: () => void; initialDate?: string }) {
  const t = useT();
  const p = data.property;
  const [a, setA] = useState<Assumptions>(() => defaultAssumptions(p));
  const [showA, setShowA] = useState(false);
  const inp = useMemo(() => ({ property: p, stays: data.stays, bookings: data.bookings, slots: data.slots, blocks: data.blocks, today: data.today, nowMin: data.nowMin }), [data, p]);
  const week = useMemo(() => analyseWeek(inp, a, 7), [inp, a]);
  const firstGood = week.find((d) => d.candidates.some((c) => c.recommendation === 'open' && !c.alreadyOpen))?.date;
  const [date, setDate] = useState(initialDate ?? firstGood ?? data.today);
  const day = week.find((d) => d.date === date) ?? week[0];
  const [dismissed, setDismissed] = useState<string[]>([]);
  const [custom, setCustom] = useState<{ start: string; end: string } | null>(null);
  const customC = custom ? evaluateWindow(inp, date, custom.start, custom.end, a) : null;

  return (
    <div className="space-y-4">
      <div className="clip-corner bg-ink p-4 text-white">
        <div className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.1em] text-lavender"><Sparkles size={13} /> {t('Smart Availability')}</div>
        <p className="mt-1 text-[14px] leading-snug text-ice-200">{t('Pick a day to see which vacant daytime windows are safe and worth opening.')}</p>
        <div className="no-scrollbar -mx-1 mt-3 flex gap-1.5 overflow-x-auto px-1">
          {week.map((d) => {
            const s = shortDate(d.date);
            const best = d.candidates.find((c) => c.alreadyOpen) ? 'open' : d.candidates.find((c) => c.recommendation === 'open') ? 'rec' : d.candidates.find((c) => c.recommendation === 'hold') ? 'hold' : 'none';
            return (
              <button key={d.date} onClick={() => { setDate(d.date); setCustom(null); }} aria-pressed={d.date === date} className={`flex min-h-[56px] min-w-[52px] shrink-0 flex-col items-center rounded-lg px-2 py-1.5 ${d.date === date ? 'bg-white text-ink' : 'bg-white/10'}`}>
                <span className="whitespace-nowrap text-[11px] font-semibold opacity-80">{d.date === data.today ? t('Today') : s.dow}</span>
                <span className="text-[16px] font-bold">{s.day}</span>
                <span className={`mt-0.5 h-1.5 w-4 rounded-full ${best === 'open' ? 'bg-emerald-400' : best === 'rec' ? 'bg-electric' : best === 'hold' ? 'bg-amber-400' : 'bg-white/25'}`} />
              </button>
            );
          })}
        </div>
      </div>

      <div className="card p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2"><h3 className="text-[16px] font-bold">{dayLabel(date)}</h3>
          <div className="flex flex-wrap gap-1.5 text-[12px]">
            <span className="inline-flex items-center gap-1 rounded-md bg-ivory-100 px-2 py-1"><Moon size={11} /> {day.nightBefore ? `${day.nightBefore.channel} → ${p.overnight.checkout}` : t('No guest last night')}</span>
            <span className="inline-flex items-center gap-1 rounded-md bg-ivory-100 px-2 py-1"><Sun size={11} /> {day.nightAfter ? `${day.nightAfter.channel} ${p.overnight.checkin} →` : t('Tonight open')}</span>
          </div>
        </div>
        {p.schedule?.[date] && <><TimelineBar day={p.schedule[date]} date={date} /><TimelineAxis /><TimelineLegend /></>}
        {day.reasons.length > 0 && <p className="mt-3 rounded-lg bg-ivory-100 px-3 py-2 text-[12.5px] text-ink-600">{day.reasons.map((r) => t(REASON[r])).join(' · ')}</p>}
      </div>

      <div className="space-y-3">
        {day.candidates.filter((c) => !dismissed.includes(c.id)).map((c, i) => <CandidateCard key={c.id} c={c} a={a} p={p} label={i === 0 && c.hours > a.durationHours ? t('Longest safe window') : toMin(c.start) < 12 * 60 ? t('Morning') : toMin(c.start) < 17 * 60 ? t('Afternoon') : t('Evening')} onDismiss={() => setDismissed([...dismissed, c.id])} onAdjust={() => setCustom({ start: c.start, end: c.end })} onApproved={onChanged} />)}
        {day.candidates.length > 0 && day.candidates.every((c) => dismissed.includes(c.id)) && <p className="text-center text-[13px] text-ink-500">{t('All suggestions for this day were rejected.')}</p>}
        <div className="card p-4">
          <div className="flex items-center justify-between"><h4 className="text-[14px] font-bold">{t('Custom window')}</h4>{!custom && <button onClick={() => setCustom({ start: toHHMM(day.window?.[0] ?? 9 * 60), end: toHHMM(Math.min(day.window?.[1] ?? 17 * 60, (day.window?.[0] ?? 9 * 60) + a.durationHours * 60)) })} className="text-[12.5px] font-semibold text-electric-600">{t('Set times')}</button>}</div>
          {custom && <>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <select className="input py-2.5" value={custom.start} onChange={(e) => setCustom({ ...custom, start: e.target.value })}>{TIME_OPTIONS.map((x) => <option key={x}>{x}</option>)}</select>
              <select className="input py-2.5" value={custom.end} onChange={(e) => setCustom({ ...custom, end: e.target.value })}>{TIME_OPTIONS.filter((x) => toMin(x) > toMin(custom.start)).map((x) => <option key={x}>{x}</option>)}</select>
            </div>
            {customC && <div className="mt-3"><CandidateCard c={customC} a={a} p={p} label={t('Your window')} onApproved={onChanged} flat /></div>}
          </>}
        </div>
      </div>

      <div className="card overflow-hidden">
        <button className="flex min-h-[52px] w-full items-center justify-between p-4" aria-expanded={showA} onClick={() => setShowA(!showA)}><span className="flex items-center gap-2 text-[15px] font-bold"><SlidersHorizontal size={16} /> {t('Adjust assumptions')}</span><ChevronDown size={18} className={`transition ${showA ? 'rotate-180' : ''}`} /></button>
        {showA && (
          <div className="space-y-3 border-t border-ivory-200 p-4">
            <p className="text-[13px] text-ink-500">{t('Likelihoods are adjustable scenario inputs, not predictions — SpaceTime has no historical demand data for this property yet.')}</p>
            <Num label={t('Proposed daytime price (€/h)')} v={a.hourlyPrice} on={(hourlyPrice) => setA({ ...a, hourlyPrice })} />
            <Num label={t('Typical booking length (h)')} v={a.durationHours} on={(durationHours) => setA({ ...a, durationHours: Math.max(1, Math.min(12, durationHours)) })} />
            <Num label={t('Extra clean — actual cost (€)')} v={a.cleaningCost} on={(cleaningCost) => setA({ ...a, cleaningCost })} />
            <Num label={t('Linen, utilities & supplies (€)')} v={a.consumables} on={(consumables) => setA({ ...a, consumables })} />
            <Num label={t('Management fee (%)')} v={a.mgmtFeePct} on={(mgmtFeePct) => setA({ ...a, mgmtFeePct })} />
            <Num label={t('Overnight rate (€)')} v={a.overnightRate} on={(overnightRate) => setA({ ...a, overnightRate })} />
            <Num label={t('Overnight channel fee (%)')} v={a.channelFeePct} on={(channelFeePct) => setA({ ...a, channelFeePct })} />
            <Range label={t('Chance tonight still sells overnight (assumption)')} v={a.overnightLikelihood} on={(overnightLikelihood) => setA({ ...a, overnightLikelihood })} />
            <Range label={t('Expected booking probability (assumption)')} v={a.daytimeLikelihood} on={(daytimeLikelihood) => setA({ ...a, daytimeLikelihood })} />
            <Num label={t('Turnover buffer (min)')} v={a.bufferMins} on={(bufferMins) => setA({ ...a, bufferMins })} />
            <div className="grid grid-cols-2 gap-2"><label className="text-[12px] text-ink-500">{t('Cleaners from')}<select className="input mt-1 py-2" value={a.staffStart} onChange={(e) => setA({ ...a, staffStart: e.target.value })}>{TIME_OPTIONS.map((x) => <option key={x}>{x}</option>)}</select></label><label className="text-[12px] text-ink-500">{t('Cleaners until')}<select className="input mt-1 py-2" value={a.staffEnd} onChange={(e) => setA({ ...a, staffEnd: e.target.value })}>{TIME_OPTIONS.map((x) => <option key={x}>{x}</option>)}</select></label></div>
            <button className="text-[12.5px] font-semibold text-electric-600" onClick={() => setA(defaultAssumptions(p))}>{t('Reset to property defaults')}</button>
          </div>
        )}
      </div>
    </div>
  );
}

function CandidateCard({ c, a, p, label, onDismiss, onAdjust, onApproved, flat }: { c: Candidate; a: Assumptions; p: Property; label: string; onDismiss?: () => void; onAdjust?: () => void; onApproved: () => void; flat?: boolean }) {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const [explain, setExplain] = useState<{ text: string; engine: string } | null>(null);
  const [why, setWhy] = useState(false);
  const [busy, setBusy] = useState<'explain' | 'approve' | null>(null);
  const [err, setErr] = useState('');
  const doExplain = async () => {
    setBusy('explain');
    try { setExplain(await api('/api/ai/explain', { body: { candidate: c, assumptions: a, lang } })); } catch { /* ignore */ } finally { setBusy(null); }
  };
  const approve = async () => {
    setBusy('approve');
    setErr('');
    try {
      await api(`/api/manager/properties/${p.id}/slots`, { body: { date: c.date, start: c.start, end: c.end, source: 'optimiser' } });
      useStore.getState().showToast('Slot approved — now bookable by guests');
      onApproved();
    } catch (e) { setErr(e instanceof Error ? t(e.message) : 'Error'); }
    finally { setBusy(null); }
  };
  const cleanEnd = toHHMM(toMin(c.end) + a.bufferMins);
  const recText = c.alreadyOpen ? t('Already open to guests') : c.recommendation === 'open' ? t('Open this slot') : c.recommendation === 'hold' ? t('Hold — gain too small or uncertain') : t('Cannot be booked safely');
  const recTone = c.alreadyOpen ? 'text-emerald-700' : c.recommendation === 'open' ? 'text-electric-700' : c.recommendation === 'hold' ? 'text-amber-700' : 'text-rose-700';
  // Breakdown of the existing model (shared/optimiser.ts) — same numbers, clearer order.
  const rows: [string, number, string?][] = [
    [t('Expected daytime booking revenue ({h} h at {x}/h)', { h: c.hours, x: eur(a.hourlyPrice) }), c.daytime.gross],
    [t('SpaceTime commission ({n}%)', { n: RATES.commissionPct }), -c.daytime.commission],
    [t('Property-management fee ({n}%)', { n: a.mgmtFeePct }), -c.daytime.mgmtFee],
    [t('Cleaning fee paid by guest'), c.daytime.cleaningRecovered],
    [t('Cleaning & turnover cost'), -c.daytime.cleaningCost],
    [t('Linen, utilities & supplies'), -c.daytime.consumables],
    [t('Net if booked'), c.daytime.net, 'font-bold border-t border-ivory-200 pt-1'],
  ];
  return (
    <div className={`${flat ? 'rounded-xl bg-ivory-50 ring-1 ring-ivory-200' : 'card'} p-4 ${c.recommendation === 'open' && !c.alreadyOpen ? 'ring-2 ring-electric' : ''}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="text-[12.5px] font-semibold text-ink-500">{label} · {longDate(c.date)}</div>
          <div className="text-[22px] font-bold tabular-nums tracking-tight">{c.start}–{c.end} <span className="text-[14px] font-semibold text-ink-500">· {c.hours} h</span></div>
        </div>
        <div className="shrink-0">{recPill(c, t)}</div>
      </div>
      <div className={`mt-1 text-[15px] font-bold ${recTone}`}>{t('Recommendation: {r}', { r: recText })}</div>

      {/* The three questions: safe? worthwhile? next step? */}
      <dl className="mt-3 divide-y divide-ivory-200 rounded-xl bg-ivory-50 text-[14px]">
        <div className="flex items-start gap-2.5 px-3 py-2.5">
          {c.feasible ? <CheckCircle2 size={18} className="mt-0.5 shrink-0 text-emerald-600" /> : <XCircle size={18} className="mt-0.5 shrink-0 text-rose-600" />}
          <div className="min-w-0 flex-1">
            <dt className="text-[12.5px] text-ink-500">{t('Can it be booked safely?')}</dt>
            {c.feasible
              ? <dd className="font-semibold">{t('Cleaning buffer: sufficient')} <span className="font-normal text-ink-600">· {t('turnover clean {s}–{e}', { s: c.end, e: cleanEnd })}{c.nightAfter ? ` · ${t('overnight check-in {t}', { t: p.overnight.checkin })}` : ''}</span></dd>
              : <dd><ul className="space-y-0.5">{c.reasons.map((r) => <li key={r} className="flex items-center gap-1.5 font-semibold"><X size={13} className="shrink-0 text-rose-500" /> {t(REASON[r])}</li>)}</ul></dd>}
            {c.feasible && c.blocksOvernight && <dd className="mt-1 flex items-center gap-1 text-[13px] text-amber-800"><Moon size={13} /> {t('Blocks tonight\'s overnight check-in')}</dd>}
          </div>
        </div>
        {c.feasible && (
          <div className="flex items-start gap-2.5 px-3 py-2.5">
            {c.expectedGain > 0 ? <CheckCircle2 size={18} className="mt-0.5 shrink-0 text-emerald-600" /> : <CircleAlert size={18} className="mt-0.5 shrink-0 text-amber-600" />}
            <div className="min-w-0 flex-1">
              <dt className="text-[12.5px] text-ink-500">{t('Is it financially worthwhile?')}</dt>
              <dd><span className="font-semibold">{t('Estimated incremental contribution')}{t(':')} </span><span className={`font-bold tabular-nums ${c.expectedGain > 0 ? 'text-emerald-700' : 'text-rose-700'}`}>{eur(c.expectedGain)}</span></dd>
              <dd className="text-[13px] text-ink-600">{t('{n} if booked · assumes a {p}% booking probability', { n: eur(c.daytime.net), p: a.daytimeLikelihood })}</dd>
            </div>
          </div>
        )}
      </dl>

      {err && <p className="mt-2 text-[13px] font-semibold text-rose-700" role="alert">{err}</p>}
      {c.feasible && !c.alreadyOpen && (
        <button onClick={approve} disabled={!!busy} className={`${c.recommendation === 'open' ? 'btn-accent' : 'btn-primary'} mt-3 w-full py-3.5`}>
          {busy === 'approve' ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />} {busy === 'approve' ? t('Approving…') : t('Approve availability')}
        </button>
      )}
      {(onAdjust && c.feasible && !c.alreadyOpen) || (onDismiss && !c.alreadyOpen) ? (
        <div className="mt-2 flex gap-2">
          {onAdjust && c.feasible && !c.alreadyOpen && <button onClick={onAdjust} className="btn-ghost min-h-[44px] flex-1 px-3 py-2 text-[13.5px]">{t('Adjust times')}</button>}
          {onDismiss && !c.alreadyOpen && <button onClick={onDismiss} className="btn-ghost min-h-[44px] flex-1 px-3 py-2 text-[13.5px]"><ThumbsDown size={14} /> {t('Reject')}</button>}
        </div>
      ) : null}

      {c.feasible && (
        <div className="mt-3 border-t border-ivory-200 pt-1">
          <button onClick={() => setWhy(!why)} aria-expanded={why} className="flex min-h-[44px] w-full items-center justify-between text-[14px] font-semibold text-ink">{t('Why this recommendation?')}<ChevronDown size={17} className={`text-ink-500 transition ${why ? 'rotate-180' : ''}`} /></button>
          {why && (
            <div className="space-y-3 pb-1 text-[13.5px]">
              <div className="space-y-1">
                {rows.map(([l, v, cls]) => <div key={l} className={`flex justify-between gap-3 ${cls ?? 'text-ink-700'}`}><span className="min-w-0">{l}</span><span className="shrink-0 tabular-nums">{v < 0 ? `−${eur(-v)}` : eur(v)}</span></div>)}
              </div>
              <div className="space-y-1 rounded-lg bg-ivory-50 p-3">
                <div className="flex justify-between gap-3"><span className="flex items-center gap-1"><Sun size={13} /> {t('Expected daytime value ({p}% × net)', { p: a.daytimeLikelihood })}</span><span className="shrink-0 tabular-nums">{eur(c.expectedDaytime)}</span></div>
                <div className="flex justify-between gap-3"><span className="flex items-center gap-1"><Moon size={13} /> {t('Overnight opportunity cost')}</span><span className="shrink-0 tabular-nums">−{eur(c.opportunityCost)}</span></div>
                <div className="text-[12.5px] text-ink-500">{c.nightAfter ? t('Tonight is already booked on {ch} — the window ends before check-in and cleaning.', { ch: c.nightAfter.channel }) : c.blocksOvernight ? t('Opening this window would block tonight. Overnight net {x} × {l}% chance it still sells (assumption).', { x: eur(c.overnight.net), l: a.overnightLikelihood }) : t('Ends before check-in and cleaning — no overnight impact.')}</div>
                <div className="flex justify-between gap-3 border-t border-ivory-200 pt-1 font-bold"><span>{t('Estimated incremental contribution')}</span><span className="shrink-0 tabular-nums">{eur(c.expectedGain)}</span></div>
              </div>
              <ul className="space-y-1 text-[12.5px] text-ink-600">
                <li className="flex items-start gap-1.5"><SprayCan size={13} className="mt-0.5 shrink-0 text-lavender-600" /> {t('Turnover clean {s}–{e}', { s: c.end, e: cleanEnd })} · {t('cleaners {a}–{b}', { a: a.staffStart, b: a.staffEnd })}</li>
                <li>{t('Break-even price: {x}/h', { x: c.minViableHourly ? eur(c.minViableHourly) : '—' })}</li>
                <li>{t('Recommended when net if booked is positive and the expected gain is at least {x}.', { x: eur(10) })}</li>
              </ul>
              {explain && <div className="rounded-lg bg-ice-50 p-3 text-[13px] leading-relaxed text-ink-700"><div className="mb-1 flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-ink-500"><Bot size={12} /> {explain.engine === 'claude' ? t('AI explanation (Claude)') : t('Generated explanation')}</div>{explain.text}</div>}
              {!explain && <button onClick={doExplain} className="btn-ghost min-h-[44px] w-full px-3 py-2 text-[13.5px]">{busy === 'explain' ? <Loader2 size={14} className="animate-spin" /> : <Wand2 size={14} />} {t('Explain in plain words')}</button>}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Num({ label, v, on }: { label: string; v: number; on: (n: number) => void }) {
  return <label className="flex items-center justify-between gap-3 text-[14px]"><span className="min-w-0 text-ink-700">{label}</span><input type="number" inputMode="decimal" className="min-h-[40px] w-24 shrink-0 rounded-lg border border-ivory-300 bg-white px-2 py-1.5 text-right font-semibold" value={v} onChange={(e) => on(+e.target.value)} /></label>;
}
function Range({ label, v, on }: { label: string; v: number; on: (n: number) => void }) {
  return <label className="block text-[14px]"><span className="flex justify-between gap-3 text-ink-700"><span className="min-w-0">{label}</span><b className="shrink-0">{v}%</b></span><input type="range" min={0} max={100} step={5} value={v} onChange={(e) => on(+e.target.value)} className="w-full accent-electric" /></label>;
}
