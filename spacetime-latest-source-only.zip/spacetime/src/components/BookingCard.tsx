import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CalendarX, ChevronRight, KeyRound, Loader2, MessageCircle } from 'lucide-react';
import type { Booking, Conversation, Property } from '@/types';
import { Img } from './Img';
import { Sheet, StatusPill } from './ui';
import { dayLabel } from '@/lib/time';
import { eur } from '@/lib/pricing';
import { api } from '@/lib/api';
import { useStore } from '@/store/useStore';
import { CANCELLATION } from '@/data/vocab';
import { useT } from '@/i18n';

export type GuestBooking = Booking & { property: Property | null };

export const statusTone = (s: Booking['status']) => (s === 'confirmed' ? 'ok' : s === 'pending' ? 'warn' : s === 'completed' ? 'info' : 'muted') as 'ok' | 'warn' | 'info' | 'muted';

/** Guest-facing booking summary: tap to open the booking, message button to open the conversation with the Space Partner. */
export function BookingCard({ b, conv }: { b: GuestBooking; conv?: Pick<Conversation, 'id' | 'unread'> }) {
  const t = useT();
  const nav = useNavigate();
  const [opening, setOpening] = useState(false);
  const p = b.property;
  const active = b.status === 'confirmed' || b.status === 'pending';
  const openChat = async () => {
    if (conv) { nav(`/messages/${conv.id}`); return; }
    if (!p) return;
    setOpening(true);
    try { const c = await api<{ id: string }>('/api/conversations', { body: { propertyId: p.id, kind: 'guest' } }); nav(`/messages/${c.id}`); }
    catch { useStore.getState().showToast('Could not open the conversation. Please try again.', undefined, 'error'); }
    finally { setOpening(false); }
  };

  return (
    <div className={`card overflow-hidden ${b.status === 'cancelled' || b.status === 'declined' ? 'opacity-60' : ''}`}>
      <div className="flex items-center gap-2 p-3 pr-3">
        <Link to={`/confirmed/${b.id}`} className="flex min-w-0 flex-1 gap-3">
          {p && <Img src={p.images[0]} alt={p.shortTitle} className="h-20 w-20 shrink-0 rounded-xl" />}
          <div className="min-w-0 flex-1">
            <StatusPill tone={statusTone(b.status)}>{t(b.status === 'pending' ? 'Awaiting approval' : b.status[0].toUpperCase() + b.status.slice(1))}</StatusPill>
            <div className="mt-1 truncate text-[15px] font-bold text-ink">{p?.shortTitle}</div>
            <div className="text-[13px] text-ink-500">{dayLabel(b.date)} · {b.start}–{b.end}</div>
            <div className="text-[13px] text-ink-500">{b.guests.adults + b.guests.children === 1 ? t('1 guest') : t('{n} guests', { n: b.guests.adults + b.guests.children })} · {eur(b.price.guestTotal)}{b.cancelFee ? ` · ${t('late cancellation {x}', { x: eur(b.cancelFee) })}` : ''}</div>
          </div>
        </Link>
        {p && (
          <button onClick={openChat} aria-label={conv?.unread ? t('Message the Space Partner ({n} unread)', { n: conv.unread }) : t('Message the Space Partner')} className="relative grid h-11 w-11 shrink-0 place-items-center rounded-full bg-electric-50 text-electric-700 transition hover:bg-electric-100 active:scale-95">
            {opening ? <Loader2 size={19} className="animate-spin" /> : <MessageCircle size={20} />}
            {!!conv?.unread && <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-electric px-1 text-[11px] font-bold text-white">{conv.unread}</span>}
          </button>
        )}
      </div>
      {active && (
        <Link to={`/confirmed/${b.id}`} className="flex items-center justify-between gap-3 border-t border-ivory-200 px-3 py-2.5 text-[13px]">
          {b.status === 'confirmed' ? <span className="inline-flex items-center gap-1.5 font-semibold text-ink"><KeyRound size={14} className="text-electric-600" /> {t('Code')} {b.accessCode}</span> : <span className="text-ink-500">{t('The Space Partner will confirm shortly')}</span>}
          <span className="inline-flex items-center gap-0.5 font-semibold text-electric-600">{t('Details')}<ChevronRight size={15} /></span>
        </Link>
      )}
    </div>
  );
}

/**
 * Deliberately low-key cancellation, shown at the bottom of a booking's own page (not on the list):
 * a text link that opens a confirmation sheet with the cancellation terms.
 */
export function CancelBookingLink({ b, onCancelled }: { b: GuestBooking; onCancelled: () => void }) {
  const t = useT();
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const p = b.property;
  const late = (new Date(`${b.date}T${b.start}:00`).getTime() - Date.now()) / 3600000 < 2;
  const cancel = async () => {
    setBusy(true);
    setErr('');
    try {
      await api(`/api/bookings/${b.id}/cancel`, { body: {} });
      setConfirm(false);
      useStore.getState().bump();
      void useStore.getState().loadCatalog(); // the freed hours become bookable again
      useStore.getState().showToast('Booking cancelled');
      onCancelled();
    } catch (e) {
      setErr(e instanceof Error ? t(e.message) : t('Could not cancel. Please try again.'));
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <div className="pt-2 text-center">
        <p className="text-[12.5px] text-ink-500">{t(CANCELLATION.label)}</p>
        <button onClick={() => { setErr(''); setConfirm(true); }} className="mt-1 min-h-[44px] px-3 text-[14px] font-semibold text-ink-500 underline decoration-ivory-300 underline-offset-4 hover:text-rose-700">{t('Cancel this booking')}</button>
      </div>
      <Sheet open={confirm} onClose={() => !busy && setConfirm(false)} title={t('Cancel booking?')} footer={
        <div className="space-y-2">
          {err && <p className="text-[13px] font-semibold text-rose-700" role="alert">{err}</p>}
          <button className="btn w-full bg-rose-700 text-white hover:bg-rose-800" disabled={busy} onClick={cancel}>{busy ? <Loader2 size={16} className="animate-spin" /> : <CalendarX size={16} />} {busy ? t('Cancelling…') : t('Yes, cancel this booking')}</button>
          <button className="btn-ghost w-full" disabled={busy} onClick={() => setConfirm(false)}>{t('Keep booking')}</button>
        </div>
      }>
        <div className="space-y-3 pb-4 text-[14px] leading-relaxed text-ink-700">
          <div className="rounded-xl bg-white p-3 shadow-card"><div className="font-bold text-ink">{p?.shortTitle}</div><div className="text-ink-500">{dayLabel(b.date)} · {b.start}–{b.end} · {eur(b.price.guestTotal)}</div></div>
          <p><b>{t(CANCELLATION.label)}.</b> {t(CANCELLATION.detail)}</p>
          <p>{b.status === 'confirmed' && late ? <b className="text-rose-700">{t('Your booking starts in less than 2 hours, so the full amount ({x}) would be due. No card is charged in this preview.', { x: eur(b.price.guestTotal) })}</b> : t('This cancellation is free.')}</p>
        </div>
      </Sheet>
    </>
  );
}
