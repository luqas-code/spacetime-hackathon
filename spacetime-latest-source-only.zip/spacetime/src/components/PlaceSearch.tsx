import { useEffect, useRef, useState } from 'react';
import { Building2, Globe, Landmark, Loader2, MapPin, Plane, Search, TrainFront, Hash } from 'lucide-react';
import type { Place } from '@/types';
import { searchPlaces } from '@/data/places';
import { api } from '@/lib/api';
import { useT } from '@/i18n';

const kindIcon = (k?: Place['kind']) => (k === 'station' ? TrainFront : k === 'airport' ? Plane : k === 'landmark' ? Landmark : k === 'address' ? Building2 : k === 'arrondissement' ? Hash : MapPin);

/**
 * Address & landmark autocomplete. Transport hubs (airports, international stations) are suggested first.
 * Offline Paris gazetteer + live lookup through the server (Geoapify when configured, else OpenStreetMap).
 */
export function PlaceSearch({ value, onPick, placeholder, autoFocus }: { value?: string; onPick: (p: Place) => void; placeholder?: string; autoFocus?: boolean }) {
  const t = useT();
  const [q, setQ] = useState(value ?? '');
  const [open, setOpen] = useState(false);
  const [online, setOnline] = useState<Place[]>([]);
  const [loading, setLoading] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const local = searchPlaces(q, q.trim() ? 6 : 8);

  useEffect(() => { setQ(value ?? ''); }, [value]);
  useEffect(() => {
    const h = (e: MouseEvent) => !ref.current?.contains(e.target as Node) && setOpen(false);
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  // debounce live address lookup
  useEffect(() => {
    if (q.trim().length < 4 || local.length >= 3) { setOnline([]); return; }
    setLoading(true);
    const tm = setTimeout(async () => {
      try {
        const out = await api<{ results: Place[] }>(`/api/geo?q=${encodeURIComponent(q)}`);
        setOnline(out.results);
      } catch { setOnline([]); }
      setLoading(false);
    }, 450);
    return () => { clearTimeout(tm); setLoading(false); };
  }, [q]); // eslint-disable-line react-hooks/exhaustive-deps

  const pick = (p: Place) => {
    setQ(p.label);
    setOpen(false);
    setOnline([]);
    onPick(p);
  };
  const Row = ({ p, online: o }: { p: Place; online?: boolean }) => {
    const Icon = kindIcon(p.kind);
    return (
      <button onClick={() => pick(p)} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left hover:bg-ice-50">
        <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg ${o ? 'bg-electric-100 text-electric-600' : p.hub ? 'bg-ink text-white' : 'bg-ice-100 text-ink'}`}><Icon size={16} /></span>
        <span className="min-w-0">
          <span className="block truncate text-[14px] font-semibold text-ink">{p.label}</span>
          <span className="block truncate text-[12px] text-ink-500">{p.sub}</span>
        </span>
      </button>
    );
  };

  return (
    <div ref={ref} className="relative">
      <div className="relative">
        <Search size={18} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-ink-500" />
        <input
          className="input pl-11"
          value={q}
          autoFocus={autoFocus}
          placeholder={placeholder ?? t('Address, station, area or arrondissement')}
          onFocus={() => setOpen(true)}
          onChange={(e) => { setQ(e.target.value); setOpen(true); }}
          onKeyDown={(e) => { if (e.key === 'Enter' && (local[0] || online[0])) pick(local[0] ?? online[0]); }}
          aria-label={t('Search for a place')}
        />
      </div>
      {open && (
        <div className="absolute inset-x-0 top-[calc(100%+6px)] z-50 max-h-80 overflow-y-auto rounded-xl bg-white p-1.5 shadow-float ring-1 ring-ivory-200">
          {!q.trim() && <div className="px-3 pb-1 pt-2 text-[11px] font-bold uppercase tracking-wider text-ink-500">{t('Airports & international stations')}</div>}
          {local.map((p) => <Row key={p.id} p={p} />)}
          {online.length > 0 && <div className="px-3 pb-1 pt-2 text-[11px] font-bold uppercase tracking-wider text-ink-500">{t('Addresses')}</div>}
          {online.map((p) => <Row key={p.id} p={p} online />)}
          {loading && <div className="flex items-center gap-2 px-3 py-2.5 text-[13px] text-ink-500"><Loader2 size={15} className="animate-spin" /> {t('Looking up addresses…')}</div>}
          {!local.length && !online.length && !loading && q.trim().length >= 4 && <div className="flex items-center gap-2 px-3 py-3 text-[13px] text-ink-500"><Globe size={15} /> {t('No match — try a street name or station')}</div>}
        </div>
      )}
    </div>
  );
}
