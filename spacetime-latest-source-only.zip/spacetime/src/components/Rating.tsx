import { Star } from 'lucide-react';
import { useT } from '@/i18n';

export function Rating({ value, count, className = '' }: { value?: number; count?: number; className?: string }) {
  const t = useT();
  if (!value) return <span className={`text-xs font-semibold text-electric-600 ${className}`}>{t('New')}</span>;
  return (
    <span className={`inline-flex items-center gap-1 text-[13px] font-semibold text-ink ${className}`}>
      <Star size={13} className="fill-electric text-electric" />
      {value.toFixed(2)}
      {count !== undefined && <span className="font-normal text-ink-500">({count})</span>}
    </span>
  );
}
