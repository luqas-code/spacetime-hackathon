import { useEffect, useId, useMemo, useRef, useState, type PointerEvent as RPointerEvent } from 'react';
import { Landmark, Minus, Plus, TrainFront } from 'lucide-react';
import type { Property } from '@/types';
import { useT } from '@/i18n';
import { BOUNDS, MAP_LABELS, MAP_POIS, MAP_SHAPES, WORLD, metresPerPx, toLL, toXY } from './parisMap';

/**
 * Self-contained illustrated map of Paris (no map tiles, no API key, works offline).
 * Same props as the previous Leaflet map, so pages did not change. Markers, the search
 * radius and the location pin are placed at their real coordinates; the basemap itself is
 * a simplified illustration (see parisMap.ts).
 */
export interface MapMarker {
  property: Property;
  label?: string;
}

interface Props {
  center: { lat: number; lng: number };
  zoom?: number;
  markers?: MapMarker[];
  activeId?: string | null;
  favIds?: string[];
  onMarkerClick?: (id: string) => void;
  onMapClick?: () => void;
  circle?: { lat: number; lng: number; radiusKm: number } | null;
  pin?: { lat: number; lng: number } | null;
  onCenterChange?: (c: { lat: number; lng: number }) => void;
  fit?: boolean;
  interactive?: boolean;
  className?: string;
  zoomControl?: boolean;
  /** Parts of the map covered by overlays (top bar, bottom sheet), in px; markers are fitted and centred in the rest. */
  insets?: { top?: number; bottom?: number | ((mapHeight: number) => number) };
}

const Z_MIN = 11.6;
const Z_MAX = 15.6;
const clampZ = (z: number) => Math.max(Z_MIN, Math.min(Z_MAX, z));
const clampC = (c: { lat: number; lng: number }) => ({
  lat: Math.max(BOUNDS.latMin + 0.004, Math.min(BOUNDS.latMax - 0.004, c.lat)),
  lng: Math.max(BOUNDS.lngMin + 0.006, Math.min(BOUNDS.lngMax - 0.006, c.lng)),
});

const C = { outside: '#E0DBCD', land: '#F4F1EA', edge: '#D3CCBA', water: '#B7C7F3', waterEdge: '#9DB2EE', wood: '#D6E2CF', park: '#DCE7D5', avenue: '#FFFFFF', avenueEdge: '#E4DFD3', dot: '#E2DDD0' };

export function MapView({ center, zoom = 14, markers = [], activeId, favIds = [], onMarkerClick, onMapClick, circle, pin, onCenterChange, fit, interactive = true, className = '', zoomControl = false, insets }: Props) {
  const t = useT();
  const uid = useId().replace(/:/g, '');
  const box = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });
  // Small static maps (listing, confirmation) show a little more context: an illustration has no street detail.
  const startZoom = interactive ? zoom : Math.min(zoom, 13.9);
  const [view, setView] = useState(() => ({ ...clampC(center), zoom: clampZ(startZoom) }));
  const [drag, setDrag] = useState<{ x: number; y: number; dx: number; dy: number; moved: boolean } | null>(null);
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    const el = box.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setSize({ w: el.clientWidth, h: el.clientHeight }));
    ro.observe(el);
    setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  const insetTop = Math.min(insets?.top ?? 0, size.h * 0.4);
  const rawBottom = typeof insets?.bottom === 'function' ? insets.bottom(size.h) : insets?.bottom ?? 0;
  const insetBottom = Math.max(0, Math.min(rawBottom, size.h - insetTop - 120));
  const anchorY = insetTop + (size.h - insetTop - insetBottom) / 2;

  const moveTo = (v: { lat: number; lng: number; zoom?: number }, anim = true) => {
    setAnimate(anim);
    setView((cur) => ({ ...clampC(v), zoom: clampZ(v.zoom ?? cur.zoom) }));
  };

  // Follow the `center` prop (search area, listing location…) unless fitting to results.
  useEffect(() => { if (!fit) moveTo({ ...center, zoom: startZoom }); }, [center.lat, center.lng, startZoom]); // eslint-disable-line react-hooks/exhaustive-deps

  // Fit all markers (+ search circle) into view.
  const fitKey = markers.map((m) => m.property.id).join(',') + (circle ? `|${circle.lat},${circle.lng},${circle.radiusKm}` : '');
  useEffect(() => {
    if (!fit || !size.w) return;
    const pts = markers.map((m) => toXY(m.property.lat, m.property.lng));
    if (circle) { const [x, y] = toXY(circle.lat, circle.lng); const r = circle.radiusKm * 1000; pts.push([x - r, y - r], [x + r, y + r]); }
    if (!pts.length) { moveTo({ ...center, zoom }, false); return; }
    const xs = pts.map((p) => p[0]); const ys = pts.map((p) => p[1]);
    const [x0, x1, y0, y1] = [Math.min(...xs), Math.max(...xs), Math.min(...ys), Math.max(...ys)];
    const need = Math.max((x1 - x0) / Math.max(120, size.w - 90), (y1 - y0) / Math.max(80, size.h - insetTop - insetBottom - 70), 0.0001);
    const z = Math.log2((156543.03 * Math.cos((48.857 * Math.PI) / 180)) / need);
    moveTo({ ...toLL((x0 + x1) / 2, (y0 + y1) / 2), zoom: Math.min(15, z) }, false);
  }, [fitKey, fit, size.w > 0, Math.round(insetBottom / 40)]); // eslint-disable-line react-hooks/exhaustive-deps

  // Bring the selected listing into view.
  useEffect(() => {
    const m = markers.find((x) => x.property.id === activeId);
    if (m) moveTo({ lat: m.property.lat, lng: m.property.lng });
  }, [activeId]); // eslint-disable-line react-hooks/exhaustive-deps

  const mpp = metresPerPx(view.zoom);
  const s = 1 / mpp;
  const [cx, cy] = toXY(view.lat, view.lng);
  const ox = size.w / 2 - cx * s + (drag?.dx ?? 0);
  const oy = anchorY - cy * s + (drag?.dy ?? 0);
  const px = (lat: number, lng: number) => { const [x, y] = toXY(lat, lng); return { left: x * s, top: y * s }; };

  const onDown = (e: RPointerEvent<HTMLDivElement>) => {
    if (!interactive || (e.target as HTMLElement).closest('button')) return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    setAnimate(false);
    setDrag({ x: e.clientX, y: e.clientY, dx: 0, dy: 0, moved: false });
  };
  const onMove = (e: RPointerEvent<HTMLDivElement>) => {
    if (!drag) return;
    const dx = e.clientX - drag.x; const dy = e.clientY - drag.y;
    setDrag({ ...drag, dx, dy, moved: drag.moved || Math.hypot(dx, dy) > 5 });
  };
  const onUp = () => {
    if (!drag) return;
    if (!drag.moved) { setDrag(null); onMapClick?.(); return; }
    const c = clampC(toLL(cx - drag.dx * mpp, cy - drag.dy * mpp));
    setDrag(null);
    setView((v) => ({ ...v, ...c }));
    onCenterChange?.(c);
  };
  const zoomBy = (d: number) => { setAnimate(false); setView((v) => ({ ...v, zoom: clampZ(v.zoom + d) })); };

  const labels = useMemo(() => MAP_LABELS.filter((l) => view.zoom >= 13.2 || l.major), [view.zoom]);
  const ordered = useMemo(() => [...markers].sort((a, b) => (a.property.id === activeId ? 1 : 0) - (b.property.id === activeId ? 1 : 0)), [markers, activeId]);

  return (
    <div
      ref={box}
      className={`relative h-full w-full select-none overflow-hidden ${interactive ? (drag?.moved ? 'cursor-grabbing' : 'cursor-grab') : ''} ${className}`}
      style={{ background: C.outside, touchAction: interactive ? 'none' : 'auto' }}
      onPointerDown={onDown}
      onPointerMove={onMove}
      onPointerUp={onUp}
      onPointerCancel={() => setDrag(null)}
      onWheel={interactive ? (e) => zoomBy(e.deltaY > 0 ? -0.35 : 0.35) : undefined}
      role="region"
      aria-label={t('Map of Paris')}
    >
      <div className={`absolute left-0 top-0 ${animate ? 'transition-transform duration-300 ease-out motion-reduce:transition-none' : ''}`} style={{ transform: `translate3d(${ox}px, ${oy}px, 0)` }}>
        <svg width={WORLD.w * s} height={WORLD.h * s} viewBox={`0 0 ${WORLD.w} ${WORLD.h}`} className="block" aria-hidden>
          <defs>
            <pattern id={`dots-${uid}`} width={18 * mpp} height={18 * mpp} patternUnits="userSpaceOnUse"><circle cx={9 * mpp} cy={9 * mpp} r={0.9 * mpp} fill={C.dot} /></pattern>
          </defs>
          {MAP_SHAPES.woods.map((d, i) => <path key={`w${i}`} d={d} fill={C.wood} />)}
          <path d={MAP_SHAPES.paris} fill={C.land} stroke={C.edge} strokeWidth={Math.max(60, 3 * mpp)} strokeLinejoin="round" />
          <path d={MAP_SHAPES.paris} fill={`url(#dots-${uid})`} />
          {MAP_SHAPES.parks.map((d, i) => <path key={`p${i}`} d={d} fill={C.park} />)}
          {MAP_SHAPES.avenues.map((d, i) => <path key={`a${i}`} d={d} fill="none" stroke={C.avenueEdge} strokeWidth={Math.max(34, 4.2 * mpp)} strokeLinecap="round" strokeLinejoin="round" />)}
          {MAP_SHAPES.avenues.map((d, i) => <path key={`b${i}`} d={d} fill="none" stroke={C.avenue} strokeWidth={Math.max(24, 2.6 * mpp)} strokeLinecap="round" strokeLinejoin="round" />)}
          <path d={MAP_SHAPES.canal} fill="none" stroke={C.water} strokeWidth={Math.max(26, 2.2 * mpp)} strokeLinecap="round" />
          <path d={MAP_SHAPES.seine} fill="none" stroke={C.waterEdge} strokeWidth={Math.max(150, 7 * mpp)} strokeLinecap="round" strokeLinejoin="round" />
          <path d={MAP_SHAPES.seine} fill="none" stroke={C.water} strokeWidth={Math.max(120, 5.5 * mpp)} strokeLinecap="round" strokeLinejoin="round" />
          {MAP_SHAPES.islands.map((d, i) => <path key={`i${i}`} d={d} fill={C.land} />)}
        </svg>

        {labels.map((l) => (
          <span key={l.t} className={`pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 whitespace-nowrap font-semibold uppercase ${l.major ? 'text-[10.5px] tracking-[0.14em] text-ink-500/70' : 'text-[9.5px] tracking-[0.12em] text-ink-500/55'}`} style={px(l.lat, l.lng)}>{l.t}</span>
        ))}

        {view.zoom >= 12 && MAP_POIS.map((p) => (
          <span key={p.t} className="pointer-events-none absolute flex -translate-x-[9px] -translate-y-1/2 items-center gap-1 whitespace-nowrap" style={px(p.lat, p.lng)}>
            <span className={`grid h-[18px] w-[18px] place-items-center rounded-md text-white shadow-sm ring-2 ring-white ${p.kind === 'station' ? 'bg-ink' : 'bg-lavender-600'}`}>{p.kind === 'station' ? <TrainFront size={11} /> : <Landmark size={11} />}</span>
            {view.zoom >= (p.kind === 'station' ? 12.2 : 12.9) && <span className="rounded bg-white/80 px-1 text-[10.5px] font-semibold text-ink-700">{p.t}</span>}
          </span>
        ))}

        {circle && (() => { const r = circle.radiusKm * 1000 * s; const p = px(circle.lat, circle.lng); return <div className="pointer-events-none absolute rounded-full border-2 border-dashed border-electric bg-electric/[0.08]" style={{ left: p.left - r, top: p.top - r, width: r * 2, height: r * 2 }} />; })()}

        {pin && (
          <div className="pointer-events-none absolute" style={px(pin.lat, pin.lng)}>
            <svg width="34" height="42" viewBox="0 0 34 42" className="absolute -translate-x-1/2 -translate-y-full drop-shadow-md" aria-hidden><path d="M17 1C8.2 1 1 8 1 16.6 1 28.4 17 41 17 41s16-12.6 16-24.4C33 8 25.8 1 17 1z" fill="#4062E8" stroke="#fff" strokeWidth="2" /><circle cx="17" cy="16" r="6" fill="#fff" /></svg>
          </div>
        )}

        {ordered.map((m) => {
          const on = m.property.id === activeId;
          const fav = favIds.includes(m.property.id);
          return (
            <div key={m.property.id} className="absolute" style={px(m.property.lat, m.property.lng)}>
              <button
                type="button"
                title={m.property.shortTitle}
                aria-label={`${m.property.shortTitle} · ${m.label ?? `€${m.property.pricePerHour}`}`}
                aria-pressed={on}
                onClick={(e) => { e.stopPropagation(); onMarkerClick?.(m.property.id); }}
                className={`absolute flex -translate-x-1/2 -translate-y-1/2 items-center gap-1 whitespace-nowrap rounded-full border-[1.5px] px-2.5 py-1.5 text-[13px] font-bold shadow-[0_4px_14px_-4px_rgba(22,29,53,.45)] transition ${on ? 'z-10 scale-110 border-ink bg-ink text-white' : 'border-ink/10 bg-white text-ink hover:scale-105'}`}
              >
                {fav && <span className="text-[11px] text-electric" aria-hidden>♥</span>}
                {m.label ?? `€${m.property.pricePerHour}`}
              </button>
            </div>
          );
        })}
      </div>

      {zoomControl && interactive && (
        <div className="absolute bottom-3 right-3 z-10 flex flex-col overflow-hidden rounded-xl bg-white shadow-card">
          <button type="button" aria-label={t('Zoom in')} onClick={() => zoomBy(0.6)} className="grid h-10 w-10 place-items-center text-ink hover:bg-ivory-100"><Plus size={18} /></button>
          <button type="button" aria-label={t('Zoom out')} onClick={() => zoomBy(-0.6)} className="grid h-10 w-10 place-items-center border-t border-ivory-200 text-ink hover:bg-ivory-100"><Minus size={18} /></button>
        </div>
      )}
      <span className="pointer-events-none absolute bottom-1 left-2 text-[10px] font-medium text-ink-500/70">{t('Illustrative map')}</span>
    </div>
  );
}
