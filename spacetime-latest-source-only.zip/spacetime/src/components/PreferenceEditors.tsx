import { useState } from 'react';
import { Briefcase, Home, MapPin, Plus, Trash2 } from 'lucide-react';
import type { Accessibility, Activity, SavedLocation, UserPrefs } from '@/types';
import { ACCESSIBILITY, ACTIVITIES } from '@/data/vocab';
import { PlaceSearch } from './PlaceSearch';
import { Chip, Toggle } from './ui';
import { useT } from '@/i18n';

export function InterestPicker({ value, onChange, big }: { value: Activity[]; onChange: (v: Activity[]) => void; big?: boolean }) {
  const t = useT();
  const toggle = (a: Activity) => onChange(value.includes(a) ? value.filter((x) => x !== a) : [...value, a]);
  if (big)
    return (
      <div className="grid grid-cols-2 gap-2.5">
        {(Object.keys(ACTIVITIES) as Activity[]).map((a) => {
          const A = ACTIVITIES[a];
          const on = value.includes(a);
          return (
            <button key={a} onClick={() => toggle(a)} aria-pressed={on} className={`flex items-center gap-2.5 rounded-2xl border-2 p-3 text-left transition active:scale-[.98] ${on ? 'border-ink bg-ice-50' : 'border-transparent bg-white shadow-card'}`}>
              <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${A.tint}`}><A.icon size={19} /></span>
              <span className="text-[13.5px] font-semibold leading-tight text-ink">{t(A.label)}</span>
            </button>
          );
        })}
      </div>
    );
  return (
    <div className="flex flex-wrap gap-2">
      {(Object.keys(ACTIVITIES) as Activity[]).map((a) => {
        const A = ACTIVITIES[a];
        return <Chip key={a} on={value.includes(a)} onClick={() => toggle(a)} icon={<A.icon size={14} />}>{t(A.label)}</Chip>;
      })}
    </div>
  );
}

export function AccessibilityPicker({ value, onChange }: { value: Accessibility[]; onChange: (v: Accessibility[]) => void }) {
  const t = useT();
  return (
    <div className="flex flex-wrap gap-2">
      {(Object.keys(ACCESSIBILITY) as Accessibility[]).map((a) => {
        const A = ACCESSIBILITY[a];
        return <Chip key={a} on={value.includes(a)} onClick={() => onChange(value.includes(a) ? value.filter((x) => x !== a) : [...value, a])} icon={<A.icon size={14} />}>{t(A.label)}</Chip>;
      })}
    </div>
  );
}

export function HouseholdEditor({ value, onChange }: { value: UserPrefs['household']; onChange: (v: UserPrefs['household']) => void }) {
  const t = useT();
  return (
    <div className="divide-y divide-ivory-200 rounded-2xl bg-white px-4 shadow-card">
      <div className="flex items-center justify-between py-3.5"><div><div className="text-[15px] font-semibold">{t('I often travel with kids')}</div><div className="text-[12.5px] text-ink-500">{t('Prioritise family-friendly spaces')}</div></div><Toggle label={t('Kids')} checked={value.kids} onChange={(kids) => onChange({ ...value, kids })} /></div>
      <div className="flex items-center justify-between py-3.5"><div><div className="text-[15px] font-semibold">{t('I bring a pet')}</div><div className="text-[12.5px] text-ink-500">{t('Show a pet-friendly row on Discover')}</div></div><Toggle label={t('Pets')} checked={value.pets} onChange={(pets) => onChange({ ...value, pets })} /></div>
    </div>
  );
}

const tagIcon = (t: SavedLocation['tag']) => (t === 'home' ? Home : t === 'work' ? Briefcase : MapPin);

/** Edit home / work / other saved places. */
export function LocationsEditor({ value, onChange }: { value: SavedLocation[]; onChange: (v: SavedLocation[]) => void }) {
  const t = useT();
  const [adding, setAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const slot = (tag: 'home' | 'work') => value.find((l) => l.tag === tag);
  const setSlot = (tag: 'home' | 'work', place: Omit<SavedLocation, 'tag' | 'name' | 'id'> | null) => {
    const rest = value.filter((l) => l.tag !== tag);
    onChange(place ? [...rest, { ...place, id: `loc-${tag}`, tag, name: tag === 'home' ? 'Home' : 'Work' }].sort((a, b) => order(a) - order(b)) : rest);
  };
  const order = (l: SavedLocation) => (l.tag === 'home' ? 0 : l.tag === 'work' ? 1 : 2);

  return (
    <div className="space-y-4">
      {(['home', 'work'] as const).map((tag) => {
        const Icon = tagIcon(tag);
        const cur = slot(tag);
        return (
          <div key={tag}>
            <div className="mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[13px] font-bold uppercase tracking-wider text-ink-500"><Icon size={14} /> {t(tag === 'home' ? 'Home area' : 'Work area')}</span>
              {cur && <button onClick={() => setSlot(tag, null)} className="text-[12.5px] font-semibold text-ink-500 underline">{t('Remove')}</button>}
            </div>
            <PlaceSearch value={cur?.label} placeholder={t(tag === 'home' ? 'e.g. Oberkampf, Bastille…' : 'e.g. Station F, Opéra…')} onPick={(p) => setSlot(tag, { label: p.label, sub: p.sub, lat: p.lat, lng: p.lng, kind: p.kind })} />
          </div>
        );
      })}
      <div>
        <span className="mb-1.5 flex items-center gap-1.5 text-[13px] font-bold uppercase tracking-wider text-ink-500"><MapPin size={14} /> {t('Other places')}</span>
        <div className="space-y-2">
          {value.filter((l) => l.tag === 'other').map((l) => (
            <div key={l.id} className="flex items-center gap-3 rounded-2xl bg-white px-4 py-3 shadow-card">
              <MapPin size={16} className="text-electric-600" />
              <div className="min-w-0 flex-1"><div className="text-[14px] font-semibold text-ink">{l.name}</div><div className="truncate text-[12px] text-ink-500">{l.label}</div></div>
              <button aria-label={`${t('Remove')} ${l.name}`} onClick={() => onChange(value.filter((x) => x.id !== l.id))} className="text-ink-500"><Trash2 size={16} /></button>
            </div>
          ))}
          {adding ? (
            <div className="space-y-2 rounded-2xl bg-ice-50 p-3">
              <input className="input" placeholder={t("Name, e.g. Gym, Mum's, Studio")} value={newName} onChange={(e) => setNewName(e.target.value)} />
              <PlaceSearch placeholder={t('Where is it?')} onPick={(p) => { onChange([...value, { label: p.label, sub: p.sub, lat: p.lat, lng: p.lng, kind: p.kind, id: `loc-${Date.now()}`, tag: 'other', name: newName.trim() || p.label }]); setAdding(false); setNewName(''); }} />
            </div>
          ) : (
            <button onClick={() => setAdding(true)} className="flex w-full items-center justify-center gap-2 rounded-2xl border border-dashed border-electric-400 py-3 text-[14px] font-semibold text-electric-600"><Plus size={16} /> {t('Add a place')}</button>
          )}
        </div>
      </div>
    </div>
  );
}
