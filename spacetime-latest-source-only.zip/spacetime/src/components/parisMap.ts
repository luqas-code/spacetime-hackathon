/**
 * Static, stylised map of Paris — no tiles, no API, works offline.
 * Geometry is hand-simplified from public geography (approximate, for illustration):
 * the Seine and its islands, the city boundary (périphérique), the two woods, main parks,
 * a few main avenues and neighbourhood labels. Everything is in [lat, lng] and projected to
 * metres with a local equirectangular projection, which is accurate to a few metres across Paris.
 */
export type LL = [number, number];

export const BOUNDS = { latMax: 48.912, latMin: 48.795, lngMin: 2.21, lngMax: 2.485 };
const KX = 111320 * Math.cos((48.857 * Math.PI) / 180); // metres per degree of longitude
const KY = 111140; // metres per degree of latitude
export const WORLD = { w: (BOUNDS.lngMax - BOUNDS.lngMin) * KX, h: (BOUNDS.latMax - BOUNDS.latMin) * KY };
export const toXY = (lat: number, lng: number): [number, number] => [(lng - BOUNDS.lngMin) * KX, (BOUNDS.latMax - lat) * KY];
export const toLL = (x: number, y: number) => ({ lat: BOUNDS.latMax - y / KY, lng: BOUNDS.lngMin + x / KX });
/** Metres per screen pixel at a web-map style zoom level (matches the previous map's zoom numbers). */
export const metresPerPx = (zoom: number) => (156543.03 * Math.cos((48.857 * Math.PI) / 180)) / 2 ** zoom;

/** Smooth path through points (Catmull-Rom → cubic Bézier). */
function smooth(pts: LL[], closed = false) {
  const p = pts.map(([la, ln]) => toXY(la, ln));
  if (p.length < 2) return '';
  const at = (i: number) => (closed ? p[(i + p.length) % p.length] : p[Math.max(0, Math.min(p.length - 1, i))]);
  let d = `M${p[0][0].toFixed(0)} ${p[0][1].toFixed(0)}`;
  const n = closed ? p.length : p.length - 1;
  for (let i = 0; i < n; i++) {
    const [p0, p1, p2, p3] = [at(i - 1), at(i), at(i + 1), at(i + 2)];
    const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
    const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
    d += ` C${c1[0].toFixed(0)} ${c1[1].toFixed(0)} ${c2[0].toFixed(0)} ${c2[1].toFixed(0)} ${p2[0].toFixed(0)} ${p2[1].toFixed(0)}`;
  }
  return closed ? d + ' Z' : d;
}
/** Rotated ellipse-ish blob for parks: centre, size in metres, rotation in degrees. */
function blob(lat: number, lng: number, w: number, h: number, rot = 0) {
  const [cx, cy] = toXY(lat, lng);
  const r = (rot * Math.PI) / 180;
  const pts: [number, number][] = [];
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    // squarish superellipse so parks read as city blocks rather than ovals
    const ex = Math.sign(Math.cos(a)) * Math.abs(Math.cos(a)) ** 0.55 * (w / 2);
    const ey = Math.sign(Math.sin(a)) * Math.abs(Math.sin(a)) ** 0.55 * (h / 2);
    pts.push([cx + ex * Math.cos(r) - ey * Math.sin(r), cy + ex * Math.sin(r) + ey * Math.cos(r)]);
  }
  return smooth(pts.map(([x, y]) => [toLL(x, y).lat, toLL(x, y).lng] as LL), true);
}

const PARIS: LL[] = [
  [48.878, 2.283], [48.886, 2.293], [48.8945, 2.3135], [48.8975, 2.329], [48.8985, 2.359], [48.898, 2.37], [48.8975, 2.386], [48.8885, 2.3925],
  [48.877, 2.4065], [48.864, 2.4085], [48.847, 2.4105], [48.835, 2.406], [48.8295, 2.3995], [48.825, 2.39], [48.8215, 2.369], [48.819, 2.3595],
  [48.823, 2.3255], [48.8275, 2.305], [48.832, 2.287], [48.838, 2.257], [48.848, 2.258], [48.86, 2.269], [48.8715, 2.277],
];
const SEINE: LL[] = [
  [48.811, 2.43], [48.819, 2.41], [48.824, 2.395], [48.827, 2.387], [48.8323, 2.3805], [48.8385, 2.3745], [48.8453, 2.3655], [48.8505, 2.36],
  [48.8528, 2.3572], [48.8545, 2.3525], [48.8565, 2.3465], [48.8578, 2.3405], [48.8592, 2.3335], [48.8615, 2.3265], [48.8637, 2.3197],
  [48.8641, 2.3105], [48.8636, 2.3015], [48.8605, 2.2935], [48.8556, 2.2877], [48.851, 2.281], [48.8467, 2.2758], [48.838, 2.27],
  [48.829, 2.258], [48.8245, 2.2385], [48.832, 2.2245], [48.85, 2.2185],
];
const CANAL: LL[] = [[48.8532, 2.3692], [48.861, 2.367], [48.8675, 2.3648], [48.8725, 2.3662], [48.8795, 2.3698], [48.8838, 2.3705], [48.8875, 2.3778], [48.8902, 2.3832]];
const WOODS = [
  smooth([[48.879, 2.262], [48.872, 2.274], [48.859, 2.265], [48.847, 2.253], [48.8435, 2.2445], [48.855, 2.2365], [48.87, 2.242], [48.8785, 2.253]], true),
  smooth([[48.843, 2.411], [48.8465, 2.433], [48.84, 2.458], [48.829, 2.4685], [48.824, 2.447], [48.828, 2.425], [48.833, 2.412]], true),
];
const PARKS = [
  blob(48.8462, 2.3372, 640, 440), // Luxembourg
  blob(48.8636, 2.3275, 950, 280, -25), // Tuileries
  blob(48.8556, 2.2986, 1000, 230, 48), // Champ de Mars
  blob(48.8809, 2.3828, 520, 400, -20), // Buttes-Chaumont
  blob(48.8222, 2.3378, 460, 360), // Montsouris
  blob(48.8797, 2.3091, 340, 300), // Monceau
  blob(48.844, 2.359, 420, 300, 30), // Jardin des Plantes
  blob(48.8614, 2.3933, 700, 460, 10), // Père-Lachaise
  blob(48.8938, 2.39, 620, 420, 10), // La Villette
  blob(48.8655, 2.3135, 520, 160, -5), // Champs-Élysées gardens
  blob(48.8405, 2.3815, 700, 220, -35), // Parc de Bercy
  blob(48.8375, 2.2695, 600, 220, -25), // Parc André-Citroën
];
const ISLANDS = [blob(48.8546, 2.3468, 1050, 230, -18), blob(48.8516, 2.3568, 600, 160, -30)];
/** Main avenues — drawn as light lines to give the map structure. */
const AVENUES: LL[][] = [
  [[48.8738, 2.295], [48.8697, 2.3075], [48.8656, 2.3212]], // Champs-Élysées
  [[48.8656, 2.3212], [48.8607, 2.3375], [48.8566, 2.3522], [48.8533, 2.3692]], // Rivoli → Bastille
  [[48.8396, 2.3365], [48.8504, 2.3442], [48.8635, 2.3505], [48.8757, 2.3577], [48.884, 2.3595]], // Saint-Michel / Sébastopol / Magenta
  [[48.8738, 2.295], [48.8825, 2.3135], [48.8842, 2.3325], [48.8836, 2.3497], [48.8829, 2.3707], [48.8708, 2.3836]], // northern boulevards
  [[48.8533, 2.3692], [48.8483, 2.3958]], // Faubourg Saint-Antoine → Nation
  [[48.8405, 2.3195], [48.8392, 2.3295], [48.8396, 2.3365], [48.8352, 2.3525], [48.8325, 2.3555]], // Montparnasse → Port-Royal → Place d'Italie
  [[48.8443, 2.374], [48.8483, 2.3958]], // Gare de Lyon → Nation
  [[48.8574, 2.3046], [48.8530, 2.3263], [48.8530, 2.3404], [48.8495, 2.3525]], // Saint-Germain
];

export const MAP_SHAPES = {
  paris: smooth(PARIS, true),
  seine: smooth(SEINE),
  canal: smooth(CANAL),
  woods: WOODS,
  parks: PARKS,
  islands: ISLANDS,
  avenues: AVENUES.map((a) => smooth(a)),
};

export const MAP_LABELS: { t: string; lat: number; lng: number; major?: boolean }[] = [
  { t: 'Montmartre', lat: 48.8895, lng: 2.3385, major: true },
  { t: 'Le Marais', lat: 48.8593, lng: 2.3605, major: true },
  { t: 'Quartier Latin', lat: 48.8478, lng: 2.3452, major: true },
  { t: 'Bastille', lat: 48.8512, lng: 2.3735 },
  { t: 'Belleville', lat: 48.8716, lng: 2.3843 },
  { t: 'Montparnasse', lat: 48.8452, lng: 2.3228, major: true },
  { t: 'Batignolles', lat: 48.8862, lng: 2.3195 },
  { t: 'Opéra', lat: 48.8716, lng: 2.3318 },
  { t: 'République', lat: 48.8676, lng: 2.3636 },
  { t: 'Nation', lat: 48.8468, lng: 2.3958 },
  { t: 'Bercy', lat: 48.8352, lng: 2.3866 },
  { t: 'Passy', lat: 48.8578, lng: 2.2795 },
  { t: 'Invalides', lat: 48.8565, lng: 2.3128 },
  { t: 'Saint-Germain', lat: 48.8535, lng: 2.3335 },
  { t: 'Canal Saint-Martin', lat: 48.8738, lng: 2.3672 },
  { t: 'Batignolles', lat: 48.8862, lng: 2.3195 },
  { t: 'Butte-aux-Cailles', lat: 48.8275, lng: 2.3505 },
  { t: 'Bois de Boulogne', lat: 48.862, lng: 2.2495, major: true },
  { t: 'Bois de Vincennes', lat: 48.8335, lng: 2.4385, major: true },
].filter((l, i, a) => a.findIndex((x) => x.t === l.t) === i);

/** Train stations and landmarks — useful reference points for guests between journeys. */
export const MAP_POIS: { t: string; lat: number; lng: number; kind: 'station' | 'landmark' }[] = [
  { t: 'Gare du Nord', lat: 48.8809, lng: 2.3553, kind: 'station' },
  { t: 'Gare de l’Est', lat: 48.8768, lng: 2.3592, kind: 'station' },
  { t: 'Gare de Lyon', lat: 48.8443, lng: 2.374, kind: 'station' },
  { t: 'Gare d’Austerlitz', lat: 48.8420, lng: 2.3655, kind: 'station' },
  { t: 'Gare Montparnasse', lat: 48.8412, lng: 2.3208, kind: 'station' },
  { t: 'Gare Saint-Lazare', lat: 48.8763, lng: 2.3253, kind: 'station' },
  { t: 'Tour Eiffel', lat: 48.8584, lng: 2.2945, kind: 'landmark' },
  { t: 'Louvre', lat: 48.8606, lng: 2.3376, kind: 'landmark' },
  { t: 'Notre-Dame', lat: 48.853, lng: 2.3499, kind: 'landmark' },
  { t: 'Sacré-Cœur', lat: 48.8867, lng: 2.3431, kind: 'landmark' },
  { t: 'Arc de Triomphe', lat: 48.8738, lng: 2.295, kind: 'landmark' },
];
