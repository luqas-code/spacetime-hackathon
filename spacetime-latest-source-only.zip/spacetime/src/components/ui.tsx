import { useEffect, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { ChevronLeft, Minus, Plus, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useT } from '@/i18n';
import { useStore } from '@/store/useStore';

export function Stepper({ label, sub, value, onChange, min = 0, max = 20, disabledReason }: { label: string; sub?: string; value: number; onChange: (n: number) => void; min?: number; max?: number; disabledReason?: string }) {
  const t = useT();
  return (
    <div className="flex items-center justify-between py-3.5">
      <div>
        <div className="text-[15px] font-semibold text-ink">{label}</div>
        {(disabledReason || sub) && <div className={`text-[13px] ${disabledReason ? 'text-electric-600' : 'text-ink-500'}`}>{disabledReason ?? sub}</div>}
      </div>
      <div className="flex items-center gap-3">
        <button aria-label={`${t('Decrease')} ${label}`} disabled={value <= min} onClick={() => onChange(value - 1)} className="grid h-11 w-11 place-items-center rounded-full border border-ivory-300 bg-white text-ink transition active:scale-90 disabled:opacity-30">
          <Minus size={16} />
        </button>
        <span className="w-5 text-center text-[16px] font-bold tabular-nums" aria-live="polite">{value}</span>
        <button aria-label={`${t('Increase')} ${label}`} disabled={value >= max || !!disabledReason} onClick={() => onChange(value + 1)} className="grid h-11 w-11 place-items-center rounded-full border border-ivory-300 bg-white text-ink transition active:scale-90 disabled:opacity-30">
          <Plus size={16} />
        </button>
      </div>
    </div>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)} className={`relative h-7 w-12 shrink-0 rounded-full transition ${checked ? 'bg-ink' : 'bg-ivory-300'}`}>
      <span className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all ${checked ? 'left-[22px]' : 'left-0.5'}`} />
    </button>
  );
}

export function Chip({ on, onClick, children, icon }: { on: boolean; onClick: () => void; children: ReactNode; icon?: ReactNode }) {
  return (
    <button type="button" aria-pressed={on} onClick={onClick} className={on ? 'chip-on' : 'chip-off'}>
      {icon}
      {children}
    </button>
  );
}

export function Segmented<T extends string>({ value, options, onChange }: { value: T; options: { value: T; label: string }[]; onChange: (v: T) => void }) {
  return (
    <div className="flex rounded-2xl bg-ivory-100 p-1">
      {options.map((o) => (
        <button key={o.value} aria-pressed={value === o.value} onClick={() => onChange(o.value)} className={`min-h-[40px] min-w-0 flex-1 rounded-xl px-2 py-2 text-[13.5px] font-semibold leading-tight transition ${value === o.value ? 'bg-white text-ink shadow-card' : 'text-ink-500'}`}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function PageHeader({ title, back, right, sub, transparent }: { title?: ReactNode; back?: boolean | string; right?: ReactNode; sub?: ReactNode; transparent?: boolean }) {
  const nav = useNavigate();
  const t = useT();
  return (
    <header className={`sticky top-0 z-30 flex items-center gap-3 px-4 pb-3 pt-[max(env(safe-area-inset-top),14px)] ${transparent ? '' : 'bg-ivory-50/90 backdrop-blur'}`}>
      {back && (
        <button aria-label={t('Back')} className="icon-btn h-11 w-11" onClick={() => (typeof back === 'string' ? nav(back) : window.history.length > 1 ? nav(-1) : nav('/'))}>
          <ChevronLeft size={20} />
        </button>
      )}
      <div className="min-w-0 flex-1">
        {title && <h1 className="truncate text-[18px] font-bold text-ink">{title}</h1>}
        {sub && <div className="truncate text-[13px] text-ink-500">{sub}</div>}
      </div>
      {right}
    </header>
  );
}

/** Bottom sheet modal rendered into the phone shell. */
export function Sheet({ open, onClose, title, children, footer, full }: { open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode; full?: boolean }) {
  const t = useT();
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  const host = document.getElementById('sheet-root');
  if (!host) return null;
  return createPortal(
    <div className="absolute inset-0 z-[1200] flex flex-col justify-end" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 bg-ink-900/40 backdrop-blur-[2px] animate-fade-up" onClick={onClose} />
      <div className={`relative flex ${full ? 'h-[94%]' : 'max-h-[88%]'} flex-col rounded-t-4xl bg-ivory-50 animate-slide-up`}>
        <div className="flex items-center justify-between px-5 pb-2 pt-4">
          <button aria-label={t('Close')} onClick={onClose} className="grid h-11 w-11 place-items-center rounded-full bg-ivory-100 text-ink"><X size={18} /></button>
          <h2 className="min-w-0 truncate px-2 text-[17px] font-bold text-ink">{title}</h2>
          <span className="w-11" />
        </div>
        <div className="flex-1 overflow-y-auto px-5 pb-4">{children}</div>
        {footer && <div className="border-t border-ivory-200 bg-white px-5 py-3 pb-[max(env(safe-area-inset-bottom),12px)]">{footer}</div>}
      </div>
    </div>,
    host,
  );
}

/**
 * Toasts appear at the top of the phone, clear of bottom navigation, booking bars and totals.
 * Info disappears after ~3.5 s (6 s with a link); errors stay 9 s and can always be dismissed.
 */
export function Toast() {
  const toast = useStore((s) => s.toast);
  const nav = useNavigate();
  const t = useT();
  useEffect(() => {
    if (!toast) return;
    const ms = toast.tone === 'error' ? 9000 : toast.link ? 6000 : 3500;
    const tm = setTimeout(() => useStore.setState((s) => (s.toast?.id === toast.id ? { toast: null } : s)), ms);
    return () => clearTimeout(tm);
  }, [toast]);
  if (!toast) return null;
  const err = toast.tone === 'error';
  const close = () => useStore.setState({ toast: null });
  return (
    <div key={toast.id} className="pointer-events-none absolute inset-x-0 top-[max(env(safe-area-inset-top),10px)] z-[1300] flex justify-center px-4">
      <div role={err ? 'alert' : 'status'} aria-live={err ? 'assertive' : 'polite'} className={`pointer-events-auto flex w-full max-w-[400px] items-center gap-2 rounded-2xl py-1.5 pl-4 pr-1.5 text-[14px] font-semibold shadow-float animate-fade-up ${err ? 'bg-rose-700 text-white' : 'bg-ink text-white'}`}>
        {toast.link
          ? <button className="min-h-[40px] flex-1 text-left" onClick={() => { nav(toast.link!); close(); }}>{t(toast.text)} <span className="ml-1 text-lavender">→</span></button>
          : <span className="flex-1 py-2">{t(toast.text)}</span>}
        <button aria-label={t('Dismiss')} onClick={close} className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white/70 hover:text-white"><X size={16} /></button>
      </div>
    </div>
  );
}

export function EmptyState({ icon, title, text, action }: { icon: ReactNode; title: string; text: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center px-8 py-14 text-center">
      <div className="mb-4 grid h-20 w-20 place-items-center rounded-full bg-ice-100 text-ink">{icon}</div>
      <h3 className="h-display text-[22px]">{title}</h3>
      <p className="mt-2 max-w-[280px] text-[14px] leading-relaxed text-ink-500">{text}</p>
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}

export function PreviewNote({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-start gap-2 rounded-xl bg-ice-50 px-3 py-2.5 text-[13px] leading-snug text-ink-600">
      <span className="mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full bg-lavender-600" />
      <span>{children}</span>
    </div>
  );
}

export function Avatar({ name, color = '#4062E8', size = 44, src }: { name: string; color?: string; size?: number; src?: string }) {
  const initials = name.split(/[\s&]+/).filter(Boolean).slice(0, 2).map((x) => x[0]).join('').toUpperCase() || '•';
  if (src) return <img src={src} alt={name} width={size} height={size} className="shrink-0 rounded-full object-cover ring-2 ring-white" style={{ width: size, height: size }} />;
  return (
    <div className="grid shrink-0 place-items-center rounded-full font-bold text-white" style={{ width: size, height: size, background: color, fontSize: size * 0.38 }}>
      {initials}
    </div>
  );
}

export const partnerColor = (name: string) => ['#4062E8', '#161D35', '#4062E8', '#7C66D4', '#B5A5EC', '#3A4470'][name.length % 6];

export function StatusPill({ tone, children }: { tone: 'ok' | 'warn' | 'info' | 'muted' | 'bad'; children: ReactNode }) {
  const cls = { ok: 'bg-emerald-50 text-emerald-700', warn: 'bg-amber-50 text-amber-700', info: 'bg-electric-50 text-electric-700', muted: 'bg-ivory-100 text-ink-500', bad: 'bg-rose-50 text-rose-700' }[tone];
  return <span className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-bold uppercase tracking-wide ${cls}`}>{children}</span>;
}

/** Clear two-option language choice (onboarding + Profile → Settings → Language). Bilingual labels so either reader understands. */
export function LanguageOptions({ value, onChange, dark }: { value: 'en' | 'fr'; onChange: (l: 'en' | 'fr') => void; dark?: boolean }) {
  const opts = [{ v: 'en' as const, label: 'English', sub: 'English' }, { v: 'fr' as const, label: 'Français', sub: 'French' }];
  return (
    <div role="radiogroup" aria-label="Language / Langue" className="space-y-2.5">
      {opts.map((o) => {
        const on = value === o.v;
        return (
          <button key={o.v} type="button" role="radio" aria-checked={on} onClick={() => onChange(o.v)}
            className={`flex min-h-[56px] w-full items-center gap-3 rounded-2xl px-4 py-3 text-left transition ${dark
              ? on ? 'bg-white text-ink ring-2 ring-electric' : 'bg-white/[0.08] text-white ring-1 ring-white/15 hover:bg-white/[0.14]'
              : on ? 'bg-white text-ink ring-2 ring-electric shadow-card' : 'bg-white text-ink ring-1 ring-ivory-300 hover:ring-electric-400'}`}>
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-ice-100 text-[12px] font-bold uppercase text-ink">{o.v}</span>
            <span className="flex-1"><span className="block text-[16px] font-semibold">{o.label}</span></span>
            <span className={`grid h-6 w-6 place-items-center rounded-full border-2 ${on ? 'border-electric bg-electric' : dark ? 'border-white/40' : 'border-ivory-300'}`}>{on && <span className="h-2 w-2 rounded-full bg-white" />}</span>
          </button>
        );
      })}
    </div>
  );
}
