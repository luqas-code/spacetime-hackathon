import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import type { Economics, ListingStatus } from '@/types';
import { eur, RATES } from '@/lib/pricing';
import { useT } from '@/i18n';
import { StatusPill, Avatar } from './ui';
import { Logo } from './Logo';
import { useStore } from '@/store/useStore';

export function DashHeader({ title, sub, profileLink }: { title: string; sub?: string; profileLink: string }) {
  const t = useT();
  const user = useStore((s) => s.user)!;
  const live = useStore((s) => s.live);
  return (
    <header className="bg-ink px-5 pb-5 pt-[max(env(safe-area-inset-top),16px)] text-white">
      <div className="flex items-center justify-between gap-3">
        <Logo light size={26} />
        <Link to={profileLink} aria-label={t('Profile and settings')} className="relative -m-1 grid h-11 w-11 shrink-0 place-items-center rounded-full">
          <Avatar name={user.name} src={user.avatarUrl || undefined} size={36} />
          <span className={`absolute bottom-1 right-1 h-2.5 w-2.5 rounded-full ring-2 ring-ink ${live ? 'bg-emerald-400' : 'bg-amber-400'}`} title={t(live ? 'Live' : 'Reconnecting')} />
        </Link>
      </div>
      <h1 className="mt-4 text-[24px] font-bold leading-tight tracking-tight">{title}</h1>
      {sub && <p className="mt-0.5 truncate text-[14px] text-ice-200">{sub}</p>}
    </header>
  );
}

export function Metric({ label, value, sub, tone = 'plain', to }: { label: string; value: ReactNode; sub?: string; tone?: 'plain' | 'accent' | 'dark'; to?: string }) {
  const cls = tone === 'accent' ? 'bg-electric text-white' : tone === 'dark' ? 'bg-ink text-white' : 'bg-white text-ink';
  const body = (
    <div className={`clip-corner h-full p-3.5 shadow-card ${cls}`}>
      <div className={`text-[12px] font-semibold leading-tight ${tone === 'plain' ? 'text-ink-500' : 'text-ice-200'}`}>{label}</div>
      <div className="mt-1.5 text-[24px] font-bold leading-none tracking-tight tabular-nums">{value}</div>
      {sub && <div className={`mt-1.5 text-[12.5px] leading-snug ${tone === 'plain' ? 'text-ink-500' : 'text-ice-200'}`}>{sub}</div>}
    </div>
  );
  return to ? <Link to={to} className="block">{body}</Link> : body;
}

export function Panel({ title, action, children, className = '' }: { title: ReactNode; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={className}>
      <div className="mb-2.5 flex min-h-[28px] items-center justify-between gap-3 px-1"><h2 className="min-w-0 text-[17px] font-bold tracking-tight text-ink">{title}</h2>{action}</div>
      {children}
    </section>
  );
}

export function RowLink({ to, children }: { to: string; children: ReactNode }) {
  return <Link to={to} className="flex items-center gap-3 px-4 py-3 hover:bg-ivory-50">{children}<ChevronRight size={16} className="shrink-0 text-ink-500" /></Link>;
}

const STATUS_TONE: Record<ListingStatus, 'ok' | 'warn' | 'info' | 'muted' | 'bad'> = { draft: 'muted', in_review: 'warn', changes_requested: 'bad', approved: 'info', published: 'ok', paused: 'muted' };
const STATUS_LABEL: Record<ListingStatus, string> = { draft: 'Draft', in_review: 'In review', changes_requested: 'Changes requested', approved: 'Approved', published: 'Published', paused: 'Paused' };
export function ListingStatusPill({ s }: { s: ListingStatus }) {
  const t = useT();
  return <StatusPill tone={STATUS_TONE[s]}>{t(STATUS_LABEL[s])}</StatusPill>;
}

/** Transparent split of one booking (or a total), identical maths on every device. */
export function FinanceBreakdown({ e, mult = 1, compact, explain }: { e: Pick<Economics, 'gross' | 'guestFee' | 'cleaning' | 'commission' | 'mgmtFee' | 'ownerProceeds'> & { mgmtFeePct: number | null }; mult?: number; compact?: boolean; explain?: boolean }) {
  const t = useT();
  const m = (n: number) => eur(Math.round(n * mult * 100) / 100);
  const rows: [string, string, string?, string?][] = [
    [t('Gross booking value'), m(e.gross), 'font-bold text-ink', t('Total rental value before deductions.')],
    [t('SpaceTime platform fee ({n}%)', { n: RATES.commissionPct }), `−${m(e.commission)}`, undefined, t('Commission charged by SpaceTime.')],
    [e.mgmtFeePct == null ? t('Property management fee') : t('Property management fee ({n}%)', { n: e.mgmtFeePct }), `−${m(e.mgmtFee)}`, undefined, t('Amount paid to the property\'s manager.')],
    [t('Estimated owner proceeds'), m(e.ownerProceeds), 'border-t border-ivory-200 pt-1.5 font-bold text-electric-700', t('Before taxes and other owner costs. Not profit.')],
  ];
  const info: [string, string][] = [
    ...(RATES.guestFeePct > 0 ? [[t('Guest service fee ({n}%) — paid by guest', { n: RATES.guestFeePct }), m(e.guestFee)] as [string, string]] : []),
    [t('Cleaning — charged at cost, paid to cleaner'), m(e.cleaning)],
  ];
  return (
    <div className={`space-y-1.5 ${compact ? 'text-[13px]' : 'text-[14px]'}`}>
      {rows.map(([l, v, c, d]) => (
        <div key={l} className={c ?? 'text-ink-700'}>
          <div className="flex items-baseline justify-between gap-3"><span className="min-w-0">{l}</span><span className="shrink-0 tabular-nums">{v}</span></div>
          {explain && d && <div className="text-[12.5px] font-normal text-ink-500">{d}</div>}
        </div>
      ))}
      <div className="mt-1 space-y-1 border-t border-dashed border-ivory-300 pt-1.5 text-[12.5px] text-ink-500">
        <div className="text-[12px] font-semibold">{t('Not part of owner proceeds')}</div>
        {info.map(([l, v]) => <div key={l} className="flex justify-between gap-3"><span className="min-w-0">{l}</span><span className="shrink-0 tabular-nums">{v}</span></div>)}
      </div>
    </div>
  );
}

export const Spinner = () => <div className="grid flex-1 place-items-center py-16"><div className="h-8 w-8 animate-spin rounded-full border-4 border-ice-200 border-t-electric" /></div>;
