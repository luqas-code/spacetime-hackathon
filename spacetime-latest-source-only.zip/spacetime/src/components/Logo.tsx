/**
 * SpaceTime identity — the custom "spacetime" wordmark (public/brand/spacetime-wordmark-*.png),
 * in white on dark backgrounds and navy (#161D35) on light ones. The compact icon is the
 * wordmark's own "s" on a rounded tile (also used for the favicon and home-screen icon).
 */
const WORDMARK = { light: './brand/spacetime-wordmark-white.png', dark: './brand/spacetime-wordmark-navy.png' };
const RATIO = 1200 / 239; // width / height of the wordmark artwork

/** `light` = render for a dark background (white artwork). */
export function Wordmark({ light = false, height = 22, className = '' }: { light?: boolean; height?: number; className?: string }) {
  return <img src={light ? WORDMARK.light : WORDMARK.dark} alt="SpaceTime" height={height} width={Math.round(height * RATIO)} className={`block shrink-0 select-none ${className}`} style={{ height, width: 'auto' }} draggable={false} />;
}

/** Compact standalone icon: the wordmark's "s" on a rounded tile. `light` = ivory tile for dark backgrounds. */
export function LogoMark({ size = 32, light = false }: { size?: number; light?: boolean }) {
  return <img src={light ? './brand/icon-ivory-512.png' : './brand/icon-navy-512.png'} alt="" aria-hidden width={size} height={size} className="block shrink-0 select-none" draggable={false} />;
}

/** Header logo. `size` is the approximate visual height in px. */
export function Logo({ size = 28, light = false }: { size?: number; light?: boolean }) {
  return <Wordmark light={light} height={Math.round(size * 0.8)} />;
}
