import { Heart } from 'lucide-react';
import { useState } from 'react';
import { useIsFav, useStore } from '@/store/useStore';

export function FavButton({ id, variant = 'overlay', size = 18 }: { id: string; variant?: 'overlay' | 'plain'; size?: number }) {
  const fav = useIsFav(id);
  const toggle = useStore((s) => s.toggleFavourite);
  const [pop, setPop] = useState(false);
  return (
    <button
      aria-label={fav ? 'Remove from favourites' : 'Save to favourites'}
      aria-pressed={fav}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        toggle(id);
        setPop(true);
        setTimeout(() => setPop(false), 350);
      }}
      className={
        variant === 'overlay'
          ? 'grid h-9 w-9 place-items-center rounded-full bg-white/90 shadow-card backdrop-blur transition active:scale-90'
          : 'grid h-10 w-10 place-items-center rounded-full bg-white shadow-card transition active:scale-90'
      }
    >
      <Heart size={size} className={`${pop ? 'animate-pop' : ''} ${fav ? 'fill-electric text-electric' : 'text-ink'}`} strokeWidth={2.2} />
    </button>
  );
}
