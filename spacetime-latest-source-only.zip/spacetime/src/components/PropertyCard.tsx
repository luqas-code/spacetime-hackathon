import { Link } from 'react-router-dom';
import { Clock, MapPin, Zap } from 'lucide-react';
import type { Property } from '@/types';
import { Img } from './Img';
import { FavButton } from './FavButton';
import { Rating } from './Rating';
import { formatDistance } from '@/lib/geo';
import { availabilityLabel } from '@/lib/availability';
import { eur } from '@/lib/pricing';
import { useT } from '@/i18n';

interface Props {
  property: Property;
  distance?: number;
  distanceFrom?: string;
  variant?: 'rail' | 'list' | 'compact';
  date?: string;
  slotLabel?: string;
  totalPrice?: number;
  totalHours?: number;
  badge?: string;
  onClick?: () => void;
  to?: string;
}

function AvailPill({ p, date, slotLabel }: { p: Property; date?: string; slotLabel?: string }) {
  if (slotLabel)
    return (
      <span className="inline-flex items-center gap-1 text-[12px] font-semibold text-electric-600">
        <Clock size={12} /> {slotLabel}
      </span>
    );
  const a = availabilityLabel(p, date);
  return (
    <span className={`inline-flex items-center gap-1 text-[12px] font-semibold ${a.tone === 'now' ? 'text-emerald-600' : a.tone === 'later' ? 'text-electric-600' : 'text-ink-500'}`}>
      {a.tone === 'now' ? <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> : <Clock size={12} />}
      {a.text}
    </span>
  );
}

export function PropertyCard({ property: p, distance, distanceFrom, variant = 'rail', date, slotLabel, totalPrice, totalHours, badge, onClick, to }: Props) {
  const t = useT();
  const isNew = !!p.publishedAt && Date.now() - p.publishedAt < 7 * 86400000 && !p.reviewCount;
  const href = to ?? `/space/${p.id}`;
  const dist = distance !== undefined && (
    <span className="inline-flex items-center gap-1 text-[12px] text-ink-500">
      <MapPin size={12} /> {formatDistance(distance)}
      {distanceFrom && <span className="truncate">· {distanceFrom}</span>}
    </span>
  );

  if (variant === 'compact') {
    return (
      <Link to={href} onClick={onClick} className="card flex gap-3 overflow-hidden p-2.5 animate-fade-up">
        <Img src={p.images[0]} alt={p.shortTitle} className="h-24 w-24 shrink-0 rounded-2xl" />
        <div className="flex min-w-0 flex-1 flex-col justify-between py-0.5 pr-1">
          <div>
            <div className="flex items-start justify-between gap-2">
              <h3 className="line-clamp-2 text-[14px] font-bold leading-snug text-ink">{p.shortTitle}</h3>
              <FavButton id={p.id} variant="plain" size={16} />
            </div>
            <div className="mt-0.5 flex items-center gap-2">{dist}</div>
          </div>
          <div className="flex items-end justify-between">
            <AvailPill p={p} date={date} slotLabel={slotLabel} />
            <span className="text-[14px] font-bold text-ink">{eur(p.pricePerHour)}<span className="text-xs font-medium text-ink-500">/{t('hr')}</span></span>
          </div>
        </div>
      </Link>
    );
  }

  const isRail = variant === 'rail';
  return (
    <Link to={href} onClick={onClick} className={`group block ${isRail ? 'w-[248px] shrink-0 snap-start' : 'w-full'}`}>
      <div className="relative">
        <Img src={p.images[0]} alt={p.shortTitle} seed={p.id.length} className={`${isRail ? 'h-[168px]' : 'h-[220px]'} w-full rounded-2xl`} />
        <div className="absolute right-3 top-3"><FavButton id={p.id} /></div>
        <div className="absolute left-3 top-3 flex gap-1.5">
          {badge && <span className="rounded-md bg-white/95 px-2 py-1 text-[11px] font-bold text-ink shadow-card">{badge}</span>}
          {isNew && !badge && <span className="rounded-md bg-lavender px-2 py-1 text-[11px] font-bold uppercase tracking-wide text-ink shadow-card">{t('New')}</span>}
          {p.instantBook && !badge && (
            <span className="inline-flex items-center gap-1 rounded-md bg-white/95 px-2 py-1 text-[11px] font-bold text-ink shadow-card">
              <Zap size={11} className="fill-electric text-electric" /> {t('Instant')}
            </span>
          )}
        </div>
        <div className="absolute bottom-3 left-3 rounded-md bg-ink/85 px-2.5 py-1 text-[12px] font-bold text-white backdrop-blur">
          {eur(p.pricePerHour)}<span className="font-medium text-white/70">/{t('hr')}</span>
        </div>
      </div>
      <div className="px-1 pt-2.5">
        <div className="flex items-start justify-between gap-2">
          <h3 className={`${isRail ? 'line-clamp-1' : 'line-clamp-2'} text-[15px] font-bold leading-snug text-ink`}>{isRail ? p.shortTitle : p.title}</h3>
          <Rating value={p.rating} count={isRail ? undefined : p.reviewCount} className="shrink-0" />
        </div>
        <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5">
          {dist}
          {!isRail && <span className="text-[12px] text-ink-500">· {t('up to {n} guests', { n: p.capacity.guests })}</span>}
        </div>
        <div className="mt-1 flex flex-wrap items-center justify-between gap-x-3 gap-y-0.5">
          <AvailPill p={p} date={date} slotLabel={slotLabel} />
          {totalPrice !== undefined && <span className="text-[13.5px] text-ink-600"><b className="text-[15px] text-ink">{eur(totalPrice)}</b> {totalHours ? t('total for {h} h, incl. fees', { h: totalHours }) : t('total')}</span>}
        </div>
      </div>
    </Link>
  );
}
