import { useMemo, useState } from 'react';
import type { Accessibility, Activity, Amenity, Filters, PropertyType } from '@/types';
import { Sheet, Chip, Toggle, Stepper, Segmented } from './ui';
import { ACCESSIBILITY, ACTIVITIES, AMENITIES, PROPERTY_TYPES } from '@/data/vocab';
import { DEFAULT_FILTERS, PRICE_CEIL, runSearch } from '@/lib/search';
import { useStore } from '@/store/useStore';
import { useT } from '@/i18n';
import { PROPERTIES } from '@/data/properties';

const FILTER_AMENITIES: Amenity[] = ['wifi', 'shower', 'bed', 'kitchen', 'pro_kitchen', 'desk', 'monitor', 'projector', 'whiteboard', 'terrace', 'garden', 'bbq_grill', 'bathtub', 'crib', 'toys', 'luggage', 'soundproof', 'piano', 'ac', 'parking'];

export function FiltersSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const t = useT();
  const { filters, setFilters, query } = useStore();
  const [d, setD] = useState<Filters>(filters);
  const count = useMemo(() => runSearch(query, d).length, [query, d]);
  const toggle = <T,>(arr: T[], v: T) => (arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title={t('Filters')}
      full
      footer={
        <div className="flex items-center gap-3">
          <button className="text-[14px] font-semibold text-ink underline underline-offset-4" onClick={() => setD({ ...DEFAULT_FILTERS, sort: d.sort })}>{t('Clear all')}</button>
          <button className="btn-primary flex-1" onClick={() => { setFilters(d); onClose(); }}>{t(count === 1 ? 'Show 1 space' : 'Show {n} spaces', { n: count })}</button>
        </div>
      }
    >
      <div className="space-y-7 pb-6">
        <Section title={t('Sort by')}>
          <Segmented value={d.sort} onChange={(sort) => setD({ ...d, sort })} options={[{ value: 'recommended', label: t('Best match') }, { value: 'distance', label: t('Nearest') }, { value: 'price', label: t('Price') }, { value: 'rating', label: t('Rating') }]} />
        </Section>

        <Section title={t('Price per hour')}>
          <div className="flex items-center justify-between text-[14px] font-bold text-ink">
            <span>€{d.priceMin}</span>
            <span>{d.priceMax >= PRICE_CEIL ? `€${PRICE_CEIL}+` : `€${d.priceMax}`}</span>
          </div>
          <PriceHistogram min={d.priceMin} max={d.priceMax} />
          <div className="space-y-1">
            <label className="flex items-center gap-3 text-[12px] text-ink-500">{t('Min')}<input type="range" min={0} max={PRICE_CEIL} step={1} value={d.priceMin} onChange={(e) => setD({ ...d, priceMin: Math.min(+e.target.value, d.priceMax - 1) })} className="flex-1 accent-ink" aria-label="Minimum price" /></label>
            <label className="flex items-center gap-3 text-[12px] text-ink-500">{t('Max')}<input type="range" min={1} max={PRICE_CEIL} step={1} value={d.priceMax} onChange={(e) => setD({ ...d, priceMax: Math.max(+e.target.value, d.priceMin + 1) })} className="flex-1 accent-ink" aria-label="Maximum price" /></label>
          </div>
        </Section>

        <Section title={t('Booking duration')}>
          <div className="flex flex-wrap gap-2">
            {[0, 1, 2, 4, 6, 8].map((h) => (
              <Chip key={h} on={d.minDuration === h} onClick={() => setD({ ...d, minDuration: h })}>{h === 0 ? t('As searched') : `${h}h+`}</Chip>
            ))}
          </div>
        </Section>

        <Section title={t('Capacity & distance')}>
          <Stepper label={t('Minimum capacity')} sub={t('Total guests the space allows')} value={d.capacity} max={14} onChange={(capacity) => setD({ ...d, capacity })} />
          <div className="mt-2">
            <div className="mb-1 flex justify-between text-[13px]"><span className="font-semibold text-ink-500">{t('Max distance')}</span><span className="font-bold">{d.radiusKm ? `${d.radiusKm} km` : `${t('As searched')} (${query.where.radiusKm} km)`}</span></div>
            <input type="range" min={0} max={10} step={0.5} value={d.radiusKm} onChange={(e) => setD({ ...d, radiusKm: +e.target.value })} className="w-full accent-ink" aria-label="Maximum distance" />
          </div>
        </Section>

        <Section title={t('What are you planning?')}>
          <div className="flex flex-wrap gap-2">
            {(Object.keys(ACTIVITIES) as Activity[]).map((a) => {
              const A = ACTIVITIES[a];
              return <Chip key={a} on={d.activities.includes(a)} onClick={() => setD({ ...d, activities: toggle(d.activities, a) })} icon={<A.icon size={14} />}>{t(A.label)}</Chip>;
            })}
          </div>
        </Section>

        <Section title={t('Type of space')}>
          <div className="grid grid-cols-3 gap-2">
            {(Object.keys(PROPERTY_TYPES) as PropertyType[]).map((pt) => {
              const T = PROPERTY_TYPES[pt];
              const on = d.types.includes(pt);
              return (
                <button key={pt} onClick={() => setD({ ...d, types: toggle(d.types, pt) })} className={`flex flex-col items-start gap-2 rounded-2xl border p-3 text-left transition ${on ? 'border-ink bg-ice-50' : 'border-ivory-300 bg-white'}`}>
                  <T.icon size={20} className="text-ink" />
                  <span className="text-[13px] font-semibold text-ink">{t(T.label)}</span>
                </button>
              );
            })}
          </div>
        </Section>

        <Section title={t('Amenities')}>
          <div className="flex flex-wrap gap-2">
            {FILTER_AMENITIES.map((a) => {
              const A = AMENITIES[a];
              return <Chip key={a} on={d.amenities.includes(a)} onClick={() => setD({ ...d, amenities: toggle(d.amenities, a) })} icon={<A.icon size={14} />}>{t(A.label)}</Chip>;
            })}
          </div>
        </Section>

        <Section title={t('Accessibility')}>
          <div className="flex flex-wrap gap-2">
            {(Object.keys(ACCESSIBILITY) as Accessibility[]).map((a) => {
              const A = ACCESSIBILITY[a];
              return <Chip key={a} on={d.accessibility.includes(a)} onClick={() => setD({ ...d, accessibility: toggle(d.accessibility, a) })} icon={<A.icon size={14} />}>{t(A.label)}</Chip>;
            })}
          </div>
        </Section>

        <Section title={t('More')}>
          <Row label={t('Pets allowed')} sub={t('Bring your dog or cat')}><Toggle label="Pets allowed" checked={d.petsAllowed} onChange={(petsAllowed) => setD({ ...d, petsAllowed })} /></Row>
          <Row label={t('Instant book')} sub={t('Confirmed instantly, no approval needed')}><Toggle label="Instant book" checked={d.instantOnly} onChange={(instantOnly) => setD({ ...d, instantOnly })} /></Row>
        </Section>
      </div>
    </Sheet>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <h3 className="mb-3 text-[16px] font-bold text-ink">{title}</h3>
      {children}
    </section>
  );
}
function Row({ label, sub, children }: { label: string; sub: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 py-2.5">
      <div><div className="text-[15px] font-semibold text-ink">{label}</div><div className="text-[13px] text-ink-500">{sub}</div></div>
      {children}
    </div>
  );
}

function PriceHistogram({ min, max }: { min: number; max: number }) {
  const bins = useMemo(() => {
    const b = Array(12).fill(0) as number[];
    for (const p of PROPERTIES) b[Math.min(11, Math.floor((p.pricePerHour / PRICE_CEIL) * 12))]++;
    return b;
  }, []);
  const top = Math.max(...bins);
  return (
    <div className="my-2 flex h-12 items-end gap-1" aria-hidden>
      {bins.map((n, i) => {
        const lo = (i / 12) * PRICE_CEIL;
        const inRange = lo + PRICE_CEIL / 12 > min && lo <= max;
        return <div key={i} className={`flex-1 rounded-t-md ${inRange ? 'bg-electric' : 'bg-ivory-300'}`} style={{ height: `${Math.max(8, (n / top) * 100)}%` }} />;
      })}
    </div>
  );
}
