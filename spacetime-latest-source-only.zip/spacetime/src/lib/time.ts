import { localeTag } from './locale';
import { tr } from '@/i18n';
export const pad = (n: number) => String(n).padStart(2, '0');

export const toMin = (hhmm: string) => {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + (m || 0);
};
export const toHHMM = (min: number) => {
  const m = Math.max(0, Math.min(24 * 60, Math.round(min)));
  return m === 24 * 60 ? '24:00' : `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
};

export const isoDate = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const parseISO = (s: string) => {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
};
export const todayISO = () => isoDate(new Date());
export const addDays = (iso: string, n: number) => {
  const d = parseISO(iso);
  d.setDate(d.getDate() + n);
  return isoDate(d);
};
export const nextDays = (n: number, from = todayISO()) => Array.from({ length: n }, (_, i) => addDays(from, i));

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1).replace(/\.$/, '');

export function dayLabel(iso: string): string {
  const t = todayISO();
  if (iso === t) return tr('Today');
  if (iso === addDays(t, 1)) return tr('Tomorrow');
  const d = parseISO(iso);
  return cap(d.toLocaleDateString(localeTag(), { weekday: 'short', day: 'numeric', month: 'short' }));
}
export function shortDate(iso: string) {
  const d = parseISO(iso);
  return { dow: cap(d.toLocaleDateString(localeTag(), { weekday: 'short' })), day: d.getDate(), mon: cap(d.toLocaleDateString(localeTag(), { month: 'short' })) };
}
export const longDate = (iso: string) => cap(parseISO(iso).toLocaleDateString(localeTag(), { weekday: 'long', day: 'numeric', month: 'long' }));

export const nowMinutes = () => {
  const d = new Date();
  return d.getHours() * 60 + d.getMinutes();
};

/** Next sensible start time: the next full hour (or 09:00 if night). */
export function defaultStart(): string {
  const n = nowMinutes();
  const next = Math.ceil((n + 15) / 60) * 60;
  if (next < 7 * 60 || next > 21 * 60) return '10:00';
  return toHHMM(next);
}
export function defaultDate(): string {
  const n = nowMinutes();
  return n > 20 * 60 ? addDays(todayISO(), 1) : todayISO();
}

export const fmtHours = (h: number) => (h === 1 ? tr('1 hr') : tr('{n} hrs', { n: h % 1 === 0 ? h : h.toFixed(1) }));

export function partOfDay(d = new Date()): 'morning' | 'afternoon' | 'evening' | 'night' {
  const h = d.getHours();
  if (h < 5) return 'night';
  if (h < 12) return 'morning';
  if (h < 18) return 'afternoon';
  return 'evening';
}

export const TIME_OPTIONS = Array.from({ length: 48 }, (_, i) => toHHMM(i * 30));
