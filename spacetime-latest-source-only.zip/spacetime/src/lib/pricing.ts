import { calcEconomics, RATES } from '../../shared/economics.ts';
import type { Property } from '@/types';
import { localeTag } from './locale';

export { RATES };
export const calcPrice = (p: Property, hours: number, occurrences = 1) => calcEconomics(p, hours, occurrences);

export const eur = (n: number, digits?: number) =>
  new Intl.NumberFormat(localeTag(), { style: 'currency', currency: 'EUR', maximumFractionDigits: digits ?? (n % 1 === 0 ? 0 : 2), minimumFractionDigits: digits ?? (n % 1 === 0 ? 0 : 2) }).format(n);
