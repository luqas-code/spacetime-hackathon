import type { Lang } from '@/types';
let current: Lang = 'en';
export const setLocaleLang = (l: Lang) => {
  current = l;
  document.documentElement.lang = l;
};
export const getLang = () => current;
export const localeTag = () => (current === 'fr' ? 'fr-FR' : 'en-GB');
