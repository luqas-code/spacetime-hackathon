/**
 * Natural-language matching (client side).
 * Parsing happens on the server: Claude when ANTHROPIC_API_KEY is configured there, otherwise the
 * deterministic rule-based parser in shared/nlu.ts. Matching below only uses real listing data
 * (amenities, permitted activities, capacity and the live availability schedule) — nothing is invented.
 */
import type { Property } from '@/types';
import { parseIntent, type ParsedIntent } from '../../shared/nlu.ts';
import { PROPERTIES } from '@/data/properties';
import { distanceMeters, formatDistance } from './geo';
import { findFit, freeRanges } from './availability';
import { toHHMM, todayISO } from './time';
import { AMENITIES, ACTIVITIES } from '@/data/vocab';
import { api } from './api';
import { tr } from '@/i18n';
import { useStore } from '@/store/useStore';

export type { ParsedIntent };
export { EXAMPLE_PROMPTS } from '../../shared/nlu.ts';

export async function parseRequest(text: string, previous?: ParsedIntent): Promise<{ intent: ParsedIntent; engine: 'claude' | 'rules' }> {
  try {
    return await api('/api/ai/parse', { body: { text, previous, lang: useStore.getState().lang } });
  } catch {
    await new Promise((r) => setTimeout(r, 300));
    return { intent: parseIntent(text, new Date(), previous), engine: 'rules' };
  }
}

/** `must`: something the guest explicitly needs (time, capacity, requested amenity, permitted use). Otherwise a preference. */
export interface MatchCheck { ok: boolean; label: string; must?: boolean }
export interface Match { property: Property; score: number; distance?: number; window?: { start: string; end: string; partial: boolean }; checks: MatchCheck[]; mustMet: number; mustTotal: number }

const isQuiet = (p: Property) => p.accessibility.includes('low_sensory') || p.amenities.includes('soundproof') || /quiet|calm|silent/i.test(p.highlights.join(' ') + p.description);

export function matchProperties(it: ParsedIntent, anchor?: { lat: number; lng: number; label?: string }): Match[] {
  const guests = it.adults + it.children;
  const date = it.date ?? todayISO();
  const out: Match[] = [];
  for (const p of PROPERTIES) {
    if (p.capacity.guests < guests) continue;
    if ((it.children || it.infants) && !p.childrenAllowed) continue;
    if (it.pets && !p.petsAllowed) continue;
    if (it.accessibility.some((a) => !p.accessibility.includes(a))) continue;
    // only recommend for activities the listing is authorised for
    const primary = it.activities.filter((a) => a !== 'layover' && a !== 'relax');
    if (primary.length && !primary.some((a) => p.activities.includes(a))) continue;

    // Score: availability and distance dominate; amenities and permitted uses refine. Unavailable spaces are capped.
    const checks: MatchCheck[] = [];
    let score = 40;
    let cap = 99;
    const distance = anchor ? distanceMeters(anchor, p) : undefined;
    if (distance !== undefined) {
      score += Math.max(-25, 20 - distance / 150);
      checks.push({ ok: distance < 2500, label: tr('{d} from {place}', { d: formatDistance(distance), place: anchor?.label ?? it.location?.label ?? it.locationText ?? '' }) });
    }
    let window: Match['window'];
    if (it.start) {
      const hours = Math.min(p.maxHours, Math.max(p.minHours, it.durationHours ?? 3));
      const fit = findFit(p, date, it.start, hours, 1);
      if (fit) {
        const want = it.durationHours ?? hours;
        window = { start: fit.start, end: fit.end, partial: hours < want };
        score += fit.shifted === 0 ? 25 : 12;
        if (window.partial) cap = Math.min(cap, 80);
        checks.push({ must: true, ok: !window.partial, label: window.partial ? tr('Free {s}–{e} (max {n}h)', { s: fit.start, e: fit.end, n: p.maxHours }) : tr('Free {s}–{e}', { s: fit.start, e: fit.end }) + (fit.shifted ? ` (${tr('shifted')})` : '') });
      } else {
        const r = freeRanges(p, date);
        checks.push({ must: true, ok: false, label: r.length ? tr('Not free then · open {s}–{e}', { s: toHHMM(r[0][0]), e: toHHMM(r[0][1]) }) : tr('No availability that day') });
        cap = Math.min(cap, 45);
      }
    }
    checks.push({ must: true, ok: true, label: tr('Fits {n} guests', { n: guests }) + (it.infants ? ` + ${it.infants} ${tr('infant')}` : '') });
    for (const n of it.needs) {
      const ok = p.amenities.includes(n) || (n === 'bed' && p.amenities.includes('sofa_bed')) || (n === 'kitchen' && p.amenities.includes('pro_kitchen'));
      score += ok ? 5 : -10;
      if (!ok) cap = Math.min(cap, 75);
      checks.push({ must: true, ok, label: tr(AMENITIES[n]?.label ?? n) });
    }
    if (it.quiet) {
      const q = isQuiet(p);
      score += q ? 5 : -5;
      checks.push({ ok: q, label: tr('Quiet space') });
    }
    const hits = it.activities.filter((a) => p.activities.includes(a));
    score += hits.length * 3;
    if (hits.length) checks.push({ must: true, ok: true, label: tr('Permitted: {list}', { list: hits.map((a) => tr(ACTIVITIES[a].label)).join(', ') }) });
    if (it.activities.includes('family')) score += (['crib', 'high_chair', 'toys', 'baby_bath'] as const).filter((a) => p.amenities.includes(a)).length * 2;
    if (it.budgetMax) {
      const ok = p.pricePerHour <= it.budgetMax;
      score += ok ? 3 : -10;
      checks.push({ ok, label: tr('€{p}/hr — {v} budget', { p: p.pricePerHour, v: ok ? tr('within') : tr('over') }) });
    }
    if (p.rating) score += (p.rating - 4.5) * 10;
    score = Math.min(score, cap);
    const musts = checks.filter((c) => c.must);
    out.push({ property: p, score: Math.max(1, Math.min(99, Math.round(score))), distance, window, checks, mustMet: musts.filter((c) => c.ok).length, mustTotal: musts.length });
  }
  // Spaces that meet every must-have always come first; the score only orders within that.
  return out.sort((a, b) => (b.mustMet - b.mustTotal) - (a.mustMet - a.mustTotal) || b.score - a.score).slice(0, 5);
}
