/**
 * Recommendation layer. Discover asks a `RecommendationProvider` for sections. The shipped provider is
 * transparent and rule-based; an AI ranking service can implement the same interface later.
 * Spaces are only recommended for activities their listing explicitly permits.
 */
import type { Activity, Amenity, Property, UserPrefs } from '@/types';
import { PROPERTIES } from '@/data/properties';
import { PARIS_CENTER } from '@/data/places';
import { distanceMeters } from './geo';
import { freeRanges } from './availability';
import { nowMinutes, todayISO, addDays } from './time';
import { tr } from '@/i18n';
import { ACTIVITIES } from '@/data/vocab';

export interface RecContext { prefs: UserPrefs; pastPropertyIds: string[]; now: Date }
export interface RecItem { property: Property; distance: number; anchorLabel: string }
export type RecGroup = 'foryou' | 'rest' | 'work' | 'create' | 'near';
export interface RecSection { id: string; group: RecGroup; title: string; subtitle: string; activity?: Activity; need?: Amenity; items: RecItem[] }
export interface RecommendationProvider { id: string; label: string; getSections(ctx: RecContext): RecSection[] }

type Anchor = { lat: number; lng: number; label: string };
const has = (p: Property, a: Amenity[]) => a.filter((x) => p.amenities.includes(x)).length;
const quiet = (p: Property) => p.accessibility.includes('low_sensory') || p.amenities.includes('soundproof') || /quiet|calm/i.test(p.highlights.join(' '));
const bookableSoon = (p: Property) => [0, 1, 2, 3, 4, 5, 6].some((i) => freeRanges(p, addDays(todayISO(), i)).length > 0);

function rank(anchor: Anchor, scorer: (p: Property) => number | null, ctx: RecContext, limit = 8, maxDist = 8000): RecItem[] {
  const liked = [...ctx.prefs.favourites, ...ctx.pastPropertyIds].map((id) => PROPERTIES.find((x) => x.id === id)).filter(Boolean) as Property[];
  const likedActs = new Set(liked.flatMap((l) => l.activities));
  const out: (RecItem & { s: number })[] = [];
  for (const p of PROPERTIES) {
    if (!ctx.prefs.accessibility.every((n) => p.accessibility.includes(n))) continue;
    const d = distanceMeters(anchor, p);
    if (d > maxDist) continue;
    const base = scorer(p);
    if (base === null) continue;
    const affinity = liked.length ? (p.activities.filter((a) => likedActs.has(a)).length / p.activities.length) * 1.5 : 0;
    const s = base + (ctx.prefs.favourites.includes(p.id) ? 1.5 : 0) + affinity + (p.pricePerHour <= ctx.prefs.budgetMax ? 0 : -3) + (p.rating ?? 4.7) - d / 900 + (bookableSoon(p) ? 2 : -4);
    out.push({ property: p, distance: d, anchorLabel: anchor.label, s });
  }
  return out.sort((a, b) => b.s - a.s).slice(0, limit).map(({ s: _s, ...r }) => (void _s, r));
}
const permits = (a: Activity, extra?: (p: Property) => number | null) => (p: Property) => {
  if (!p.activities.includes(a)) return null;
  const e = extra ? extra(p) : 0;
  return e === null ? null : 3 + e;
};

export const ruleBasedProvider: RecommendationProvider = {
  id: 'rules-v2',
  label: 'Rule-based (listing data)',
  getSections(ctx) {
    const home = ctx.prefs.locations.find((l) => l.tag === 'home');
    const work = ctx.prefs.locations.find((l) => l.tag === 'work');
    const H: Anchor = home ? { lat: home.lat, lng: home.lng, label: tr('home') } : { ...PARIS_CENTER, label: '' };
    const W: Anchor = work ? { lat: work.lat, lng: work.lng, label: tr('work') } : H;
    const C: Anchor = { ...PARIS_CENTER, label: '' };
    const interests = ctx.prefs.interests;
    const hour = ctx.now.getHours();
    const weekday = ![0, 6].includes(ctx.now.getDay());
    const S: RecSection[] = [];

    if (interests.length)
      S.push({ id: 'for-you', group: 'foryou', title: tr('Picked for you'), subtitle: tr('Because you chose {list}', { list: interests.slice(0, 2).map((i) => tr(ACTIVITIES[i].label).toLowerCase()).join(' & ') }),
        items: rank(home ? H : C, (p) => { const o = p.activities.filter((a) => interests.includes(a)).length; return o ? o * 2 : null; }, ctx) });
    if (hour >= 6 && hour < 21) {
      const now = nowMinutes();
      S.push({ id: 'now', group: 'foryou', title: tr('Free right now'), subtitle: tr('Book and walk in within the hour'),
        items: rank(home ? H : C, (p) => (freeRanges(p, todayISO()).some(([s, e]) => s <= now + 45 && e - now >= 120) ? 2 : null), ctx) });
    }
    if (home) S.push({ id: 'near-home', group: 'near', title: tr('Near home'), subtitle: home.label, items: rank(H, () => 0, ctx, 8, 3000) });
    if (work) S.push({ id: 'near-work', group: 'near', title: tr('Near work'), subtitle: work.label, items: rank(W, () => 0, ctx, 8, 3000) });

    const rest: RecSection[] = [
      { id: 'nap', group: 'rest', title: tr('Take a nap'), subtitle: tr('A real bed, blackout blinds, from 1–2 hours'), activity: 'rest', need: 'bed', items: rank(weekday ? W : H, permits('rest', (p) => (p.amenities.includes('bed') ? has(p, ['blackout', 'soundproof']) + (p.minHours <= 2 ? 1 : 0) : null)), ctx) },
      { id: 'shower', group: 'rest', title: tr('Shower between journeys'), subtitle: tr('Near the big stations, with luggage space'), activity: 'layover', need: 'shower', items: rank(C, permits('layover', (p) => (p.amenities.includes('shower') ? has(p, ['luggage', 'towels', 'bed']) : null)), ctx) },
      { id: 'family-stop', group: 'rest', title: tr('Family stopovers'), subtitle: tr('Cots, high chairs and room to play'), activity: 'family', items: rank(C, permits('family', (p) => (p.childrenAllowed ? has(p, ['crib', 'high_chair', 'toys', 'baby_bath']) : null)), ctx) },
      { id: 'pre-checkin', group: 'rest', title: tr('Relax before check-in'), subtitle: tr('Bathtubs, books and calm'), activity: 'relax', items: rank(C, (p) => (p.activities.includes('relax') || p.activities.includes('wellness') ? 2 + has(p, ['bathtub', 'blackout']) : null), ctx) },
    ];
    const workS: RecSection[] = [
      { id: 'remote', group: 'work', title: tr('Remote work'), subtitle: tr('Desks, screens and fast Wi‑Fi'), activity: 'work', need: 'desk', items: rank(W, permits('work', (p) => has(p, ['desk', 'monitor', 'wifi'])), ctx) },
      { id: 'meetings', group: 'work', title: tr('Private meetings'), subtitle: tr('Tables, screens & coffee — nicer than a hotel'), activity: 'meeting', items: rank(W, permits('meeting', (p) => has(p, ['whiteboard', 'projector', 'monitor', 'dining_table'])), ctx) },
      { id: 'quiet', group: 'work', title: tr('Quiet workspaces'), subtitle: tr('Low-noise spaces to focus'), activity: 'work', items: rank(W, permits('work', (p) => (quiet(p) ? 2 : null)), ctx) },
      { id: 'calls', group: 'work', title: tr('Video-call friendly'), subtitle: tr('Wi‑Fi plus a quiet room to talk'), activity: 'work', need: 'wifi', items: rank(W, permits('work', (p) => (p.amenities.includes('wifi') && (quiet(p) || p.amenities.includes('monitor')) ? 1 : null)), ctx) },
    ];
    const create: RecSection[] = [
      { id: 'cook', group: 'create', title: tr('Cooking & baking'), subtitle: tr('Proper ovens and space to spread out'), activity: 'cooking', need: 'kitchen', items: rank(C, permits('cooking', (p) => has(p, ['pro_kitchen', 'oven', 'dining_table'])), ctx) },
      { id: 'creative', group: 'create', title: tr('Creative activities'), subtitle: tr('Light, space and permission to make'), activity: 'creative', items: rank(C, permits('creative', (p) => has(p, ['piano', 'desk'])), ctx) },
      { id: 'rehearse', group: 'create', title: tr('Rehearsals'), subtitle: tr('Pianos and soundproofing'), activity: 'rehearsal', items: rank(C, permits('rehearsal', (p) => has(p, ['piano', 'soundproof', 'speakers'])), ctx) },
      { id: 'gather', group: 'create', title: tr('Permitted social gatherings'), subtitle: tr('Spaces where small gatherings are authorised'), activity: 'party', items: rank(C, permits('party', (p) => p.capacity.guests / 5), ctx) },
    ];
    const boost = (arr: RecSection[]) => arr.sort((a, b) => Number(!!b.activity && interests.includes(b.activity)) - Number(!!a.activity && interests.includes(a.activity)));
    const groups = weekday && hour >= 7 && hour < 17 ? [boost(workS), boost(rest), boost(create)] : [boost(rest), boost(workS), boost(create)];
    if (ctx.prefs.household.kids) rest.sort((a) => (a.id === 'family-stop' ? -1 : 0));
    return [...S, ...groups.flat()].filter((s) => s.items.length > 0);
  },
};

export const recommendationProvider: RecommendationProvider = ruleBasedProvider;
