import type { Booking, Property } from '@/types';
import { recurringDates } from './search';

/** Build a downloadable .ics so the demo booking can be added to any calendar. */
export function downloadICS(b: Booking, p: Property) {
  const dates = b.recurring ? recurringDates(b.date, b.recurring.freq, b.recurring.count) : [b.date];
  const fmt = (d: string, t: string) => d.replace(/-/g, '') + 'T' + t.replace(':', '') + '00';
  const events = dates.map((d, i) => [
    'BEGIN:VEVENT',
    `UID:${b.id}-${i}@spacetime.demo`,
    `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').split('.')[0]}Z`,
    `DTSTART;TZID=Europe/Paris:${fmt(d, b.start)}`,
    `DTEND;TZID=Europe/Paris:${fmt(d, b.end === '24:00' ? '23:59' : b.end)}`,
    `SUMMARY:SpaceTime · ${p.shortTitle}`,
    `LOCATION:${p.address || `${p.neighbourhood}, Paris`}`,
    `DESCRIPTION:Access code ${b.accessCode}. Space Partner: ${p.partner.name}.`,
    'END:VEVENT',
  ].join('\r\n'));
  const ics = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//SpaceTime//Prototype//EN', ...events, 'END:VCALENDAR'].join('\r\n');
  const url = URL.createObjectURL(new Blob([ics], { type: 'text/calendar' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = `spacetime-${b.id}.ics`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const gcalStamp = (d: string, t: string) => d.replace(/-/g, '') + 'T' + (t === '24:00' ? '2359' : t.replace(':', '')) + '00';
export const googleCalendarUrl = (b: Booking, p: Property) =>
  `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(`SpaceTime · ${p.shortTitle}`)}&dates=${gcalStamp(b.date, b.start)}/${gcalStamp(b.date, b.end)}&ctz=Europe/Paris&location=${encodeURIComponent(p.address || p.neighbourhood)}&details=${encodeURIComponent(`Access code ${b.accessCode}`)}`;
export const outlookCalendarUrl = (b: Booking, p: Property) =>
  `https://outlook.live.com/calendar/0/deeplink/compose?subject=${encodeURIComponent(`SpaceTime · ${p.shortTitle}`)}&startdt=${b.date}T${b.start}:00&enddt=${b.date}T${b.end === '24:00' ? '23:59' : b.end}:00&location=${encodeURIComponent(p.address || p.neighbourhood)}&body=${encodeURIComponent(`Access code ${b.accessCode}`)}`;
