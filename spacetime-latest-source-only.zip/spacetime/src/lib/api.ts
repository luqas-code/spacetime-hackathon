import { useCallback, useEffect, useRef, useState } from 'react';
import { useStore } from '@/store/useStore';

export class ApiError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string, message: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export async function api<T = unknown>(path: string, opts: { method?: string; body?: unknown } = {}): Promise<T> {
  const token = useStore.getState().token;
  const res = await fetch(path, {
    method: opts.method ?? (opts.body !== undefined ? 'POST' : 'GET'),
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) {
    if (res.status === 401 && token && path !== '/api/login') useStore.getState().signedOut();
    throw new ApiError(res.status, data?.error ?? 'error', data?.message ?? data?.error ?? 'Request failed');
  }
  return data as T;
}

/** Fetch + auto-refresh whenever the server pushes a change (or the device reconnects). */
export function useApi<T>(path: string | null) {
  const rev = useStore((s) => s.rev);
  const [data, setData] = useState<T | undefined>(undefined);
  const [error, setError] = useState<ApiError | null>(null);
  const [loading, setLoading] = useState(!!path);
  const [local, setLocal] = useState(0);
  const lastPath = useRef(path);
  useEffect(() => {
    if (!path) return;
    let alive = true;
    if (lastPath.current !== path) {
      setData(undefined);
      lastPath.current = path;
    }
    setLoading(true);
    api<T>(path)
      .then((d) => { if (alive) { setData(d); setError(null); } })
      .catch((e) => { if (alive) setError(e instanceof ApiError ? e : new ApiError(0, 'network', String(e))); })
      .finally(() => alive && setLoading(false));
    return () => { alive = false; };
  }, [path, rev, local]);
  const reload = useCallback(() => setLocal((n) => n + 1), []);
  return { data, error, loading, reload, setData };
}

/** Resize an image in the browser before upload so phones can send camera photos quickly. */
export async function uploadImage(file: File, max = 1600): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);
      c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', 0.84));
    };
    img.onerror = () => reject(new Error('Could not read image'));
    img.src = url;
  });
  const out = await api<{ url: string }>('/api/uploads', { body: { dataUrl } });
  return out.url;
}

/** Server-Sent Events: any change pushed by the server bumps `rev`, which refreshes every mounted query. */
export function connectLive() {
  let es: EventSource | null = null;
  let stopped = false;
  let poll: ReturnType<typeof setInterval> | null = null;
  const open = () => {
    const token = useStore.getState().token;
    if (!token || stopped) return;
    es = new EventSource(`/api/events?token=${encodeURIComponent(token)}`);
    es.onopen = () => useStore.setState({ live: true });
    es.onmessage = (ev) => {
      const msg = JSON.parse(ev.data) as { type: string; scope?: string; text?: string; link?: string };
      if (msg.type === 'ping' || msg.type === 'hello') return;
      const st = useStore.getState();
      if (msg.type === 'changed' && msg.scope === 'catalog') st.loadCatalog();
      st.bump();
      if ((msg.type === 'notification' || msg.type === 'message') && msg.text) st.showToast(msg.text, msg.link);
    };
    es.onerror = () => useStore.setState({ live: false });
  };
  open();
  // Reliable fallback: refresh every 20 s while the live channel is down, and when the tab regains focus.
  poll = setInterval(() => {
    if (document.visibilityState === 'visible' && (!es || es.readyState !== EventSource.OPEN)) {
      useStore.getState().bump();
      useStore.getState().loadCatalog();
      if (es?.readyState === EventSource.CLOSED) open();
    }
  }, 20000);
  const onVis = () => {
    if (document.visibilityState === 'visible') {
      useStore.getState().bump();
      useStore.getState().loadCatalog();
    }
  };
  document.addEventListener('visibilitychange', onVis);
  return () => {
    stopped = true;
    es?.close();
    if (poll) clearInterval(poll);
    document.removeEventListener('visibilitychange', onVis);
  };
}

export async function uploadFile(file: File): Promise<string> {
  if (file.type.startsWith('image/')) return uploadImage(file);
  const dataUrl = await new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result as string); r.onerror = rej; r.readAsDataURL(file); });
  return (await api<{ url: string }>('/api/uploads', { body: { dataUrl } })).url;
}
