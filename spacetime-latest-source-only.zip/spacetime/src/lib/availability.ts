import type { DaySchedule, Property } from '@/types';
import { addDays, nowMinutes, parseISO, toHHMM, toMin, todayISO } from './time';
import { subtract } from '../../shared/time.ts';
import { tr } from '@/i18n';
import { localeTag } from './locale';

type Range = [number, number];
const EMPTY: DaySchedule = { open: [], overnight: [], booked: [], pending: [], buffers: [], blocked: [], free: [] };

/** Server-computed schedule for a date (approved windows minus bookings, buffers, overnight stays, blocks). */
export const dayOf = (p: Property, date: string): DaySchedule => p.schedule?.[date] ?? EMPTY;

export function openingWindow(p: Property, date: string): Range | null {
  const o = dayOf(p, date).open;
  return o.length ? [o[0][0], o[o.length - 1][1]] : null;
}

export function freeRanges(p: Property, date: string): Range[] {
  let f = dayOf(p, date).free;
  if (date === todayISO()) f = subtract(f, [[0, Math.ceil(nowMinutes() / 30) * 30]]);
  return f.filter(([s, e]) => e - s >= 60);
}

export function isFree(p: Property, date: string, startMin: number, hours: number): boolean {
  const end = startMin + hours * 60;
  return freeRanges(p, date).some(([s, e]) => startMin >= s && end <= e);
}

export function findFit(p: Property, date: string, start: string, hours: number, flexHours = 0): { start: string; end: string; shifted: number } | null {
  const want = toMin(start);
  const offsets = [0];
  for (let o = 30; o <= flexHours * 60; o += 30) offsets.push(-o, o);
  for (const o of offsets) {
    const s = want + o;
    if (s < 0) continue;
    if (isFree(p, date, s, hours)) return { start: toHHMM(s), end: toHHMM(s + hours * 60), shifted: o };
  }
  return null;
}

export interface Slot { start: string; available: boolean }

export function startSlots(p: Property, date: string, hours: number): Slot[] {
  const day = dayOf(p, date);
  const slots: Slot[] = [];
  const isToday = date === todayISO();
  const now = nowMinutes();
  for (const [os, oe] of day.open) {
    for (let m = os; m + 60 <= oe; m += 30) {
      if (isToday && m < now) continue;
      slots.push({ start: toHHMM(m), available: isFree(p, date, m, hours) });
    }
  }
  return slots;
}

export function availabilityLabel(p: Property, date = todayISO()): { text: string; tone: 'now' | 'later' | 'closed' } {
  const ranges = freeRanges(p, date);
  const now = nowMinutes();
  if (ranges.length) {
    const cur = date === todayISO() ? ranges.find(([s, e]) => s <= now + 30 && e > now) : undefined;
    if (cur) return { text: tr('Free now · until {t}', { t: toHHMM(cur[1]) }), tone: 'now' };
    const lbl = date === todayISO() ? tr('Today') : '';
    return { text: `${lbl ? lbl + ' ' : ''}${toHHMM(ranges[0][0])}–${toHHMM(ranges[0][1])}`, tone: 'later' };
  }
  for (let i = 1; i < 14; i++) {
    const d = addDays(date, i);
    const r = freeRanges(p, d);
    if (r.length) {
      const name = i === 1 ? tr('Tomorrow') : parseISO(d).toLocaleDateString(localeTag(), { weekday: 'short', day: 'numeric' });
      return { text: tr('{day} from {t}', { day: name, t: toHHMM(r[0][0]) }), tone: 'closed' };
    }
  }
  return { text: tr('No open slots yet'), tone: 'closed' };
}

export function openingLabel(p: Property): string[] {
  const names = (d: number) => new Date(2026, 0, 4 + d).toLocaleDateString(localeTag(), { weekday: 'short' });
  const weekly = p.availability.map((w) => {
    const d = [...w.days].sort((a, b) => ((a + 6) % 7) - ((b + 6) % 7));
    const label = d.length === 7 ? tr('Every day') : d.length === 5 && !d.includes(0) && !d.includes(6) ? tr('Mon–Fri') : d.length === 2 && d.includes(0) && d.includes(6) ? tr('Sat–Sun') : d.map(names).join(', ');
    return `${label} · ${w.start}–${w.end}`;
  });
  return weekly.length ? weekly : [tr('Dated windows approved by the Space Partner')];
}

/** Total bookable hours in the next `days` days. */
export function bookableHours(p: Property, days = 7) {
  let h = 0;
  for (let i = 0; i < days; i++) h += freeRanges(p, addDays(todayISO(), i)).reduce((s, [a, b]) => s + (b - a) / 60, 0);
  return Math.round(h);
}
