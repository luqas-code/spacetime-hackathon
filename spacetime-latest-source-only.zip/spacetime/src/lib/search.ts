import type { Filters, Property, SearchQuery } from '@/types';
import { PROPERTIES } from '@/data/properties';
import { PARIS_CENTER } from '@/data/places';
import { distanceMeters } from './geo';
import { findFit } from './availability';
import { defaultDate, defaultStart, addDays } from './time';

export const DEFAULT_QUERY = (): SearchQuery => ({
  where: { mode: 'city', label: 'Paris', lat: PARIS_CENTER.lat, lng: PARIS_CENTER.lng, radiusKm: 6, city: 'Paris' },
  when: { date: defaultDate(), start: defaultStart(), durationHours: 3, flex: 1, recurring: null },
  who: { adults: 1, children: 0, infants: 0, pets: 0, accessibility: [] },
});

export const DEFAULT_FILTERS: Filters = {
  priceMin: 0, priceMax: 60, minDuration: 0, capacity: 0, radiusKm: 0,
  amenities: [], types: [], accessibility: [], petsAllowed: false, activities: [], instantOnly: false, sort: 'recommended',
};

export const PRICE_CEIL = 60;

export interface Result {
  property: Property;
  distance: number;
  fit: { start: string; end: string; shifted: number } | null;
  /** fraction of requested occurrences that are available (recurring searches) */
  recurringFit?: number;
  score: number;
}

export function totalGuests(q: SearchQuery) {
  return q.who.adults + q.who.children; // infants don't count towards capacity
}

export function activeFilterCount(f: Filters) {
  let n = 0;
  if (f.priceMin > 0 || f.priceMax < PRICE_CEIL) n++;
  if (f.minDuration) n++;
  if (f.capacity) n++;
  if (f.radiusKm) n++;
  n += f.amenities.length + f.types.length + f.accessibility.length + f.activities.length;
  if (f.petsAllowed) n++;
  if (f.instantOnly) n++;
  return n;
}

/** Hard constraints from the query (who/where/when) and the filter sheet. */
export function runSearch(q: SearchQuery, f: Filters = DEFAULT_FILTERS, opts: { requireAvailability?: boolean } = {}): Result[] {
  const requireAvail = opts.requireAvailability ?? true;
  const guests = totalGuests(q);
  const radius = f.radiusKm || q.where.radiusKm;
  const access = Array.from(new Set([...q.who.accessibility, ...f.accessibility]));
  const hours = Math.max(q.when.durationHours, f.minDuration || 0);

  const out: Result[] = [];
  for (const p of PROPERTIES) {
    const distance = distanceMeters(q.where, p);
    if (radius && distance > radius * 1000) continue;
    if (p.capacity.guests < Math.max(guests, f.capacity)) continue;
    if ((q.who.children > 0 || q.who.infants > 0) && !p.childrenAllowed) continue;
    if ((q.who.pets > 0 || f.petsAllowed) && !p.petsAllowed) continue;
    if (access.some((a) => !p.accessibility.includes(a))) continue;
    if (p.pricePerHour < f.priceMin || (f.priceMax < PRICE_CEIL && p.pricePerHour > f.priceMax)) continue;
    if (hours < p.minHours && q.when.durationHours < p.minHours && f.minDuration === 0) {
      // the space needs a longer minimum booking than requested: still show, booking flow will round up
    }
    if (hours > p.maxHours) continue;
    if (f.amenities.some((a) => !p.amenities.includes(a))) continue;
    if (f.types.length && !f.types.includes(p.type)) continue;
    if (f.activities.length && !f.activities.every((a) => p.activities.includes(a))) continue;
    if (q.activity && !p.activities.includes(q.activity)) continue;
    if (f.instantOnly && !p.instantBook) continue;

    const effHours = Math.max(hours, p.minHours);
    const fit = findFit(p, q.when.date, q.when.start, effHours, q.when.flex);
    if (requireAvail && !fit) continue;

    let recurringFit: number | undefined;
    if (q.when.recurring) {
      const dates = recurringDates(q.when.date, q.when.recurring.freq, q.when.recurring.count);
      recurringFit = dates.filter((d) => findFit(p, d, q.when.start, effHours, q.when.flex)).length / dates.length;
    }

    const score = (p.rating ?? 4.5) * 10 - distance / 250 + (fit && fit.shifted === 0 ? 5 : 0) + (p.instantBook ? 2 : 0) + (recurringFit ?? 1) * 5;
    out.push({ property: p, distance, fit, recurringFit, score });
  }

  const sorters: Record<Filters['sort'], (a: Result, b: Result) => number> = {
    recommended: (a, b) => b.score - a.score,
    distance: (a, b) => a.distance - b.distance,
    price: (a, b) => a.property.pricePerHour - b.property.pricePerHour,
    rating: (a, b) => (b.property.rating ?? 0) - (a.property.rating ?? 0),
  };
  return out.sort(sorters[f.sort]);
}

export function recurringDates(start: string, freq: 'daily' | 'weekdays' | 'weekly', count: number): string[] {
  const out: string[] = [];
  let d = start;
  let guard = 0;
  while (out.length < count && guard++ < 120) {
    const dow = new Date(d + 'T12:00').getDay();
    if (freq !== 'weekdays' || (dow !== 0 && dow !== 6)) out.push(d);
    d = addDays(d, freq === 'weekly' ? 7 : 1);
  }
  return out;
}

export function describeWhen(q: SearchQuery, dayLabel: (iso: string) => string) {
  const flex = q.when.flex ? ` ±${q.when.flex}h` : '';
  return `${dayLabel(q.when.date)} · ${q.when.start}${flex} · ${q.when.durationHours}h${q.when.recurring ? ' · repeats' : ''}`;
}

export function describeWho(q: SearchQuery) {
  const g = totalGuests(q);
  const parts = [`${g} guest${g === 1 ? '' : 's'}`];
  if (q.who.infants) parts.push(`${q.who.infants} infant${q.who.infants > 1 ? 's' : ''}`);
  if (q.who.pets) parts.push(`${q.who.pets} pet${q.who.pets > 1 ? 's' : ''}`);
  return parts.join(', ');
}
