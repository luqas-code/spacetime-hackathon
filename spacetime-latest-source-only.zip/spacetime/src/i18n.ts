import { useCallback } from 'react';
import { useStore } from '@/store/useStore';
import { FR } from './i18n.fr';
import type { Lang } from '@/types';

/**
 * English source strings are the keys; French translations live in i18n.fr.ts.
 * `{name}` placeholders are interpolated.
 */
export function translate(lang: Lang, s: string, vars?: Record<string, string | number>): string {
  // "nav:" keys are short navigation labels: the English text is the key without the prefix, and French may use a
  // shorter word than the normal translation so tab labels stay readable on narrow phones.
  const ctx = s.startsWith('nav:') ? s.slice(4) : null;
  let out = lang === 'fr' ? FR[s] ?? (ctx !== null ? FR[ctx] ?? ctx : s) : ctx ?? s;
  if (import.meta.env.DEV && lang === 'fr' && !(s in FR) && !(ctx !== null && ctx in FR)) (window as unknown as { __missing?: Set<string> }).__missing = ((window as unknown as { __missing?: Set<string> }).__missing ?? new Set()).add(s);
  if (vars) for (const [k, v] of Object.entries(vars)) out = out.split(`{${k}}`).join(String(v));
  return out;
}

export type T = (s: string, vars?: Record<string, string | number>) => string;

export function useT(): T {
  const lang = useStore((s) => s.lang);
  return useCallback((s: string, vars?: Record<string, string | number>) => translate(lang, s, vars), [lang]);
}

/** Non-hook access (for helpers called during render). */
export const tr: T = (s, vars) => translate(useStore.getState().lang, s, vars);
