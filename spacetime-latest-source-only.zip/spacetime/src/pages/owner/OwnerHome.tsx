import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Bell, ChevronDown, Info, Plus } from 'lucide-react';
import { useApi } from '@/lib/api';
import { DashHeader, FinanceBreakdown, ListingStatusPill, Panel, RowLink, Spinner } from '@/components/dash';
import { Avatar, Segmented, StatusPill } from '@/components/ui';
import { Img } from '@/components/Img';
import { eur } from '@/lib/pricing';
import { dayLabel } from '@/lib/time';
import { localeTag } from '@/lib/locale';
import { useT } from '@/i18n';
import { timeAgo } from '../InboxList';
import { useStore } from '@/store/useStore';
import type { Booking, Notification, Property } from '@/types';

type Totals = { gross: number; commission: number; guestFees: number; cleaning: number; mgmtFee: number; ownerProceeds: number; bookings: number; mgmtFeePct: number | null };
export type OwnerPeriod = 'this_month' | 'last_month' | 'all';
export type OwnerOverview = {
  period: { key: OwnerPeriod; month: string | null; today: string; basis: 'scheduled_date' };
  totals: Totals & { upcoming: number; completed: number };
  pending: { bookings: number; gross: number };
  comparison: (Totals & { month: string }) | null;
  properties: (Property & { occupancy?: { openHours: number; bookedHours: number; occupancy: number } })[];
  bookings: (Booking & { property: { id: string; shortTitle?: string; image?: string; managerName?: string } })[];
  managers: { id: string; name: string; company: string; avatarUrl: string; properties: number; bookings: number; cleaningDone: number; cleaningTotal: number; slotsApproved: number; responseMins: number | null }[];
  updates: Notification[];
};

export const monthLabel = (ym: string, capitalise = true) => { const [y, m] = ym.split('-').map(Number); const s = new Date(y, m - 1, 1).toLocaleDateString(localeTag(), { month: 'long', year: 'numeric' }); return capitalise ? s.charAt(0).toUpperCase() + s.slice(1) : s; };

export default function OwnerHome() {
  const t = useT();
  const user = useStore((s) => s.user)!;
  const [period, setPeriod] = useState<OwnerPeriod>('this_month');
  const { data, loading } = useApi<OwnerOverview>(`/api/owner/overview?period=${period}`);
  const latest = data?.bookings.find((b) => b.status === 'confirmed' || b.status === 'pending');
  return (
    <div className="page">
      <DashHeader title={t('Owner dashboard')} sub={user.company} profileLink="/owner/profile" />
      {!data ? <Spinner /> : (
        <div className="space-y-6 px-4 pt-4">
          <Link to="/owner/new" className="btn-accent w-full py-4 text-[16px]"><Plus size={18} /> {t('List a space')}</Link>
          <OwnerFinance data={data} period={period} setPeriod={setPeriod} loading={loading} />

          {latest && (
            <Panel title={t('Latest booking')}>
              <Link to={`/owner/property/${latest.propertyId}`} className="card block p-4">
                <div className="flex items-center gap-3">
                  <Img src={latest.property.image ?? ''} alt="" className="h-14 w-14 rounded-lg" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2"><StatusPill tone={latest.status === 'confirmed' ? 'ok' : 'warn'}>{t(latest.status === 'confirmed' ? 'Confirmed' : 'Awaiting approval')}</StatusPill><span className="text-[11px] text-ink-500">{timeAgo(latest.createdAt)}</span></div>
                    <div className="mt-0.5 truncate text-[14px] font-bold">{latest.property.shortTitle}</div>
                    <div className="text-[12px] text-ink-500">{dayLabel(latest.date)} · {latest.start}–{latest.end} · {latest.guestName} · {t('managed by {m}', { m: latest.property.managerName ?? '—' })}</div>
                  </div>
                </div>
                <div className="mt-3 rounded-lg bg-ivory-50 p-3"><FinanceBreakdown e={latest.price} compact /></div>
                {latest.status === 'pending' && <p className="mt-2 text-[12.5px] text-ink-500">{t('Not counted in proceeds until the manager confirms it.')}</p>}
              </Link>
            </Panel>
          )}

          <Panel title={t('Your listings')} action={<Link to="/owner/listings" className="text-[12.5px] font-bold text-electric-600">{t('All')}</Link>}>
            <div className="card divide-y divide-ivory-200 overflow-hidden">
              {data.properties.slice(0, 5).map((p) => (
                <RowLink key={p.id} to={`/owner/property/${p.id}`}>
                  <Img src={p.images[0] ?? ''} alt="" className="h-12 w-12 shrink-0 rounded-lg" />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[14px] font-semibold">{p.shortTitle || p.title}</div>
                    <div className="flex items-center gap-2 text-[12px] text-ink-500"><ListingStatusPill s={p.status} /> <span className="truncate">{p.managerName ? t('Manager: {m}', { m: p.managerName }) : t('No manager yet')}</span></div>
                  </div>
                  <div className="text-right text-[12.5px] text-ink-500"><div className="text-[14px] font-bold text-ink">{p.occupancy?.occupancy ?? 0}%</div>{t('occupancy')}</div>
                </RowLink>
              ))}
            </div>
          </Panel>

          <Panel title={t('Your managers')}>
            <div className="space-y-2">
              {data.managers.map((m) => (
                <div key={m.id} className="card flex items-center gap-3 p-3">
                  <Avatar name={m.name} src={m.avatarUrl || undefined} size={42} />
                  <div className="min-w-0 flex-1"><div className="text-[14px] font-bold">{m.name}</div><div className="truncate text-[12px] text-ink-500">{m.company} · {t('{n} of your properties', { n: m.properties })}</div></div>
                  <div className="grid grid-cols-3 gap-2 text-center text-[11.5px] text-ink-500">
                    <div><div className="text-[14px] font-bold text-ink">{m.bookings}</div>{t('bookings')}</div>
                    <div><div className="text-[14px] font-bold text-ink">{m.cleaningTotal ? Math.round((m.cleaningDone / m.cleaningTotal) * 100) : 100}%</div>{t('cleans done')}</div>
                    <div><div className="text-[14px] font-bold text-ink">{m.responseMins ?? '–'}</div>{t('min reply')}</div>
                  </div>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title={<span className="flex items-center gap-1.5"><Bell size={13} /> {t('Operational updates')}</span>}>
            <div className="card divide-y divide-ivory-200">
              {data.updates.length === 0 && <p className="p-4 text-[13px] text-ink-500">{t('Updates from your managers will appear here.')}</p>}
              {data.updates.map((n) => <Link key={n.id} to={n.link} className="flex gap-3 px-4 py-3 text-[13px]"><span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${n.read ? 'bg-ivory-300' : 'bg-electric'}`} /><span className="flex-1 text-ink-700">{n.text}</span><span className="shrink-0 text-[11px] text-ink-500">{timeAgo(n.at)}</span></Link>)}
            </div>
          </Panel>
          <div className="h-4" />
        </div>
      )}
    </div>
  );
}

function OwnerFinance({ data, period, setPeriod, loading }: { data: OwnerOverview; period: OwnerPeriod; setPeriod: (p: OwnerPeriod) => void; loading: boolean }) {
  const t = useT();
  const [how, setHow] = useState(false);
  const [detail, setDetail] = useState(false);
  const tot = data.totals;
  const periodName = data.period.month ? monthLabel(data.period.month) : t('All time');
  const cmp = data.comparison;
  const delta = cmp ? tot.ownerProceeds - cmp.ownerProceeds : 0;
  return (
    <section aria-labelledby="fin-h" className="space-y-3">
      <div className="flex items-center justify-between gap-3 px-1"><h2 id="fin-h" className="text-[17px] font-bold tracking-tight">{t('Earnings')}</h2></div>
      <Segmented value={period} onChange={setPeriod} options={[{ value: 'this_month', label: t('This month') }, { value: 'last_month', label: t('Last month') }, { value: 'all', label: t('All time') }]} />
      <div className={`card overflow-hidden transition-opacity ${loading ? 'opacity-60' : ''}`} aria-busy={loading}>
        <div className="bg-ink p-4 text-white">
          <div className="flex items-center gap-1.5 text-[13px] font-semibold text-ice-200">
            {t('Estimated owner proceeds')}
            <button onClick={() => setHow(!how)} aria-expanded={how} aria-label={t('How is this calculated?')} className="-m-2 grid h-9 w-9 place-items-center rounded-full text-ice-200 hover:text-white"><Info size={15} /></button>
          </div>
          <div className="mt-1 text-[32px] font-bold leading-none tracking-tight tabular-nums">{eur(tot.ownerProceeds)}</div>
          <div className="mt-2 text-[13.5px] text-ice-200">{periodName} · {t(tot.bookings === 1 ? '{n} confirmed/completed booking' : '{n} confirmed/completed bookings', { n: tot.bookings })}</div>
          {how && <p className="mt-3 rounded-lg bg-white/10 p-3 text-[13px] leading-relaxed text-ice-100">{t('Gross booking value minus the SpaceTime platform fee and the property management fee. Taxes and your other costs are not deducted, so this is not profit. Bookings are counted in the month they are scheduled to take place.')}</p>}
          {cmp && <p className="mt-2 text-[12.5px] text-ice-200">{t('{d} vs {m} ({x})', { d: `${delta >= 0 ? '+' : '−'}${eur(Math.abs(delta))}`, m: monthLabel(cmp.month, false), x: eur(cmp.ownerProceeds) })}</p>}
        </div>
        <div className="grid grid-cols-2 divide-x divide-ivory-200 border-b border-ivory-200">
          <div className="p-3.5"><div className="text-[12.5px] text-ink-500">{t('Gross booking value')}</div><div className="mt-0.5 text-[18px] font-bold tabular-nums">{eur(tot.gross)}</div></div>
          <div className="p-3.5"><div className="text-[12.5px] text-ink-500">{t('Bookings')}</div><div className="mt-0.5 text-[18px] font-bold tabular-nums">{tot.bookings}</div><div className="text-[12px] text-ink-500">{t('{n} upcoming', { n: tot.upcoming })}</div></div>
        </div>
        {data.pending.bookings > 0 && <div className="border-b border-ivory-200 bg-amber-50 px-4 py-2.5 text-[13px] text-amber-800">{t('{n} pending request(s) worth {x} are not included until confirmed.', { n: data.pending.bookings, x: eur(data.pending.gross) })}</div>}
        <button onClick={() => setDetail(!detail)} aria-expanded={detail} className="flex min-h-[48px] w-full items-center justify-between px-4 text-[14px] font-semibold text-ink">
          {t('Fee breakdown')}<ChevronDown size={18} className={`text-ink-500 transition ${detail ? 'rotate-180' : ''}`} />
        </button>
        {detail && (
          <div className="px-4 pb-4">
            <FinanceBreakdown explain e={{ gross: tot.gross, guestFee: tot.guestFees, cleaning: tot.cleaning, commission: tot.commission, mgmtFee: tot.mgmtFee, mgmtFeePct: tot.mgmtFeePct, ownerProceeds: tot.ownerProceeds }} />
            <p className="mt-3 text-[12.5px] leading-snug text-ink-500">{t('Confirmed and completed bookings only, by scheduled date. Pending, declined and cancelled bookings are excluded. Proposed commercial terms.')}</p>
          </div>
        )}
      </div>
    </section>
  );
}
