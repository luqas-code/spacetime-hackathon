import { useEffect, useRef, useState, type ReactNode } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { BadgeCheck, CalendarDays, Check, ChevronLeft, FileUp, ImagePlus, Loader2, Plus, Rocket, Sparkles, Trash2, Upload, Wand2, X } from 'lucide-react';
import { api, uploadFile, uploadImage, useApi } from '@/lib/api';
import { useStore } from '@/store/useStore';
import { Avatar, Chip, Segmented, Stepper, Toggle, PreviewNote } from '@/components/ui';
import { Img } from '@/components/Img';
import { PlaceSearch } from '@/components/PlaceSearch';
import { FinanceBreakdown } from '@/components/dash';
import { ACCESSIBILITY, ACTIVITIES, AMENITIES, PROPERTY_TYPES } from '@/data/vocab';
import { SAMPLE_PHOTOS } from '../../../shared/samplePhotos.ts';
import { calcEconomics } from '../../../shared/economics.ts';
import { eur } from '@/lib/pricing';
import { useT } from '@/i18n';
import type { Accessibility, Activity, Amenity, ComplianceDoc, Property, PropertyType, WeeklyWindow } from '@/types';

type Draft = Omit<Property, 'id' | 'status' | 'ownerId' | 'createdAt' | 'partner'> & { id?: string; status?: Property['status'] };
type Manager = { id: string; name: string; company: string; avatarUrl: string; properties: number };
type OperatorFile = { company: string; registrationScope: string; permittedUses: Activity[]; documents: ComplianceDoc[] };

const STEPS = ['Basics', 'Photos', 'Amenities', 'Uses & rules', 'Hours & pricing', 'Compliance', 'Management', 'Review'];
/** The eight detailed steps, grouped into four plain-language stages for the progress display. */
const STAGES: { title: string; steps: number[] }[] = [
  { title: 'Your space', steps: [0, 1, 2, 3] },
  { title: 'Availability & pricing', steps: [4] },
  { title: 'Management & compliance', steps: [5, 6] },
  { title: 'Review & submit', steps: [7] },
];
const KEY_AMENITIES: Amenity[] = ['kitchen', 'bed', 'sofa', 'sofa_bed', 'shower', 'bathtub', 'wifi', 'desk', 'heating', 'ac', 'towels', 'luggage', 'crib', 'high_chair', 'toys', 'blackout', 'washer', 'tv', 'oven', 'coffee', 'elevator', 'monitor'];
const RULE_SUGGESTIONS = ['No parties or events', 'No smoking', 'Quiet hours after 21:00', 'Shoes off in the bedroom', 'Children supervised at all times'];
const DAYS = [1, 2, 3, 4, 5, 6, 0];

const empty = (): Draft => ({
  title: '', shortTitle: '', type: 'apartment', neighbourhood: '', arrondissement: '', address: '', lat: 48.8606, lng: 2.3476, images: [], description: '', highlights: [],
  amenities: [], accessibility: [], activities: [], capacity: { guests: 2, beds: 1, bathrooms: 1 }, sizeM2: 40, floor: '', pricePerHour: 20, minBookingPrice: 40, cleaningFee: 20,
  otherCharges: [], minHours: 2, maxHours: 8, bufferMins: 60, petsAllowed: false, childrenAllowed: true, rules: [], checkout: [], checkinInstructions: '', availability: [],
  ownerWindows: [{ days: [0, 1, 2, 3, 4, 5, 6], start: '08:00', end: '20:00' }], overnight: { enabled: false, channel: 'Airbnb', checkin: '16:00', checkout: '11:00', nightlyRate: 140, channelFeePct: 15 },
  instantBook: true, managerId: null, cleaningProviderId: null, cleaningNotes: '',
  compliance: { usage: 'tourist_furnished', registrationNumber: '', changeOfUse: 'unknown', changeOfUseRef: '', ownerAuthorised: false, buildingAllowsDaytime: 'unknown', buildingNotes: '', insurer: '', insurancePolicy: '', insuranceCoversDaytime: false, dpeGrade: '', restrictions: '', documents: [], attestation: false },
  delegation: { availability: true, pricing: true, priceFloor: 0, approveBookings: true, cleaning: true, messaging: true, mgmtFeePct: 20 },
});

/** Pre-filled example so the live demo is quick — every field remains editable. */
const SAMPLE = (): Partial<Draft> => ({
  title: 'Bright family apartment near Gare de Lyon', shortTitle: 'Family apartment · Gare de Lyon', type: 'serviced',
  address: '27 rue de Lyon, 75012 Paris', neighbourhood: 'Gare de Lyon', arrondissement: '12e', lat: 48.8486, lng: 2.3709,
  description: 'A calm two-bedroom serviced apartment four minutes from Gare de Lyon. Made for families in transit: a rain shower and bathtub, two real beds behind blackout blinds, a travel cot, toys and a kitchen for snacks. Leave your luggage, freshen up and rest before your hotel check-in.',
  highlights: ['4 min walk from Gare de Lyon', 'Shower, bathtub & two bedrooms', 'Travel cot, high chair and toys'],
  amenities: ['wifi', 'shower', 'bathtub', 'towels', 'bed', 'sofa', 'kitchen', 'coffee', 'crib', 'high_chair', 'toys', 'luggage', 'blackout', 'heating', 'elevator', 'desk'],
  accessibility: ['elevator'], activities: ['rest', 'layover', 'family', 'relax', 'work'], capacity: { guests: 5, beds: 2, bathrooms: 1 }, sizeM2: 64, floor: '3rd floor (lift)',
  petsAllowed: false, childrenAllowed: true, rules: ['No parties or events', 'No smoking', 'Children supervised at all times'],
  checkout: ['Put used towels in the bathtub', 'Close windows and switch off lights', 'Leave the key in the key box'],
  checkinInstructions: 'Enter the door code at 27 rue de Lyon, take the lift to the 3rd floor (door on the left) and use the same code on the key box.',
  pricePerHour: 24, minBookingPrice: 48, cleaningFee: 22, minHours: 2, maxHours: 8, bufferMins: 60, instantBook: true,
  ownerWindows: [{ days: [0, 1, 2, 3, 4, 5, 6], start: '08:00', end: '20:00' }],
  overnight: { enabled: true, channel: 'Airbnb', checkin: '17:00', checkout: '11:00', nightlyRate: 155, channelFeePct: 15 },
});

export default function ListingWizard() {
  const t = useT();
  const nav = useNavigate();
  const { id: editId } = useParams();
  const user = useStore((s) => s.user)!;
  const file = (user as unknown as { operatorFile?: OperatorFile }).operatorFile;
  const { data: managers } = useApi<Manager[]>('/api/owner/managers');
  const { data: existing } = useApi<{ property: Property }>(editId ? `/api/owner/properties/${editId}` : null);
  const [d, setD] = useState<Draft>(empty);
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');
  const [result, setResult] = useState<Property | null>(null);
  const [stays, setStays] = useState<number | null>(null);
  const loaded = useRef(false);
  useEffect(() => { if (existing && !loaded.current) { loaded.current = true; setD({ ...empty(), ...existing.property }); } }, [existing]);
  const set = (patch: Partial<Draft>) => setD((x) => ({ ...x, ...patch }));
  const setC = (patch: Partial<Draft['compliance']>) => setD((x) => ({ ...x, compliance: { ...x.compliance, ...patch } }));

  const persist = async (): Promise<string> => {
    const body = { ...d, shortTitle: d.shortTitle || (d.title && d.neighbourhood ? `${d.title.split(' ').slice(0, 3).join(' ')} · ${d.neighbourhood}` : d.title) };
    if (d.id) { await api(`/api/owner/properties/${d.id}`, { method: 'PUT', body }); return d.id; }
    const p = await api<Property>('/api/owner/properties', { body });
    set({ id: p.id });
    return p.id;
  };
  const next = async () => {
    setErr('');
    setSaving(true);
    try { await persist(); setStep((s) => s + 1); document.getElementById('wiz-scroll')?.scrollTo(0, 0); }
    catch (e) { setErr(e instanceof Error ? t(e.message) : 'Error'); }
    finally { setSaving(false); }
  };
  const submit = async () => {
    setErr('');
    setSaving(true);
    try { const pid = await persist(); const p = await api<Property>(`/api/owner/properties/${pid}/submit`, { body: {} }); setResult(p); }
    catch (e) { setErr(e instanceof Error ? t(e.message) : 'Error'); }
    finally { setSaving(false); }
  };
  const publish = async () => {
    if (!result) return;
    setSaving(true);
    try { const p = await api<Property>(`/api/owner/properties/${result.id}/publish`, { body: {} }); setResult(p); }
    catch (e) { setErr(e instanceof Error ? t(e.message) : 'Error'); }
    finally { setSaving(false); }
  };

  const canNext = [
    !!d.title.trim() && !!d.address.trim() && !!d.neighbourhood,
    d.images.length >= 1,
    true,
    d.activities.length > 0,
    d.pricePerHour > 0 && d.ownerWindows.length > 0,
    true,
    !!d.managerId,
    d.compliance.attestation,
  ][step];

  const HINTS = ['Add a property name, street address and neighbourhood to continue.', 'Add at least one photo to continue.', '', 'Choose at least one permitted use to continue.', 'Set an hourly price and at least one daytime window to continue.', '', 'Choose who will manage this property to continue.', 'Tick the confirmation to submit.'];
  const stageIdx = STAGES.findIndex((g) => g.steps.includes(step));
  const stage = STAGES[stageIdx];
  if (result) return <SubmitResult p={result} busy={saving} onPublish={publish} onDone={() => nav(`/owner/property/${result.id}`)} err={err} />;

  return (
    <div className="relative flex flex-1 flex-col overflow-hidden">
      <header className="bg-ink px-4 pb-3 pt-[max(env(safe-area-inset-top),14px)] text-white">
        <div className="flex items-center gap-3">
          <button className="grid h-10 w-10 place-items-center rounded-full bg-white/10" aria-label={t('Back')} onClick={() => (step ? setStep(step - 1) : nav('/owner'))}><ChevronLeft size={20} /></button>
          <div className="min-w-0 flex-1">
            <div className="text-[12px] font-semibold text-lavender">{t('Stage {a} of {b}', { a: stageIdx + 1, b: STAGES.length })} · {t(stage.title)}</div>
            <div className="truncate text-[18px] font-bold">{t(STEPS[step])}{stage.steps.length > 1 && <span className="ml-1.5 text-[13px] font-semibold text-ice-200">{t('({a} of {b})', { a: stage.steps.indexOf(step) + 1, b: stage.steps.length })}</span>}</div>
          </div>
          {step === 0 && !d.title && <button onClick={() => set(SAMPLE())} className="inline-flex min-h-[40px] shrink-0 items-center gap-1 rounded-lg bg-white/10 px-2.5 py-1.5 text-[12.5px] font-semibold"><Wand2 size={14} /> {t('Sample details')}</button>}
        </div>
        <div className="mt-3 grid grid-cols-4 gap-1.5" aria-hidden>
          {STAGES.map((g, gi) => {
            const done = gi < stageIdx ? 1 : gi > stageIdx ? 0 : (g.steps.indexOf(step) + 1) / g.steps.length;
            return <div key={g.title} className="h-1.5 overflow-hidden rounded-full bg-white/15"><div className="h-full rounded-full bg-electric transition-all" style={{ width: `${done * 100}%` }} /></div>;
          })}
        </div>
        {d.id && <div className="mt-2 text-[12px] text-ice-200">{t('Draft saved automatically when you continue — you can come back to it from Listings.')}</div>}
      </header>

      <div id="wiz-scroll" className="flex-1 overflow-y-auto px-4 pb-40 pt-4">
        <div className="space-y-5 animate-fade-up" key={step}>
          {step === 0 && <>
            <F req label={t('Property name')}><input className="input" value={d.title} onChange={(e) => set({ title: e.target.value })} placeholder={t('e.g. Bright family apartment near Gare de Lyon')} /></F>
            <F label={t('Category')}><div className="flex flex-wrap gap-2">{(Object.keys(PROPERTY_TYPES) as PropertyType[]).map((k) => { const T = PROPERTY_TYPES[k]; return <Chip key={k} on={d.type === k} onClick={() => set({ type: k })} icon={<T.icon size={14} />}>{t(T.label)}</Chip>; })}</div></F>
            <F label={t('Find the location')} hint={t('Pins the map and neighbourhood. Guests only see the exact address after booking.')}>
              <PlaceSearch value={d.neighbourhood} onPick={(p) => { const arr = /(\d{1,2}(?:e|er))\b/.exec(p.sub ?? '')?.[1] ?? /750(\d{2})/.exec(p.sub ?? p.label)?.[1]?.replace(/^0/, '') ?? ''; set({ lat: p.lat, lng: p.lng, neighbourhood: p.kind === 'address' ? (p.sub?.split(',')[0] ?? p.label) : p.label.replace(/^Paris /, ''), arrondissement: /^\d+$/.test(arr) ? `${arr}e` : arr, address: d.address || (p.kind === 'address' ? `${p.label}, Paris` : d.address) }); }} />
            </F>
            <F req label={t('Street address')}><input className="input" value={d.address} onChange={(e) => set({ address: e.target.value })} placeholder="27 rue de Lyon, 75012 Paris" /></F>
            <div className="grid grid-cols-2 gap-3"><F req label={t('Neighbourhood')}><input className="input" value={d.neighbourhood} onChange={(e) => set({ neighbourhood: e.target.value })} /></F><F label={t('Arrondissement')}><input className="input" value={d.arrondissement} onChange={(e) => set({ arrondissement: e.target.value })} placeholder="12e" /></F></div>
            <F label={t('Description')}><textarea rows={5} className="input resize-none" value={d.description} onChange={(e) => set({ description: e.target.value })} placeholder={t('What makes the space good for a few hours?')} /></F>
            <div className="card divide-y divide-ivory-200 px-4">
              <Stepper label={t('Maximum guests')} value={d.capacity.guests} min={1} max={20} onChange={(guests) => set({ capacity: { ...d.capacity, guests } })} />
              <Stepper label={t('Beds')} value={d.capacity.beds} max={10} onChange={(beds) => set({ capacity: { ...d.capacity, beds } })} />
              <Stepper label={t('Bathrooms')} value={d.capacity.bathrooms} min={1} max={5} onChange={(bathrooms) => set({ capacity: { ...d.capacity, bathrooms } })} />
            </div>
            <div className="grid grid-cols-2 gap-3"><F label={t('Size (m²)')}><input type="number" className="input" value={d.sizeM2} onChange={(e) => set({ sizeM2: +e.target.value })} /></F><F label={t('Floor / access')}><input className="input" value={d.floor} onChange={(e) => set({ floor: e.target.value })} placeholder={t('3rd floor (lift)')} /></F></div>
          </>}

          {step === 1 && <PhotoStep images={d.images} onChange={(images) => set({ images })} />}

          {step === 2 && <>
            <F label={t('Amenities')}><div className="grid grid-cols-2 gap-2">{KEY_AMENITIES.map((a) => { const A = AMENITIES[a]; const on = d.amenities.includes(a); return <button key={a} onClick={() => set({ amenities: on ? d.amenities.filter((x) => x !== a) : [...d.amenities, a] })} className={`flex items-center gap-2 rounded-lg border px-3 py-2.5 text-left text-[13px] font-semibold ${on ? 'border-ink bg-ink text-white' : 'border-ivory-300 bg-white text-ink'}`}><A.icon size={16} /> {t(A.label)}</button>; })}</div></F>
            <F label={t('Accessibility features')}><div className="flex flex-wrap gap-2">{(Object.keys(ACCESSIBILITY) as Accessibility[]).map((a) => { const A = ACCESSIBILITY[a]; return <Chip key={a} on={d.accessibility.includes(a)} onClick={() => set({ accessibility: d.accessibility.includes(a) ? d.accessibility.filter((x) => x !== a) : [...d.accessibility, a] })} icon={<A.icon size={14} />}>{t(A.label)}</Chip>; })}</div></F>
          </>}

          {step === 3 && <>
            <F req label={t('Permitted activities')} hint={t('Guests will only find this space for the uses you authorise.')}>
              <div className="grid grid-cols-2 gap-2">{(Object.keys(ACTIVITIES) as Activity[]).map((a) => { const A = ACTIVITIES[a]; const on = d.activities.includes(a); const outOfScope = file && !file.permittedUses.includes(a); return (
                <button key={a} onClick={() => set({ activities: on ? d.activities.filter((x) => x !== a) : [...d.activities, a] })} className={`relative flex items-center gap-2 rounded-lg border px-3 py-2.5 text-left text-[13px] font-semibold ${on ? 'border-electric bg-electric-50 text-ink' : 'border-ivory-300 bg-white text-ink'}`}>
                  <A.icon size={16} className="text-electric" /> {t(A.label)}{outOfScope && <span className="ml-auto rounded bg-amber-50 px-1 text-[9.5px] font-bold uppercase text-amber-700">{t('review')}</span>}{on && <Check size={14} className="ml-auto text-electric" />}
                </button>
              ); })}</div>
              {file && d.activities.some((a) => !file.permittedUses.includes(a)) && <p className="mt-2 text-[12px] text-amber-700">{t('Gatherings, BBQs and rehearsals aren’t covered by your verified file — the listing will go to a human compliance reviewer.')}</p>}
            </F>
            <div className="card divide-y divide-ivory-200 px-4">
              <Row label={t('Children allowed')}><Toggle label="children" checked={d.childrenAllowed} onChange={(childrenAllowed) => set({ childrenAllowed })} /></Row>
              <Row label={t('Pets allowed')}><Toggle label="pets" checked={d.petsAllowed} onChange={(petsAllowed) => set({ petsAllowed })} /></Row>
            </div>
            <ListEditor label={t('House rules')} items={d.rules} suggestions={RULE_SUGGESTIONS} onChange={(rules) => set({ rules })} />
            <ListEditor label={t('Checkout instructions')} items={d.checkout} suggestions={['Put used towels in the bathtub', 'Close windows and switch off lights', 'Leave the key in the key box']} onChange={(checkout) => set({ checkout })} />
          </>}

          {step === 4 && <>
            <F req label={t('When may guests use the space during the day?')} hint={t('Your manager can only open bookable slots inside these hours.')}>
              <WindowsEditor value={d.ownerWindows} onChange={(ownerWindows) => set({ ownerWindows })} />
            </F>
            <div className="card divide-y divide-ivory-200 px-4">
              <Stepper label={t('Minimum duration (h)')} value={d.minHours} min={1} max={d.maxHours} onChange={(minHours) => set({ minHours })} />
              <Stepper label={t('Maximum duration (h)')} value={d.maxHours} min={d.minHours} max={12} onChange={(maxHours) => set({ maxHours })} />
              <Stepper label={t('Cleaning buffer (min)')} sub={t('Between bookings, for turnover')} value={d.bufferMins} min={15} max={180} onChange={(v) => set({ bufferMins: Math.round(v / 15) * 15 })} />
            </div>
            <div className="card p-4">
              <Row label={t('Also let overnight (Airbnb, Booking.com…)')}><Toggle label="overnight" checked={d.overnight.enabled} onChange={(enabled) => set({ overnight: { ...d.overnight, enabled } })} /></Row>
              {d.overnight.enabled && <div className="mt-3 space-y-3">
                <Segmented value={d.overnight.channel || 'Airbnb'} onChange={(channel) => set({ overnight: { ...d.overnight, channel } })} options={[{ value: 'Airbnb', label: 'Airbnb' }, { value: 'Booking.com', label: 'Booking.com' }, { value: 'Direct', label: t('Direct') }]} />
                <div className="grid grid-cols-2 gap-2"><F label={t('Check-in')}><input type="time" className="input py-2.5" value={d.overnight.checkin} onChange={(e) => set({ overnight: { ...d.overnight, checkin: e.target.value } })} /></F><F label={t('Check-out')}><input type="time" className="input py-2.5" value={d.overnight.checkout} onChange={(e) => set({ overnight: { ...d.overnight, checkout: e.target.value } })} /></F></div><F label={t('€ / night')}><input type="number" className="input py-2.5" value={d.overnight.nightlyRate} onChange={(e) => set({ overnight: { ...d.overnight, nightlyRate: +e.target.value } })} /></F>
                <button className="btn-soft w-full py-2.5 text-[13px]" onClick={async () => { const pid = await persist(); const out = await api<{ stays: unknown[] }>(`/api/owner/properties/${pid}/import-calendar`, { body: {} }); setStays(out.stays.length); }}><CalendarDays size={15} /> {t('Import overnight calendar (sample iCal feed)')}</button>
                {stays !== null && <p className="text-[12.5px] font-semibold text-emerald-700">{t('{n} overnight stays imported — daytime windows will be planned around them.', { n: stays })}</p>}
              </div>}
            </div>
            <div className="card space-y-3 p-4">
              <div className="grid grid-cols-3 gap-2">
                <F req label={t('€ / hour')}><input type="number" className="input py-2.5" value={d.pricePerHour} onChange={(e) => set({ pricePerHour: +e.target.value })} /></F>
                <F label={t('Min. booking €')}><input type="number" className="input py-2.5" value={d.minBookingPrice} onChange={(e) => set({ minBookingPrice: +e.target.value })} /></F>
                <F label={t('Cleaning €')}><input type="number" className="input py-2.5" value={d.cleaningFee} onChange={(e) => set({ cleaningFee: +e.target.value })} /></F>
              </div>
              <ChargesEditor value={d.otherCharges} onChange={(otherCharges) => set({ otherCharges })} />
              <div className="rounded-lg bg-ivory-50 p-3"><div className="mb-2 text-[12px] font-bold text-ink-500">{t('Example: a 4-hour booking')}</div><FinanceBreakdown e={calcEconomics(d, 4)} compact /><div className="mt-2 text-[12px] text-ink-500">{t('Guest pays {x}', { x: eur(calcEconomics(d, 4).guestTotal) })}</div></div>
            </div>
          </>}

          {step === 5 && <ComplianceStep d={d} setC={setC} file={file} />}

          {step === 6 && <>
            <F req label={t('Assign a Space Manager')} hint={t('Your property manager runs daytime availability, guests and cleaning for you.')}>
              <div className="space-y-2">{(managers ?? []).map((m) => (
                <button key={m.id} onClick={() => set({ managerId: m.id })} className={`flex w-full items-center gap-3 rounded-xl border p-3 text-left ${d.managerId === m.id ? 'border-electric bg-electric-50' : 'border-ivory-300 bg-white'}`}>
                  <Avatar name={m.name} src={m.avatarUrl || undefined} size={42} />
                  <div className="min-w-0 flex-1"><div className="text-[14.5px] font-bold">{m.name}</div><div className="text-[12px] text-ink-500">{m.company} · {t('{n} properties on SpaceTime', { n: m.properties })}</div></div>
                  {d.managerId === m.id && <Check size={18} className="text-electric" />}
                </button>
              ))}</div>
            </F>
            <F label={t('Delegated authority')}>
              <div className="card divide-y divide-ivory-200 px-4">
                {(['availability', 'pricing', 'approveBookings', 'cleaning', 'messaging'] as const).map((k) => <Row key={k} label={t({ availability: 'Open & block daytime slots', pricing: 'Adjust pricing & durations', approveBookings: 'Approve booking requests', cleaning: 'Coordinate cleaning', messaging: 'Message guests' }[k])}><Toggle label={k} checked={d.delegation[k]} onChange={(v) => set({ delegation: { ...d.delegation, [k]: v } })} /></Row>)}
              </div>
            </F>
            <div className="grid grid-cols-2 gap-3">
              <F label={t('Management fee %')}><input type="number" className="input" value={d.delegation.mgmtFeePct} onChange={(e) => set({ delegation: { ...d.delegation, mgmtFeePct: +e.target.value } })} /></F>
              <F label={t('Price floor €/h')}><input type="number" className="input" value={d.delegation.priceFloor} onChange={(e) => set({ delegation: { ...d.delegation, priceFloor: +e.target.value } })} /></F>
            </div>
            <div className="card px-4"><Row label={t('Instant booking (no approval needed)')}><Toggle label="instant" checked={d.instantBook} onChange={(instantBook) => set({ instantBook })} /></Row></div>
            <F label={t('Cleaning arrangements')}><textarea rows={2} className="input resize-none" value={d.cleaningNotes ?? ''} onChange={(e) => set({ cleaningNotes: e.target.value })} placeholder={t("Use the manager's usual cleaning provider; linen in the hall cupboard.")} /></F>
            <F label={t('Check-in instructions')}><textarea rows={3} className="input resize-none" value={d.checkinInstructions} onChange={(e) => set({ checkinInstructions: e.target.value })} /></F>
          </>}

          {step === 7 && <>
            <div className="card overflow-hidden">{d.images[0] && <Img src={d.images[0]} alt="" className="h-36 w-full" />}<div className="p-4"><div className="text-[17px] font-bold">{d.title}</div><div className="text-[12.5px] text-ink-500">{d.address}</div><div className="mt-2 flex flex-wrap gap-1.5">{d.activities.map((a) => <span key={a} className="rounded-md bg-ice-100 px-2 py-0.5 text-[12.5px] font-semibold">{t(ACTIVITIES[a].label)}</span>)}</div></div></div>
            <Summary label={t('Capacity')} value={`${d.capacity.guests} · ${d.capacity.beds} ${t('beds')} · ${d.capacity.bathrooms} ${t('bath')}`} />
            <Summary label={t('Pricing')} value={`${eur(d.pricePerHour)}/h · ${t('min')} ${eur(d.minBookingPrice)} · ${t('cleaning')} ${eur(d.cleaningFee)}`} />
            <Summary label={t('Daytime hours')} value={d.ownerWindows.map((w) => `${w.days.length === 7 ? t('Every day') : w.days.length + ' ' + t('days')} ${w.start}–${w.end}`).join(' · ')} />
            <Summary label={t('Manager')} value={(managers ?? []).find((m) => m.id === d.managerId)?.name ?? '—'} />
            <Summary label={t('Compliance documents')} value={`${d.compliance.documents.length} ${t('attached')}${d.compliance.documents.every((x) => x.source === 'on_file') && d.compliance.documents.length ? ` · ${t('all from your verified file')}` : ''}`} />
            <label className="card flex cursor-pointer items-start gap-3 p-4"><input type="checkbox" className="mt-1 h-5 w-5 accent-electric" checked={d.compliance.attestation} onChange={(e) => setC({ attestation: e.target.checked })} /><span className="text-[13px] text-ink-700">{t('I confirm the information is accurate and that daytime use of this property for the activities listed is authorised.')}</span></label>
            <PreviewNote>{t('SpaceTime checks completeness automatically. Approval relies on documents verified by SpaceTime Compliance or a human review — software never certifies legality on its own.')}</PreviewNote>
          </>}
          {err && <p className="rounded-lg bg-rose-50 px-3 py-2 text-[13px] font-semibold text-rose-700">{err}</p>}
        </div>
      </div>

      <div className="absolute inset-x-0 bottom-0 border-t border-ivory-200 bg-white px-4 py-3 pb-[max(env(safe-area-inset-bottom),12px)]">
        {!canNext && HINTS[step] && <p className="mb-2 text-center text-[13px] text-ink-500">{t(HINTS[step])}</p>}
        {step < STEPS.length - 1
          ? <button className="btn-primary w-full py-4" disabled={!canNext || saving} onClick={next}>{saving ? <Loader2 size={17} className="animate-spin" /> : null}{t('Save & continue')}</button>
          : <button className="btn-accent w-full py-4" disabled={!canNext || saving} onClick={submit}>{saving ? <Loader2 size={17} className="animate-spin" /> : <Rocket size={17} />} {t('Submit for review')}</button>}
      </div>
    </div>
  );
}

function SubmitResult({ p, busy, onPublish, onDone, err }: { p: Property; busy: boolean; onPublish: () => void; onDone: () => void; err: string }) {
  const t = useT();
  const published = p.status === 'published';
  const approved = p.status === 'approved' || published;
  return (
    <div className="relative flex flex-1 flex-col items-center justify-center overflow-hidden bg-ink px-6 text-center text-white">
      <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-electric/40 blur-3xl" />
      <div className="relative grid h-16 w-16 place-items-center rounded-2xl bg-electric animate-pop" style={{ transform: 'skewX(-8deg)' }}>{published ? <Rocket size={30} /> : approved ? <BadgeCheck size={32} /> : <Sparkles size={30} />}</div>
      <h1 className="relative mt-5 text-[26px] font-bold">{published ? t('Your space is live') : approved ? t('Approved — ready to publish') : t('Submitted for review')}</h1>
      <p className="relative mt-2 max-w-[320px] text-[14px] text-ice-200">{published ? t('{m} has been notified and can now open daytime windows for guests.', { m: p.managerName ?? t('Your manager') }) : approved ? t('All documents match your verified compliance file ({by}).', { by: p.compliance.review?.reviewer ?? '' }) : t('A compliance reviewer will check your documents. We’ll notify you as soon as it’s approved.')}</p>
      {err && <p className="relative mt-3 text-[13px] text-rose-300">{err}</p>}
      <div className="relative mt-8 w-full space-y-2">
        {approved && !published && <button className="btn w-full bg-electric py-4 text-white" disabled={busy} onClick={onPublish}><Rocket size={17} /> {t('Publish now')}</button>}
        <button className="btn w-full bg-white/10 py-3.5 text-white" onClick={onDone}>{t('View listing status')}</button>
      </div>
    </div>
  );
}

function PhotoStep({ images, onChange }: { images: string[]; onChange: (v: string[]) => void }) {
  const t = useT();
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(0);
  const add = async (files: FileList | null) => {
    if (!files) return;
    const list = Array.from(files).slice(0, 10);
    setBusy(list.length);
    const urls: string[] = [];
    for (const f of list) { try { urls.push(await uploadImage(f)); } catch { /* skip */ } setBusy((n) => n - 1); }
    onChange([...images, ...urls]);
  };
  return (
    <div className="space-y-5">
      <button onClick={() => ref.current?.click()} className="flex w-full flex-col items-center gap-2 rounded-2xl border-2 border-dashed border-electric-400 bg-ice-50 py-8 text-electric-700">
        {busy ? <Loader2 size={28} className="animate-spin" /> : <Upload size={28} />}
        <span className="text-[15px] font-bold">{busy ? t('Uploading {n}…', { n: busy }) : t('Upload photos from this device')}</span>
        <span className="text-[12px] text-ink-500">{t('Camera roll or files · resized automatically')}</span>
      </button>
      <input ref={ref} type="file" accept="image/*" multiple className="hidden" onChange={(e) => add(e.target.files)} />
      {images.length > 0 && <div><div className="label">{t('Your photos ({n}) — first is the cover', { n: images.length })}</div><div className="grid grid-cols-3 gap-2">{images.map((src, i) => (
        <div key={src + i} className="relative"><Img src={src} alt="" className="aspect-square w-full rounded-lg" />{i === 0 && <span className="absolute left-1 top-1 rounded bg-ink px-1.5 text-[10px] font-bold text-white">{t('Cover')}</span>}<button aria-label={t('Remove')} onClick={() => onChange(images.filter((_, j) => j !== i))} className="absolute right-1 top-1 grid h-6 w-6 place-items-center rounded-full bg-white/90"><X size={13} /></button></div>
      ))}</div></div>}
      <div><div className="label flex items-center gap-1"><ImagePlus size={12} /> {t('Or pick from the sample library')}</div><div className="grid grid-cols-4 gap-2">{SAMPLE_PHOTOS.map((s) => { const on = images.includes(s.url); return <button key={s.url} onClick={() => onChange(on ? images.filter((x) => x !== s.url) : [...images, s.url])} className={`relative overflow-hidden rounded-lg ring-2 ${on ? 'ring-electric' : 'ring-transparent'}`}><Img src={s.url.replace('w=1200', 'w=300')} alt={s.tag} className="aspect-square w-full" />{on && <span className="absolute right-1 top-1 grid h-5 w-5 place-items-center rounded-full bg-electric text-white"><Check size={12} /></span>}</button>; })}</div></div>
    </div>
  );
}

function ComplianceStep({ d, setC, file }: { d: Draft; setC: (p: Partial<Draft['compliance']>) => void; file?: OperatorFile }) {
  const t = useT();
  const c = d.compliance;
  const ref = useRef<HTMLInputElement>(null);
  const [docType, setDocType] = useState<ComplianceDoc['type']>('registration');
  const [uploading, setUploading] = useState(false);
  const useFile = () => file && setC({
    usage: 'tourist_furnished', registrationNumber: file.registrationScope, changeOfUse: 'granted', changeOfUseRef: 'CU-2024-0412', ownerAuthorised: true, buildingAllowsDaytime: 'yes',
    insurer: 'AXA France', insurancePolicy: '4410 7782', insuranceCoversDaytime: true, dpeGrade: 'C', documents: file.documents,
  });
  const upload = async (f?: File) => {
    if (!f) return;
    setUploading(true);
    try { const url = await uploadFile(f); setC({ documents: [...c.documents, { id: `up_${Date.now()}`, type: docType, name: f.name, url, source: 'upload' }] }); } finally { setUploading(false); }
  };
  const DOC_TYPES: [ComplianceDoc['type'], string][] = [['registration', 'Registration'], ['change_of_use', 'Change of use'], ['owner_authorisation', 'Owner authorisation'], ['building_rules', 'Building rules'], ['insurance', 'Insurance'], ['dpe', 'Energy rating (DPE)'], ['other', 'Other']];
  return (
    <div className="space-y-5">
      <p className="text-[13px] leading-relaxed text-ink-600">{t('Daytime rentals are not exempt from France’s short-term rental rules (including the Le Meur law). Provide the documents that apply to this property.')}</p>
      {file && <button onClick={useFile} className="clip-corner flex w-full items-center gap-3 bg-ink p-4 text-left text-white"><BadgeCheck size={22} className="text-emerald-400" /><span className="flex-1"><span className="block text-[14.5px] font-bold">{t('Use my verified compliance file')}</span><span className="block text-[12px] text-ice-200">{file.company} · {t('{n} documents verified', { n: file.documents.length })}</span></span></button>}
      <F label={t('Authorised use')}><select className="input" value={c.usage} onChange={(e) => setC({ usage: e.target.value as Draft['compliance']['usage'] })}>{[['tourist_furnished', 'Furnished tourist accommodation'], ['serviced_apartment', 'Serviced apartment'], ['aparthotel', 'Aparthotel'], ['commercial', 'Commercial premises'], ['residential_other', 'Other residential']].map(([v, l]) => <option key={v} value={v}>{t(l)}</option>)}</select></F>
      <F label={t('Registration number')}><input className="input" value={c.registrationNumber} onChange={(e) => setC({ registrationNumber: e.target.value })} placeholder="75112 000 123 AB" /></F>
      <div className="grid grid-cols-2 gap-3">
        <F label={t('Change of use')}><select className="input" value={c.changeOfUse} onChange={(e) => setC({ changeOfUse: e.target.value as Draft['compliance']['changeOfUse'] })}>{[['granted', 'Granted'], ['not_required', 'Not required'], ['pending', 'Pending'], ['unknown', 'Unknown']].map(([v, l]) => <option key={v} value={v}>{t(l)}</option>)}</select></F>
        <F label={t('Reference')}><input className="input" value={c.changeOfUseRef} onChange={(e) => setC({ changeOfUseRef: e.target.value })} /></F>
      </div>
      <F label={t('Building rules allow daytime use?')}><Segmented value={c.buildingAllowsDaytime} onChange={(v) => setC({ buildingAllowsDaytime: v })} options={[{ value: 'yes', label: t('Yes') }, { value: 'no', label: t('No') }, { value: 'unknown', label: t('Not sure') }]} /></F>
      <div className="grid grid-cols-2 gap-3"><F label={t('Insurer')}><input className="input" value={c.insurer} onChange={(e) => setC({ insurer: e.target.value })} /></F><F label={t('Policy number')}><input className="input" value={c.insurancePolicy} onChange={(e) => setC({ insurancePolicy: e.target.value })} /></F></div>
      <div className="card divide-y divide-ivory-200 px-4">
        <Row label={t('Insurance covers daytime guest use')}><Toggle label="ins" checked={c.insuranceCoversDaytime} onChange={(insuranceCoversDaytime) => setC({ insuranceCoversDaytime })} /></Row>
        <Row label={t('I own or am authorised to let this property')}><Toggle label="own" checked={c.ownerAuthorised} onChange={(ownerAuthorised) => setC({ ownerAuthorised })} /></Row>
      </div>
      <F label={t('Energy rating (DPE)')}><div className="flex gap-1.5">{['A', 'B', 'C', 'D', 'E', 'F', 'G'].map((g) => <button key={g} onClick={() => setC({ dpeGrade: g })} className={`h-10 flex-1 rounded-lg text-[14px] font-bold ${c.dpeGrade === g ? 'bg-ink text-white' : 'bg-white text-ink ring-1 ring-ivory-300'}`}>{g}</button>)}</div></F>
      <F label={t('Restrictions on use')}><textarea rows={2} className="input resize-none" value={c.restrictions} onChange={(e) => setC({ restrictions: e.target.value })} placeholder={t('e.g. no amplified music; building quiet hours 22:00–08:00')} /></F>
      <F label={t('Supporting documents')}>
        <div className="space-y-2">
          {c.documents.map((doc) => <div key={doc.id} className="flex items-center gap-2 rounded-lg bg-white p-2.5 text-[12.5px] shadow-card">{doc.source === 'on_file' ? <BadgeCheck size={16} className="shrink-0 text-emerald-600" /> : <FileUp size={16} className="shrink-0 text-electric" />}<span className="min-w-0 flex-1"><span className="block truncate font-semibold">{doc.name}</span><span className="text-[11px] text-ink-500">{doc.source === 'on_file' ? t('Verified file') : t('Uploaded — needs review')}</span></span><button aria-label={t('Remove')} onClick={() => setC({ documents: c.documents.filter((x) => x.id !== doc.id) })}><Trash2 size={15} className="text-ink-500" /></button></div>)}
          <div className="flex gap-2"><select className="input flex-1 py-2.5 text-[13px]" value={docType} onChange={(e) => setDocType(e.target.value as ComplianceDoc['type'])}>{DOC_TYPES.map(([v, l]) => <option key={v} value={v}>{t(l)}</option>)}</select><button className="btn-soft px-3 py-2.5 text-[13px]" onClick={() => ref.current?.click()}>{uploading ? <Loader2 size={15} className="animate-spin" /> : <Upload size={15} />} {t('Upload')}</button></div>
          <input ref={ref} type="file" accept="application/pdf,image/*" className="hidden" onChange={(e) => upload(e.target.files?.[0])} />
        </div>
      </F>
    </div>
  );
}

function WindowsEditor({ value, onChange }: { value: WeeklyWindow[]; onChange: (v: WeeklyWindow[]) => void }) {
  const t = useT();
  const w = value[0] ?? { days: [], start: '08:00', end: '20:00' };
  const set = (patch: Partial<WeeklyWindow>) => onChange([{ ...w, ...patch }]);
  const names = (d: number) => new Date(2026, 0, 4 + d).toLocaleDateString(document.documentElement.lang === 'fr' ? 'fr-FR' : 'en-GB', { weekday: 'short' });
  return (
    <div className="card space-y-3 p-4">
      <div className="flex gap-1.5">{DAYS.map((d) => <button key={d} onClick={() => set({ days: w.days.includes(d) ? w.days.filter((x) => x !== d) : [...w.days, d] })} className={`h-10 flex-1 rounded-lg text-[12px] font-bold capitalize ${w.days.includes(d) ? 'bg-ink text-white' : 'bg-ivory-100 text-ink-500'}`}>{names(d).slice(0, 2)}</button>)}</div>
      <div className="grid grid-cols-2 gap-3"><F label={t('From')}><input type="time" className="input py-2.5" value={w.start} onChange={(e) => set({ start: e.target.value })} /></F><F label={t('Until')}><input type="time" className="input py-2.5" value={w.end} onChange={(e) => set({ end: e.target.value })} /></F></div>
    </div>
  );
}

function ListEditor({ label, items, suggestions, onChange }: { label: string; items: string[]; suggestions: string[]; onChange: (v: string[]) => void }) {
  const t = useT();
  const [v, setV] = useState('');
  return (
    <F label={label}>
      <div className="space-y-2">
        {items.map((r, i) => <div key={i} className="flex items-center gap-2 rounded-lg bg-white px-3 py-2 text-[13px] shadow-card"><span className="flex-1">{r}</span><button aria-label={t('Remove')} onClick={() => onChange(items.filter((_, j) => j !== i))}><X size={15} className="text-ink-500" /></button></div>)}
        <div className="flex flex-wrap gap-1.5">{suggestions.filter((s) => !items.includes(s)).map((s) => <button key={s} onClick={() => onChange([...items, s])} className="chip-off py-1.5 text-[12px]"><Plus size={12} /> {t(s)}</button>)}</div>
        <form onSubmit={(e) => { e.preventDefault(); if (v.trim()) { onChange([...items, v.trim()]); setV(''); } }} className="flex gap-2"><input className="input flex-1 py-2.5" value={v} onChange={(e) => setV(e.target.value)} placeholder={t('Add your own…')} /><button className="btn-soft px-3 py-2.5"><Plus size={16} /></button></form>
      </div>
    </F>
  );
}

function ChargesEditor({ value, onChange }: { value: { label: string; amount: number }[]; onChange: (v: { label: string; amount: number }[]) => void }) {
  const t = useT();
  return (
    <div>
      <div className="label">{t('Other disclosed charges')}</div>
      {value.map((c, i) => <div key={i} className="mb-2 flex gap-2"><input className="input flex-1 py-2.5" value={c.label} onChange={(e) => onChange(value.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)))} /><input type="number" className="input w-24 py-2.5" value={c.amount} onChange={(e) => onChange(value.map((x, j) => (j === i ? { ...x, amount: +e.target.value } : x)))} /><button aria-label={t('Remove')} onClick={() => onChange(value.filter((_, j) => j !== i))}><X size={16} /></button></div>)}
      <button onClick={() => onChange([...value, { label: t('Linen pack'), amount: 5 }])} className="text-[12.5px] font-semibold text-electric-600"><Plus size={12} className="inline" /> {t('Add a charge')}</button>
    </div>
  );
}

function F({ label, hint, children, req }: { label: string; hint?: string; children: ReactNode; req?: boolean }) {
  const t = useT();
  return <div><div className="label">{label}{req && <span className="ml-1 normal-case tracking-normal text-rose-600">· {t('required')}</span>}</div>{children}{hint && <p className="mt-1.5 text-[12.5px] leading-snug text-ink-500">{hint}</p>}</div>;
}
function Row({ label, children }: { label: string; children: ReactNode }) {
  return <div className="flex items-center justify-between gap-3 py-3"><span className="text-[14px] font-semibold text-ink">{label}</span>{children}</div>;
}
function Summary({ label, value }: { label: string; value: string }) {
  return <div className="flex items-start justify-between gap-3 rounded-lg bg-white px-4 py-3 text-[13px] shadow-card"><span className="text-ink-500">{label}</span><span className="text-right font-semibold">{value}</span></div>;
}
