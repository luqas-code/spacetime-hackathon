import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { BadgeCheck, CheckCircle2, Circle, Eye, MessageCircle, Pause, Pencil, Rocket, ShieldCheck, XCircle } from 'lucide-react';
import { api, useApi } from '@/lib/api';
import { FinanceBreakdown, ListingStatusPill, Panel, Spinner } from '@/components/dash';
import { Avatar, Chip, PageHeader, Sheet, StatusPill, Toggle } from '@/components/ui';
import { Img } from '@/components/Img';
import { TimelineAxis, TimelineBar, TimelineLegend } from '@/components/DayTimeline';
import { ACTIVITIES } from '@/data/vocab';
import { eur } from '@/lib/pricing';
import { dayLabel, nextDays } from '@/lib/time';
import { useStore } from '@/store/useStore';
import { useT } from '@/i18n';
import type { Activity, Booking, Delegation, Property, Stay } from '@/types';

const CHECK_LABEL: Record<string, string> = { usage: 'Usage type declared', registration: 'Registration number & certificate', change_of_use: 'Change-of-use authorisation', owner_authorisation: 'Owner authorisation', building: 'Building rules allow daytime use', insurance: 'Insurance covers daytime use', dpe: 'Energy rating (DPE) A–E', attestation: 'Owner attestation', manager: 'Manager assigned', photos: 'Photos', uses_in_verified_scope: 'Uses within verified scope' };

export default function OwnerProperty() {
  const t = useT();
  const { id } = useParams();
  const nav = useNavigate();
  const { data, reload } = useApi<{ property: Property; bookings: Booking[]; stays: Stay[] }>(`/api/owner/properties/${id}`);
  const [busy, setBusy] = useState(false);
  const [perm, setPerm] = useState(false);
  if (!data) return <div className="flex flex-1 flex-col"><PageHeader back="/owner/listings" title="…" /><Spinner /></div>;
  const p = data.property;
  const counted = data.bookings.filter((b) => b.status === 'confirmed' || b.status === 'completed');
  const sum = (k: keyof Booking['price']) => counted.reduce((s, b) => s + (b.price[k] as number), 0);
  const steps: [string, boolean][] = [['Draft', true], ['Submitted', p.status !== 'draft'], ['Approved', ['approved', 'published', 'paused'].includes(p.status)], ['Published', p.status === 'published']];
  const act = async (path: string) => {
    setBusy(true);
    try { await api(`/api/owner/properties/${p.id}/${path}`, { body: {} }); reload(); useStore.getState().showToast(path === 'publish' ? 'Listing published' : 'Listing paused'); }
    catch (e) { useStore.getState().showToast(e instanceof Error ? e.message : 'Error', undefined, 'error'); }
    finally { setBusy(false); }
  };
  const messageManager = async () => { const c = await api<{ id: string }>('/api/conversations', { body: { propertyId: p.id, kind: 'owner' } }); nav(`/owner/messages/${c.id}`); };
  const review = p.compliance.review;

  return (
    <div className="page pb-10">
      <PageHeader back="/owner/listings" title={p.shortTitle || p.title} sub={p.address} right={<ListingStatusPill s={p.status} />} />
      <div className="space-y-5 px-4">
        <div className="relative overflow-hidden rounded-2xl"><Img src={p.images[0] ?? ''} alt="" className="h-40 w-full" /><div className="absolute bottom-2 left-2 flex gap-1">{p.images.slice(1, 4).map((x) => <Img key={x} src={x} alt="" className="h-10 w-10 rounded-md ring-2 ring-white" />)}</div></div>

        {/* Status pipeline */}
        <div className="card p-4">
          <div className="flex items-center justify-between">{steps.map(([l, done], i) => (
            <div key={l} className="flex flex-1 items-center">
              <div className="flex flex-col items-center gap-1">{done ? <CheckCircle2 size={22} className="text-electric" /> : <Circle size={22} className="text-ivory-300" />}<span className={`text-[11.5px] font-bold ${done ? 'text-ink' : 'text-ink-500'}`}>{t(l)}</span></div>
              {i < steps.length - 1 && <div className={`mx-1 mb-4 h-0.5 flex-1 ${steps[i + 1][1] ? 'bg-electric' : 'bg-ivory-300'}`} />}
            </div>
          ))}</div>
          {p.status === 'approved' && <button disabled={busy} onClick={() => act('publish')} className="btn-accent mt-4 w-full"><Rocket size={17} /> {t('Publish listing')}</button>}
          {p.status === 'paused' && <button disabled={busy} onClick={() => act('publish')} className="btn-accent mt-4 w-full"><Rocket size={17} /> {t('Re-publish')}</button>}
          {p.status === 'in_review' && <p className="mt-3 text-[12.5px] text-ink-600">{t('A SpaceTime compliance reviewer is checking your documents. You’ll be notified here.')}</p>}
          {(p.status === 'draft' || p.status === 'changes_requested') && <Link to={`/owner/edit/${p.id}`} className="btn-primary mt-4 w-full"><Pencil size={16} /> {t('Continue editing')}</Link>}
          {p.status === 'published' && (
            <div className="mt-4 grid grid-cols-2 gap-2">
              <Link to={`/space/${p.id}`} className="btn-ghost py-2.5 text-[13px]"><Eye size={15} /> {t('Guest view')}</Link>
              <button disabled={busy} onClick={() => act('pause')} className="btn-ghost py-2.5 text-[13px]"><Pause size={15} /> {t('Pause listing')}</button>
            </div>
          )}
        </div>

        {review && (
          <Panel title={t('Compliance review')}>
            <div className="card p-4">
              <div className="flex items-center gap-2">{review.status === 'approved' ? <BadgeCheck size={18} className="text-emerald-600" /> : <ShieldCheck size={18} className="text-amber-600" />}<span className="text-[14px] font-bold">{t(review.status === 'approved' ? 'Approved' : review.status === 'pending' ? 'Awaiting human review' : 'Changes requested')}</span></div>
              {review.basis && <p className="mt-1 text-[12.5px] text-ink-600">{t(review.basis === 'verified_file' ? 'Basis: documents previously verified by SpaceTime Compliance' : 'Basis: manual review')}{review.reviewer ? ` · ${review.reviewer}` : ''}</p>}
              {review.notes && <p className="mt-1 text-[12px] text-ink-500">{review.notes}</p>}
              {review.checks.length > 0 && <ul className="mt-3 grid grid-cols-1 gap-1">{review.checks.map((c) => <li key={c.key} className="flex items-center gap-2 text-[12.5px]">{c.ok ? <CheckCircle2 size={14} className="text-emerald-600" /> : <XCircle size={14} className="text-rose-500" />}{t(CHECK_LABEL[c.key] ?? c.key)}</li>)}</ul>}
              <p className="mt-3 text-[11px] text-ink-500">{t('Automated checks only verify completeness. Legal authorisation is confirmed by a human reviewer or by previously verified documents.')}</p>
            </div>
          </Panel>
        )}

        <Panel title={t('Manager')}>
          <div className="card flex items-center gap-3 p-4">
            <Avatar name={p.managerName ?? '?'} src={p.partner.avatar || undefined} size={46} />
            <div className="min-w-0 flex-1"><div className="text-[15px] font-bold">{p.managerName ?? t('Not assigned')}</div><div className="text-[12px] text-ink-500">{p.managerCompany}</div>
              <div className="mt-1 flex flex-wrap gap-1">{(['availability', 'pricing', 'approveBookings', 'cleaning', 'messaging'] as const).filter((k) => p.delegation[k]).map((k) => <StatusPill key={k} tone="muted">{t(DELEG[k])}</StatusPill>)}</div>
            </div>
            {p.managerId && <button onClick={messageManager} aria-label={t('Message manager')} className="grid h-11 w-11 place-items-center rounded-full bg-ice-100"><MessageCircle size={19} /></button>}
          </div>
          <button onClick={() => setPerm(true)} className="mt-2 w-full text-center text-[13px] font-semibold text-electric-600">{t('Edit permitted uses & delegation')}</button>
        </Panel>

        <Panel title={t('Next 7 days')}>
          <div className="card space-y-2.5 p-4">
            {nextDays(7).map((d) => <div key={d}><div className="mb-0.5 text-[12.5px] font-semibold text-ink-600">{dayLabel(d)}</div>{p.schedule?.[d] && <TimelineBar day={p.schedule[d]} date={d} height="h-6" />}</div>)}
            <TimelineAxis />
            <TimelineLegend />
          </div>
        </Panel>

        <Panel title={t('Earnings from this space')}>
          <div className="card p-4">
            <div className="mb-3 flex items-end justify-between"><div><div className="text-[11px] font-bold uppercase tracking-wider text-ink-500">{t('Est. owner proceeds')}</div><div className="text-[26px] font-bold text-electric-700">{eur(sum('ownerProceeds'))}</div></div><div className="text-right text-[12px] text-ink-500">{t('{n} bookings', { n: counted.length })}</div></div>
            <FinanceBreakdown e={{ gross: sum('gross'), guestFee: sum('guestFee'), cleaning: sum('cleaning'), commission: sum('commission'), mgmtFee: sum('mgmtFee'), mgmtFeePct: p.delegation.mgmtFeePct, ownerProceeds: sum('ownerProceeds') }} />
          </div>
        </Panel>

        <Panel title={t('Bookings')}>
          <div className="space-y-2">
            {data.bookings.length === 0 && <p className="card p-4 text-[13px] text-ink-500">{t('No bookings yet.')}</p>}
            {data.bookings.map((b) => (
              <details key={b.id} className="card overflow-hidden">
                <summary className="flex cursor-pointer items-center gap-3 p-3">
                  <Avatar name={b.guestName ?? ''} src={b.guestAvatar || undefined} size={34} />
                  <div className="min-w-0 flex-1"><div className="text-[13.5px] font-semibold">{dayLabel(b.date)} · {b.start}–{b.end}</div><div className="text-[12px] text-ink-500">{b.guestName} · {t('{n} guests', { n: b.guests.adults + b.guests.children })}</div></div>
                  <div className="text-right"><StatusPill tone={b.status === 'confirmed' ? 'ok' : b.status === 'pending' ? 'warn' : b.status === 'completed' ? 'info' : 'muted'}>{t(b.status === 'pending' ? 'Awaiting approval' : b.status[0].toUpperCase() + b.status.slice(1))}</StatusPill><div className="mt-0.5 text-[13px] font-bold">{eur(b.price.ownerProceeds)}</div></div>
                </summary>
                <div className="border-t border-ivory-200 bg-ivory-50 p-3"><FinanceBreakdown e={b.price} compact /><p className="mt-2 text-[12.5px] text-ink-500">{t('Handled by {m}', { m: p.managerName ?? '—' })}</p></div>
              </details>
            ))}
          </div>
        </Panel>
      </div>
      {perm && <PermissionsSheet p={p} onClose={() => setPerm(false)} onSaved={reload} />}
    </div>
  );
}

const DELEG: Record<string, string> = { availability: 'Availability', pricing: 'Pricing', approveBookings: 'Approve bookings', cleaning: 'Cleaning', messaging: 'Guest messages' };

function PermissionsSheet({ p, onClose, onSaved }: { p: Property; onClose: () => void; onSaved: () => void }) {
  const t = useT();
  const [acts, setActs] = useState<Activity[]>(p.activities);
  const [d, setD] = useState<Delegation>(p.delegation);
  const [err, setErr] = useState('');
  const live = !['draft', 'changes_requested'].includes(p.status);
  const save = async () => {
    try { await api(`/api/owner/properties/${p.id}`, { method: 'PUT', body: { activities: acts, delegation: d } }); onSaved(); onClose(); useStore.getState().showToast('Saved'); }
    catch (e) { setErr(e instanceof Error ? t(e.message) : 'Error'); }
  };
  return (
    <Sheet open onClose={onClose} title={t('Permitted uses & delegation')} full footer={<button className="btn-primary w-full" onClick={save}>{t('Save')}</button>}>
      <div className="space-y-5 pb-4">
        <div>
          <h3 className="mb-2 text-[15px] font-bold">{t('Permitted uses')}</h3>
          <div className="flex flex-wrap gap-2">{(live ? p.activities : (Object.keys(ACTIVITIES) as Activity[])).map((a) => { const A = ACTIVITIES[a]; return <Chip key={a} on={acts.includes(a)} onClick={() => setActs(acts.includes(a) ? acts.filter((x) => x !== a) : [...acts, a])} icon={<A.icon size={14} />}>{t(A.label)}</Chip>; })}</div>
          {live && <p className="mt-2 text-[12px] text-ink-500">{t('While live you can restrict uses. Adding a new use requires a new compliance review.')}</p>}
        </div>
        <div>
          <h3 className="mb-2 text-[15px] font-bold">{t('What your manager may do')}</h3>
          <div className="card divide-y divide-ivory-200">{(['availability', 'pricing', 'approveBookings', 'cleaning', 'messaging'] as const).map((k) => <div key={k} className="flex items-center justify-between px-4 py-3"><span className="text-[14px] font-semibold">{t(DELEG[k])}</span><Toggle label={k} checked={d[k]} onChange={(v) => setD({ ...d, [k]: v })} /></div>)}</div>
          <label className="mt-3 block"><span className="label">{t('Minimum hourly price the manager may set (€)')}</span><input type="number" className="input" value={d.priceFloor} onChange={(e) => setD({ ...d, priceFloor: +e.target.value })} /></label>
          <p className="mt-2 text-[12px] text-ink-500">{t('Managers can never change ownership, permitted uses, compliance documents or publication status.')}</p>
        </div>
        {err && <p className="text-[13px] font-semibold text-rose-700">{err}</p>}
      </div>
    </Sheet>
  );
}
