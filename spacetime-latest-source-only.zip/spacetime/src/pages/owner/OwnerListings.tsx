import { Link } from 'react-router-dom';
import { BadgeCheck, FileText, Plus } from 'lucide-react';
import { useApi } from '@/lib/api';
import { ListingStatusPill, Panel, Spinner } from '@/components/dash';
import { Img } from '@/components/Img';
import { useStore } from '@/store/useStore';
import { useT } from '@/i18n';
import type { OwnerOverview } from './OwnerHome';
import type { ComplianceDoc } from '@/types';

export default function OwnerListings() {
  const t = useT();
  const { data } = useApi<OwnerOverview>('/api/owner/overview');
  const file = (useStore((s) => s.user) as unknown as { operatorFile?: { company: string; registrationScope: string; documents: ComplianceDoc[] } }).operatorFile;
  return (
    <div className="page">
      <header className="px-5 pb-3 pt-[max(env(safe-area-inset-top),20px)]">
        <div className="flex items-center justify-between"><h1 className="h-display text-[28px]">{t('Listings')}</h1><Link to="/owner/new" className="btn-primary px-4 py-2.5 text-[13px]"><Plus size={16} /> {t('List a space')}</Link></div>
      </header>
      {!data ? <Spinner /> : (
        <div className="space-y-6 px-4">
          <div className="space-y-3">
            {data.properties.map((p) => (
              <Link key={p.id} to={p.status === 'draft' || p.status === 'changes_requested' ? `/owner/edit/${p.id}` : `/owner/property/${p.id}`} className="card flex gap-3 p-3">
                <Img src={p.images[0] ?? ''} alt="" className="h-20 w-20 shrink-0 rounded-lg" />
                <div className="min-w-0 flex-1">
                  <ListingStatusPill s={p.status} />
                  <div className="mt-1 truncate text-[15px] font-bold">{p.title}</div>
                  <div className="truncate text-[12px] text-ink-500">{p.address || p.neighbourhood}</div>
                  <div className="text-[12px] text-ink-500">{p.managerName ? `${t('Manager')}: ${p.managerName} · ${p.managerCompany}` : t('No manager assigned')}</div>
                </div>
              </Link>
            ))}
          </div>
          {file && (
            <Panel title={t('Verified compliance file')}>
              <div className="card p-4">
                <div className="flex items-center gap-2 text-[14px] font-bold"><BadgeCheck size={18} className="text-emerald-600" /> {file.company}</div>
                <div className="text-[12px] text-ink-500">{t('Registration scope')}: {file.registrationScope}</div>
                <ul className="mt-3 space-y-1.5">{file.documents.map((d) => <li key={d.id} className="flex items-start gap-2 text-[12.5px] text-ink-700"><FileText size={14} className="mt-0.5 shrink-0 text-electric-600" /><span>{d.name}<span className="block text-[11px] text-ink-500">{t('Verified {d} by {by}', { d: d.verifiedAt ?? '', by: d.verifiedBy ?? '' })}</span></span></li>)}</ul>
                <p className="mt-3 text-[12.5px] text-ink-500">{t('Listings that rely only on these verified documents, for uses within their scope, are approved on that basis. Anything else goes to a human compliance reviewer.')}</p>
              </div>
            </Panel>
          )}
          <div className="h-4" />
        </div>
      )}
    </div>
  );
}
