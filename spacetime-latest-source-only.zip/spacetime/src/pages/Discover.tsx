import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Briefcase, Info, MapPin, Moon, Palette, Plus, Sparkles } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { recommendationProvider, type RecGroup, type RecSection } from '@/lib/recommend';
import { PropertyCard } from '@/components/PropertyCard';
import { Sheet } from '@/components/ui';
import { Logo } from '@/components/Logo';
import { ACTIVITIES, PURPOSE_GROUPS } from '@/data/vocab';
import { partOfDay } from '@/lib/time';
import { useApi } from '@/lib/api';
import { useT } from '@/i18n';
import type { Booking, SearchQuery } from '@/types';

/** Each purpose has its own colour so the three groups are easy to tell apart at a glance. */
const GROUP_META: Record<Exclude<RecGroup, 'foryou' | 'near'>, { icon: typeof Moon; title: string; sub: string; tint: string; card: string; item: string }> = {
  rest: { icon: Moon, title: 'Rest & Recharge', sub: 'Nap, shower, reset between journeys', tint: 'bg-lavender-600 text-white', card: 'bg-lavender-100', item: 'text-lavender-600' },
  work: { icon: Briefcase, title: 'Work & Focus', sub: 'Quiet desks, calls and private meetings', tint: 'bg-electric text-white', card: 'bg-electric-50', item: 'text-electric-600' },
  create: { icon: Palette, title: 'Create & Gather', sub: 'Cook, rehearse, shoot or celebrate', tint: 'bg-ink text-white', card: 'bg-ivory-100', item: 'text-ink' },
};

export default function DiscoverPage() {
  const t = useT();
  const nav = useNavigate();
  const { user, query, setQuery, commitSearch, catalogRev, lang } = useStore();
  const { data: myBookings } = useApi<Booking[]>('/api/bookings/mine');
  const [why, setWhy] = useState(false);
  const prefs = user!.prefs;

  const sections = useMemo(
    () => recommendationProvider.getSections({ prefs, pastPropertyIds: (myBookings ?? []).map((b) => b.propertyId), now: new Date() }),
    [prefs, myBookings, catalogRev, lang], // eslint-disable-line react-hooks/exhaustive-deps
  );
  const home = prefs.locations.find((l) => l.tag === 'home');
  const work = prefs.locations.find((l) => l.tag === 'work');
  const shown = sections;
  const greet = { morning: 'Good morning', afternoon: 'Good afternoon', evening: 'Good evening', night: 'Good evening' }[partOfDay()];
  const firstName = user!.name.split(' ')[0];

  const seeAll = (s: RecSection) => {
    const anchor = s.id === 'near-home' ? home : s.id === 'near-work' ? work : undefined;
    const q: SearchQuery = { ...query, activity: s.activity, where: anchor ? { mode: 'place', label: anchor.label, lat: anchor.lat, lng: anchor.lng, radiusKm: 3 } : { ...query.where } };
    setQuery(q);
    commitSearch();
    nav('/results');
  };
  const browse = (activity: SearchQuery['activity']) => { setQuery({ ...query, activity }); commitSearch(); nav('/results'); };

  let lastGroup: string | null = null;
  return (
    <div className="page">
      <header className="px-5 pb-1 pt-[max(env(safe-area-inset-top),18px)]">
        <Logo size={30} />
        <p className="mt-4 text-[14px] font-semibold text-ink-500">{t(greet)}, {firstName}</p>
        <h1 className="h-display mt-0.5 text-[28px] leading-tight">{t('What do you need to do?')}</h1>
        <p className="mt-1 text-[15px] leading-snug text-ink-600">{t('Find the right private space for a few hours, based on what you need to do.')}</p>
      </header>

      <div className="px-5 pt-4">
        <Link to="/assistant" className="clip-corner relative flex items-center gap-4 overflow-hidden bg-ink p-4 text-white shadow-card">
          <div className="pointer-events-none absolute -right-8 -top-8 h-28 w-28 rounded-full bg-electric/50 blur-2xl" />
          <span className="relative grid h-12 w-12 shrink-0 place-items-center rounded-lg bg-electric"><Sparkles size={22} /></span>
          <span className="relative flex-1">
            <span className="block text-[15px] font-bold">{t('Describe it — we’ll match the space')}</span>
            <span className="block text-[12.5px] text-ice-200">{t('“Arriving at Gare de Lyon at 9 with two kids, need to shower and rest…”')}</span>
          </span>
          <ArrowRight size={18} className="relative shrink-0" />
        </Link>
      </div>

      {/* Purpose tiles */}
      <div className="mt-5 space-y-3 px-5">
        {PURPOSE_GROUPS.map((g) => {
          const meta = GROUP_META[g.id as keyof typeof GROUP_META];
          return (
            <div key={g.id} className={`rounded-2xl p-3 ${meta.card}`}>
              <div className="mb-2.5 flex items-center gap-2.5"><span className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg ${meta.tint}`}><meta.icon size={17} /></span><span className="min-w-0"><span className="block text-[16px] font-bold leading-tight text-ink">{t(g.title)}</span><span className="block text-[13px] leading-tight text-ink-600">{t(meta.sub)}</span></span></div>
              <div className="grid grid-cols-2 gap-2">
                {g.items.map((it) => {
                  const A = ACTIVITIES[it.activity];
                  return (
                    <button key={it.id} onClick={() => browse(it.activity)} className="flex min-h-[48px] min-w-0 items-center gap-2 rounded-xl bg-white px-2.5 py-2 text-left shadow-card transition active:scale-[.98]">
                      <A.icon size={16} className={`shrink-0 ${meta.item}`} />
                      <span className="min-w-0 text-[13.5px] font-semibold leading-tight text-ink">{t(it.label)}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {(!home || !work) && (
        <div className="mx-5 mt-5 flex items-center gap-3 rounded-xl border border-dashed border-electric-400 bg-ice-50 p-4">
          <MapPin size={20} className="text-electric-600" />
          <p className="flex-1 text-[13px] text-ink-700">{t('Add your home and work areas to see spaces right around the corner.')}</p>
          <Link to="/profile?edit=locations" className="inline-flex items-center gap-1 rounded-lg bg-ink px-3 py-2 text-[12.5px] font-bold text-white"><Plus size={14} /> {t('Add')}</Link>
        </div>
      )}

      <div className="mt-6 space-y-7">
        {shown.map((s) => {
          const meta = s.group in GROUP_META ? GROUP_META[s.group as keyof typeof GROUP_META] : null;
          const showHeader = meta && s.group !== lastGroup;
          lastGroup = s.group;
          return (
            <section key={s.id} className="animate-fade-up">
              {showHeader && meta && (
                <div className="mb-4 mt-2 flex items-center gap-2 px-5">
                  <span className={`grid h-7 w-7 place-items-center rounded-md ${meta.tint}`}><meta.icon size={14} /></span>
                  <span className="text-[13px] font-bold uppercase tracking-[0.12em] text-ink-600">{t(meta.title)}</span>
                  <span className="h-px flex-1 bg-ivory-300" />
                </div>
              )}
              <div className="mb-3 flex items-end justify-between gap-3 px-5">
                <div className="min-w-0"><h2 className="section-title">{s.title}</h2><p className="truncate text-[13px] text-ink-500">{s.subtitle}</p></div>
                <button onClick={() => seeAll(s)} className="shrink-0 text-[13px] font-bold text-electric-600">{t('See all')}</button>
              </div>
              <div className="rail">
                {s.items.map((it) => <PropertyCard key={it.property.id} property={it.property} distance={it.anchorLabel ? it.distance : undefined} distanceFrom={it.anchorLabel ? t('from {place}', { place: it.anchorLabel }) : undefined} />)}
              </div>
            </section>
          );
        })}
        {shown.length === 0 && <p className="px-5 text-[14px] text-ink-500">{t('No spaces match yet — check back soon.')}</p>}
      </div>

      <button onClick={() => setWhy(true)} className="mx-auto mt-8 flex items-center gap-1.5 px-5 text-[12.5px] font-semibold text-ink-500"><Info size={14} /> {t('Why am I seeing these?')}</button>
      <div className="h-4" />
      <Sheet open={why} onClose={() => setWhy(false)} title={t('How Discover works')}>
        <div className="space-y-3 pb-4 text-[14px] leading-relaxed text-ink-700">
          <p>{t('Discover ranks live listings with a transparent rule-based engine. It uses:')}</p>
          <ul className="list-disc space-y-1 pl-5">
            <li>{t('Your home, work and saved places')}</li>
            <li>{t('The activities you chose: {list}', { list: prefs.interests.map((i) => t(ACTIVITIES[i].label)).join(', ') || '—' })}</li>
            <li>{t("Spaces you've saved or booked before")}</li>
            <li>{t('Time of day — work spaces first during office hours')}</li>
            <li>{t('Accessibility needs and budget')}</li>
          </ul>
          <p>{t('A space only appears under an activity if its listing explicitly permits it, and only when the Space Partner has opened bookable hours.')}</p>
          <Link to="/profile?edit=interests" className="btn-soft mt-2 w-full" onClick={() => setWhy(false)}>{t('Edit my preferences')}</Link>
        </div>
      </Sheet>
    </div>
  );
}
