import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bookmark, ChevronRight, Heart, Search, Trash2 } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { getProperty } from '@/data/properties';
import { PropertyCard } from '@/components/PropertyCard';
import { EmptyState, Segmented } from '@/components/ui';
import { distanceMeters } from '@/lib/geo';
import { ACTIVITIES } from '@/data/vocab';
import { dayLabel, todayISO } from '@/lib/time';
import { activeFilterCount } from '@/lib/search';
import { describeWhoT } from './Search';
import { useT } from '@/i18n';
import type { Property } from '@/types';

export default function FavouritesPage() {
  const t = useT();
  const nav = useNavigate();
  const { user, deleteSavedSearch, setQuery, setFilters, commitSearch } = useStore();
  useStore((s) => s.catalogRev);
  const [tab, setTab] = useState<'spaces' | 'searches'>('spaces');
  const prefs = user!.prefs;
  const home = prefs.locations.find((l) => l.tag === 'home');
  const props = prefs.favourites.map(getProperty).filter(Boolean) as Property[];
  const saved = prefs.savedSearches;

  return (
    <div className="page">
      <header className="px-5 pb-3 pt-[max(env(safe-area-inset-top),20px)]">
        <h1 className="h-display text-[30px]">{t('Favourites')}</h1>
        <p className="text-[13px] text-ink-500">{t('Spaces and searches you’ve saved — synced to your account.')}</p>
      </header>
      <div className="px-5"><Segmented value={tab} onChange={setTab} options={[{ value: 'spaces', label: `${t('Spaces')} (${props.length})` }, { value: 'searches', label: `${t('Searches')} (${saved.length})` }]} /></div>
      {tab === 'spaces' && (props.length === 0 ? (
        <EmptyState icon={<Heart size={30} />} title={t('No favourites yet')} text={t('Tap the heart on any space to save it here for later.')} action={<Link to="/discover" className="btn-primary">{t('Discover spaces')}</Link>} />
      ) : (
        <div className="space-y-6 px-5 pt-5">
          {props.map((p) => <PropertyCard key={p.id} variant="list" property={p} distance={home ? distanceMeters(home, p) : undefined} distanceFrom={home ? t('from {place}', { place: t('home') }) : undefined} />)}
          <p className="text-center text-[12px] text-ink-500">{t('Tap ♥ again to remove a space.')}</p>
        </div>
      ))}
      {tab === 'searches' && (saved.length === 0 ? (
        <EmptyState icon={<Bookmark size={30} />} title={t('No saved searches')} text={t('On the results map, tap the bookmark icon to save a search with its time, guests and filters.')} action={<Link to="/search" className="btn-primary"><Search size={17} /> {t('Start a search')}</Link>} />
      ) : (
        <div className="space-y-3 px-5 pt-5">
          {saved.map((s) => {
            const nf = s.filters ? activeFilterCount(s.filters) : 0;
            const date = s.query.when.date < todayISO() ? todayISO() : s.query.when.date;
            return (
              <div key={s.id} className="card flex items-center gap-3 p-4">
                <button className="flex min-w-0 flex-1 items-center gap-3 text-left" onClick={() => { setQuery({ ...s.query, when: { ...s.query.when, date } }); if (s.filters) setFilters(s.filters); commitSearch(); nav('/results'); }}>
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-lg bg-electric-100 text-electric-600"><Bookmark size={18} className="fill-electric" /></span>
                  <span className="min-w-0">
                    <span className="block truncate text-[15px] font-bold text-ink">{s.name}</span>
                    <span className="block truncate text-[12.5px] text-ink-500">{s.query.where.label}{s.query.activity ? ` · ${t(ACTIVITIES[s.query.activity].label)}` : ''} · {dayLabel(date)} {s.query.when.start} · {s.query.when.durationHours}h</span>
                    <span className="block truncate text-[12px] text-ink-500">{describeWhoT(s.query, t)}{nf ? ` · ${t('{n} filter(s)', { n: nf })}` : ''}</span>
                  </span>
                  <ChevronRight size={18} className="ml-auto shrink-0 text-ink-500" />
                </button>
                <button aria-label={t('Delete saved search')} onClick={() => deleteSavedSearch(s.id)} className="grid h-9 w-9 place-items-center rounded-full bg-ivory-100 text-ink-500"><Trash2 size={16} /></button>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}
