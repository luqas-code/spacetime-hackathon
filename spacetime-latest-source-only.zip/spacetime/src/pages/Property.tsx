import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Award, Ban, Baby, Check, ChevronLeft, Clock, MessageCircle, PawPrint, Share2, ShieldCheck, Users, Zap, BedDouble, Bath, Ruler, Hourglass, Info, MapPin, BadgeCheck } from 'lucide-react';
import { getProperty } from '@/data/properties';
import { Img } from '@/components/Img';
import { FavButton } from '@/components/FavButton';
import { Rating } from '@/components/Rating';
import { MapView } from '@/components/MapView';
import { DayTimeline } from '@/components/DayTimeline';
import { Avatar, Sheet, partnerColor } from '@/components/ui';
import { ShareFallback, shareListing } from '@/components/ShareSheet';
import { ACCESSIBILITY, ACTIVITIES, AMENITIES, CANCELLATION, PROPERTY_TYPES } from '@/data/vocab';
import { useStore } from '@/store/useStore';
import { calcPrice, eur, RATES } from '@/lib/pricing';
import { findFit, openingLabel, dayOf } from '@/lib/availability';
import { nextDays, shortDate, todayISO, dayLabel, toMin, fmtHours } from '@/lib/time';
import { distanceMeters, formatDistance, walkMinutes } from '@/lib/geo';
import { api } from '@/lib/api';
import { useT } from '@/i18n';
import type { Amenity, Economics, Property } from '@/types';

export default function PropertyPage() {
  const t = useT();
  const { id = '' } = useParams();
  useStore((s) => s.catalogRev);
  const fromCatalog = getProperty(id);
  const [fetched, setFetched] = useState<Property | null>(null);
  const [missing, setMissing] = useState(false);
  useEffect(() => {
    if (fromCatalog) return;
    api<Property>(`/api/listing/${id}`).then(setFetched).catch(() => setMissing(true));
  }, [id, fromCatalog]);
  const p = fromCatalog ?? fetched;
  const nav = useNavigate();
  const { query, user } = useStore();
  const [img, setImg] = useState(0);
  const [allAmenities, setAllAmenities] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [date, setDate] = useState(query.when.date);
  const galleryRef = useRef<HTMLDivElement>(null);
  // Open on the searched day if it has hours, otherwise on the next day that does.
  const jumped = useRef(false);
  useEffect(() => {
    if (!p || jumped.current) return;
    jumped.current = true;
    if (!dayOf(p, date).free.length) { const next = nextDays(14).find((d) => dayOf(p, d).free.length); if (next) setDate(next); }
  }, [p]); // eslint-disable-line react-hooks/exhaustive-deps
  const hours = p ? Math.min(p.maxHours, Math.max(p.minHours, query.when.durationHours)) : 0;
  const fit = useMemo(() => (p ? findFit(p, date, query.when.start, hours, Math.max(query.when.flex, 3)) : null), [p, date, query.when.start, hours, query.when.flex]);

  if (!p) return <div className="grid flex-1 place-items-center p-10 text-center text-ink-500">{missing ? <div>{t('This space is not available.')} <Link className="underline" to="/">{t('Back')}</Link></div> : <div className="h-8 w-8 animate-spin rounded-full border-4 border-ice-200 border-t-electric" />}</div>;

  const price = calcPrice(p, hours);
  const T = PROPERTY_TYPES[p.type];
  const notAllowed: { label: string; icon: typeof Ban }[] = [];
  if (!p.activities.includes('party')) notAllowed.push({ label: 'No parties or events', icon: Ban });
  if (!p.petsAllowed) notAllowed.push({ label: 'No pets', icon: PawPrint });
  if (!p.childrenAllowed) notAllowed.push({ label: 'Not suitable for children', icon: Baby });
  const groups = groupAmenities(p.amenities);
  const isGuest = user?.role === 'guest';
  const bookUrl = `/book/${p.id}?date=${date}${fit ? `&start=${fit.start}` : ''}&hours=${hours}`;
  const message = async () => {
    if (!user) return nav(`/login?next=/space/${p.id}`);
    const c = await api<{ id: string }>('/api/conversations', { body: { propertyId: p.id, kind: 'guest' } });
    nav(`/messages/${c.id}`);
  };

  return (
    <div className="relative flex-1 overflow-hidden">
      <div className="h-full overflow-y-auto pb-28">
        <div className="relative">
          <div ref={galleryRef} className="no-scrollbar flex h-[300px] snap-x snap-mandatory overflow-x-auto" onScroll={(e) => setImg(Math.round(e.currentTarget.scrollLeft / e.currentTarget.clientWidth))}>
            {p.images.map((src, i) => <Img key={i} src={src} alt={`${p.shortTitle} ${i + 1}`} seed={i} className="h-full w-full shrink-0 snap-center" />)}
          </div>
          <div className="absolute inset-x-0 top-0 flex items-center justify-between px-4 pt-[max(env(safe-area-inset-top),14px)]">
            <button aria-label={t('Back')} className="icon-btn" onClick={() => (window.history.length > 1 ? nav(-1) : nav('/'))}><ChevronLeft size={20} /></button>
            <div className="flex gap-2">
              <button aria-label={t('Share')} className="icon-btn" onClick={() => shareListing(p.title, p.id, () => setShareOpen(true))}><Share2 size={17} /></button>
              {isGuest && <FavButton id={p.id} variant="plain" />}
            </div>
          </div>
          <div className="absolute bottom-9 left-1/2 flex -translate-x-1/2 gap-1.5">
            {p.images.map((_, i) => <button key={i} aria-label={`${i + 1}`} onClick={() => galleryRef.current?.scrollTo({ left: i * galleryRef.current.clientWidth, behavior: 'smooth' })} className={`h-1.5 rounded-full transition-all ${i === img ? 'w-5 bg-white' : 'w-1.5 bg-white/60'}`} />)}
          </div>
          <span className="absolute bottom-8 right-4 rounded-md bg-ink/70 px-2.5 py-1 text-[11px] font-semibold text-white">{img + 1}/{p.images.length}</span>
        </div>

        <div className="relative -mt-5 rounded-t-[1.75rem] bg-ivory-50 px-5 pt-6">
          <div className="flex items-center gap-2 text-[12.5px] font-semibold text-ink-500"><T.icon size={14} /> {t(T.label)} · {p.neighbourhood}, {p.arrondissement}</div>
          <h1 className="h-display mt-1.5 text-[26px] leading-[1.12]">{p.title}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1">
            <Rating value={p.rating} count={p.reviewCount} />
            {p.partner.superPartner && <span className="inline-flex items-center gap-1 text-[12.5px] font-semibold text-ink"><Award size={14} className="text-electric" /> {t('Top Space Partner')}</span>}
            {p.instantBook && <span className="inline-flex items-center gap-1 text-[12.5px] font-semibold text-ink"><Zap size={13} className="fill-electric text-electric" /> {t('Instant book')}</span>}
            {p.compliance?.review?.status === 'approved' && <span className="inline-flex items-center gap-1 text-[12.5px] font-semibold text-emerald-700"><BadgeCheck size={14} /> {t('Verified listing')}</span>}
          </div>

          {/* Next bookable hours — time-first */}
          <div className="mt-4 rounded-xl bg-ink p-3.5 text-white">
            <div className="flex items-center justify-between"><span className="text-[11px] font-bold uppercase tracking-[0.12em] text-lavender">{t('Next bookable hours')}</span><Clock size={14} className="text-lavender" /></div>
            <div className="no-scrollbar mt-2 flex gap-2 overflow-x-auto">
              {nextDays(7).flatMap((d) => dayOf(p, d).free.slice(0, 2).map(([s, e]) => ({ d, s, e }))).slice(0, 6).map(({ d, s, e }) => (
                <button key={d + s} onClick={() => setDate(d)} className="shrink-0 rounded-lg bg-white/10 px-3 py-2 text-left ring-1 ring-white/15">
                  <div className="text-[11px] text-ice-200">{dayLabel(d)}</div>
                  <div className="text-[14px] font-bold tabular-nums">{String(Math.floor(s / 60)).padStart(2, '0')}:{String(s % 60).padStart(2, '0')}–{String(Math.floor(e / 60)).padStart(2, '0')}:{String(e % 60).padStart(2, '0')}</div>
                </button>
              ))}
              {nextDays(7).every((d) => !dayOf(p, d).free.length) && <span className="text-[13px] text-ice-200">{t('No open hours this week yet — message the Space Partner.')}</span>}
            </div>
          </div>

          <div className="no-scrollbar -mx-5 mt-4 flex gap-2 overflow-x-auto px-5">
            <Fact icon={<Users size={16} />} label={t('Up to {n}', { n: p.capacity.guests })} sub={t('guests')} />
            {p.capacity.beds > 0 && <Fact icon={<BedDouble size={16} />} label={t('{n} bed(s)', { n: p.capacity.beds })} sub={t('for resting')} />}
            <Fact icon={<Bath size={16} />} label={t('{n} bath', { n: p.capacity.bathrooms })} sub={p.amenities.includes('shower') ? t('with shower') : t('room')} />
            <Fact icon={<Ruler size={16} />} label={`${p.sizeM2} m²`} sub={p.floor} />
            <Fact icon={<Hourglass size={16} />} label={`${p.minHours}–${p.maxHours} h`} sub={t('per booking')} />
          </div>
          <ul className="mt-5 space-y-2">{p.highlights.map((h) => <li key={h} className="flex items-start gap-2.5 text-[14px] text-ink-700"><Check size={17} className="mt-0.5 shrink-0 text-electric-600" strokeWidth={3} /> {h}</li>)}</ul>

          <div className="card mt-6 flex items-center gap-3 p-4">
            <Avatar name={p.partner.name} src={p.partner.avatar || undefined} color={partnerColor(p.partner.name)} size={48} />
            <div className="min-w-0 flex-1">
              <div className="text-[15px] font-bold text-ink">{t('Managed by {name}', { name: p.partner.name })}</div>
              <div className="text-[12.5px] text-ink-500">{p.partner.company} · {t('Space Partner')}</div>
              <div className="text-[12px] text-ink-500">{t('Usually replies in ~{n} min', { n: p.partner.responseMins })}</div>
            </div>
            {isGuest && <button aria-label={t('Message the Space Partner')} onClick={message} className="grid h-11 w-11 place-items-center rounded-full bg-ice-100 text-ink"><MessageCircle size={19} /></button>}
          </div>

          <Block title={t('About this space')}><p className="whitespace-pre-line text-[14.5px] leading-relaxed text-ink-700">{p.description}</p></Block>
          <Block title={t('Permitted uses')}>
            <div className="grid grid-cols-2 gap-2">
              {p.activities.map((a) => { const A = ACTIVITIES[a]; return (
                <div key={a} className="flex items-center gap-2.5 rounded-xl bg-white p-3 shadow-card"><span className={`grid h-9 w-9 place-items-center rounded-lg ${A.tint}`}><A.icon size={17} /></span><span className="text-[13px] font-semibold text-ink">{t(A.label)}</span></div>
              ); })}
            </div>
            {notAllowed.length > 0 && <div className="mt-3 flex flex-wrap gap-2">{notAllowed.map((n) => <span key={n.label} className="inline-flex items-center gap-1.5 rounded-md bg-ivory-100 px-3 py-1.5 text-[12.5px] font-semibold text-ink-500"><n.icon size={13} /> {t(n.label)}</span>)}</div>}
            <p className="mt-2 text-[12px] text-ink-500">{t('Uses not listed here are not authorised by the owner.')}</p>
          </Block>
          <Block title={t('Amenities')}>
            <div className="grid grid-cols-2 gap-x-4 gap-y-3">{p.amenities.slice(0, 10).map((a) => { const A = AMENITIES[a]; return A ? <div key={a} className="flex items-center gap-2.5 text-[14px] text-ink-700"><A.icon size={18} className="text-ink" /> {t(A.label)}</div> : null; })}</div>
            {p.amenities.length > 10 && <button className="btn-ghost mt-4 w-full py-3" onClick={() => setAllAmenities(true)}>{t('Show all {n} amenities', { n: p.amenities.length })}</button>}
          </Block>
          {p.accessibility.length > 0 && <Block title={t('Accessibility')}><div className="flex flex-wrap gap-2">{p.accessibility.map((a) => { const A = ACCESSIBILITY[a]; return <span key={a} className="inline-flex items-center gap-1.5 rounded-md bg-electric-100 px-3 py-1.5 text-[12.5px] font-semibold text-ink"><A.icon size={14} /> {t(A.label)}</span>; })}</div></Block>}
          <Block title={t('Availability')}>
            <div className="no-scrollbar -mx-5 mb-3 flex gap-2 overflow-x-auto px-5">
              {nextDays(14).map((d) => { const s = shortDate(d); const on = d === date; const any = dayOf(p, d).free.length > 0; return (
                <button key={d} onClick={() => setDate(d)} className={`flex w-[50px] shrink-0 flex-col items-center rounded-xl border py-1.5 ${on ? 'border-ink bg-ink text-white' : 'border-ivory-300 bg-white text-ink'} ${!any && !on ? 'opacity-40' : ''}`}>
                  <span className={`text-[11.5px] font-semibold ${on ? 'text-ice-200' : 'text-ink-500'}`}>{d === todayISO() ? t('Today') : s.dow}</span><span className="text-[16px] font-bold">{s.day}</span>
                  <span className={`mt-0.5 h-1 w-1 rounded-full ${any ? 'bg-electric' : 'bg-transparent'}`} />
                </button>
              ); })}
            </div>
            <DayTimeline p={p} date={date} highlight={fit ? [toMin(fit.start), toMin(fit.end)] : undefined} />
            <div className="mt-3 rounded-xl bg-white p-3 text-[13px] text-ink-700 shadow-card"><div className="mb-1 flex items-center gap-1.5 font-semibold text-ink"><Clock size={14} /> {t('Daytime hours')}</div>{openingLabel(p).map((l) => <div key={l}>{l}</div>)}</div>
          </Block>
          <Block title={t('Where you’ll be')}>
            <div className="h-48 overflow-hidden rounded-2xl ring-1 ring-ivory-200"><MapView center={p} zoom={15} interactive={false} circle={{ lat: p.lat, lng: p.lng, radiusKm: 0.18 }} /></div>
            <p className="mt-2 text-[14px] font-semibold text-ink">{p.neighbourhood}, Paris {p.arrondissement}</p>
            <p className="text-[12.5px] text-ink-500">{t('Approximate location. The exact address and door code are shared after booking.')}</p>
            <div className="mt-3 space-y-1.5">{(user?.prefs.locations ?? []).slice(0, 3).map((l) => { const d = distanceMeters(l, p); return <div key={l.id} className="flex items-center gap-2 text-[13px] text-ink-700"><MapPin size={14} className="text-electric-600" /> {t('{d} from {place}', { d: formatDistance(d), place: t(l.name) })} · ~{walkMinutes(d)} min</div>; })}</div>
          </Block>
          <Block title={t('House rules')}>
            <ul className="space-y-2">
              {p.rules.map((r) => <li key={r} className="flex items-start gap-2.5 text-[14px] text-ink-700"><Info size={16} className="mt-0.5 shrink-0 text-ink-500" /> {r}</li>)}
              <li className="flex items-start gap-2.5 text-[14px] text-ink-700"><Users size={16} className="mt-0.5 shrink-0 text-ink-500" /> {t('Maximum occupancy: {n} guests', { n: p.capacity.guests })}</li>
            </ul>
          </Block>
          <Block title={t('Price details')}>
            <div className="card space-y-2 p-4 text-[14px]">
              <div className="text-[12.5px] font-semibold text-ink-500">{t('For {h}', { h: fmtHours(hours) })}</div>
              <PriceRows price={price} />
            </div>
          </Block>
          <Block title={t('Cancellation')}>
            <div className="flex items-start gap-3 rounded-xl bg-white p-4 shadow-card"><ShieldCheck size={20} className="mt-0.5 shrink-0 text-electric-600" /><div><div className="text-[14px] font-bold text-ink">{t(CANCELLATION.label)}</div><p className="text-[13.5px] leading-relaxed text-ink-700">{t(CANCELLATION.detail)}</p></div></div>
          </Block>
          {p.reviews && p.reviews.length > 0 && (
            <Block title={<span className="flex items-center gap-2">{t('Guest reviews')} <Rating value={p.rating} count={p.reviewCount} /></span>}>
              <div className="no-scrollbar -mx-5 flex gap-3 overflow-x-auto px-5">{p.reviews.map((r) => (
                <div key={r.name} className="card w-[260px] shrink-0 p-4"><div className="flex items-center gap-2"><Avatar name={r.name} size={32} color={partnerColor(r.name)} /><div><div className="text-[13px] font-bold">{r.name}</div><div className="text-[12.5px] text-ink-500">{r.purpose}</div></div></div><p className="mt-2 text-[13.5px] leading-relaxed text-ink-700">“{r.text}”</p></div>
              ))}</div>
            </Block>
          )}
          <div className="h-6" />
        </div>
      </div>

      <div className="absolute inset-x-0 bottom-0 z-40 flex items-center gap-3 border-t border-ivory-200 bg-white px-5 py-3 pb-[max(env(safe-area-inset-bottom),12px)]">
        <div className="min-w-0 flex-1">
          <div className="text-[17px] font-bold text-ink">{eur(p.pricePerHour)}<span className="text-[13px] font-medium text-ink-500"> / {t('hour')}</span></div>
          <div className="truncate text-[12.5px] text-ink-500">{fit ? `${dayLabel(date)} · ${fit.start}–${fit.end} · ${t('{x} total', { x: eur(price.guestTotal) })}` : t('No {h} slot on {d} — pick another day', { h: fmtHours(hours), d: dayLabel(date).toLowerCase() })}</div>
        </div>
        {isGuest || !user ? <Link to={user ? bookUrl : `/login?next=${encodeURIComponent(bookUrl)}`} className="btn-accent px-7">{p.instantBook ? t('Reserve') : t('Request')}</Link> : <span className="text-[12px] text-ink-500">{t('Guest view')}</span>}
      </div>
      <Sheet open={allAmenities} onClose={() => setAllAmenities(false)} title={t('Amenities')}>
        <div className="space-y-5 pb-4">{Object.entries(groups).map(([g, list]) => (
          <div key={g}><h3 className="mb-2 text-[14px] font-bold text-ink">{t(g)}</h3><div className="space-y-2.5">{list.map((a) => { const A = AMENITIES[a]; return <div key={a} className="flex items-center gap-3 text-[14px] text-ink-700"><A.icon size={18} /> {t(A.label)}</div>; })}</div></div>
        ))}</div>
      </Sheet>
      <ShareFallback open={shareOpen} onClose={() => setShareOpen(false)} title={p.title} id={p.id} />
    </div>
  );
}

export function PriceRows({ price }: { price: Economics }) {
  const t = useT();
  return (
    <>
      <Row l={price.minApplied ? t('Minimum booking price') : `${eur(price.hourly)} × ${fmtHours(price.hours)}`} r={eur(price.rental)} />
      {price.otherCharges > 0 && <Row l={t('Other disclosed charges')} r={eur(price.otherCharges)} />}
      <Row l={t('Cleaning (at cost)')} r={eur(price.cleaning)} />
      {RATES.guestFeePct > 0 && <Row l={t('Guest service fee ({n}%)', { n: RATES.guestFeePct })} r={eur(price.guestFee)} />}
      <div className="flex justify-between border-t border-ivory-200 pt-2 text-[15px] font-bold text-ink"><span>{t('Total')}{price.occurrences > 1 ? ` ${t('per booking')}` : ''}</span><span>{eur(price.guestTotal)}</span></div>
      {price.occurrences > 1 && <div className="flex justify-between text-[15px] font-bold text-ink"><span>× {price.occurrences}</span><span>{eur(price.grandTotal)}</span></div>}
    </>
  );
}
const Row = ({ l, r }: { l: string; r: string }) => <div className="flex justify-between text-ink-700"><span>{l}</span><span>{r}</span></div>;

function Fact({ icon, label, sub }: { icon: React.ReactNode; label: string; sub: string }) {
  return <div className="flex shrink-0 items-center gap-2.5 rounded-xl bg-white px-3.5 py-2.5 shadow-card"><span className="text-electric-600">{icon}</span><div><div className="text-[13.5px] font-bold leading-tight text-ink">{label}</div><div className="text-[12.5px] text-ink-500">{sub}</div></div></div>;
}
function Block({ title, children }: { title: React.ReactNode; children: React.ReactNode }) {
  return <section className="mt-7 border-t border-ivory-200 pt-6"><h2 className="mb-3 text-[19px] font-bold tracking-tight text-ink">{title}</h2>{children}</section>;
}
function groupAmenities(list: Amenity[]) {
  const g: Record<string, Amenity[]> = {};
  for (const a of list) if (AMENITIES[a]) (g[AMENITIES[a].group] ??= []).push(a);
  return g;
}
