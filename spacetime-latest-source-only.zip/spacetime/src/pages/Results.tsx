import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bookmark, ChevronLeft, List, Map as MapIcon, SlidersHorizontal, SearchX, X, Zap, PawPrint, ArrowUpDown } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { MapView } from '@/components/MapView';
import { PropertyCard } from '@/components/PropertyCard';
import { FiltersSheet } from '@/components/FiltersSheet';
import { Sheet, EmptyState } from '@/components/ui';
import { activeFilterCount, runSearch } from '@/lib/search';
import { describeWhoT } from './Search';
import { useT } from '@/i18n';
import { calcPrice } from '@/lib/pricing';
import { dayLabel } from '@/lib/time';
import { ACTIVITIES } from '@/data/vocab';

type Snap = 'peek' | 'half' | 'full';

export default function ResultsPage() {
  const nav = useNavigate();
  const t = useT();
  const { query, filters, setFilters, saveSearch, patchQuery } = useStore();
  const favourites = useStore((s) => s.user?.prefs.favourites ?? []);
  const catalogRev = useStore((s) => s.catalogRev);
  const results = useMemo(() => runSearch(query, filters), [query, filters, catalogRev]); // eslint-disable-line react-hooks/exhaustive-deps
  const [active, setActive] = useState<string | null>(null);
  const [snap, setSnap] = useState<Snap>('half');
  const [showFilters, setShowFilters] = useState(false);
  const [showSave, setShowSave] = useState(false);
  const [saveName, setSaveName] = useState('');
  const listRef = useRef<HTMLDivElement>(null);
  const nFilters = activeFilterCount(filters);
  const activeResult = results.find((r) => r.property.id === active);

  useEffect(() => { setActive(null); }, [query, filters]);

  // drag-to-snap bottom sheet
  const drag = useRef<{ y: number; snap: Snap } | null>(null);
  const onPointerDown = (e: React.PointerEvent) => {
    drag.current = { y: e.clientY, snap };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onPointerUp = (e: React.PointerEvent) => {
    if (!drag.current) return;
    const dy = e.clientY - drag.current.y;
    const order: Snap[] = ['peek', 'half', 'full'];
    let i = order.indexOf(drag.current.snap);
    if (Math.abs(dy) < 6) i = (i + 1) % 3; // tap cycles
    else if (dy < -40) i = Math.min(2, i + 1);
    else if (dy > 40) i = Math.max(0, i - 1);
    setSnap(order[i]);
    drag.current = null;
  };

  const sheetHeight = { peek: '128px', half: '52%', full: 'calc(100% - 132px)' }[snap];
  const summaryWhere = query.where.label + (query.activity ? ` · ${t(ACTIVITIES[query.activity].label)}` : '');
  const flexOn = query.when.flex > 0;

  return (
    <div className="relative flex-1 overflow-hidden">
      {/* Map */}
      <div className="absolute inset-0 pb-[76px]">
        <MapView
          center={query.where}
          zoom={14}
          markers={results.map((r) => ({ property: r.property }))}
          activeId={active}
          favIds={favourites}
          onMarkerClick={(id) => { setActive(id); setSnap('peek'); }}
          onMapClick={() => setActive(null)}
          circle={query.where.mode === 'city' ? null : { lat: query.where.lat, lng: query.where.lng, radiusKm: filters.radiusKm || query.where.radiusKm }}
          pin={query.where.mode === 'place' ? query.where : null}
          fit
          insets={{ top: 116, bottom: (h) => (snap === 'peek' ? 128 : snap === 'half' ? 0.52 * (h + 76) : h) }}
        />
      </div>

      {/* Top bar */}
      <div className="absolute inset-x-0 top-0 z-[800] space-y-2 px-3 pt-[max(env(safe-area-inset-top),12px)]">
        <div className="flex items-center gap-2">
          <button aria-label={t('Back')} className="icon-btn" onClick={() => nav('/search')}><ChevronLeft size={20} /></button>
          <button onClick={() => nav('/search')} className="min-w-0 flex-1 rounded-xl bg-white px-4 py-2 text-left shadow-card">
            <div className="truncate text-[14px] font-bold text-ink">{summaryWhere}</div>
            <div className="truncate text-[12px] text-ink-500">{dayLabel(query.when.date)} · {query.when.start}{flexOn ? ` ±${query.when.flex}h` : ''} · {query.when.durationHours}h · {describeWhoT(query, t)}</div>
          </button>
          <button aria-label={t('Save search')} className="icon-btn" onClick={() => { setSaveName(summaryWhere); setShowSave(true); }}><Bookmark size={18} /></button>
          <button aria-label={t('Filters')} className="icon-btn relative" onClick={() => setShowFilters(true)}>
            <SlidersHorizontal size={18} />
            {nFilters > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-electric px-1 text-[10px] font-bold text-white">{nFilters}</span>}
          </button>
        </div>
        <div className="no-scrollbar -mx-3 flex gap-2 overflow-x-auto px-3">
          <QuickChip on={filters.instantOnly} onClick={() => setFilters({ ...filters, instantOnly: !filters.instantOnly })}><Zap size={13} /> {t('Instant book')}</QuickChip>
          <QuickChip on={filters.petsAllowed} onClick={() => setFilters({ ...filters, petsAllowed: !filters.petsAllowed })}><PawPrint size={13} /> {t('Pets')}</QuickChip>
          <QuickChip on={filters.sort === 'price'} onClick={() => setFilters({ ...filters, sort: filters.sort === 'price' ? 'recommended' : 'price' })}><ArrowUpDown size={13} /> {t('Cheapest')}</QuickChip>
          <QuickChip on={filters.priceMax <= 20} onClick={() => setFilters({ ...filters, priceMax: filters.priceMax <= 20 ? 60 : 20 })}>{t('Under €20/hr')}</QuickChip>
          {query.activity && <QuickChip on onClick={() => patchQuery((q) => ({ ...q, activity: undefined }))}>{t(ACTIVITIES[query.activity].label)} <X size={13} /></QuickChip>}
        </div>
      </div>

      {/* Selected marker card */}
      {activeResult && (
        <div className="absolute inset-x-3 z-[850]" style={{ bottom: `calc(${sheetHeight} + 88px)` }}>
          <PropertyCard variant="compact" property={activeResult.property} distance={activeResult.distance} date={query.when.date} slotLabel={activeResult.fit ? `${activeResult.fit.start}–${activeResult.fit.end}` : undefined} />
        </div>
      )}

      {/* Bottom sheet */}
      <div className="absolute inset-x-0 z-[820] flex flex-col rounded-t-4xl bg-ivory-50 shadow-float transition-[height] duration-300 ease-out" style={{ height: sheetHeight, bottom: 76 }}>
        <div onPointerDown={onPointerDown} onPointerUp={onPointerUp} className="flex cursor-grab touch-none flex-col items-center px-5 pb-2 pt-2.5" role="button" aria-label={t('Resize results list')}>
          <span className="h-1.5 w-10 rounded-full bg-ivory-300" />
          <div className="mt-2 flex w-full items-center justify-between">
            <h2 className="text-[16px] font-bold text-ink">{t(results.length === 1 ? '1 space available' : '{n} spaces available', { n: results.length })}</h2>
            <span className="text-[12px] text-ink-500">{query.when.recurring ? `${query.when.recurring.count}× ${query.when.recurring.freq}` : `${query.when.start} · ${query.when.durationHours}h`}</span>
          </div>
        </div>
        <div ref={listRef} className="flex-1 space-y-6 overflow-y-auto px-4 pb-6">
          {results.length === 0 && (
            <EmptyState
              icon={<SearchX size={30} />}
              title={t('Nothing free at that time')}
              text={t('Try widening your radius, being flexible on time, or clearing a few filters.')}
              action={
                <div className="flex flex-wrap justify-center gap-2">
                  <button className="btn-soft py-2.5 text-[13px]" onClick={() => patchQuery((q) => ({ ...q, where: { ...q.where, radiusKm: Math.min(10, q.where.radiusKm + 2) } }))}>{t('+2 km radius')}</button>
                  <button className="btn-soft py-2.5 text-[13px]" onClick={() => patchQuery((q) => ({ ...q, when: { ...q.when, flex: 2 } }))}>{t('± 2 hours')}</button>
                  {nFilters > 0 && <button className="btn-soft py-2.5 text-[13px]" onClick={() => setFilters({ ...filters, amenities: [], types: [], activities: [], accessibility: [], instantOnly: false, petsAllowed: false, priceMin: 0, priceMax: 60, capacity: 0, minDuration: 0, radiusKm: 0 })}>{t('Clear filters')}</button>}
                </div>
              }
            />
          )}
          {results.map((r) => {
            const hours = Math.max(query.when.durationHours, r.property.minHours);
            const price = calcPrice(r.property, hours, query.when.recurring?.count ?? 1);
            return (
              <div key={r.property.id} onMouseEnter={() => setActive(r.property.id)} className={`rounded-[28px] transition ${active === r.property.id ? 'ring-2 ring-electric ring-offset-4 ring-offset-ivory-50' : ''}`}>
                <PropertyCard
                  variant="list"
                  property={r.property}
                  distance={r.distance}
                  distanceFrom={query.where.mode === 'place' ? query.where.label : undefined}
                  date={query.when.date}
                  slotLabel={r.fit ? `${r.fit.shifted ? t('Closest:') + ' ' : ''}${r.fit.start}–${r.fit.end}${hours > query.when.durationHours ? ` (min ${r.property.minHours}h)` : ''}` : undefined}
                  totalPrice={price.grandTotal}
                  totalHours={price.occurrences > 1 ? undefined : hours}
                  badge={r.recurringFit !== undefined && r.recurringFit < 1 ? t('{n}% of dates free', { n: Math.round(r.recurringFit * 100) }) : undefined}
                />
              </div>
            );
          })}
        </div>
      </div>

      {/* Map / list toggle */}
      <div className="absolute inset-x-0 z-[860] flex justify-center" style={{ bottom: 92 }}>
        <button onClick={() => setSnap(snap === 'full' ? 'peek' : 'full')} className="inline-flex items-center gap-2 rounded-full bg-ink px-4 py-2.5 text-[13px] font-bold text-white shadow-float">
          {snap === 'full' ? <><MapIcon size={15} /> {t('Map')}</> : <><List size={15} /> {t('List')}</>}
        </button>
      </div>

      {showFilters && <FiltersSheet open onClose={() => setShowFilters(false)} />}
      <Sheet open={showSave} onClose={() => setShowSave(false)} title={t('Save this search')} footer={<button className="btn-primary w-full" disabled={!saveName.trim()} onClick={() => { saveSearch(saveName.trim()); setShowSave(false); }}>{t('Save search')}</button>}>
        <p className="mb-3 text-[14px] text-ink-500">{t('Saved searches keep your place, time, guests and filters. Find them in Favourites → Searches.')}</p>
        <input className="input" value={saveName} onChange={(e) => setSaveName(e.target.value)} placeholder={t('e.g. Tuesday focus session')} autoFocus />
      </Sheet>
    </div>
  );
}

function QuickChip({ on, onClick, children }: { on: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className={`inline-flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-[13px] font-semibold shadow-card transition active:scale-95 ${on ? 'bg-ink text-white' : 'bg-white text-ink'}`}>
      {children}
    </button>
  );
}
