import { Link, useLocation } from 'react-router-dom';
import { Inbox as InboxIcon } from 'lucide-react';
import { useApi } from '@/lib/api';
import { Avatar, EmptyState, StatusPill, partnerColor } from '@/components/ui';
import { useT } from '@/i18n';
import type { Conversation } from '@/types';

export const timeAgo = (at: number) => {
  const m = Math.round((Date.now() - at) / 60000);
  if (m < 1) return '•';
  if (m < 60) return `${m} min`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} h`;
  const d = Math.round(h / 24);
  return d < 7 ? `${d} j`.replace(' j', document.documentElement.lang === 'fr' ? ' j' : ' d') : new Date(at).toLocaleDateString(document.documentElement.lang === 'fr' ? 'fr-FR' : 'en-GB', { day: 'numeric', month: 'short' });
};

export function ConversationList({ convs, base, showKind }: { convs: Conversation[]; base: string; showKind?: boolean }) {
  const t = useT();
  return (
    <ul className="divide-y divide-ivory-200">
      {convs.map((c) => (
        <li key={c.id}>
          <Link to={`${base}/${c.id}`} className="flex items-center gap-3 py-3.5">
            <Avatar name={c.title} src={c.counterpartAvatar || undefined} color={partnerColor(c.title)} size={48} />
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className={`truncate text-[15px] ${c.unread ? 'font-bold' : 'font-semibold'} text-ink`}>{c.title}</span>
                <span className="shrink-0 text-[12px] text-ink-500">{c.last ? timeAgo(c.last.at) : ''}</span>
              </div>
              <div className="flex items-center gap-1.5 truncate text-[12.5px] text-ink-500">
                {showKind && <StatusPill tone={c.kind === 'owner' ? 'info' : 'muted'}>{t(c.kind === 'owner' ? 'Owner' : 'Guest')}</StatusPill>}
                <span className="truncate">{c.subtitle}</span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className={`truncate text-[13.5px] ${c.unread ? 'font-semibold text-ink' : 'text-ink-600'}`}>{c.last ? (c.last.senderRole === 'system' ? '• ' : '') + c.last.body : t('Start the conversation')}</span>
                {c.unread > 0 && <span className="grid h-5 min-w-5 shrink-0 place-items-center rounded-full bg-electric px-1.5 text-[11px] font-bold text-white">{c.unread}</span>}
              </div>
            </div>
          </Link>
        </li>
      ))}
    </ul>
  );
}

/** Owner & manager inboxes. */
export default function InboxList() {
  const t = useT();
  const { pathname } = useLocation();
  const base = pathname.startsWith('/owner') ? '/owner/messages' : '/manager/messages';
  const { data } = useApi<Conversation[]>('/api/conversations');
  return (
    <div className="page">
      <header className="px-5 pb-3 pt-[max(env(safe-area-inset-top),20px)]">
        <h1 className="h-display text-[30px]">{t(base.startsWith('/owner') ? 'Messages' : 'Inbox')}</h1>
        <p className="text-[13px] text-ink-500">{t(base.startsWith('/owner') ? 'Conversations with the managers of your properties.' : 'Guest enquiries and owner conversations for your assigned properties only.')}</p>
      </header>
      <div className="px-5">
        {data && data.length === 0 && <EmptyState icon={<InboxIcon size={30} />} title={t('No conversations yet')} text={t('Messages about your properties will appear here.')} />}
        <ConversationList convs={data ?? []} base={base} showKind={!base.startsWith('/owner')} />
      </div>
    </div>
  );
}
