import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowUp, Bot, CalendarDays, Check, Clock, Loader2, Map as MapIcon, MapPin, Sparkles, Users, X, Info } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { PageHeader } from '@/components/ui';
import { Img } from '@/components/Img';
import { EXAMPLE_PROMPTS, matchProperties, parseRequest, type Match, type ParsedIntent } from '@/lib/nlu';
import { ACCESSIBILITY, ACTIVITIES, AMENITIES } from '@/data/vocab';
import { PARIS_CENTER } from '@/data/places';
import { dayLabel, addDays, todayISO, toMin, nowMinutes, toHHMM } from '@/lib/time';
import { eur, calcPrice } from '@/lib/pricing';
import { useT, type T } from '@/i18n';
import type { SearchQuery } from '@/types';

type Turn = { role: 'user'; text: string } | { role: 'ai'; intent: ParsedIntent; ask?: Ask; matches?: Match[]; engine: 'claude' | 'rules' };
type Ask = { field: 'date' | 'time' | 'location' | 'adults'; question: string; options: string[] };

const EXAMPLES = [
  EXAMPLE_PROMPTS[0],
  'I have three hours between meetings near République and need somewhere quiet with Wi-Fi.',
  'Somewhere to bake a cake with my daughter on Sunday morning near Nation',
  'Rehearsal space for my band of 4, Friday 6pm for 3 hours',
];

// Keep the conversation while the guest opens a listing and comes back.
let memory: { turns: Turn[]; intent?: ParsedIntent } = { turns: [] };

export default function AssistantPage() {
  const t = useT();
  const nav = useNavigate();
  const [params] = useSearchParams();
  const { user, query, setQuery, commitSearch } = useStore();
  const catalogRev = useStore((s) => s.catalogRev);
  const [turns, setTurns] = useState<Turn[]>(() => (params.get('q') ? [] : memory.turns));
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [intent, setIntent] = useState<ParsedIntent | undefined>(() => (params.get('q') ? undefined : memory.intent));
  useEffect(() => { memory = { turns, intent }; }, [turns, intent]);
  const endRef = useRef<HTMLDivElement>(null);
  const started = useRef(false);
  const prefs = user!.prefs;

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, [turns, busy]);
  useEffect(() => {
    const q = params.get('q');
    if (q && !started.current) { started.current = true; void submit(q); }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  // live re-match when the catalogue changes (e.g. a manager just opened new hours)
  useEffect(() => {
    setTurns((ts) => ts.map((x) => (x.role === 'ai' && x.matches ? { ...x, matches: matchProperties(x.intent, resolveAnchor(x.intent)) } : x)));
  }, [catalogRev]); // eslint-disable-line react-hooks/exhaustive-deps

  function resolveAnchor(it: ParsedIntent) {
    if (it.location) return { lat: it.location.lat, lng: it.location.lng, label: it.location.label };
    const tag = it.locationText === 'home' ? 'home' : it.locationText === 'work' ? 'work' : null;
    const loc = tag && prefs.locations.find((l) => l.tag === tag);
    if (loc) return { lat: loc.lat, lng: loc.lng, label: loc.label };
    if (it.locationText) return { ...PARIS_CENTER, label: t('central Paris') };
    return undefined;
  }

  async function submit(raw: string) {
    const msg = raw.trim();
    if (!msg || busy) return;
    setText('');
    setTurns((x) => [...x, { role: 'user', text: msg }]);
    setBusy(true);
    const { intent: it, engine } = await parseRequest(msg, intent);
    for (const a of prefs.accessibility) if (!it.accessibility.includes(a)) it.accessibility.push(a);
    if (it.location || it.locationText) it.missing = it.missing.filter((m) => m !== 'location');
    setIntent(it);
    // Children mentioned but no adult count given: ask instead of silently assuming one adult.
    const wasUnconfirmed = !!intent?.adultsUnconfirmed;
    it.adultsUnconfirmed = false;
    if (it.children > 0 && (it.assumptions.includes('Assumed 1 adult') || it.assumptions.includes('Assumed 2 adults'))) it.adultsUnconfirmed = true;
    else if (wasUnconfirmed && !/\badults?\b|\badulte/i.test(msg)) it.adultsUnconfirmed = true;
    const ask = nextQuestion(it, prefs.locations.map((l) => l.name), t);
    setTurns((x) => [...x, { role: 'ai', intent: it, ask, matches: ask ? undefined : matchProperties(it, resolveAnchor(it)), engine }]);
    setBusy(false);
  }

  /** Carry the confirmed request (who, when, where, purpose) into the shared search state so the
   *  results, listing, booking form and confirmation all use the same guest details. */
  const syncQuery = (it: ParsedIntent) => {
    const a = resolveAnchor(it) ?? { ...PARIS_CENTER, label: 'Paris' };
    const q: SearchQuery = {
      where: { mode: 'place', label: a.label, lat: a.lat, lng: a.lng, radiusKm: 3 },
      when: { date: it.date ?? todayISO(), start: it.start ?? query.when.start, durationHours: Math.min(12, it.durationHours ?? 3), flex: 1, recurring: null },
      who: { adults: Math.max(1, it.adults), children: it.children, infants: it.infants, pets: it.pets, accessibility: it.accessibility },
      activity: it.activities[0],
    };
    setQuery(q);
    commitSearch();
  };
  const toSearch = (it: ParsedIntent) => { syncQuery(it); nav('/results'); };

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      <PageHeader back title={<span className="flex items-center gap-2">{t('SpaceTime Match')}</span>} sub={t('Describe your plans in your own words')} right={turns.length > 0 ? <button onClick={() => { setTurns([]); setIntent(undefined); }} className="text-[13px] font-semibold text-electric-600">{t('New')}</button> : undefined} />
      <div className="flex-1 space-y-4 overflow-y-auto px-4 pb-6 pt-1">
        {turns.length === 0 && (
          <div className="animate-fade-up">
            <div className="clip-corner relative overflow-hidden bg-ink p-5 text-white">
              <div className="pointer-events-none absolute -right-10 -top-10 h-36 w-36 rounded-full bg-electric/50 blur-2xl" />
              <Sparkles className="relative text-lavender" />
              <h2 className="relative mt-2 text-[23px] font-bold leading-tight tracking-tight">{t('Tell us what you need.')}<br />{t('We’ll find the space.')}</h2>
              <p className="relative mt-2 text-[13px] leading-relaxed text-ice-200">{t('Say where, when, who’s coming and what you need (shower, bed, kitchen, quiet…). I’ll ask if anything’s missing.')}</p>
            </div>
            <p className="mb-2 mt-5 px-1 text-[12px] font-bold uppercase tracking-wider text-ink-500">{t('Try an example')}</p>
            <div className="space-y-2">{EXAMPLES.map((e) => <button key={e} onClick={() => submit(e)} className="w-full rounded-xl bg-white p-3.5 text-left text-[13.5px] leading-snug text-ink-700 shadow-card transition active:scale-[.99]">“{e}”</button>)}</div>
            <p className="mt-5 flex items-start gap-2 px-1 text-[12.5px] leading-snug text-ink-500"><Info size={14} className="mt-0.5 shrink-0" /> {t('Matches use live listing data — amenities, permitted uses and hours opened by each Space Partner. Nothing is invented.')}</p>
          </div>
        )}
        {turns.map((x, i) => x.role === 'user'
          ? <div key={i} className="flex justify-end"><div className="max-w-[85%] rounded-2xl rounded-br-md bg-ink px-4 py-3 text-[14.5px] leading-snug text-white">{x.text}</div></div>
          : <AiTurn key={i} turn={x} latest={i === turns.length - 1} onAnswer={submit} onSearch={() => toSearch(x.intent)} onOpen={() => syncQuery(x.intent)} anchorLabel={resolveAnchor(x.intent)?.label} />)}
        {busy && <div className="flex items-center gap-2 text-[13px] font-semibold text-ink-500"><span className="grid h-8 w-8 place-items-center rounded-full bg-ice-100 text-ink"><Bot size={16} /></span><Loader2 size={15} className="animate-spin" /> {t('Reading your request…')}</div>}
        <div ref={endRef} />
      </div>
      <form onSubmit={(e) => { e.preventDefault(); void submit(text); }} className="border-t border-ivory-200 bg-white px-3 pb-[max(env(safe-area-inset-bottom),10px)] pt-2.5">
        <div className="flex items-end gap-2">
          <textarea rows={1} value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void submit(text); } }} placeholder={intent?.missing.length ? t('Answer, or add more details…') : t('e.g. Quiet desk near Bastille, 10–2')} className="input max-h-28 min-h-[48px] flex-1 resize-none rounded-3xl py-3" aria-label={t('Describe what you need…')} />
          <button type="submit" disabled={!text.trim() || busy} aria-label={t('Send')} className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-electric text-white disabled:opacity-40"><ArrowUp size={20} /></button>
        </div>
      </form>
    </div>
  );
}

function nextQuestion(it: ParsedIntent, locNames: string[], t: T): Ask | undefined {
  if (it.missing.includes('date')) {
    const days = [0, 1, 2, 3].map((n) => addDays(todayISO(), n));
    return { field: 'date', question: t('Which day is this for?'), options: days.map((d, i) => (i === 0 ? 'today' : i === 1 ? 'tomorrow' : new Date(d + 'T12:00').toLocaleDateString('en-GB', { weekday: 'long' }).toLowerCase())) };
  }
  if (it.missing.includes('time')) return { field: 'time', question: t('Roughly what time would you like to start?'), options: [`now (${toHHMM(Math.ceil(nowMinutes() / 30) * 30)})`, 'at 9:00', 'at 12:00', 'at 14:00', 'at 18:00'] };
  if (it.missing.includes('location')) return { field: 'location', question: t('Whereabouts in Paris?'), options: [...locNames.slice(0, 2).map((n) => `near ${n.toLowerCase()}`), 'Gare de Lyon', 'Gare du Nord', 'Châtelet', 'anywhere central'] };
  if (it.adultsUnconfirmed) return { field: 'adults', question: t('How many adults are coming with the {n} children?', { n: it.children }), options: ['1 adult', '2 adults', '3 adults'] };
  return undefined;
}

const OPTION_LABEL: Record<string, string> = { today: 'Today', tomorrow: 'Tomorrow', 'near home': 'Near home', 'near work': 'Near work', 'anywhere central': 'Anywhere central' };
const WEEKDAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
function optionLabel(o: string, t: T) {
  if (OPTION_LABEL[o]) return t(OPTION_LABEL[o]);
  const now = /^now \((.+)\)$/.exec(o);
  if (now) return t('Now ({t})', { t: now[1] });
  if (o.startsWith('at ')) return t('At {t}', { t: o.slice(3) });
  const wd = WEEKDAYS.indexOf(o.toLowerCase());
  if (wd >= 0) { const d = new Date(2026, 0, 4 + wd); const s = d.toLocaleDateString(document.documentElement.lang === 'fr' ? 'fr-FR' : 'en-GB', { weekday: 'long' }); return s.charAt(0).toUpperCase() + s.slice(1); }
  if (o.startsWith('near ')) return t('Near {place}', { place: o.slice(5) });
  const ad = /^(\d) adults?$/.exec(o);
  if (ad) return t(ad[1] === '1' ? '1 adult' : '{n} adults', { n: ad[1] });
  return o;
}

function AiTurn({ turn, latest, onAnswer, onSearch, onOpen, anchorLabel }: { turn: Extract<Turn, { role: 'ai' }>; latest: boolean; onAnswer: (s: string) => void; onSearch: () => void; onOpen: () => void; anchorLabel?: string }) {
  const t = useT();
  const it = turn.intent;
  const chips: { icon: React.ReactNode; label: string; missing?: boolean }[] = [
    { icon: <MapPin size={13} />, label: it.location?.label ?? (it.locationText ? (it.locationText === 'home' || it.locationText === 'work' ? t(it.locationText === 'home' ? 'Near home' : 'Near work') : it.locationText) : t('Where?')), missing: !it.location && !it.locationText },
    { icon: <CalendarDays size={13} />, label: it.date ? dayLabel(it.date) : t('Which day?'), missing: !it.date },
    { icon: <Clock size={13} />, label: it.start ? `${it.start}${it.end ? `–${it.end}` : ''}${it.durationHours ? ` (${it.durationHours} h)` : ''}` : t('What time?'), missing: !it.start },
    { icon: <Users size={13} />, missing: !!it.adultsUnconfirmed, label: [it.adultsUnconfirmed ? t('Adults?') : `${it.adults} ${t('adult(s)')}`, it.children && `${it.children} ${t('child(ren)')}`, it.infants && `${it.infants} ${t('infant')}`, it.pets && `${it.pets} ${t('pet')}`].filter(Boolean).join(', ') },
    ...it.needs.map((n) => ({ icon: <Check size={13} />, label: t(AMENITIES[n]?.label ?? n) })),
    ...(it.quiet ? [{ icon: <Check size={13} />, label: t('Quiet space') }] : []),
    ...it.activities.map((a) => ({ icon: <Sparkles size={13} />, label: t(ACTIVITIES[a].label) })),
    ...it.accessibility.map((a) => ({ icon: <Check size={13} />, label: t(ACCESSIBILITY[a].label) })),
    ...(it.budgetMax ? [{ icon: <Check size={13} />, label: `≤ €${it.budgetMax}/h` }] : []),
  ];
  return (
    <div className="flex gap-2.5 animate-fade-up">
      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-ice-100 text-ink"><Bot size={16} /></span>
      <div className="min-w-0 flex-1 space-y-3">
        <div className="rounded-2xl rounded-tl-md bg-white p-4 shadow-card">
          <div className="flex items-center justify-between"><p className="text-[12px] font-bold uppercase tracking-wider text-ink-500">{t('Here’s what I understood')}</p><span className="text-[11.5px] font-semibold text-ink-500">{turn.engine === 'claude' ? 'Claude' : t('Rule-based parser')}</span></div>
          <div className="mt-2 flex flex-wrap gap-1.5">{chips.map((c, i) => <span key={i} className={`inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-[12.5px] font-semibold ${c.missing ? 'border border-dashed border-electric bg-electric-50 text-electric-700' : 'bg-ice-100 text-ink'}`}>{c.icon}{c.label}</span>)}</div>
          {it.assumptions.filter((a) => !(it.adultsUnconfirmed && /^Assumed \d adults?$/.test(a))).length > 0 && <p className="mt-2 text-[12.5px] text-ink-500">{t('Assumptions:')} {it.assumptions.filter((a) => !(it.adultsUnconfirmed && /^Assumed \d adults?$/.test(a))).map((a) => t(a)).join(' · ')}</p>}
          {turn.ask && (
            <div className="mt-3 border-t border-ivory-200 pt-3">
              <p className="text-[14.5px] font-semibold text-ink">{turn.ask.question}</p>
              {latest && <div className="mt-2 flex flex-wrap gap-2">{turn.ask.options.map((o) => <button key={o} onClick={() => onAnswer(o)} className="chip-off py-1.5">{optionLabel(o, t)}</button>)}</div>}
            </div>
          )}
        </div>
        {turn.matches && (
          <>
            <p className="px-1 text-[14px] text-ink-700">{turn.matches.length ? t('{n} spaces found{near}. Spaces meeting all your must-haves come first.', { n: turn.matches.length, near: anchorLabel ? ` ${t('near {place}', { place: anchorLabel })}` : '' }) : t('No space fits all of that yet. Try loosening a requirement or another time.')}</p>
            {turn.matches.length > 0 && <p className="px-1 text-[12.5px] text-ink-500">{t('Must-haves: the time you asked for, your group size, requested amenities and permitted use. Distance and quiet are preferences.')}</p>}
            {turn.matches.map((m) => <MatchCard key={m.property.id} m={m} it={it} onOpen={onOpen} />)}
            {turn.matches.length > 0 && <button onClick={onSearch} className="btn-ghost w-full py-3 text-[14px]"><MapIcon size={16} /> {t('See these on the map')}</button>}
          </>
        )}
      </div>
    </div>
  );
}

function MatchCard({ m, it, onOpen }: { m: Match; it: ParsedIntent; onOpen: () => void }) {
  const t = useT();
  const p = m.property;
  const hours = m.window ? Math.max(1, (toMin(m.window.end) - toMin(m.window.start)) / 60) : Math.max(p.minHours, it.durationHours ?? 3);
  const price = calcPrice(p, hours);
  const bookUrl = `/book/${p.id}?date=${it.date ?? todayISO()}${m.window ? `&start=${m.window.start}` : ''}&hours=${hours}`;
  const isNew = !!p.publishedAt && Date.now() - p.publishedAt < 7 * 86400000 && !p.reviewCount;
  const good = m.checks.filter((c) => c.ok);
  const missing = [...m.checks.filter((c) => !c.ok && c.must), ...m.checks.filter((c) => !c.ok && !c.must)];
  const all = m.mustMet === m.mustTotal;
  return (
    <div className="card overflow-hidden">
      <Link to={`/space/${p.id}`} onClick={onOpen} className="block p-3">
        <div className="flex gap-3">
          <div className="relative shrink-0">
            <Img src={p.images[0]} alt={p.shortTitle} className="h-20 w-20 rounded-xl" />
            {isNew && <span className="absolute -bottom-1 left-1 rounded-md bg-lavender px-1.5 py-0.5 text-[10px] font-bold uppercase text-ink">{t('New')}</span>}
          </div>
          <div className="min-w-0 flex-1">
            <div className={`inline-flex rounded-md px-2 py-0.5 text-[12px] font-bold ${all ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-800'}`}>{t('Meets {a} of {b} must-haves', { a: m.mustMet, b: m.mustTotal })}</div>
            <div className="mt-1 text-[15px] font-bold leading-snug text-ink">{p.shortTitle}</div>
            <div className="text-[13px] text-ink-600"><b className="text-ink">{eur(price.guestTotal)}</b> {t('total for {h} h, incl. fees', { h: hours })} · {eur(p.pricePerHour)}/h</div>
          </div>
        </div>
        <div className="mt-2.5 grid gap-1">
          <div className="text-[12px] font-semibold text-ink-500">{t('Why this matches')}</div>
          <ul className="space-y-0.5">{good.slice(0, 5).map((c, i) => <li key={i} className="flex items-start gap-1.5 text-[13px] text-ink-700"><Check size={13} className="mt-0.5 shrink-0 text-emerald-600" strokeWidth={3} /><span>{c.label}</span></li>)}</ul>
          {missing.length > 0 && <>
            <div className="mt-1 text-[12px] font-semibold text-ink-500">{t('Missing')}</div>
            <ul className="space-y-0.5">{missing.map((c, i) => <li key={i} className="flex items-start gap-1.5 text-[13px] text-ink-700"><X size={13} className="mt-0.5 shrink-0 text-rose-500" strokeWidth={3} /><span>{c.label}{c.must ? '' : ` (${t('preference')})`}</span></li>)}</ul>
          </>}
        </div>
      </Link>
      <div className="flex border-t border-ivory-200">
        <Link to={`/space/${p.id}`} onClick={onOpen} className="flex min-h-[48px] flex-1 items-center justify-center text-[14px] font-semibold text-ink">{t('Details')}</Link>
        <Link to={bookUrl} onClick={onOpen} className="flex min-h-[48px] flex-1 items-center justify-center border-l border-ivory-200 text-[14px] font-bold text-electric-600">{t('Book')} {m.window ? `${m.window.start}–${m.window.end}` : ''}</Link>
      </div>
    </div>
  );
}
