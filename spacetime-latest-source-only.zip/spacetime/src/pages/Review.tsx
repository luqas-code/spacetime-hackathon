import { useState } from 'react';
import { BadgeCheck, CheckCircle2, ExternalLink, FileText, XCircle } from 'lucide-react';
import { api, useApi } from '@/lib/api';
import { DashHeader, ListingStatusPill, Panel, Spinner } from '@/components/dash';
import { Img } from '@/components/Img';
import { ACTIVITIES } from '@/data/vocab';
import { useT } from '@/i18n';
import type { ComplianceReview, Property } from '@/types';

export default function ReviewPage() {
  const t = useT();
  const { data, reload } = useApi<{ pending: Property[]; recent: { id: string; title: string; status: Property['status']; ownerName?: string; review?: ComplianceReview }[] }>('/api/review/queue');
  const [notes, setNotes] = useState<Record<string, string>>({});
  const decide = async (id: string, decision: 'approve' | 'changes') => { await api(`/api/review/${id}`, { body: { decision, notes: notes[id] ?? '' } }); reload(); };
  return (
    <div className="page">
      <DashHeader title={t('Compliance review')} sub={t('Human review of listings that need authorisation checks')} profileLink="/review/profile" />
      {!data ? <Spinner /> : (
        <div className="space-y-6 px-4 pt-4">
          <Panel title={t('Waiting for review ({n})', { n: data.pending.length })}>
            {data.pending.length === 0 && <p className="card p-4 text-[13px] text-ink-500">{t('Nothing waiting.')}</p>}
            <div className="space-y-3">{data.pending.map((p) => (
              <div key={p.id} className="card overflow-hidden">
                <div className="flex gap-3 p-3"><Img src={p.images[0] ?? ''} alt="" className="h-16 w-16 rounded-lg" /><div className="min-w-0"><div className="text-[15px] font-bold">{p.title}</div><div className="text-[12px] text-ink-500">{p.address} · {p.ownerName}</div><div className="mt-1 flex flex-wrap gap-1">{p.activities.map((a) => <span key={a} className="rounded bg-ice-100 px-1.5 text-[11px] font-semibold">{t(ACTIVITIES[a].label)}</span>)}</div></div></div>
                <div className="border-t border-ivory-200 p-3 text-[12.5px]">
                  <div className="grid grid-cols-2 gap-1">{p.compliance.review?.checks.map((c) => <div key={c.key} className="flex items-center gap-1.5">{c.ok ? <CheckCircle2 size={13} className="text-emerald-600" /> : <XCircle size={13} className="text-rose-500" />}{c.key.replace(/_/g, ' ')}</div>)}</div>
                  <div className="mt-2 text-ink-600">{t('Registration')}: <b>{p.compliance.registrationNumber || '—'}</b> · {t('Change of use')}: <b>{p.compliance.changeOfUse}</b> · DPE <b>{p.compliance.dpeGrade || '—'}</b></div>
                  <ul className="mt-2 space-y-1">{p.compliance.documents.map((d) => <li key={d.id} className="flex items-center gap-1.5">{d.source === 'on_file' ? <BadgeCheck size={13} className="text-emerald-600" /> : <FileText size={13} />}{d.url ? <a href={d.url} target="_blank" rel="noreferrer" className="text-electric-600 underline">{d.name} <ExternalLink size={11} className="inline" /></a> : d.name}</li>)}</ul>
                  {p.compliance.restrictions && <p className="mt-2 text-ink-600">{p.compliance.restrictions}</p>}
                  <textarea className="input mt-3 resize-none text-[13px]" rows={2} placeholder={t('Reviewer notes')} value={notes[p.id] ?? ''} onChange={(e) => setNotes({ ...notes, [p.id]: e.target.value })} />
                  <div className="mt-2 grid grid-cols-2 gap-2"><button className="btn-ghost py-2.5 text-[13px]" onClick={() => decide(p.id, 'changes')}>{t('Request changes')}</button><button className="btn-accent py-2.5 text-[13px]" onClick={() => decide(p.id, 'approve')}>{t('Approve')}</button></div>
                </div>
              </div>
            ))}</div>
          </Panel>
          <Panel title={t('Recent decisions')}>
            <div className="card divide-y divide-ivory-200">{data.recent.map((r) => <div key={r.id} className="flex items-center gap-2 px-4 py-3 text-[13px]"><span className="min-w-0 flex-1 truncate font-semibold">{r.title}</span><ListingStatusPill s={r.status} /><span className="text-[11px] text-ink-500">{r.review?.basis === 'verified_file' ? t('verified file') : t('manual')}</span></div>)}</div>
          </Panel>
          <div className="h-4" />
        </div>
      )}
    </div>
  );
}
