import { useState, type ReactNode } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Bookmark, CalendarDays, ChevronRight, Clock, Crosshair, History, LocateFixed, MapPin, Repeat, Search as SearchIcon, Sparkles, Users, Wand2 } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { Logo } from '@/components/Logo';
import { Avatar, Chip, Segmented, Stepper, Toggle } from '@/components/ui';
import { PlaceSearch } from '@/components/PlaceSearch';
import { MapView } from '@/components/MapView';
import { CITIES, PARIS_CENTER } from '@/data/places';
import { ACCESSIBILITY, ACTIVITIES } from '@/data/vocab';
import { TIME_OPTIONS, dayLabel, nextDays, shortDate, toHHMM, toMin, todayISO } from '@/lib/time';
import { DEFAULT_QUERY, totalGuests } from '@/lib/search';
import type { Accessibility, Activity, SearchQuery } from '@/types';
import { distanceMeters } from '@/lib/geo';
import { useT, type T } from '@/i18n';

type Panel = 'where' | 'when' | 'who' | null;

export function describeWhoT(q: SearchQuery, t: T) {
  const g = totalGuests(q);
  const parts = [t(g === 1 ? '1 guest' : '{n} guests', { n: g })];
  if (q.who.infants) parts.push(t('{n} infant(s)', { n: q.who.infants }));
  if (q.who.pets) parts.push(t('{n} pet(s)', { n: q.who.pets }));
  return parts.join(', ');
}

export default function SearchPage() {
  const t = useT();
  const nav = useNavigate();
  const { query, setQuery, commitSearch, user, recentSearches, setFilters, filters } = useStore();
  const [panel, setPanel] = useState<Panel>('where');
  const [nl, setNl] = useState('');
  const savedSearches = user?.prefs.savedSearches ?? [];
  const go = (q?: SearchQuery) => {
    if (q) setQuery(q);
    commitSearch();
    nav('/results');
  };
  const firstName = user?.name.split(' ')[0] ?? '';
  const end = toHHMM(toMin(query.when.start) + query.when.durationHours * 60);
  const fresh = (q: SearchQuery) => ({ ...q, when: { ...q.when, date: q.when.date < todayISO() ? todayISO() : q.when.date } });

  return (
    <div className="page">
      <div className="relative overflow-hidden bg-ink px-5 pb-20 pt-[max(env(safe-area-inset-top),18px)] text-white">
        <div className="pointer-events-none absolute -right-16 -top-10 h-56 w-56 rounded-full bg-electric/45 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -left-10 h-56 w-56 rounded-full bg-lavender/30 blur-3xl" />
        <div className="relative flex items-center justify-between">
          <Logo light size={28} />
          <Link to="/profile" aria-label={t('Profile')} className="-m-1 grid h-11 w-11 place-items-center rounded-full"><Avatar name={user?.name ?? ''} src={user?.avatarUrl || undefined} size={36} /></Link>
        </div>
        <h1 className="relative mt-7 text-[34px] font-bold leading-[1.02] tracking-[-0.03em]">
          {t('Your space.')}<br /><span className="text-electric-400">{t('Your time.')}</span>
        </h1>
        <p className="relative mt-2 max-w-[320px] text-[14px] leading-relaxed text-ice-200">
          {firstName ? `${firstName}, ` : ''}{t('book a private apartment for a few hours — to rest, work, meet, cook or create.')}
        </p>
      </div>

      <div className="relative -mt-14 space-y-4 px-4">
        <form onSubmit={(e) => { e.preventDefault(); nav(`/assistant${nl.trim() ? `?q=${encodeURIComponent(nl.trim())}` : ''}`); }} className="card flex items-center gap-2 p-2 pl-4">
          <Sparkles size={18} className="shrink-0 text-electric" />
          <input value={nl} onChange={(e) => setNl(e.target.value)} placeholder={t('Describe what you need…')} className="min-w-0 flex-1 bg-transparent py-2 text-[15px] outline-none placeholder:text-ink-500/70" aria-label={t('Describe what you need…')} />
          <button className="inline-flex items-center gap-1.5 rounded-lg bg-ink px-3 py-2 text-[13px] font-semibold text-white" type="submit"><Wand2 size={15} /> {t('Match')}</button>
        </form>

        <div className="space-y-3">
          <PanelCard id="where" open={panel} setOpen={setPanel} title={t('Where?')} icon={<MapPin size={18} />} summary={query.where.label + (query.where.mode !== 'city' ? ` · ${query.where.radiusKm} km` : '')}><WherePanel /></PanelCard>
          <PanelCard id="when" open={panel} setOpen={setPanel} title={t('When?')} icon={<CalendarDays size={18} />} summary={`${dayLabel(query.when.date)} · ${query.when.start}–${end}${query.when.flex ? ` (±${query.when.flex}h)` : ''}${query.when.recurring ? ` · ${t('repeats')}` : ''}`}><WhenPanel /></PanelCard>
          <PanelCard id="who" open={panel} setOpen={setPanel} title={t('Who?')} icon={<Users size={18} />} summary={describeWhoT(query, t) + (query.who.accessibility.length ? ` · ${t('{n} access need(s)', { n: query.who.accessibility.length })}` : '')}><WhoPanel /></PanelCard>
        </div>

        <div className="flex items-center gap-3 pt-1">
          <button className="text-[14px] font-semibold text-ink-500 underline underline-offset-4" onClick={() => { setQuery(DEFAULT_QUERY()); setFilters({ ...filters, activities: [] }); setPanel('where'); }}>{t('Clear all')}</button>
          <button className="btn-primary flex-1 py-4 text-[16px]" onClick={() => go()}><SearchIcon size={19} /> {t('Search spaces')}</button>
        </div>

        <section className="pt-4">
          <h2 className="section-title mb-3">{t('Browse by purpose')}</h2>
          <div className="no-scrollbar -mx-4 flex gap-2.5 overflow-x-auto px-4 pb-1">
            {(['rest', 'layover', 'work', 'meeting', 'family', 'cooking', 'creative', 'rehearsal', 'party', 'wellness'] as Activity[]).map((a) => {
              const A = ACTIVITIES[a];
              return (
                <button key={a} onClick={() => go({ ...query, activity: a })} className="flex w-[86px] shrink-0 flex-col items-center gap-2 rounded-xl bg-white p-3 shadow-card transition active:scale-95">
                  <span className={`grid h-11 w-11 place-items-center rounded-lg ${A.tint}`}><A.icon size={20} /></span>
                  <span className="text-center text-[12.5px] font-semibold leading-tight text-ink">{t(A.label)}</span>
                </button>
              );
            })}
          </div>
        </section>

        {(savedSearches.length > 0 || recentSearches.length > 0) && (
          <section className="pt-3">
            <h2 className="section-title mb-3">{t('Pick up where you left off')}</h2>
            <div className="space-y-2">
              {savedSearches.slice(0, 3).map((s) => <SearchRow key={s.id} icon={<Bookmark size={16} className="fill-electric text-electric" />} title={s.name} q={s.query} onClick={() => { if (s.filters) setFilters(s.filters); go(fresh(s.query)); }} />)}
              {recentSearches.slice(0, 3).map((q, i) => <SearchRow key={i} icon={<History size={16} />} title={q.where.label + (q.activity ? ` · ${t(ACTIVITIES[q.activity].label)}` : '')} q={q} onClick={() => go(fresh(q))} />)}
            </div>
          </section>
        )}
        <div className="h-4" />
      </div>
    </div>
  );
}

function SearchRow({ icon, title, q, onClick }: { icon: ReactNode; title: string; q: SearchQuery; onClick: () => void }) {
  const t = useT();
  return (
    <button onClick={onClick} className="flex w-full items-center gap-3 rounded-xl bg-white px-4 py-3 text-left shadow-card">
      <span className="grid h-9 w-9 place-items-center rounded-lg bg-ice-100 text-ink">{icon}</span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[14px] font-semibold text-ink">{title}</span>
        <span className="block truncate text-[12px] text-ink-500">{dayLabel(q.when.date < todayISO() ? todayISO() : q.when.date)} · {q.when.start} · {q.when.durationHours}h · {describeWhoT(q, t)}</span>
      </span>
      <ChevronRight size={18} className="text-ink-500" />
    </button>
  );
}

function PanelCard({ id, open, setOpen, title, icon, summary, children }: { id: Exclude<Panel, null>; open: Panel; setOpen: (p: Panel) => void; title: string; icon: ReactNode; summary: string; children: ReactNode }) {
  const isOpen = open === id;
  return (
    <div className={`card transition-all ${isOpen ? 'p-4' : 'p-0'}`}>
      {isOpen ? (
        <>
          <div className="mb-3 flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-ink text-white">{icon}</span>
            <h2 className="h-display text-[24px]">{title}</h2>
          </div>
          {children}
        </>
      ) : (
        <button onClick={() => setOpen(id)} className="flex w-full items-center justify-between gap-3 px-4 py-4 text-left">
          <span className="flex items-center gap-2 text-[14px] font-semibold text-ink-500">{icon}{title.replace(/[?？]/, '').trim()}</span>
          <span className="truncate text-[14px] font-semibold text-ink">{summary}</span>
        </button>
      )}
    </div>
  );
}

function WherePanel() {
  const t = useT();
  const { query, patchQuery, user } = useStore();
  const w = query.where;
  const set = (patch: Partial<SearchQuery['where']>) => patchQuery((q) => ({ ...q, where: { ...q.where, ...patch } }));
  const [geoMsg, setGeoMsg] = useState('');
  const useMyLocation = () => {
    if (!navigator.geolocation) return setGeoMsg(t('Location is not available in this browser.'));
    setGeoMsg(t('Locating…'));
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const c = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        if (distanceMeters(c, PARIS_CENTER) > 25000) {
          setGeoMsg(t('You seem to be outside Paris — showing central Paris.'));
          set({ mode: 'place', lat: PARIS_CENTER.lat, lng: PARIS_CENTER.lng, label: t('Central Paris'), radiusKm: 2 });
        } else {
          setGeoMsg('');
          set({ mode: 'place', label: t('Current location'), ...c, radiusKm: 1.5 });
        }
      },
      () => setGeoMsg(t('Location permission denied.')),
      { timeout: 8000 },
    );
  };
  return (
    <div className="space-y-3">
      <Segmented value={w.mode} onChange={(mode) => {
        if (mode === 'city') set({ mode, lat: PARIS_CENTER.lat, lng: PARIS_CENTER.lng, label: 'Paris', radiusKm: 6, city: 'Paris' });
        else if (mode === 'map') set({ mode, label: t('Map area'), radiusKm: Math.min(w.radiusKm, 2) || 1.5 });
        else set({ mode, radiusKm: Math.min(w.radiusKm, 2) || 1.5, label: w.mode === 'place' ? w.label : t('Central Paris') });
      }} options={[{ value: 'place', label: t('Address') }, { value: 'map', label: t('Map area') }, { value: 'city', label: t('City') }]} />
      {w.mode === 'place' && (
        <>
          <PlaceSearch value={w.label === t('Central Paris') ? '' : w.label} onPick={(p) => set({ label: p.label, lat: p.lat, lng: p.lng })} />
          <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4">
            <button onClick={useMyLocation} className="chip-off"><LocateFixed size={14} /> {t('Near me')}</button>
            {(user?.prefs.locations ?? []).map((l) => <Chip key={l.id} on={w.label === l.label} onClick={() => set({ label: l.label, lat: l.lat, lng: l.lng })} icon={<MapPin size={14} />}>{t(l.name)}</Chip>)}
          </div>
          {geoMsg && <p className="text-[12px] text-ink-500">{geoMsg}</p>}
        </>
      )}
      {w.mode === 'map' && (
        <div className="relative h-60 overflow-hidden rounded-xl ring-1 ring-ivory-200">
          <MapView center={{ lat: w.lat, lng: w.lng }} zoom={Math.min(14.5, Math.round(Math.log2(10300 / Math.max(0.3, w.radiusKm)) * 4) / 4)} circle={{ lat: w.lat, lng: w.lng, radiusKm: w.radiusKm }} onCenterChange={(c) => set({ lat: c.lat, lng: c.lng, label: t('Map area') })} zoomControl />
          <div className="pointer-events-none absolute left-1/2 top-1/2 z-[500] -translate-x-1/2 -translate-y-1/2 text-electric"><Crosshair size={26} strokeWidth={2.5} /></div>
          <div className="pointer-events-none absolute inset-x-0 top-2 z-[500] flex justify-center"><span className="rounded-md bg-white/95 px-3 py-1 text-[12.5px] font-semibold text-ink shadow-card">{t('Drag the map to place your search area')}</span></div>
        </div>
      )}
      {w.mode === 'city' && (
        <div className="grid grid-cols-2 gap-2">
          {CITIES.map((c) => (
            <button key={c.id} disabled={!c.live} onClick={() => set({ label: c.label, lat: c.lat, lng: c.lng, city: c.label, radiusKm: 6 })} className={`rounded-xl border p-3 text-left transition ${w.city === c.label ? 'border-ink bg-ice-50' : 'border-ivory-300 bg-white'} disabled:opacity-50`}>
              <div className="text-[15px] font-bold text-ink">{c.label}</div>
              <div className="text-[12px] text-ink-500">{c.live ? t('Live now') : t('Coming soon')}</div>
            </button>
          ))}
        </div>
      )}
      {w.mode !== 'city' && (
        <div>
          <div className="mb-1 flex justify-between text-[13px]"><span className="font-semibold text-ink-500">{t('Search radius')}</span><span className="font-bold text-ink">{w.radiusKm < 1 ? `${w.radiusKm * 1000} m` : `${w.radiusKm} km`}</span></div>
          <input type="range" min={0.5} max={8} step={0.5} value={w.radiusKm} onChange={(e) => set({ radiusKm: +e.target.value })} className="w-full accent-ink" aria-label={t('Search radius')} />
        </div>
      )}
    </div>
  );
}

function WhenPanel() {
  const t = useT();
  const { query, patchQuery } = useStore();
  const w = query.when;
  const set = (patch: Partial<SearchQuery['when']>) => patchQuery((q) => ({ ...q, when: { ...q.when, ...patch } }));
  const [mode, setMode] = useState<'duration' | 'end'>('end');
  const end = toHHMM(toMin(w.start) + w.durationHours * 60);
  return (
    <div className="space-y-4">
      <div>
        <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
          {nextDays(14).map((d) => {
            const s = shortDate(d);
            const on = w.date === d;
            return (
              <button key={d} onClick={() => set({ date: d })} className={`flex w-[54px] shrink-0 flex-col items-center rounded-xl border py-2 transition ${on ? 'border-ink bg-ink text-white' : 'border-ivory-300 bg-white text-ink'}`}>
                <span className={`text-[11px] font-semibold ${on ? 'text-ice-200' : 'text-ink-500'}`}>{d === todayISO() ? t('Today') : s.dow}</span>
                <span className="text-[18px] font-bold leading-tight">{s.day}</span>
                <span className={`text-[10px] ${on ? 'text-ice-200' : 'text-ink-500'}`}>{s.mon}</span>
              </button>
            );
          })}
        </div>
        <label className="mt-2 flex items-center gap-2 text-[13px] text-ink-500"><CalendarDays size={14} /> {t('Other date:')}
          <input type="date" min={todayISO()} value={w.date} onChange={(e) => e.target.value && set({ date: e.target.value })} className="rounded-lg border border-ivory-300 bg-white px-2 py-1 text-[13px]" />
        </label>
      </div>
      {/* Hour-first time picker */}
      <div className="rounded-xl bg-ice-50 p-3">
        <div className="grid grid-cols-2 gap-3">
          <label><span className="label">{t('Start')}</span>
            <select className="input py-3 text-[17px] font-bold" value={w.start} onChange={(e) => set({ start: e.target.value })}>{TIME_OPTIONS.map((x) => <option key={x}>{x}</option>)}</select>
          </label>
          <div>
            <span className="label">{mode === 'duration' ? t('Duration') : t('End')}</span>
            {mode === 'duration' ? (
              <select className="input py-3 text-[17px] font-bold" value={w.durationHours} onChange={(e) => set({ durationHours: +e.target.value })}>
                {[1, 1.5, 2, 3, 4, 5, 6, 7, 8, 10, 12].map((h) => <option key={h} value={h}>{h} h</option>)}
              </select>
            ) : (
              <select className="input py-3 text-[17px] font-bold" value={end} onChange={(e) => set({ durationHours: Math.max(1, (toMin(e.target.value) - toMin(w.start)) / 60) })}>
                {TIME_OPTIONS.filter((x) => toMin(x) >= toMin(w.start) + 60).map((x) => <option key={x}>{x}</option>)}
                <option value="24:00">24:00</option>
              </select>
            )}
          </div>
        </div>
        <div className="mt-2 flex items-center justify-between text-[12.5px]">
          <span className="font-semibold text-ink"><Clock size={13} className="mr-1 inline" />{w.start} → {end} · {w.durationHours} h</span>
          <button onClick={() => setMode(mode === 'duration' ? 'end' : 'duration')} className="font-semibold text-electric-600">{mode === 'duration' ? t('Set an end time instead') : t('Set a duration instead')}</button>
        </div>
      </div>
      <div><span className="label">{t('How flexible?')}</span>
        <Segmented value={String(w.flex) as '0' | '1' | '2'} onChange={(v) => set({ flex: +v as 0 | 1 | 2 })} options={[{ value: '0', label: t('Exact time') }, { value: '1', label: '± 1 h' }, { value: '2', label: '± 2 h' }]} />
      </div>
      <div className="rounded-xl bg-ivory-50 p-3 ring-1 ring-ivory-200">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-[14px] font-semibold text-ink"><Repeat size={16} /> {t('Recurring booking')}</span>
          <Toggle label={t('Recurring booking')} checked={!!w.recurring} onChange={(v) => set({ recurring: v ? { freq: 'weekly', count: 4 } : null })} />
        </div>
        {w.recurring && (
          <div className="mt-3 space-y-2">
            <Segmented value={w.recurring.freq} onChange={(freq) => set({ recurring: { ...w.recurring!, freq } })} options={[{ value: 'daily', label: t('Daily') }, { value: 'weekdays', label: t('Weekdays') }, { value: 'weekly', label: t('Weekly') }]} />
            <Stepper label={t('Occurrences')} value={w.recurring.count} min={2} max={12} onChange={(count) => set({ recurring: { ...w.recurring!, count } })} />
          </div>
        )}
      </div>
    </div>
  );
}

function WhoPanel() {
  const t = useT();
  const { query, patchQuery } = useStore();
  const w = query.who;
  const set = (patch: Partial<SearchQuery['who']>) => patchQuery((q) => ({ ...q, who: { ...q.who, ...patch } }));
  const toggleA = (a: Accessibility) => set({ accessibility: w.accessibility.includes(a) ? w.accessibility.filter((x) => x !== a) : [...w.accessibility, a] });
  return (
    <div>
      <div className="divide-y divide-ivory-200">
        <Stepper label={t('Adults')} sub={t('Ages 13+')} value={w.adults} min={1} max={16} onChange={(adults) => set({ adults })} />
        <Stepper label={t('Children')} sub={t('Ages 2–12')} value={w.children} max={10} onChange={(children) => set({ children })} />
        <Stepper label={t('Infants')} sub={t("Under 2 · don't count to capacity")} value={w.infants} max={5} onChange={(infants) => set({ infants })} />
        <Stepper label={t('Pets')} sub={t('Only pet-friendly spaces')} value={w.pets} max={3} onChange={(pets) => set({ pets })} />
      </div>
      <div className="mt-3"><span className="label">{t('Accessibility requirements')}</span>
        <div className="flex flex-wrap gap-2">
          {(Object.keys(ACCESSIBILITY) as Accessibility[]).map((a) => { const A = ACCESSIBILITY[a]; return <Chip key={a} on={w.accessibility.includes(a)} onClick={() => toggleA(a)} icon={<A.icon size={14} />}>{t(A.label)}</Chip>; })}
        </div>
      </div>
    </div>
  );
}
