import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowRight, Loader2, LockKeyhole } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { Logo } from '@/components/Logo';
import { Avatar } from '@/components/ui';
import { useApi } from '@/lib/api';
import { useT } from '@/i18n';
import type { Role } from '@/types';

type Demo = { email: string; role: Role; name: string; company: string; avatarUrl: string; password: string };
const ROLE_LABEL: Record<Role, [string, string, string]> = {
  owner: ['S', 'Space Owner', 'List spaces, authorise uses, track earnings'],
  manager: ['M', 'Space Manager', 'Run daytime availability, bookings & cleaning'],
  guest: ['I', 'Guest', 'Find and book a space by the hour'],
  reviewer: ['R', 'Compliance reviewer', 'Review listings that need manual approval'],
};

export default function LoginPage() {
  const t = useT();
  const nav = useNavigate();
  const [params] = useSearchParams();
  const login = useStore((s) => s.login);
  const { data: demos } = useApi<Demo[]>('/api/demo-accounts');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState('');

  const go = async (e: string, p: string) => {
    setBusy(e);
    setErr('');
    try {
      await login(e, p);
      const next = params.get('next');
      nav(next && next !== '/login' ? next : '/', { replace: true });
    } catch (x) {
      setErr(x instanceof Error ? t(x.message) : t('Could not sign in'));
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="relative flex-1 overflow-y-auto bg-ink text-white">
      <div className="pointer-events-none absolute -right-24 -top-24 h-80 w-80 rounded-full bg-electric/40 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-32 -left-20 h-80 w-80 rounded-full bg-lavender/30 blur-3xl" />
      <div className="relative px-6 pb-10 pt-[max(env(safe-area-inset-top),24px)]">
        <Logo light size={32} />
        <h1 className="mt-10 text-[38px] font-bold leading-[1.02] tracking-[-0.03em]">{t('Your space.')}<br /><span className="text-electric-400">{t('Your time.')}</span></h1>
        <p className="mt-3 max-w-[330px] text-[15px] leading-relaxed text-ice-200">{t('Private apartments by the hour — for guests, owners and the property managers who run them.')}</p>

        <h2 className="mb-3 mt-8 text-[12px] font-bold uppercase tracking-[0.14em] text-lavender">{t('Demo accounts')}</h2>
        <div className="space-y-2.5">
          {(demos ?? []).map((d) => {
            const [letter, label, sub] = ROLE_LABEL[d.role];
            return (
              <button key={d.email} onClick={() => go(d.email, d.password)} disabled={!!busy} className="clip-corner flex w-full items-center gap-3 bg-white/[0.07] p-3 text-left ring-1 ring-white/10 transition hover:bg-white/[0.12] active:scale-[.99]">
                <div className="relative">
                  <Avatar name={d.name} src={d.avatarUrl || undefined} size={46} color="#3A4470" />
                  <span className="absolute -bottom-1 -right-1 grid h-5 w-5 place-items-center rounded-md bg-electric text-[11px] font-bold">{letter}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[15px] font-bold">{t(label)} · {d.name}</div>
                  <div className="truncate text-[12.5px] text-ice-200">{d.company ? `${d.company} — ` : ''}{t(sub)}</div>
                </div>
                {busy === d.email ? <Loader2 size={18} className="animate-spin" /> : <ArrowRight size={18} className="text-lavender" />}
              </button>
            );
          })}
        </div>

        <form className="mt-8 space-y-2.5" onSubmit={(e) => { e.preventDefault(); void go(email, password); }}>
          <h2 className="text-[12px] font-bold uppercase tracking-[0.14em] text-lavender">{t('Or sign in')}</h2>
          <input className="input border-white/15 bg-white/10 text-white placeholder:text-ice-200/60" type="email" autoComplete="username" placeholder={t('Email')} value={email} onChange={(e) => setEmail(e.target.value)} />
          <input className="input border-white/15 bg-white/10 text-white placeholder:text-ice-200/60" type="password" autoComplete="current-password" placeholder={t('Password')} value={password} onChange={(e) => setPassword(e.target.value)} />
          {err && <p className="text-[13px] text-rose-300">{err}</p>}
          <button className="btn w-full bg-electric text-white" disabled={!email || !password || !!busy}><LockKeyhole size={16} /> {t('Sign in')}</button>
        </form>
        <details className="mt-8 rounded-xl bg-white/[0.06] p-4 ring-1 ring-white/10">
          <summary className="cursor-pointer text-[13px] font-bold text-lavender">{t('Why SpaceTime?')}</summary>
          <div className="mt-3 space-y-3 text-[12.5px] leading-relaxed text-ice-200">
            <p><b className="text-white">{t('vs. overnight rental platforms')}</b> — {t('purpose-first daytime booking by the hour, with permitted uses made explicit.')}</p>
            <p><b className="text-white">{t('vs. hotel day-use')}</b> — {t('whole homes: kitchens, family space, workspaces and rooms to rest, for more kinds of daytime needs.')}</p>
            <p><b className="text-white">{t('For property managers')}</b> — {t('a new revenue channel for the apartments they already run, with Smart Availability deciding which daytime hours are worth opening.')}</p>
          </div>
        </details>
        <p className="mt-6 text-[12.5px] leading-relaxed text-ice-200/80">{t('Each phone keeps its own session. All three accounts share one live backend.')}</p>
        <LoginLanguage />
      </div>
    </div>
  );
}

/** Before sign-in there is no account to read a language from, so offer a quiet switch for reading this screen only.
 *  After sign-in the account's saved language applies (change it in Profile → Settings → Language). */
function LoginLanguage() {
  const lang = useStore((s) => s.lang);
  const setLang = useStore((s) => s.setLang);
  return (
    <div className="mt-4 flex items-center gap-1 text-[13px] text-ice-200" role="group" aria-label="Language / Langue">
      {(['en', 'fr'] as const).map((l, i) => (
        <span key={l} className="flex items-center gap-1">
          {i > 0 && <span aria-hidden>·</span>}
          <button onClick={() => setLang(l)} aria-pressed={lang === l} lang={l} className={`min-h-[44px] px-2 ${lang === l ? 'font-bold text-white' : 'underline-offset-2 hover:underline'}`}>{l === 'en' ? 'English' : 'Français'}</button>
        </span>
      ))}
    </div>
  );
}
