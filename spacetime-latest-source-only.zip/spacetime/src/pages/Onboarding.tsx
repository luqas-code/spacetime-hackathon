import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, ChevronLeft, Sparkles } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { LogoMark, Logo } from '@/components/Logo';
import { LanguageOptions } from '@/components/ui';
import { AccessibilityPicker, HouseholdEditor, InterestPicker, LocationsEditor } from '@/components/PreferenceEditors';
import { useT } from '@/i18n';
import type { UserPrefs } from '@/types';

const TOTAL = 3;

export default function OnboardingPage() {
  const t = useT();
  const nav = useNavigate();
  const { user, updateMe, patchQuery, lang, setLang } = useStore();
  const isGuest = user!.role === 'guest';
  // Language first — unless it was already chosen (e.g. replaying onboarding).
  const [step, setStep] = useState(user!.prefs.langChosen ? 0 : -1);
  const [d, setD] = useState<UserPrefs>(user!.prefs);
  const [building, setBuilding] = useState(false);
  const finish = async () => {
    setBuilding(true);
    await updateMe({ prefs: { ...d, onboarded: true, langChosen: true } });
    if (isGuest) patchQuery((q) => ({ ...q, who: { ...q.who, accessibility: d.accessibility, pets: d.household.pets ? 1 : 0 } }));
    setTimeout(() => nav(isGuest ? '/discover' : user!.role === 'owner' ? '/owner' : user!.role === 'manager' ? '/manager' : '/', { replace: true }), isGuest ? 900 : 300);
  };
  if (step === -1) return (
    <div className="relative flex flex-1 flex-col overflow-y-auto bg-ink px-6 pb-[max(env(safe-area-inset-bottom),24px)] pt-[max(env(safe-area-inset-top),24px)] text-white">
      <Logo light size={30} />
      <div className="mt-auto pt-10">
        <h1 className="text-[28px] font-bold leading-tight tracking-tight">Choose your language</h1>
        <p className="mt-1 text-[18px] font-medium text-ice-200" lang="fr">Choisissez votre langue</p>
        <div className="mt-6"><LanguageOptions dark value={lang} onChange={(l) => setLang(l)} /></div>
        <p className="mt-3 text-[13px] text-ice-200">{t('You can change this later in Profile → Settings.')}</p>
        <button className="btn-accent mt-6 w-full py-4" onClick={() => { void updateMe({ lang, prefs: { langChosen: true } }).catch(() => {}); setStep(0); }}>{t('Continue')} <ArrowRight size={18} /></button>
      </div>
    </div>
  );
  if (building) return (
    <div className="flex flex-1 flex-col items-center justify-center bg-ink px-8 text-center text-white">
      <div className="relative"><div className="absolute inset-0 animate-ping rounded-[22px] bg-electric/40" /><LogoMark size={72} light /></div>
      <h2 className="mt-8 text-[24px] font-bold">{t('Personalising your Discover…')}</h2>
    </div>
  );
  if (step === 0) return (
    <div className="relative flex flex-1 flex-col justify-end overflow-hidden bg-ink p-6 pb-[max(env(safe-area-inset-bottom),24px)] text-white">
      <div className="pointer-events-none absolute -right-24 -top-24 h-80 w-80 rounded-full bg-electric/40 blur-3xl" />
      <h1 className="relative text-[34px] font-bold leading-[1.05] tracking-[-0.03em]">{t('Welcome, {name}', { name: user!.name.split(' ')[0] })}</h1>
      <p className="relative mt-3 text-[16px] text-ice-200">{isGuest ? t('Three quick questions so we can suggest spaces that fit what you need to do.') : user!.role === 'owner' ? t('List your spaces, choose who manages them and follow your earnings — all in one place.') : t('Plan daytime availability, approve bookings and coordinate cleaning for the properties you manage.')}</p>
      <button className="btn-accent relative mt-6 w-full py-4" onClick={() => (isGuest ? setStep(1) : finish())}>{isGuest ? t('Get started') : t('Go to my dashboard')} <ArrowRight size={18} /></button>
      {isGuest && <button className="relative mt-2 min-h-[44px] py-2 text-[14px] font-semibold text-ice-200" onClick={finish}>{t('Skip for now')}</button>}
      {!user!.prefs.langChosen && <button className="relative mt-1 min-h-[44px] text-[13px] font-semibold text-ice-200 underline-offset-2 hover:underline" onClick={() => setStep(-1)}>{t('Change language')}</button>}
    </div>
  );
  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      <div className="flex items-center gap-3 px-5 pb-2 pt-[max(env(safe-area-inset-top),16px)]">
        <button aria-label={t('Back')} className="icon-btn" onClick={() => setStep(step - 1)}><ChevronLeft size={20} /></button>
        <div className="flex flex-1 gap-1.5">{Array.from({ length: TOTAL }, (_, i) => <span key={i} className={`h-1.5 flex-1 rounded-full ${i < step ? 'bg-electric' : 'bg-ivory-300'}`} />)}</div>
        <button className="text-[13px] font-semibold text-ink-500" onClick={finish}>{t('Skip')}</button>
      </div>
      <div className="flex-1 overflow-y-auto px-5 pb-32 pt-4" key={step}>
        <div className="animate-fade-up">
          {step === 1 && <><Title k={t('Your purposes')} title={t('What would you use SpaceTime for?')} sub={t('Pick as many as you like.')} /><div className="mt-6"><InterestPicker big value={d.interests} onChange={(interests) => setD({ ...d, interests })} /></div></>}
          {step === 2 && <><Title k={t('Your places')} title={t('Where do you spend your days?')} sub={t('We’ll show spaces near home and work, with walking distances.')} /><div className="mt-6"><LocationsEditor value={d.locations} onChange={(locations) => setD({ ...d, locations })} /></div></>}
          {step === 3 && <><Title k={t('Almost done')} title={t('Anything we should keep in mind?')} sub={t('Optional — helps us only show spaces that work for you.')} /><div className="mt-6 space-y-6"><HouseholdEditor value={d.household} onChange={(household) => setD({ ...d, household })} /><div><h3 className="mb-3 text-[15px] font-bold text-ink">{t('Accessibility needs')}</h3><AccessibilityPicker value={d.accessibility} onChange={(accessibility) => setD({ ...d, accessibility })} /></div></div></>}
        </div>
      </div>
      <div className="absolute inset-x-0 bottom-0 border-t border-ivory-200 bg-white px-5 py-3 pb-[max(env(safe-area-inset-bottom),12px)]">
        <button className="btn-primary w-full py-4" disabled={step === 1 && !d.interests.length} onClick={() => (step < TOTAL ? setStep(step + 1) : finish())}>{step < TOTAL ? t('Continue') : <><Sparkles size={17} /> {t('Build my Discover')}</>}</button>
      </div>
    </div>
  );
}
function Title({ k, title, sub }: { k: string; title: string; sub: string }) {
  return <div><p className="text-[13px] font-bold uppercase tracking-wider text-electric-600">{k}</p><h1 className="h-display mt-1 text-[28px] leading-[1.1]">{title}</h1><p className="mt-2 text-[14px] leading-relaxed text-ink-500">{sub}</p></div>;
}
