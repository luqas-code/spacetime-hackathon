import { useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, CheckCircle2, Clock } from 'lucide-react';
import { api, useApi } from '@/lib/api';
import { Spinner } from '@/components/dash';
import { Segmented, StatusPill } from '@/components/ui';
import { Img } from '@/components/Img';
import { dayLabel, TIME_OPTIONS } from '@/lib/time';
import { useStore } from '@/store/useStore';
import { useT, type T } from '@/i18n';
import { cleaningLabel, cleaningTone } from './ManagerHome';
import type { CleaningProvider, CleaningTask } from '@/types';

export type TaskView = CleaningTask & { property: { id: string; shortTitle: string; images: string[]; neighbourhood: string } | null; booking: { id: string; guestName?: string; start: string; end: string; status: string } | null; provider: CleaningProvider | null; conflicts: string[] };
const CONFLICT: Record<string, string> = { buffer_too_short: 'Cleaning window shorter than the job', next_arrival_too_soon: 'Next guest arrives before cleaning ends', overnight_checkin_too_soon: 'Overnight check-in before cleaning ends', outside_provider_hours: 'Outside the provider’s working hours', provider_double_booked: 'Provider has an overlapping job', unassigned: 'No cleaning provider assigned' };
export const conflictText = (c: string, t: T) => t(CONFLICT[c] ?? c);

export function TaskEditor({ task, providers, onSaved }: { task: TaskView; providers: CleaningProvider[]; onSaved: () => void }) {
  const t = useT();
  const [busy, setBusy] = useState(false);
  const patch = async (body: Record<string, unknown>) => {
    setBusy(true);
    try { await api(`/api/manager/cleaning/${task.id}`, { method: 'PATCH', body }); onSaved(); } catch (e) { useStore.getState().showToast(e instanceof Error ? e.message : 'Error', undefined, 'error'); } finally { setBusy(false); }
  };
  return (
    <div className={`space-y-2.5 ${busy ? 'opacity-60' : ''}`}>
      <div className="flex items-center gap-2 text-[12.5px] text-ink-700"><Clock size={14} className="text-lavender-600" /> {t('From {s} · done by', { s: task.start })}
        <select className="rounded-md border border-ivory-300 bg-white px-1.5 py-1 text-[12.5px] font-bold" value={task.deadline} onChange={(e) => patch({ deadline: e.target.value })}>{TIME_OPTIONS.map((x) => <option key={x}>{x}</option>)}</select>
        <span className="text-ink-500">· ~{task.durationMins} min</span>
      </div>
      <select className="input py-2.5 text-[13px]" value={task.providerId ?? ''} onChange={(e) => patch({ providerId: e.target.value || null })}>
        <option value="">{t('Assign a cleaning provider…')}</option>
        {providers.map((p) => <option key={p.id} value={p.id}>{p.name} · {p.workStart}–{p.workEnd}</option>)}
      </select>
      <Segmented value={task.status} onChange={(status) => patch({ status })} options={[{ value: 'scheduled', label: t('Scheduled') }, { value: 'in_progress', label: t('In progress') }, { value: 'completed', label: t('Done') }]} />
      {task.conflicts.length > 0 && <div className="space-y-1">{task.conflicts.map((c) => <div key={c} className="flex items-center gap-1.5 text-[12px] font-semibold text-rose-700"><AlertTriangle size={13} /> {conflictText(c, t)}</div>)}</div>}
      {task.provider && <p className="text-[11px] text-ink-500">{t('Provider notified via your usual channel — SpaceTime does not dispatch cleaners.')}</p>}
    </div>
  );
}

export default function ManagerCleaning() {
  const t = useT();
  const { data, reload } = useApi<{ tasks: TaskView[]; providers: CleaningProvider[]; today: string }>('/api/manager/cleaning');
  const [filter, setFilter] = useState<'open' | 'all'>('open');
  const tasks = (data?.tasks ?? []).filter((x) => filter === 'all' || (x.status !== 'completed' && x.date >= (data?.today ?? '')));
  const byDate = tasks.reduce<Record<string, TaskView[]>>((acc, x) => ((acc[x.date] ??= []).push(x), acc), {});
  return (
    <div className="page">
      <header className="px-5 pb-3 pt-[max(env(safe-area-inset-top),20px)]">
        <h1 className="h-display text-[28px]">{t('Cleaning')}</h1>
        <p className="text-[13px] text-ink-500">{t('Turnover after every daytime booking, with your existing cleaning partners.')}</p>
      </header>
      <div className="px-4"><Segmented value={filter} onChange={setFilter} options={[{ value: 'open', label: t('To do') }, { value: 'all', label: t('All') }]} /></div>
      {!data ? <Spinner /> : (
        <div className="space-y-5 px-4 pb-8 pt-4">
          {tasks.length === 0 && <p className="card flex items-center gap-2 p-4 text-[13px] text-ink-500"><CheckCircle2 size={16} className="text-emerald-600" /> {t('No open cleaning tasks.')}</p>}
          {Object.entries(byDate).map(([d, list]) => (
            <section key={d}>
              <h2 className="mb-2 px-1 text-[12px] font-bold uppercase tracking-[0.12em] text-ink-500">{dayLabel(d)}</h2>
              <div className="space-y-3">{list.map((x) => (
                <div key={x.id} className={`card p-3.5 ${x.conflicts.some((c) => c !== 'unassigned') ? 'ring-2 ring-rose-300' : ''}`}>
                  <div className="mb-3 flex items-center gap-3">
                    <Img src={x.property?.images[0] ?? ''} alt="" className="h-11 w-11 rounded-lg" />
                    <div className="min-w-0 flex-1"><div className="truncate text-[14px] font-bold">{x.property?.shortTitle}</div><Link to={`/manager/booking/${x.bookingId}`} className="text-[12px] text-electric-600">{t('After {g} · {s}–{e}', { g: x.booking?.guestName ?? '', s: x.booking?.start ?? '', e: x.booking?.end ?? '' })}</Link></div>
                    <StatusPill tone={cleaningTone(x.status)}>{cleaningLabel(x.status, t)}</StatusPill>
                  </div>
                  <TaskEditor task={x} providers={data.providers} onSaved={reload} />
                </div>
              ))}</div>
            </section>
          ))}
          <section>
            <h2 className="mb-2 px-1 text-[12px] font-bold uppercase tracking-[0.12em] text-ink-500">{t('Your cleaning providers')}</h2>
            <div className="card divide-y divide-ivory-200">{data.providers.map((p) => <div key={p.id} className="flex items-center justify-between px-4 py-3 text-[13px]"><div><div className="font-semibold">{p.name}</div><div className="text-[12.5px] text-ink-500">{p.phone} · {p.workStart}–{p.workEnd}</div></div><span className="text-ink-500">€{p.ratePerHour}/h</span></div>)}</div>
          </section>
        </div>
      )}
    </div>
  );
}
