import { useState } from 'react';
import { Sparkles } from 'lucide-react';
import { useApi } from '@/lib/api';
import { Spinner } from '@/components/dash';
import { Img } from '@/components/Img';
import { SmartAvailability, type MgrPropertyData } from '@/components/manager/SmartAvailability';
import { useT } from '@/i18n';
import type { MgrOverview } from './ManagerHome';

/** Portfolio-wide entry point to Smart Availability. */
export default function ManagerInsights() {
  const t = useT();
  const { data } = useApi<MgrOverview>('/api/manager/overview');
  const [pid, setPid] = useState<string | null>(null);
  const chosen = pid ?? data?.newAssignments[0]?.id ?? data?.properties[0]?.id ?? null;
  const { data: prop, reload } = useApi<MgrPropertyData>(chosen ? `/api/manager/properties/${chosen}` : null);
  return (
    <div className="page">
      <header className="px-5 pb-2 pt-[max(env(safe-area-inset-top),20px)]">
        <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.12em] text-electric-600"><Sparkles size={13} /> {t('Opportunity insights')}</div>
        <h1 className="h-display text-[26px] leading-tight">{t('Which daytime hours are worth opening?')}</h1>
      </header>
      {!data ? <Spinner /> : (
        <>
          <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 py-2">
            {data.properties.map((p) => (
              <button key={p.id} onClick={() => setPid(p.id)} className={`flex shrink-0 items-center gap-2 rounded-xl p-1.5 pr-3 ${chosen === p.id ? 'bg-ink text-white' : 'bg-white text-ink shadow-card'}`}>
                <Img src={p.images[0] ?? ''} alt="" className="h-9 w-9 rounded-lg" />
                <span className="max-w-[130px] truncate text-[12.5px] font-semibold">{p.shortTitle}</span>
              </button>
            ))}
          </div>
          <div className="px-4 pb-8 pt-2">{prop && prop.property.id === chosen ? <SmartAvailability key={chosen} data={prop} onChanged={reload} /> : <Spinner />}</div>
        </>
      )}
    </div>
  );
}
