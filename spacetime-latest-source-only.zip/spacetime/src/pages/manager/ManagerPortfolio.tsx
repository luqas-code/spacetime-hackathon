import { Link } from 'react-router-dom';
import { CalendarCheck, Clock, SprayCan, TriangleAlert } from 'lucide-react';
import { useApi } from '@/lib/api';
import { ListingStatusPill, Spinner } from '@/components/dash';
import { Img } from '@/components/Img';
import { TimelineBar } from '@/components/DayTimeline';
import { eur } from '@/lib/pricing';
import { todayISO } from '@/lib/time';
import { useT } from '@/i18n';
import type { MgrOverview } from './ManagerHome';

export default function ManagerPortfolio() {
  const t = useT();
  const { data } = useApi<MgrOverview>('/api/manager/overview');
  const today = todayISO();
  return (
    <div className="page">
      <header className="px-5 pb-3 pt-[max(env(safe-area-inset-top),20px)]">
        <h1 className="h-display text-[28px]">{t('Portfolio')}</h1>
        <p className="text-[13px] text-ink-500">{t('Only properties whose owners assigned them to you.')}</p>
      </header>
      {!data ? <Spinner /> : (
        <div className="space-y-3 px-4 pb-6">
          {data.properties.map((p) => (
            <Link key={p.id} to={`/manager/property/${p.id}`} className="card block overflow-hidden">
              <div className="flex gap-3 p-3">
                <Img src={p.images[0] ?? ''} alt="" className="h-20 w-20 shrink-0 rounded-lg" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2"><ListingStatusPill s={p.status} />{p.stats.readiness.length > 0 && <TriangleAlert size={14} className="text-amber-500" />}</div>
                  <div className="mt-1 truncate text-[15px] font-bold">{p.shortTitle}</div>
                  <div className="truncate text-[12px] text-ink-500">{p.address}</div>
                  <div className="text-[12px] text-ink-500">{t('Owner')}: {p.ownerName}</div>
                </div>
              </div>
              {p.schedule?.[today] && <div className="px-3"><TimelineBar day={p.schedule[today]} date={today} height="h-4" /></div>}
              <div className="mt-2 grid grid-cols-4 divide-x divide-ivory-200 border-t border-ivory-200 text-center text-[11px] text-ink-500">
                <div className="p-2"><Clock size={13} className="mx-auto mb-0.5 text-electric" /><b className="text-ink">{p.stats.freeHours7} h</b><br />{t('bookable 7d')}</div>
                <div className="p-2"><CalendarCheck size={13} className="mx-auto mb-0.5 text-electric" /><b className="text-ink">{p.stats.upcoming}</b><br />{t('upcoming')}</div>
                <div className="p-2"><SprayCan size={13} className="mx-auto mb-0.5 text-electric" /><b className="text-ink">{p.bufferMins} min</b><br />{p.stats.openTasks ? t('{n} to clean', { n: p.stats.openTasks }) : t('buffer')}</div>
                <div className="p-2"><span className="mx-auto mb-0.5 block text-[13px] font-bold text-electric">€</span><b className="text-ink">{eur(p.stats.monthGross)}</b><br />{t('this month')}</div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
