import { useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Ban, CalendarDays, CheckCircle2, ClipboardList, LayoutGrid, Lock, MessageCircle, Moon, Plus, Settings2, Sparkles, Trash2, TriangleAlert } from 'lucide-react';
import { api, useApi } from '@/lib/api';
import { ListingStatusPill, Spinner } from '@/components/dash';
import { PageHeader, Segmented, Sheet, StatusPill, Stepper, Toggle } from '@/components/ui';
import { Img } from '@/components/Img';
import { TimelineAxis, TimelineBar, TimelineLegend } from '@/components/DayTimeline';
import { SmartAvailability, type MgrPropertyData } from '@/components/manager/SmartAvailability';
import { ACTIVITIES } from '@/data/vocab';
import { eur } from '@/lib/pricing';
import { dayLabel, nextDays, TIME_OPTIONS, toMin } from '@/lib/time';
import { useStore } from '@/store/useStore';
import { useT } from '@/i18n';
import { cleaningLabel, cleaningTone } from './ManagerHome';
import type { CleaningProvider, CleaningTask } from '@/types';

type Data = MgrPropertyData & { tasks: (CleaningTask & { conflicts: string[] })[]; providers: CleaningProvider[]; readiness: string[] };
type Tab = 'overview' | 'calendar' | 'smart' | 'bookings' | 'settings';
const READY: Record<string, string> = { photos: 'At least 3 photos', checkin: 'Check-in instructions', cleaner: 'Default cleaning provider', rules: 'House rules' };

export default function ManagerProperty() {
  const t = useT();
  const { id } = useParams();
  const nav = useNavigate();
  const [params, setParams] = useSearchParams();
  const tab = (params.get('tab') as Tab) ?? 'overview';
  const { data, reload, error } = useApi<Data>(`/api/manager/properties/${id}`);
  const [daySheet, setDaySheet] = useState<string | null>(null);
  if (error?.status === 403) return <div className="flex flex-1 flex-col"><PageHeader back="/manager/portfolio" title={t('Not assigned to you')} /><p className="p-6 text-[14px] text-ink-600">{t('You can only access properties whose owners assigned them to you.')}</p></div>;
  if (!data) return <div className="flex flex-1 flex-col"><PageHeader back="/manager/portfolio" title="…" /><Spinner /></div>;
  const p = data.property;
  const messageOwner = async () => { const c = await api<{ id: string }>('/api/conversations', { body: { propertyId: p.id, kind: 'owner' } }); nav(`/manager/messages/${c.id}`); };

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      <PageHeader back="/manager/portfolio" title={p.shortTitle} sub={<span className="flex items-center gap-2"><ListingStatusPill s={p.status} /><span className="truncate">{t('Owner')}: {p.ownerName}</span></span>}
        right={<button aria-label={t('Property settings')} aria-pressed={tab === 'settings'} onClick={() => setParams({ tab: 'settings' }, { replace: true })} className={`icon-btn h-11 w-11 ${tab === 'settings' ? 'bg-ink text-white' : ''}`}><Settings2 size={19} /></button>} />
      {/* Four equal tabs fit every phone width (no sideways scrolling); settings live behind the gear. */}
      <div role="tablist" aria-label={t('Property sections')} className="mx-4 mb-2 grid grid-cols-4 gap-1 rounded-2xl bg-ivory-100 p-1">
        {([['overview', 'Overview', LayoutGrid], ['calendar', 'Calendar', CalendarDays], ['smart', 'Opportunities', Sparkles], ['bookings', 'Bookings', ClipboardList]] as const).map(([k, label, Icon]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setParams({ tab: k }, { replace: true })}
            className={`flex min-h-[48px] min-w-0 flex-col items-center justify-center gap-0.5 rounded-xl px-0.5 py-1 text-[11px] font-semibold leading-tight transition ${tab === k ? 'bg-white text-ink shadow-card' : 'text-ink-500'}`}>
            <Icon size={16} aria-hidden /><span className="w-full hyphens-auto break-words text-center">{t(label)}</span>
          </button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto px-4 pb-10 pt-2">
        {tab === 'overview' && (
          <div className="space-y-4">
            <div className="relative overflow-hidden rounded-2xl"><Img src={p.images[0] ?? ''} alt="" className="h-40 w-full" /></div>
            <div className="card p-4"><div className="text-[12px] text-ink-500">{p.address}</div><div className="mt-1 text-[13px] text-ink-700">{p.capacity.guests} {t('guests')} · {p.capacity.beds} {t('beds')} · {p.sizeM2} m² · {eur(p.pricePerHour)}/h · {p.minHours}–{p.maxHours} h</div>
              <button onClick={messageOwner} className="btn-ghost mt-3 w-full py-2.5 text-[13px]"><MessageCircle size={15} /> {t('Message owner ({n})', { n: p.ownerName ?? '' })}</button>
            </div>
            <div className="card p-4">
              <h3 className="mb-2 text-[14px] font-bold">{t('Readiness')}</h3>
              {Object.keys(READY).map((k) => <div key={k} className="flex items-center gap-2 py-1 text-[13px]">{data.readiness.includes(k) ? <TriangleAlert size={15} className="text-amber-500" /> : <CheckCircle2 size={15} className="text-emerald-600" />}{t(READY[k])}</div>)}
            </div>
            <div className="card p-4">
              <div className="mb-2 flex items-center justify-between"><h3 className="text-[14px] font-bold">{t('Permitted uses')}</h3><span className="flex items-center gap-1 text-[11px] text-ink-500"><Lock size={11} /> {t('set by owner')}</span></div>
              <div className="flex flex-wrap gap-1.5">{p.activities.map((a) => <span key={a} className="rounded-md bg-ice-100 px-2 py-1 text-[12px] font-semibold">{t(ACTIVITIES[a].label)}</span>)}</div>
              <div className="mt-3 text-[12px] text-ink-500">{t('Owner-authorised daytime hours')}: {p.ownerWindows.map((w) => `${w.start}–${w.end}`).join(', ')}</div>
              {p.overnight.enabled && <div className="mt-1 flex items-center gap-1 text-[12px] text-ink-500"><Moon size={12} /> {t('Overnight on {ch} · check-in {a} · check-out {b}', { ch: p.overnight.channel, a: p.overnight.checkin, b: p.overnight.checkout })}</div>}
            </div>
            <div className="card p-4"><h3 className="mb-2 text-[14px] font-bold">{t('Delegated to you')}</h3><div className="flex flex-wrap gap-1.5">{(['availability', 'pricing', 'approveBookings', 'cleaning', 'messaging'] as const).map((k) => <StatusPill key={k} tone={p.delegation[k] ? 'ok' : 'muted'}>{t({ availability: 'Availability', pricing: 'Pricing', approveBookings: 'Approve bookings', cleaning: 'Cleaning', messaging: 'Guest messages' }[k])}</StatusPill>)}</div><p className="mt-2 text-[12.5px] text-ink-500">{t('Management fee {n}% · price floor {f}/h', { n: p.delegation.mgmtFeePct, f: eur(p.delegation.priceFloor) })}</p></div>
            {p.status !== 'published' && <p className="rounded-lg bg-amber-50 p-3 text-[12.5px] text-amber-800">{t('The owner has not published this listing yet. You can prepare availability; guests will see it once it is live.')}</p>}
            <Link to="?tab=smart" className="btn-primary w-full">{t('Plan daytime availability')}</Link>
          </div>
        )}
        {tab === 'calendar' && (
          <div className="space-y-3">
            <div className="card p-4">
              <div className="space-y-2.5">{nextDays(14).map((d) => (
                <button key={d} onClick={() => setDaySheet(d)} className="block w-full text-left">
                  <div className="mb-0.5 flex justify-between text-[12.5px]"><span className="font-semibold text-ink-700">{dayLabel(d)}</span><span className="text-ink-500">{(p.schedule?.[d]?.free.reduce((s, [a, b]) => s + (b - a), 0) ?? 0) / 60} h {t('bookable')}</span></div>
                  {p.schedule?.[d] && <TimelineBar day={p.schedule[d]} date={d} height="h-6" />}
                </button>
              ))}</div>
              <TimelineAxis /><TimelineLegend />
            </div>
            <p className="text-center text-[12px] text-ink-500">{t('Tap a day to open or block hours. Overlaps are refused by the server.')}</p>
          </div>
        )}
        {tab === 'smart' && <SmartAvailability data={data} onChanged={reload} />}
        {tab === 'bookings' && (
          <div className="space-y-2">
            {data.bookings.length === 0 && <p className="card p-4 text-[13px] text-ink-500">{t('No bookings yet.')}</p>}
            {[...data.bookings].reverse().map((b) => {
              const task = data.tasks.find((x) => x.bookingId === b.id);
              return (
                <Link key={b.id} to={`/manager/booking/${b.id}`} className="card flex items-center gap-3 p-3">
                  <div className="min-w-0 flex-1"><div className="text-[13.5px] font-bold">{dayLabel(b.date)} · {b.start}–{b.end}</div><div className="text-[12px] text-ink-500">{b.guestName} · {b.guests.adults + b.guests.children} {t('guests')} · {eur(b.price.gross)}</div></div>
                  <div className="flex flex-col items-end gap-1"><StatusPill tone={b.status === 'confirmed' ? 'ok' : b.status === 'pending' ? 'warn' : 'muted'}>{t(b.status[0].toUpperCase() + b.status.slice(1))}</StatusPill>{task && <StatusPill tone={cleaningTone(task.status)}>{cleaningLabel(task.status, t)}</StatusPill>}</div>
                </Link>
              );
            })}
          </div>
        )}
        {tab === 'settings' && <><h2 className="mb-3 text-[18px] font-bold">{t('Property settings')}</h2><Settings data={data} onSaved={reload} /></>}
      </div>
      {daySheet && <DaySheet date={daySheet} data={data} onClose={() => setDaySheet(null)} onChanged={reload} />}
    </div>
  );
}

function DaySheet({ date, data, onClose, onChanged }: { date: string; data: Data; onClose: () => void; onChanged: () => void }) {
  const t = useT();
  const p = data.property;
  const [mode, setMode] = useState<'open' | 'block'>('open');
  const [s, setS] = useState('09:00');
  const [e, setE] = useState('13:00');
  const [reason, setReason] = useState('');
  const [err, setErr] = useState('');
  const slots = data.slots.filter((x) => x.date === date);
  const blocks = data.blocks.filter((x) => x.date === date);
  const stays = data.stays.filter((x) => x.checkinDate === date || x.checkoutDate === date || (x.checkinDate < date && x.checkoutDate > date));
  const bookings = data.bookings.filter((b) => b.date === date && (b.status === 'confirmed' || b.status === 'pending'));
  const submit = async () => {
    setErr('');
    try {
      await api(`/api/manager/properties/${p.id}/${mode === 'open' ? 'slots' : 'blocks'}`, { body: { date, start: s, end: e, reason, source: 'manual' } });
      useStore.getState().showToast(mode === 'open' ? 'Window opened for bookings' : 'Period blocked');
      onChanged();
    } catch (x) { setErr(x instanceof Error ? t(x.message) : 'Error'); }
  };
  const del = async (kind: 'slots' | 'blocks', id: string) => { await api(`/api/manager/properties/${p.id}/${kind}/${id}`, { method: 'DELETE' }); onChanged(); };
  return (
    <Sheet open onClose={onClose} title={dayLabel(date)} full>
      <div className="space-y-4 pb-6">
        {p.schedule?.[date] && <><TimelineBar day={p.schedule[date]} date={date} /><TimelineAxis /></>}
        <div className="space-y-1.5 text-[13px]">
          {stays.map((x) => <div key={x.id} className="flex items-center gap-2 rounded-lg bg-ink px-3 py-2 text-white"><Moon size={14} /> {x.channel} · {x.guestLabel} · {x.checkinDate === date ? `${t('check-in')} ${p.overnight.checkin}` : x.checkoutDate === date ? `${t('check-out')} ${p.overnight.checkout}` : t('all day')}</div>)}
          {bookings.map((b) => <div key={b.id} className="flex items-center gap-2 rounded-lg bg-lavender-100 px-3 py-2"><span className="font-bold">{b.start}–{b.end}</span> {b.guestName} <StatusPill tone={b.status === 'pending' ? 'warn' : 'ok'}>{t(b.status === 'pending' ? 'Pending' : 'Confirmed')}</StatusPill></div>)}
          {p.availability.filter((w) => w.days.includes(new Date(date + 'T12:00').getDay())).map((w, i) => <div key={i} className="flex items-center gap-2 rounded-lg bg-ice-100 px-3 py-2">{w.start}–{w.end} · {t('standing weekly window')}</div>)}
          {slots.map((x) => <div key={x.id} className="flex items-center gap-2 rounded-lg bg-electric-50 px-3 py-2"><span className="font-bold">{x.start}–{x.end}</span> {t(x.source === 'optimiser' ? 'approved via Smart Availability' : 'opened manually')}<button className="ml-auto" aria-label={t('Remove')} onClick={() => del('slots', x.id)}><Trash2 size={15} className="text-ink-500" /></button></div>)}
          {blocks.map((x) => <div key={x.id} className="block-stripe flex items-center gap-2 rounded-lg px-3 py-2"><Ban size={14} /> <span className="font-bold">{x.start}–{x.end}</span> {x.reason}<button className="ml-auto" aria-label={t('Remove')} onClick={() => del('blocks', x.id)}><Trash2 size={15} /></button></div>)}
        </div>
        <div className="card space-y-3 p-4">
          <Segmented value={mode} onChange={setMode} options={[{ value: 'open', label: t('Open for bookings') }, { value: 'block', label: t('Block period') }]} />
          <div className="grid grid-cols-2 gap-2">
            <select className="input py-2.5" value={s} onChange={(x) => setS(x.target.value)}>{TIME_OPTIONS.map((x) => <option key={x}>{x}</option>)}</select>
            <select className="input py-2.5" value={e} onChange={(x) => setE(x.target.value)}>{TIME_OPTIONS.filter((x) => toMin(x) > toMin(s)).map((x) => <option key={x}>{x}</option>)}</select>
          </div>
          {mode === 'block' && <input className="input" placeholder={t('Reason (e.g. maintenance)')} value={reason} onChange={(x) => setReason(x.target.value)} />}
          {err && <p className="text-[12.5px] font-semibold text-rose-700">{err}</p>}
          <button className="btn-primary w-full" onClick={submit}><Plus size={16} /> {mode === 'open' ? t('Open window') : t('Block')}</button>
        </div>
      </div>
    </Sheet>
  );
}

function Settings({ data, onSaved }: { data: Data; onSaved: () => void }) {
  const t = useT();
  const p = data.property;
  const [v, setV] = useState({ pricePerHour: p.pricePerHour, minHours: p.minHours, maxHours: p.maxHours, bufferMins: p.bufferMins, instantBook: p.instantBook, cleaningProviderId: p.cleaningProviderId ?? '', checkinInstructions: p.checkinInstructions });
  const [err, setErr] = useState('');
  const save = async () => {
    setErr('');
    try { await api(`/api/manager/properties/${p.id}`, { method: 'PATCH', body: v }); useStore.getState().showToast('Settings saved'); onSaved(); }
    catch (e) { setErr(e instanceof Error ? t(e.message) : 'Error'); }
  };
  return (
    <div className="space-y-4">
      <div className="card divide-y divide-ivory-200 px-4">
        <label className="flex items-center justify-between py-3"><span className="text-[14px] font-semibold">{t('Hourly price (€)')}<span className="block text-[12.5px] font-normal text-ink-500">{t('Owner floor {f}', { f: eur(p.delegation.priceFloor) })}</span></span><input type="number" className="w-24 rounded-lg border border-ivory-300 px-2 py-1.5 text-right font-bold" value={v.pricePerHour} onChange={(e) => setV({ ...v, pricePerHour: +e.target.value })} /></label>
        <Stepper label={t('Minimum duration (h)')} value={v.minHours} min={1} max={v.maxHours} onChange={(minHours) => setV({ ...v, minHours })} />
        <Stepper label={t('Maximum duration (h)')} value={v.maxHours} min={v.minHours} max={12} onChange={(maxHours) => setV({ ...v, maxHours })} />
        <Stepper label={t('Cleaning & turnover buffer (min)')} value={v.bufferMins} min={15} max={180} onChange={(n) => setV({ ...v, bufferMins: Math.round(n / 15) * 15 })} />
        <div className="flex items-center justify-between py-3"><span className="text-[14px] font-semibold">{t('Instant book')}</span><Toggle label="instant" checked={v.instantBook} onChange={(instantBook) => setV({ ...v, instantBook })} /></div>
      </div>
      <label className="block"><span className="label">{t('Default cleaning provider')}</span><select className="input" value={v.cleaningProviderId} onChange={(e) => setV({ ...v, cleaningProviderId: e.target.value })}><option value="">{t('None — assign per booking')}</option>{data.providers.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></label>
      <label className="block"><span className="label">{t('Check-in instructions')}</span><textarea rows={3} className="input resize-none" value={v.checkinInstructions} onChange={(e) => setV({ ...v, checkinInstructions: e.target.value })} /></label>
      {err && <p className="text-[13px] font-semibold text-rose-700">{err}</p>}
      <button className="btn-primary w-full" onClick={save}>{t('Save settings')}</button>
      <p className="flex items-start gap-2 text-[12.5px] text-ink-500"><Lock size={13} className="mt-0.5 shrink-0" /> {t('Ownership, permitted uses, compliance and publication are controlled by the owner.')}</p>
    </div>
  );
}
