import type React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BellRing, Building2, CalendarClock, CheckCircle2, Inbox, Sparkles, SprayCan } from 'lucide-react';
import { useApi } from '@/lib/api';
import { DashHeader, Metric, Panel, Spinner } from '@/components/dash';
import { StatusPill } from '@/components/ui';
import { Img } from '@/components/Img';
import { eur } from '@/lib/pricing';
import { dayLabel } from '@/lib/time';
import { monthLabel } from '../owner/OwnerHome';
import { useStore } from '@/store/useStore';
import { useT, type T } from '@/i18n';
import type { Booking, CleaningTask, Property } from '@/types';

export type MgrProperty = Property & { stats: { upcoming: number; monthGross: number; freeHours7: number; openTasks: number; readiness: string[] } };
export type MgrOverview = {
  period?: { month: string };
  metrics: { properties: number; active: number; upcoming: number; pending: number; freeHours7: number; openTasks: number; monthGross: number; monthMgmtFee: number; monthOwner: number };
  upcoming: (Booking & { property: { id: string; shortTitle?: string; image?: string }; cleaning: (CleaningTask & { conflicts: string[] }) | null })[];
  alerts: { kind: string; text: string; link: string; severity: 'high' | 'medium' | 'info' }[];
  newAssignments: { id: string; shortTitle: string; ownerName?: string; image?: string; status: string }[];
  properties: MgrProperty[];
};

const CLEAN_LABEL: Record<string, string> = { unassigned: 'Unassigned', scheduled: 'Scheduled', in_progress: 'In progress', completed: 'Done' };
export const cleaningTone = (s?: string) => (s === 'completed' ? 'ok' : s === 'in_progress' ? 'info' : s === 'scheduled' ? 'muted' : 'warn') as 'ok' | 'info' | 'muted' | 'warn';
export const cleaningLabel = (s: string | undefined, t: T) => t(CLEAN_LABEL[s ?? 'unassigned'] ?? 'Unassigned');

export function alertText(a: MgrOverview['alerts'][number], t: T) {
  const [code, prop, raw] = a.text.split('|');
  // "2026-11-24 14:00" → "Tue 24 Nov 14:00" (or Today / Tomorrow)
  const m = /^(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2})$/.exec(raw ?? '');
  const when = m ? `${dayLabel(m[1])} ${m[2]}` : raw;
  const M: Record<string, string> = {
    pending: 'Booking request to approve · {p} · {w}', unassigned: 'Cleaning not assigned · {p} · {w}', buffer_too_short: 'Cleaning window too short · {p} · {w}',
    next_arrival_too_soon: 'Next arrival before cleaning ends · {p} · {w}', overnight_checkin_too_soon: 'Overnight check-in before cleaning ends · {p} · {w}',
    outside_provider_hours: 'Cleaning outside provider hours · {p} · {w}', provider_double_booked: 'Cleaner double-booked · {p} · {w}',
    readiness: 'Listing not fully ready · {p}', no_availability: 'Published but no bookable hours · {p}', messages: '{p} unread guest/owner messages',
  };
  return t(M[code] ?? code, { p: prop, w: when });
}

export default function ManagerHome() {
  const t = useT();
  const user = useStore((s) => s.user)!;
  const { data } = useApi<MgrOverview>('/api/manager/overview');
  const cleaningIssues = data?.alerts.filter((a) => a.kind === 'cleaning').length ?? 0;
  const unread = Number(data?.alerts.find((a) => a.kind === 'messages')?.text.split('|')[1] ?? 0);
  const opportunities = new Set([...(data?.newAssignments.map((n) => n.id) ?? []), ...(data?.alerts.filter((a) => a.kind === 'opportunity').map((a) => a.link.split('/')[3]?.split('?')[0]) ?? [])]).size;
  return (
    <div className="page">
      <DashHeader title={t('Daytime operations')} sub={`${user.company} · ${t('Space Manager')}`} profileLink="/manager/profile" />
      {!data ? <Spinner /> : (
        <div className="space-y-6 px-4 pt-4">
          {data.newAssignments.map((n) => (
            <Link key={n.id} to={`/manager/property/${n.id}?tab=smart`} className="clip-corner flex items-center gap-3 bg-electric p-3.5 text-white shadow-card animate-fade-up">
              <Img src={n.image ?? ''} alt="" className="h-12 w-12 shrink-0 rounded-lg" />
              <div className="min-w-0 flex-1"><div className="text-[11px] font-bold uppercase tracking-[0.1em] text-ice-200">{t('New property assigned')}</div><div className="truncate text-[15px] font-bold">{n.shortTitle}</div><div className="text-[12px] text-ice-200">{t('from {o} · plan daytime availability', { o: n.ownerName ?? '' })}</div></div>
              <ArrowRight size={18} />
            </Link>
          ))}
          <Panel title={t('Needs attention')}>
            <div className="grid grid-cols-2 gap-2.5">
              <AttentionTile to={pendingLink(data)} icon={<BellRing size={17} />} n={data.metrics.pending} label={t('Requests to approve')} urgent />
              <AttentionTile to="/manager/cleaning" icon={<SprayCan size={17} />} n={cleaningIssues} label={t('Cleaning issues')} urgent={data.alerts.some((a) => a.kind === 'cleaning' && a.severity === 'high')} />
              <AttentionTile to="/manager/messages" icon={<Inbox size={17} />} n={unread} label={t('Unread messages')} />
              <AttentionTile to="/manager/insights" icon={<Sparkles size={17} />} n={opportunities} label={t('Properties with opportunities')} />
            </div>
          </Panel>

          {data.alerts.length > 0 ? (
            <div className="card divide-y divide-ivory-200 overflow-hidden">
              {[...data.alerts].sort((a, b) => SEV[a.severity] - SEV[b.severity]).slice(0, 8).map((a, i) => (
                <Link key={i} to={a.link} className="flex min-h-[52px] items-center gap-3 px-4 py-3 text-[14px]">
                  <span className={`shrink-0 rounded-md px-1.5 py-0.5 text-[11px] font-bold uppercase tracking-wide ${a.severity === 'high' ? 'bg-rose-50 text-rose-700' : a.severity === 'medium' ? 'bg-amber-50 text-amber-800' : 'bg-electric-50 text-electric-700'}`}>{t(a.severity === 'high' ? 'Urgent' : a.severity === 'medium' ? 'Soon' : 'Info')}</span>
                  <span className="min-w-0 flex-1 text-ink-700">{alertText(a, t)}</span>
                  {a.kind === 'cleaning' ? <SprayCan size={15} className="shrink-0 text-ink-500" /> : a.kind === 'pending' ? <BellRing size={15} className="shrink-0 text-ink-500" /> : <Building2 size={15} className="shrink-0 text-ink-500" />}
                </Link>
              ))}
            </div>
          ) : <p className="card flex items-center gap-2 p-4 text-[14px] text-ink-600"><CheckCircle2 size={17} className="text-emerald-600" /> {t('All clear — nothing needs your attention.')}</p>}

          <Panel title={<span className="flex items-center gap-1.5"><CalendarClock size={13} /> {t('Upcoming bookings')}</span>}>
            <div className="card overflow-hidden">
              <div className="grid grid-cols-[1fr_auto_auto] gap-2 border-b border-ivory-200 bg-ivory-50 px-3 py-2 text-[11.5px] font-bold uppercase tracking-wider text-ink-500"><span>{t('Property · guest')}</span><span>{t('Status')}</span><span>{t('Cleaning')}</span></div>
              {data.upcoming.length === 0 && <p className="p-4 text-[13px] text-ink-500">{t('No upcoming bookings.')}</p>}
              {data.upcoming.map((b) => (
                <Link key={b.id} to={`/manager/booking/${b.id}`} className="grid grid-cols-[1fr_auto_auto] items-center gap-2 border-b border-ivory-100 px-3 py-2.5 last:border-0">
                  <div className="min-w-0"><div className="truncate text-[13px] font-bold">{b.property.shortTitle}</div><div className="truncate text-[12.5px] text-ink-500">{b.guestName} · {dayLabel(b.date)} {b.start}–{b.end}</div></div>
                  <StatusPill tone={b.status === 'pending' ? 'warn' : 'ok'}>{t(b.status === 'pending' ? 'Pending' : 'Confirmed')}</StatusPill>
                  <StatusPill tone={cleaningTone(b.cleaning?.status)}>{cleaningLabel(b.cleaning?.status, t)}</StatusPill>
                </Link>
              ))}
            </div>
          </Panel>

          <Panel title={t('This month')}>
            <div className="grid grid-cols-2 gap-3">
              <Metric tone="dark" label={t('Booking revenue · {m}', { m: monthLabel(data.period?.month ?? new Date().toISOString().slice(0, 7)) })} value={eur(data.metrics.monthGross)} sub={t('Your fee {f}', { f: eur(data.metrics.monthMgmtFee) })} />
              <Metric label={t('Properties')} value={`${data.metrics.active}/${data.metrics.properties}`} sub={t('live / managed')} to="/manager/portfolio" />
              <Metric label={t('Upcoming daytime bookings')} value={data.metrics.upcoming} sub={t('{n} awaiting approval', { n: data.metrics.pending })} />
              <Metric label={t('Bookable hours · 7 days')} value={data.metrics.freeHours7} sub={t('{n} cleaning tasks open', { n: data.metrics.openTasks })} to="/manager/cleaning" />
            </div>
            <p className="mt-2 px-1 text-[12.5px] text-ink-500">{t('Confirmed and completed bookings scheduled this month — same figures as the owner dashboard.')}</p>
          </Panel>

          <div className="rounded-xl bg-ice-100 p-4 text-[13px] leading-relaxed text-ink-700">
            <b className="text-ink">{t('How SpaceTime works with you')}</b><br />{t('SpaceTime brings daytime demand to the apartments you already manage. You keep operations, cleaning partners and the owner relationship — and decide which daytime windows to open.')}
          </div>
          <div className="h-4" />
        </div>
      )}
    </div>
  );
}

const SEV = { high: 0, medium: 1, info: 2 } as const;
const pendingLink = (d: MgrOverview) => { const b = d.upcoming.find((x) => x.status === 'pending'); return b ? `/manager/booking/${b.id}` : '/manager'; };

function AttentionTile({ to, icon, n, label, urgent }: { to: string; icon: React.ReactNode; n: number; label: string; urgent?: boolean }) {
  const hot = n > 0;
  return (
    <Link to={to} className={`flex min-h-[72px] items-start gap-2.5 rounded-2xl p-3 shadow-card transition active:scale-[.98] ${hot && urgent ? 'bg-rose-50 ring-1 ring-rose-200' : hot ? 'bg-white ring-1 ring-electric/30' : 'bg-white'}`}>
      <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg ${hot && urgent ? 'bg-rose-600 text-white' : hot ? 'bg-electric text-white' : 'bg-ivory-100 text-ink-500'}`}>{icon}</span>
      <span className="min-w-0"><span className="block text-[20px] font-bold leading-none tabular-nums">{n}</span><span className="mt-1 block text-[12.5px] leading-tight text-ink-600">{label}</span></span>
    </Link>
  );
}
