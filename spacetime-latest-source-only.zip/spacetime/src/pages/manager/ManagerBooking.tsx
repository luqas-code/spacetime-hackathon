import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Baby, Check, MessageCircle, PawPrint, StickyNote, Users, X } from 'lucide-react';
import { api, useApi } from '@/lib/api';
import { FinanceBreakdown, Panel, Spinner } from '@/components/dash';
import { Avatar, PageHeader, Sheet, StatusPill } from '@/components/ui';
import { Img } from '@/components/Img';
import { ACTIVITIES } from '@/data/vocab';
import { longDate } from '@/lib/time';
import { useStore } from '@/store/useStore';
import { eur } from '@/lib/pricing';
import { useT } from '@/i18n';
import { TaskEditor, type TaskView } from './ManagerCleaning';
import type { Booking, CleaningProvider, Property } from '@/types';

type Detail = Booking & { property: Property; guest: { id: string; name: string; avatarUrl: string; phone: string; email: string } | null; cleaning: TaskView | null; providers: CleaningProvider[]; conversationId: string | null };
const OPS: [Booking['opsStatus'], string][] = [['awaiting', 'Awaiting'], ['ready', 'Ready'], ['checked_in', 'Checked in'], ['checked_out', 'Checked out']];

export default function ManagerBooking() {
  const t = useT();
  const { id } = useParams();
  const nav = useNavigate();
  const { data: b, reload } = useApi<Detail>(`/api/bookings/${id}`);
  const [busy, setBusy] = useState(false);
  const [cancel, setCancel] = useState(false);
  if (!b) return <div className="flex flex-1 flex-col"><PageHeader back="/manager" title="…" /><Spinner /></div>;
  const p = b.property;
  const run = async (path: string, body: Record<string, unknown> = {}) => {
    setBusy(true);
    try { await api(`/api/manager/bookings/${b.id}/${path}`, { body }); reload(); } catch (e) { useStore.getState().showToast(e instanceof Error ? e.message : 'Error', undefined, 'error'); } finally { setBusy(false); }
  };
  const tone = b.status === 'confirmed' ? 'ok' : b.status === 'pending' ? 'warn' : b.status === 'completed' ? 'info' : 'muted';
  return (
    <div className="page pb-10">
      <PageHeader back="/manager" title={t('Reservation')} sub={p.shortTitle} right={<StatusPill tone={tone}>{t(b.status === 'pending' ? 'Pending' : b.status[0].toUpperCase() + b.status.slice(1))}</StatusPill>} />
      <div className="space-y-5 px-4">
        <div className="card overflow-hidden">
          <div className="flex items-center gap-3 p-4">
            <Avatar name={b.guest?.name ?? ''} src={b.guest?.avatarUrl || undefined} size={50} />
            <div className="min-w-0 flex-1"><div className="text-[16px] font-bold">{b.guest?.name}</div><div className="text-[12px] text-ink-500">{b.guest?.phone} · {b.guest?.email}</div></div>
            {b.conversationId && <button onClick={() => nav(`/manager/messages/${b.conversationId}`)} aria-label={t('Message guest')} className="grid h-11 w-11 place-items-center rounded-full bg-electric text-white"><MessageCircle size={19} /></button>}
          </div>
          <div className="flex items-center gap-3 border-t border-ivory-200 p-4">
            <Img src={p.images[0] ?? ''} alt="" className="h-14 w-14 rounded-lg" />
            <div><div className="text-[15px] font-bold tabular-nums">{longDate(b.date)}</div><div className="text-[22px] font-bold tabular-nums tracking-tight">{b.start}–{b.end}</div></div>
          </div>
        </div>

        {b.status === 'pending' && (
          <div className="clip-corner bg-ink p-4 text-white">
            <div className="text-[14px] font-bold">{t('Booking request')}</div>
            <p className="text-[12.5px] text-ice-200">{t('This listing requires approval. The guest sees your decision instantly.')}</p>
            <div className="mt-3 grid grid-cols-2 gap-2"><button disabled={busy} onClick={() => run('decision', { decision: 'decline' })} className="btn bg-white/10 py-3 text-white"><X size={16} /> {t('Decline')}</button><button disabled={busy} onClick={() => run('decision', { decision: 'approve' })} className="btn bg-electric py-3 text-white"><Check size={16} /> {t('Approve')}</button></div>
          </div>
        )}

        <Panel title={t('Guest requirements')}>
          <div className="card space-y-2 p-4 text-[13.5px]">
            <div className="flex items-center gap-2"><Users size={15} className="text-electric" /> {t('{a} adult(s)', { a: b.guests.adults })}{b.guests.children ? `, ${t('{c} child(ren)', { c: b.guests.children })}` : ''}</div>
            {b.guests.infants > 0 && <div className="flex items-center gap-2"><Baby size={15} className="text-electric" /> {t('{n} infant(s) — prepare the travel cot', { n: b.guests.infants })}</div>}
            {b.guests.pets > 0 && <div className="flex items-center gap-2"><PawPrint size={15} className="text-electric" /> {t('{n} pet(s)', { n: b.guests.pets })}</div>}
            {b.purpose && <div className="flex items-center gap-2"><Check size={15} className="text-electric" /> {t('Purpose')}: {t(ACTIVITIES[b.purpose].label)}</div>}
            {b.note && <div className="flex items-start gap-2 rounded-lg bg-ivory-50 p-2.5"><StickyNote size={15} className="mt-0.5 text-lavender-600" /> “{b.note}”</div>}
          </div>
        </Panel>

        {(b.status === 'confirmed' || b.status === 'completed') && (
          <Panel title={t('Check-in & check-out')}>
            <div className="card p-3">
              <div className="grid grid-cols-4 gap-1.5">{OPS.map(([k, l]) => <button key={k} disabled={busy} onClick={() => run('ops', { opsStatus: k })} className={`rounded-lg px-1 py-2.5 text-[12.5px] font-bold ${b.opsStatus === k ? 'bg-ink text-white' : 'bg-ivory-100 text-ink-600'}`}>{t(l)}</button>)}</div>
              <p className="mt-2 text-[12.5px] text-ink-500">{t('Door code {c} · marking “Ready” notifies the guest.', { c: b.accessCode })}</p>
            </div>
          </Panel>
        )}

        {b.cleaning && (
          <Panel title={t('Cleaning after this booking')}>
            <div className="card p-4"><TaskEditor task={b.cleaning} providers={b.providers} onSaved={reload} /></div>
          </Panel>
        )}

        <Panel title={t('Financial contribution')}>
          <div className="card p-4">
            <div className="mb-2 flex justify-between text-[13px]"><span className="text-ink-500">{t('Guest pays')}</span><span className="font-bold">{eur(b.price.guestTotal)}</span></div>
            <FinanceBreakdown e={b.price} />
            <p className="mt-2 text-[12.5px] text-ink-500">{t('Your management fee on this booking: {x}', { x: eur(b.price.mgmtFee) })}</p>
          </div>
        </Panel>

        <Link to={`/manager/property/${p.id}?tab=calendar`} className="btn-ghost w-full">{t('Open property calendar')}</Link>
        {(b.status === 'confirmed' || b.status === 'pending') && <button onClick={() => setCancel(true)} className="w-full text-center text-[13px] font-semibold text-rose-700">{t('Cancel this booking')}</button>}
      </div>
      <Sheet open={cancel} onClose={() => setCancel(false)} title={t('Cancel booking?')} footer={<button className="btn-primary w-full" onClick={async () => { await api(`/api/manager/bookings/${b.id}/cancel`, { body: {} }); setCancel(false); reload(); }}>{t('Cancel booking')}</button>}>
        <p className="pb-4 text-[14px] text-ink-700">{t('The guest is notified immediately and is not charged when the manager cancels.')}</p>
      </Sheet>
    </div>
  );
}
