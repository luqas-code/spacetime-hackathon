import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CalendarDays, ChevronDown, MessageCircle } from 'lucide-react';
import { useApi } from '@/lib/api';
import { EmptyState } from '@/components/ui';
import { BookingCard, type GuestBooking } from '@/components/BookingCard';
import { ConversationList } from './InboxList';
import { todayISO } from '@/lib/time';
import { useT } from '@/i18n';
import type { Conversation } from '@/types';

/**
 * Guest "Bookings" tab: one list of bookings. Each card has a message button that opens the
 * conversation with the Space Partner for that space. Cancelled bookings leave the list
 * (they stay available under a collapsed "Cancelled" section for reference).
 */
export default function BookingsPage() {
  const t = useT();
  const { data: convs } = useApi<Conversation[]>('/api/conversations');
  const { data: bookings } = useApi<GuestBooking[]>('/api/bookings/mine');
  const [showCancelled, setShowCancelled] = useState(false);
  const list = bookings ?? [];
  const isActive = (b: GuestBooking) => b.status === 'confirmed' || b.status === 'pending';
  const upcoming = list.filter((b) => isActive(b) && b.date >= todayISO()).sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start));
  const past = list.filter((b) => b.status === 'completed' || (isActive(b) && b.date < todayISO()));
  const cancelled = list.filter((b) => b.status === 'cancelled' || b.status === 'declined');
  // One guest conversation per space: match it to the booking by property.
  const convFor = (b: GuestBooking) => (convs ?? []).find((c) => c.kind === 'guest' && (c.bookingId === b.id || c.propertyId === b.propertyId));
  const bookedProps = new Set(list.map((b) => b.propertyId));
  const otherConvs = (convs ?? []).filter((c) => !bookedProps.has(c.propertyId));

  return (
    <div className="page">
      <header className="px-5 pb-3 pt-[max(env(safe-area-inset-top),20px)]">
        <h1 className="h-display text-[30px]">{t('Bookings')}</h1>
        <p className="text-[14px] text-ink-500">{t('Tap a booking for its details and access code, or the message button to talk to the Space Partner.')}</p>
      </header>
      <div className="space-y-7 px-5 pt-2">
        <section>
          <h2 className="section-title mb-3">{t('Upcoming')}</h2>
          {!bookings ? <div className="skeleton h-28 rounded-2xl" /> : upcoming.length === 0
            ? <EmptyState icon={<CalendarDays size={30} />} title={t('Nothing booked yet')} text={t('When you reserve a space, your access code and details appear here.')} action={<Link to="/search" className="btn-primary">{t('Find a space')}</Link>} />
            : <div className="space-y-3">{upcoming.map((b) => <BookingCard key={b.id} b={b} conv={convFor(b)} />)}</div>}
        </section>

        {past.length > 0 && (
          <section>
            <h2 className="section-title mb-3">{t('Past')}</h2>
            <div className="space-y-3">{past.map((b) => <BookingCard key={b.id} b={b} conv={convFor(b)} />)}</div>
          </section>
        )}

        {otherConvs.length > 0 && (
          <section>
            <h2 className="section-title mb-1 flex items-center gap-2"><MessageCircle size={17} /> {t('Other conversations')}</h2>
            <p className="mb-2 text-[13px] text-ink-500">{t('Questions you asked about spaces you haven’t booked.')}</p>
            <ConversationList convs={otherConvs} base="/messages" />
          </section>
        )}

        {cancelled.length > 0 && (
          <section>
            <button onClick={() => setShowCancelled(!showCancelled)} aria-expanded={showCancelled} className="flex min-h-[44px] w-full items-center justify-between text-[14px] font-semibold text-ink-500">
              {t('Cancelled ({n})', { n: cancelled.length })}<ChevronDown size={17} className={`transition ${showCancelled ? 'rotate-180' : ''}`} />
            </button>
            {showCancelled && <div className="mt-2 space-y-3">{cancelled.map((b) => <BookingCard key={b.id} b={b} conv={convFor(b)} />)}</div>}
          </section>
        )}
        <div className="h-4" />
      </div>
    </div>
  );
}
