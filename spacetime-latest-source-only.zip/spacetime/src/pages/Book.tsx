import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { CalendarDays, Check, CreditCard, Loader2, Lock, Repeat, ShieldCheck, Users } from 'lucide-react';
import { getProperty } from '@/data/properties';
import { useStore } from '@/store/useStore';
import { PageHeader, Stepper, Chip, Toggle, Segmented, PreviewNote } from '@/components/ui';
import { Img } from '@/components/Img';
import { DayTimeline } from '@/components/DayTimeline';
import { PriceRows } from './Property';
import { ACTIVITIES, CANCELLATION } from '@/data/vocab';
import { startSlots, findFit } from '@/lib/availability';
import { calcPrice, eur } from '@/lib/pricing';
import { recurringDates } from '@/lib/search';
import { dayLabel, fmtHours, longDate, nextDays, shortDate, toHHMM, toMin, todayISO } from '@/lib/time';
import { api, ApiError } from '@/lib/api';
import { useT } from '@/i18n';
import type { Activity, Booking } from '@/types';

export default function BookPage() {
  const t = useT();
  const STEPS = [t('When'), t('Who'), t('Confirm')];
  const { id = '' } = useParams();
  const [params] = useSearchParams();
  useStore((s) => s.catalogRev);
  const p = getProperty(id);
  const nav = useNavigate();
  const { query } = useStore();
  const [step, setStep] = useState(0);
  const [date, setDate] = useState(params.get('date') ?? query.when.date);
  const [hours, setHours] = useState(() => { const h = Number(params.get('hours') ?? query.when.durationHours); return p ? Math.min(p.maxHours, Math.max(p.minHours, Math.round(h))) : h; });
  const [start, setStart] = useState<string | null>(params.get('start'));
  const [recurring, setRecurring] = useState(query.when.recurring);
  const [guests, setGuests] = useState(() => ({ adults: query.who.adults, children: p?.childrenAllowed ? query.who.children : 0, infants: p?.childrenAllowed ? query.who.infants : 0, pets: p?.petsAllowed ? query.who.pets : 0 }));
  const [purpose, setPurpose] = useState<Activity | undefined>(query.activity && p?.activities.includes(query.activity) ? query.activity : p?.activities[0]);
  const [note, setNote] = useState('');
  const [agree, setAgree] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const slots = useMemo(() => (p ? startSlots(p, date, hours) : []), [p, date, hours]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!p) return;
    if (start && slots.some((s) => s.start === start && s.available)) return;
    const fit = findFit(p, date, start ?? query.when.start, hours, 3);
    setStart(fit?.start ?? slots.find((s) => s.available)?.start ?? null);
  }, [date, hours, slots.length]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!p) return <div className="flex flex-1 flex-col"><PageHeader back title={t('Reserve')} /><p className="p-6 text-ink-500">{t('This space is not bookable right now.')}</p></div>;
  const occurrences = recurring ? recurringDates(date, recurring.freq, recurring.count) : [date];
  const occOk = start ? occurrences.map((d) => !!findFit(p, d, start, hours, 0)) : [];
  const bookableDates = recurring ? occurrences.filter((_, i) => occOk[i]) : [date];
  const price = calcPrice(p, hours, Math.max(1, bookableDates.length));
  const end = start ? toHHMM(toMin(start) + hours * 60) : null;
  const totalGuests = guests.adults + guests.children;
  const canNext = step === 0 ? !!start && bookableDates.length > 0 : step === 1 ? totalGuests <= p.capacity.guests && guests.adults >= 1 : agree;

  const confirm = async () => {
    if (!start) return;
    setSubmitting(true);
    setError('');
    try {
      const out = await api<{ bookings: Booking[] }>('/api/bookings', { body: { propertyId: p.id, dates: bookableDates, start, hours, guests, purpose, note, recurring: bookableDates.length > 1 ? recurring : null } });
      void useStore.getState().loadCatalog();
      nav(`/confirmed/${out.bookings[0].id}`, { replace: true });
    } catch (e) {
      const msg = e instanceof ApiError && e.code === 'slot_unavailable' ? t('Someone just booked that time. Please pick another slot.') : e instanceof Error ? t(e.message) : t('Booking failed');
      setError(msg);
      await useStore.getState().loadCatalog();
      if (e instanceof ApiError && e.code === 'slot_unavailable') setStep(0);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="relative flex flex-1 flex-col overflow-hidden">
      <PageHeader back title={p.instantBook ? t('Reserve') : t('Request to book')} sub={p.shortTitle} />
      <div className="flex gap-2 px-5 pb-3">
        {STEPS.map((s, i) => (
          <button key={s} disabled={i > step} onClick={() => setStep(i)} className="flex-1 text-left">
            <div className={`h-1.5 rounded-full transition ${i <= step ? 'bg-electric' : 'bg-ivory-300'}`} style={{ transform: 'skewX(-20deg)' }} />
            <div className={`mt-1.5 text-[12.5px] font-bold ${i === step ? 'text-ink' : 'text-ink-500'}`}>{i + 1}. {s}</div>
          </button>
        ))}
      </div>
      {error && <div className="mx-5 mb-2 rounded-lg bg-rose-50 px-3 py-2 text-[13px] font-semibold text-rose-700">{error}</div>}

      <div className="flex-1 overflow-y-auto px-5 pb-36">
        {step === 0 && (
          <div className="space-y-6 animate-fade-up">
            <section>
              <h2 className="h-display mb-3 text-[22px]">{t('Pick a day')}</h2>
              <div className="no-scrollbar -mx-5 flex gap-2 overflow-x-auto px-5">
                {nextDays(14).map((d) => { const s = shortDate(d); const on = d === date; const any = startSlots(p, d, hours).some((x) => x.available); return (
                  <button key={d} onClick={() => setDate(d)} className={`relative flex w-[54px] shrink-0 flex-col items-center rounded-xl border py-2 ${on ? 'border-ink bg-ink text-white' : 'border-ivory-300 bg-white text-ink'} ${!any && !on ? 'opacity-40' : ''}`}>
                    <span className={`text-[11px] font-semibold ${on ? 'text-ice-200' : 'text-ink-500'}`}>{d === todayISO() ? t('Today') : s.dow}</span>
                    <span className="text-[18px] font-bold">{s.day}</span>
                    <span className={`mt-0.5 h-1.5 w-1.5 rounded-full ${any ? 'bg-electric' : 'bg-ivory-300'}`} />
                  </button>
                ); })}
              </div>
            </section>
            <section className="card p-4"><Stepper label={t('Duration (hours)')} sub={t('{a}h minimum · {b}h maximum', { a: p.minHours, b: p.maxHours })} value={hours} min={p.minHours} max={p.maxHours} onChange={setHours} /></section>
            <section>
              <h2 className="h-display mb-1 text-[22px]">{t('Start time')}</h2>
              <p className="mb-3 text-[13px] text-ink-500">{longDate(date)} · {t('slots that fit {h}', { h: fmtHours(hours) })}</p>
              {slots.length === 0 ? <p className="rounded-xl bg-white p-4 text-[14px] text-ink-500 shadow-card">{t('No daytime hours open on this day. Try another date.')}</p> : (
                <div className="grid grid-cols-4 gap-2">
                  {slots.map((s) => <button key={s.start} disabled={!s.available} onClick={() => setStart(s.start)} className={`rounded-lg border py-2.5 text-[14px] font-bold tabular-nums transition ${start === s.start ? 'border-electric bg-electric text-white' : s.available ? 'border-ivory-300 bg-white text-ink' : 'border-transparent bg-ivory-100 text-ink-500/50 line-through'}`}>{s.start}</button>)}
                </div>
              )}
              {start && <div className="mt-3 rounded-lg bg-ink px-3 py-2 text-center text-[15px] font-bold text-white tabular-nums">{start} → {end}</div>}
              <div className="mt-4"><DayTimeline p={p} date={date} highlight={start ? [toMin(start), toMin(start) + hours * 60] : undefined} /></div>
            </section>
            <section className="card p-4">
              <div className="flex items-center justify-between"><span className="flex items-center gap-2 text-[15px] font-semibold text-ink"><Repeat size={16} /> {t('Make it recurring')}</span><Toggle label={t('Recurring booking')} checked={!!recurring} onChange={(v) => setRecurring(v ? { freq: 'weekly', count: 4 } : null)} /></div>
              {recurring && (
                <div className="mt-3 space-y-3">
                  <Segmented value={recurring.freq} onChange={(freq) => setRecurring({ ...recurring, freq })} options={[{ value: 'daily', label: t('Daily') }, { value: 'weekdays', label: t('Weekdays') }, { value: 'weekly', label: t('Weekly') }]} />
                  <Stepper label={t('Occurrences')} value={recurring.count} min={2} max={12} onChange={(count) => setRecurring({ ...recurring, count })} />
                  {start && <div className="flex flex-wrap gap-1.5">{occurrences.map((d, i) => <span key={d} className={`rounded-md px-2.5 py-1 text-[12px] font-semibold ${occOk[i] ? 'bg-electric-100 text-ink' : 'bg-ivory-100 text-ink-500 line-through'}`}>{dayLabel(d)}</span>)}</div>}
                  {occOk.some((x) => !x) && <p className="text-[12.5px] text-amber-700">{t('Crossed-out dates aren’t open at {s} — they’ll be skipped.', { s: start ?? '' })}</p>}
                </div>
              )}
            </section>
          </div>
        )}
        {step === 1 && (
          <div className="space-y-6 animate-fade-up">
            <section className="card px-4 py-1">
              <h2 className="h-display pt-3 text-[22px]">{t('Who’s coming?')}</h2>
              <div className="divide-y divide-ivory-200">
                <Stepper label={t('Adults')} sub={t('Ages 13+')} value={guests.adults} min={1} max={p.capacity.guests - guests.children} onChange={(adults) => setGuests({ ...guests, adults })} />
                <Stepper label={t('Children')} sub={t('Ages 2–12')} value={guests.children} max={p.capacity.guests - guests.adults} disabledReason={!p.childrenAllowed ? t('Not suitable for children') : undefined} onChange={(children) => setGuests({ ...guests, children })} />
                <Stepper label={t('Infants')} sub={t('Under 2')} value={guests.infants} max={4} disabledReason={!p.childrenAllowed ? t('Not suitable for infants') : undefined} onChange={(infants) => setGuests({ ...guests, infants })} />
                <Stepper label={t('Pets')} sub={t('Assistance animals always welcome')} value={guests.pets} max={2} disabledReason={!p.petsAllowed ? t('No pets in this space') : undefined} onChange={(pets) => setGuests({ ...guests, pets })} />
              </div>
              <p className="pb-3 text-[12.5px] text-ink-500"><Users size={13} className="mr-1 inline" />{t('{a} of {b} guests max', { a: totalGuests, b: p.capacity.guests })}</p>
            </section>
            <section>
              <h2 className="mb-2 text-[16px] font-bold text-ink">{t('What will you use it for?')}</h2>
              <div className="flex flex-wrap gap-2">{p.activities.map((a) => { const A = ACTIVITIES[a]; return <Chip key={a} on={purpose === a} onClick={() => setPurpose(a)} icon={<A.icon size={14} />}>{t(A.label)}</Chip>; })}</div>
              <p className="mt-2 text-[12px] text-ink-500">{t('Only uses authorised by the owner are listed.')}</p>
            </section>
            <section>
              <label className="mb-2 block text-[16px] font-bold text-ink" htmlFor="note">{t('Note for {name}', { name: p.partner.name })} <span className="text-[13px] font-normal text-ink-500">({t('optional')})</span></label>
              <textarea id="note" rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder={t('E.g. arriving by train with a stroller…')} className="input resize-none" />
            </section>
          </div>
        )}
        {step === 2 && start && end && (
          <div className="space-y-5 animate-fade-up">
            <div className="card flex gap-3 p-3"><Img src={p.images[0]} alt={p.shortTitle} className="h-20 w-20 shrink-0 rounded-xl" /><div className="min-w-0"><div className="text-[12px] font-semibold text-ink-500">{p.neighbourhood}</div><div className="text-[15px] font-bold leading-snug text-ink">{p.title}</div></div></div>
            <div className="card divide-y divide-ivory-200 px-4">
              <SumRow icon={<CalendarDays size={17} />} label={t('When')} value={`${longDate(date)} · ${start}–${end}`} sub={bookableDates.length > 1 ? t('{n} bookings', { n: bookableDates.length }) : fmtHours(hours)} onEdit={() => setStep(0)} />
              <SumRow icon={<Users size={17} />} label={t('Guests')} value={[`${guests.adults} ${t('adult(s)')}`, guests.children && `${guests.children} ${t('child(ren)')}`, guests.infants && `${guests.infants} ${t('infant')}`, guests.pets && `${guests.pets} ${t('pet')}`].filter(Boolean).join(', ')} sub={purpose ? t(ACTIVITIES[purpose].label) : undefined} onEdit={() => setStep(1)} />
            </div>
            <div className="card space-y-2 p-4 text-[14px]"><h3 className="mb-1 text-[16px] font-bold text-ink">{t('Price breakdown')}</h3><PriceRows price={price} /></div>
            <div className="card p-4">
              <div className="flex items-center gap-3"><CreditCard size={20} className="text-ink" /><div className="flex-1"><div className="text-[14px] font-semibold text-ink">Visa •••• 4242</div><div className="text-[12px] text-ink-500">{t('Pay on confirmation')}</div></div><Lock size={16} className="text-ink-500" /></div>
              <div className="mt-3"><PreviewNote>{t('Preview checkout: no card is charged and no payment is processed.')}</PreviewNote></div>
            </div>
            <div className="flex items-start gap-3 rounded-xl bg-white p-4 shadow-card"><ShieldCheck size={20} className="mt-0.5 shrink-0 text-electric-600" /><div className="text-[13px] text-ink-700"><b className="text-ink">{t(CANCELLATION.label)}.</b> {t(CANCELLATION.detail)}</div></div>
            <label className="flex cursor-pointer items-start gap-3 rounded-xl bg-white p-4 shadow-card">
              <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} className="mt-1 h-5 w-5 accent-electric" />
              <span className="text-[13px] text-ink-700">{t('I agree to the house rules:')}<ul className="mt-1 list-disc pl-4 text-ink-500">{p.rules.map((r) => <li key={r}>{r}</li>)}</ul></span>
            </label>
          </div>
        )}
      </div>

      <div className="absolute inset-x-0 bottom-0 z-40 flex items-center gap-3 border-t border-ivory-200 bg-white px-5 py-3 pb-[max(env(safe-area-inset-bottom),12px)]">
        <div className="min-w-0 flex-1">
          <div className="text-[17px] font-bold text-ink">{eur(price.grandTotal)}</div>
          <div className="truncate text-[12.5px] text-ink-500">{start ? `${dayLabel(date)} · ${start}–${end}` : t('Choose a start time')}{bookableDates.length > 1 ? ` · ×${bookableDates.length}` : ''}</div>
        </div>
        {step < 2 ? <button className="btn-primary px-8" disabled={!canNext} onClick={() => setStep(step + 1)}>{t('Next')}</button> : (
          <button className="btn-accent px-6" disabled={!canNext || submitting} onClick={confirm}>{submitting ? <><Loader2 size={17} className="animate-spin" /> {t('Confirming')}</> : <><Check size={17} /> {p.instantBook ? t('Confirm booking') : t('Send request')}</>}</button>
        )}
      </div>
    </div>
  );
}

function SumRow({ icon, label, value, sub, onEdit }: { icon: React.ReactNode; label: string; value: string; sub?: string; onEdit: () => void }) {
  const t = useT();
  return (
    <div className="flex items-start gap-3 py-3.5">
      <span className="mt-0.5 text-electric-600">{icon}</span>
      <div className="min-w-0 flex-1"><div className="text-[12px] font-semibold uppercase tracking-wider text-ink-500">{label}</div><div className="text-[14.5px] font-semibold text-ink">{value}</div>{sub && <div className="text-[12.5px] text-ink-500">{sub}</div>}</div>
      <button onClick={onEdit} className="text-[13px] font-semibold text-electric-600 underline underline-offset-2">{t('Edit')}</button>
    </div>
  );
}
