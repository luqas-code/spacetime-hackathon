import { Component, type ReactNode } from 'react';

/** Shows the error instead of a blank screen, with a one-tap reset of this device's saved state. */
export class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) {
    return { error };
  }
  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div style={{ minHeight: '100vh', background: '#161D35', color: '#F8F6F0', padding: 24, fontFamily: 'system-ui, sans-serif', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 12 }}>
        <div style={{ fontWeight: 700, fontSize: 20 }}>Something went wrong</div>
        <code style={{ fontSize: 12, opacity: 0.8, wordBreak: 'break-word' }}>{this.state.error.message}</code>
        <button
          onClick={() => { try { localStorage.clear(); } catch { /* ignore */ } location.hash = '#/'; location.reload(); }}
          style={{ marginTop: 8, padding: '12px 16px', borderRadius: 10, border: 0, background: '#4062E8', color: '#fff', fontWeight: 600 }}
        >
          Reset this device & reload
        </button>
      </div>
    );
  }
}
