/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: '#161D35', 900: '#0E1326', 800: '#161D35', 700: '#262F52', 600: '#3A4470', 500: '#5C6690' },
        electric: { DEFAULT: '#4062E8', 700: '#2C4BC4', 600: '#3453D6', 500: '#4062E8', 400: '#6A85EE', 100: '#E4E9FC', 50: '#F1F4FE' },
        ice: { DEFAULT: '#E4E9FC', 50: '#F4F6FE', 100: '#E4E9FC', 200: '#D4DCFA', 300: '#C9BEF2' },
        lavender: { DEFAULT: '#B5A5EC', 100: '#EFEBFB', 200: '#DCD3F7', 600: '#7C66D4' },
        ivory: { DEFAULT: '#F8F6F0', 50: '#F8F6F0', 100: '#F1EEE5', 200: '#E6E2D6', 300: '#D6D0C0' },
      },
      fontFamily: {
        sans: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        display: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(22,29,53,0.06), 0 6px 20px -6px rgba(22,29,53,0.12)',
        float: '0 10px 40px -10px rgba(22,29,53,0.35)',
        nav: '0 -6px 24px -10px rgba(22,29,53,0.18)',
      },
      borderRadius: { '4xl': '2rem' },
      keyframes: {
        'fade-up': { from: { opacity: 0, transform: 'translateY(8px)' }, to: { opacity: 1, transform: 'none' } },
        pop: { '0%': { transform: 'scale(1)' }, '40%': { transform: 'scale(1.3)' }, '100%': { transform: 'scale(1)' } },
        'slide-up': { from: { transform: 'translateY(100%)' }, to: { transform: 'none' } },
        shimmer: { from: { backgroundPosition: '-200% 0' }, to: { backgroundPosition: '200% 0' } },
      },
      animation: {
        'fade-up': 'fade-up .35s ease-out both',
        pop: 'pop .35s ease-out',
        'slide-up': 'slide-up .3s cubic-bezier(.2,.8,.2,1) both',
        shimmer: 'shimmer 1.6s linear infinite',
      },
    },
  },
  plugins: [],
};
