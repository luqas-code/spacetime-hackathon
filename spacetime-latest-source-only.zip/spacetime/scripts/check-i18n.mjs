// Lists UI strings that have no French translation. Usage: node scripts/check-i18n.mjs [--json]
import fs from 'node:fs';
import path from 'node:path';
const files = [];
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).forEach((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : /\.(tsx?|mjs)$/.test(e.name) && !e.name.startsWith('i18n') && files.push(path.join(d, e.name))));
walk('src');
const keys = new Set();
const add = (s) => s && !/^[\s\d€%·:+\-–/().,]*$/.test(s) && keys.add(s.replace(/\\'/g, "'"));
for (const f of files) {
  const src = fs.readFileSync(f, 'utf8');
  for (const m of src.matchAll(/\b(?:t|tr)\(\s*'((?:[^'\\]|\\.)*)'/g)) add(m[1]);
  for (const m of src.matchAll(/\b(?:t|tr)\(\s*"((?:[^"\\]|\\.)*)"/g)) add(m[1]);
  for (const m of src.matchAll(/\bt\(\s*([a-z]+) === '[^']*' \? '((?:[^'\\]|\\.)*)' : '((?:[^'\\]|\\.)*)'/g)) { add(m[2]); add(m[3]); }
  // t(condition ? 'Sentence A' : 'Sentence B') with any condition — only sentence-like strings
  for (const m of src.matchAll(/\bt\([^;\n]*?\?\s*'((?:[^'\\]|\\.)*)'\s*:\s*'((?:[^'\\]|\\.)*)'\s*[,)]/g)) for (const x of [m[1], m[2]]) if (/^[A-Z{(]/.test(x) && / /.test(x)) add(x);
  // maps & config objects whose values are passed through t()
  if (/vocab|ManagerHome|ManagerCleaning|ManagerBooking|ManagerProperty|OwnerProperty|SmartAvailability|Login|Inbox\.tsx|Profile|dash|DayTimeline|ListingWizard|Discover|BottomNav|Assistant|BookingCard|Review/.test(f))
    for (const m of src.matchAll(/(?:label|title|verb|detail|sub):\s*'((?:[^'\\]|\\.)*)'/g)) add(m[1]);
  for (const m of src.matchAll(/^\s+[a-z_]+:\s*'((?:[^'\\]|\\.){4,})',?\s*$/gm)) if (/[A-Z]/.test(m[1][0]) && /CHECK_LABEL|READY|REASON|CONFLICT|CLEAN_LABEL|DELEG|STATUS_LABEL|OPTION_LABEL|ROLE/.test(src)) add(m[1]);
  for (const m of src.matchAll(/\[\s*'[a-z_]+',\s*'((?:[^'\\]|\\.)*)'\s*\]/g)) add(m[1]);
  for (const m of src.matchAll(/\['(?:bg|slot|block)[^']*',\s*'([^']+)'\]/g)) add(m[1]);
}
const { FR } = await import(path.resolve('src/i18n.fr.ts').replace(/^/, 'file://')).catch(() => ({ FR: {} }));
// "nav:X" short navigation labels fall back to the translation of X.
const missing = [...keys].filter((k) => !(k in FR) && !(k.startsWith('nav:') && k.slice(4) in FR)).sort();
if (process.argv.includes('--json')) console.log(JSON.stringify(missing, null, 1));
else console.log(`${keys.size} strings, ${missing.length} missing French`);
