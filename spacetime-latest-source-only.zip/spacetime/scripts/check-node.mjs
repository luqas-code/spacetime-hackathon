// Fails early with a clear message when Node is too old for node:sqlite + TypeScript type-stripping.
const [maj, min] = process.versions.node.split('.').map(Number);
if (maj < 22 || (maj === 22 && min < 13)) {
  console.error(`\n✖ SpaceTime needs Node.js 22.13 or newer — this machine has ${process.versions.node}.`);
  console.error('  In GitHub Codespaces run:  nvm install 22 && nvm use 22   then:  npm install && npm run demo\n');
  process.exit(1);
}
