const { chromium } = require('playwright');
// Three-session end-to-end test of the marketplace (owner, manager, guest) against a running server.
// Usage: npm run db:reset && npm start   (in another terminal)  then:  node scripts/e2e-three-phones.cjs [outDir] [baseUrl]
// Needs Playwright with a Chromium browser:  npx playwright install chromium
const fs = require('node:fs');
const path = require('node:path');
const S = path.resolve(process.argv[2] || 'e2e-shots');
const B = process.argv[3] || 'http://localhost:8787';
fs.mkdirSync(path.join(S, 'e2e'), { recursive: true });
// a small generated PNG to exercise real photo upload
fs.writeFileSync(path.join(S, 'e2e', 'living-room.jpg'), Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAEAAAAAwCAIAAAAuKetIAAAAWklEQVR4nO3PQQ0AIBDAMMC/5+NB0QFsCLqz1jrv4CbN0fz2gbM1R/PbB87WHM1vHzhbczS/feBszdH89oGzNUfz2wfO1hzNbx84W3M0v33gbM3R/PaBszVH87sfQYEBH5f3nEMAAAAASUVORK5CYII=', 'base64'));
const log = (...a) => console.log('•', ...a);
(async () => {
  const browser = await chromium.launch();
  const mk = async (name) => {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, timezoneId: 'Europe/Paris', locale: 'en-GB' });
    const page = await ctx.newPage();
    page.errs = [];
    page.on('pageerror', (e) => page.errs.push(e.message));
    page.on('console', (m) => m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text()) && page.errs.push(m.text().slice(0, 200)));
    page.shot = async (n) => { await page.waitForTimeout(500); await page.screenshot({ path: `${S}/e2e/${n}.png` }); };
    await page.goto(B + '/');
    await page.getByRole('button', { name: new RegExp(name) }).click();
    await page.waitForTimeout(1000);
    return page;
  };
  const owner = await mk('Space Owner');
  const mgr = await mk('Space Manager');
  const guest = await mk('Guest');
  log('logged in 3 sessions');

  // ---------------- Phone A: owner lists a space
  await owner.getByRole('link', { name: 'List a space' }).first().click();
  await owner.getByRole('button', { name: 'Sample details' }).click();
  await owner.shot('A1-basics');
  await owner.getByRole('button', { name: 'Save & continue' }).click();
  await owner.locator('input[type=file][accept="image/*"]').setInputFiles(`${S}/e2e/living-room.jpg`);
  await owner.getByText('Your photos (1)').waitFor({ timeout: 10000 });
  const lib = owner.getByText('Or pick from the sample library').locator('xpath=../..').locator('div.grid > button');
  for (let i = 0; i < 3; i++) await lib.nth(i).click();
  await owner.shot('A2-photos');
  await owner.getByRole('button', { name: 'Save & continue' }).click(); // amenities
  await owner.getByRole('button', { name: 'Save & continue' }).click(); // uses
  await owner.shot('A3-uses');
  await owner.getByRole('button', { name: 'Save & continue' }).click(); // hours & pricing
  await owner.getByRole('button', { name: /Import overnight calendar/ }).click();
  await owner.getByText(/overnight stays imported/).waitFor();
  await owner.shot('A4-hours');
  await owner.getByRole('button', { name: 'Save & continue' }).click(); // compliance
  await owner.getByRole('button', { name: /Use my verified compliance file/ }).click();
  await owner.shot('A5-compliance');
  await owner.getByRole('button', { name: 'Save & continue' }).click(); // management
  await owner.getByRole('button', { name: /Malik Benali/ }).click();
  await owner.shot('A6-management');
  await owner.getByRole('button', { name: 'Save & continue' }).click(); // review
  await owner.locator('input[type=checkbox]').check();
  await owner.getByRole('button', { name: 'Submit for review' }).click();
  await owner.getByText('Approved — ready to publish').waitFor();
  await owner.shot('A7-approved');
  await owner.getByRole('button', { name: 'Publish now' }).click();
  await owner.getByText('Your space is live').waitFor();
  await owner.shot('A8-live');
  log('owner published listing');

  // ---------------- Phone B: manager receives the assignment live (no reload)
  await mgr.getByText('New property assigned').waitFor({ timeout: 8000 });
  await mgr.shot('B1-assigned');
  await mgr.getByText('New property assigned').click();
  await mgr.waitForURL(/tab=smart/);
  const propUrl = mgr.url();
  const pid = /property\/([^?]+)/.exec(propUrl)[1];
  log('manager sees assignment live, property', pid);
  await mgr.getByRole('button', { name: 'Calendar' }).click();
  await mgr.shot('B2-calendar');
  await mgr.getByRole('button', { name: 'Smart Availability' }).click();
  // pick tomorrow
  const tomorrow = await mgr.evaluate(() => { const d = new Date(); d.setDate(d.getDate() + 1); return d.getDate(); });
  await mgr.locator('.clip-corner button').filter({ hasText: new RegExp(`^\\D*${tomorrow}$`) }).first().click();
  await mgr.waitForTimeout(400);
  await mgr.shot('B3-smart');
  const card = mgr.locator('div.card, div.rounded-xl').filter({ hasText: 'Longest safe window' }).first();
  await card.getByRole('button', { name: 'Explain' }).click();
  await card.getByText(/Generated explanation|AI explanation/).waitFor();
  await mgr.shot('B4-explain');
  await card.getByRole('button', { name: 'Approve slot' }).click();
  await mgr.getByText('Slot approved — now bookable by guests').waitFor();
  await mgr.waitForTimeout(800);
  await mgr.shot('B5-approved');
  log('manager approved slot');

  // ---------------- Phone C: guest NL search finds the new property
  await guest.goto(B + '/#/assistant');
  await guest.getByRole('textbox').fill("I'm arriving at Gare de Lyon at 9 am with two kids, and my accommodation check-in isn't until 4 pm. We need somewhere to shower and rest.");
  await guest.keyboard.press('Enter');
  await guest.getByText('Which day is this for?').waitFor();
  await guest.shot('C1-ask');
  await guest.getByRole('button', { name: 'Tomorrow', exact: true }).click();
  await guest.getByText(/spaces fit/).waitFor();
  await guest.waitForTimeout(500);
  await guest.shot('C2-matches');
  log('ranking:', (await guest.locator('div.card').filter({ hasText: /% match/ }).allInnerTexts()).map((c) => c.split('\n').filter(Boolean).filter((x) => /match|·/.test(x)).slice(0, 2).join(' ')).join('  ||  '));
  const match = guest.locator('div.card').filter({ hasText: 'Family apartment · Gare de Lyon' }).first();
  await match.waitFor();
  const bookLink = match.getByRole('link', { name: /Book/ });
  log('guest match link:', await bookLink.textContent());
  await match.getByRole('link', { name: 'Details' }).click();
  await guest.waitForURL(/space\//);
  await guest.shot('C3-detail');
  await guest.goBack();
  await guest.locator('div.card').filter({ hasText: 'Family apartment · Gare de Lyon' }).first().getByRole('link', { name: /Book/ }).click();
  await guest.waitForURL(/book\//);
  await guest.shot('C4-when');
  await guest.getByRole('button', { name: 'Next' }).click();
  await guest.getByLabel('Increase Children').click();
  await guest.getByLabel('Increase Children').click();
  await guest.shot('C5-who');
  await guest.getByRole('button', { name: 'Next' }).click();
  await guest.locator('input[type=checkbox]').check();
  await guest.shot('C6-review');
  await guest.getByRole('button', { name: /Confirm booking|Send request/ }).click();
  await guest.waitForURL(/confirmed/, { timeout: 8000 });
  await guest.getByText('You’re all set!').waitFor();
  await guest.shot('C7-confirmed');
  const bookingId = /confirmed\/(.+)$/.exec(guest.url())[1];
  log('guest booked', bookingId);

  // ---------------- Back to Phone B: booking arrives live
  await mgr.goto(B + '/#/manager');
  await mgr.getByText('Isaac Bernard').first().waitFor({ timeout: 8000 });
  await mgr.shot('B6-dashboard-booking');
  await mgr.goto(B + `/#/manager/property/${pid}?tab=calendar`);
  await mgr.shot('B7-calendar-updated');
  await mgr.goto(B + `/#/manager/booking/${bookingId}`);
  await mgr.getByText('Guest requirements').waitFor();
  await mgr.locator('select').filter({ hasText: 'Assign a cleaning provider' }).selectOption({ label: 'Éclat Ménage Paris · 07:00–20:00' });
  await mgr.waitForTimeout(500);
  await mgr.getByRole('button', { name: 'Ready', exact: true }).click();
  await mgr.waitForTimeout(500);
  await mgr.shot('B8-booking');
  await mgr.getByRole('button', { name: 'Message guest' }).click();
  await mgr.getByPlaceholder('Write a message…').fill('Bonjour Isaac! The flat is cleaned and the travel cot is set up for the kids. See you tomorrow.');
  await mgr.getByRole('button', { name: 'Send' }).click();
  await mgr.waitForTimeout(500);
  await mgr.shot('B9-message');
  log('manager assigned cleaning + messaged guest');

  // ---------------- Phone C: guest sees reply live and answers
  await guest.goto(B + '/#/messages');
  await guest.locator('a[href^="#/messages/"]').filter({ hasText: 'Family apartment' }).first().click();
  await guest.waitForURL(/messages\//);
  await guest.locator('div.flex-1.space-y-2').getByText(/travel cot is set up/).waitFor();
  await guest.getByPlaceholder('Write a message…').fill('Merci Malik, perfect!');
  await guest.getByRole('button', { name: 'Send' }).click();
  await guest.waitForTimeout(400);
  await guest.shot('C8-thread');
  await mgr.locator('div.flex-1.space-y-2').getByText('Merci Malik, perfect!').waitFor({ timeout: 6000 });
  log('guest reply appeared live on manager phone');

  // ---------------- Phone A: owner sees booking & economics
  await owner.goto(B + '/#/owner');
  await owner.getByText('Latest booking').waitFor();
  await owner.getByText(/Isaac Bernard/).first().waitFor();
  await owner.shot('A9-dashboard');
  await owner.goto(B + `/#/owner/property/${pid}`);
  await owner.waitForTimeout(600);
  await owner.shot('A10-property');
  log('owner sees booking + finances');

  const errs = { owner: owner.errs, mgr: mgr.errs, guest: guest.errs };
  console.log('ERRORS', JSON.stringify(errs));
  console.log('PID', pid, 'BOOKING', bookingId);
  await browser.close();
})().catch((e) => { console.error('FAIL', e.message.split('\n').slice(0, 6).join('\n')); process.exit(1); });
