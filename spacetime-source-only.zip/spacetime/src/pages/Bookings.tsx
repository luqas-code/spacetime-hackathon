import { Link, useSearchParams } from 'react-router-dom';
import { CalendarDays, MessageCircle } from 'lucide-react';
import { useApi } from '@/lib/api';
import { EmptyState, Segmented } from '@/components/ui';
import { BookingCard, type GuestBooking } from '@/components/BookingCard';
import { ConversationList } from './InboxList';
import { todayISO } from '@/lib/time';
import { useT } from '@/i18n';
import type { Conversation } from '@/types';

/** Guest "Messages" tab: conversations with Space Partners + bookings. */
export default function MessagesPage() {
  const t = useT();
  const [params, setParams] = useSearchParams();
  const tab = (params.get('tab') as 'messages' | 'trips') ?? 'messages';
  const { data: convs } = useApi<Conversation[]>('/api/conversations');
  const { data: bookings } = useApi<GuestBooking[]>('/api/bookings/mine');
  const list = bookings ?? [];
  const upcoming = list.filter((b) => (b.status === 'confirmed' || b.status === 'pending') && b.date >= todayISO()).sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start));
  const past = list.filter((b) => !upcoming.includes(b));
  return (
    <div className="page">
      <header className="px-5 pb-3 pt-[max(env(safe-area-inset-top),20px)]">
        <h1 className="h-display text-[30px]">{t('Messages')}</h1>
        <p className="text-[13px] text-ink-500">{t('Talk to the Space Partner managing each space, and keep track of your bookings.')}</p>
      </header>
      <div className="px-5"><Segmented value={tab} onChange={(x) => setParams({ tab: x }, { replace: true })} options={[{ value: 'messages', label: t('Conversations') }, { value: 'trips', label: `${t('Bookings')} (${upcoming.length})` }]} /></div>
      {tab === 'messages' && (
        <div className="px-5 pt-3">
          {convs && convs.length === 0 && <EmptyState icon={<MessageCircle size={30} />} title={t('No messages yet')} text={t('Message a Space Partner from any space page.')} />}
          <ConversationList convs={convs ?? []} base="/messages" />
        </div>
      )}
      {tab === 'trips' && (
        <div className="space-y-6 px-5 pt-4">
          <section>
            <h2 className="section-title mb-3">{t('Upcoming')}</h2>
            {upcoming.length === 0 ? <EmptyState icon={<CalendarDays size={30} />} title={t('Nothing booked yet')} text={t('When you reserve a space, your access code and details appear here.')} action={<Link to="/search" className="btn-primary">{t('Find a space')}</Link>} /> : <div className="space-y-3">{upcoming.map((b) => <BookingCard key={b.id} b={b} />)}</div>}
          </section>
          {past.length > 0 && <section><h2 className="section-title mb-3">{t('Past & cancelled')}</h2><div className="space-y-3">{past.map((b) => <BookingCard key={b.id} b={b} />)}</div></section>}
        </div>
      )}
    </div>
  );
}
