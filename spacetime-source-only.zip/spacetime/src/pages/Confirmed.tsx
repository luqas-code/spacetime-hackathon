import { Link, useNavigate, useParams } from 'react-router-dom';
import { CalendarPlus, Check, Copy, DoorOpen, Hourglass, KeyRound, LogOut, Mail, MapPin, MessageCircle, ScrollText, XCircle } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { PreviewNote } from '@/components/ui';
import { Img } from '@/components/Img';
import { MapView } from '@/components/MapView';
import { longDate, fmtHours } from '@/lib/time';
import { eur } from '@/lib/pricing';
import { downloadICS, googleCalendarUrl, outlookCalendarUrl } from '@/lib/ics';
import { api, useApi } from '@/lib/api';
import { useT } from '@/i18n';
import type { GuestBooking } from '@/components/BookingCard';
import type { EmailRecord } from '@/types';

export default function ConfirmedPage() {
  const t = useT();
  const { bookingId } = useParams();
  const nav = useNavigate();
  const { data: b, error } = useApi<GuestBooking>(`/api/bookings/${bookingId}`);
  const { data: emails } = useApi<EmailRecord[]>('/api/emails');
  if (error) return <div className="p-10 text-center">{t('Booking not found.')} <Link to="/messages?tab=trips" className="underline">{t('Bookings')}</Link></div>;
  if (!b || !b.property) return <div className="grid flex-1 place-items-center"><div className="h-8 w-8 animate-spin rounded-full border-4 border-ice-200 border-t-electric" /></div>;
  const p = b.property;
  const pending = b.status === 'pending';
  const confirmed = b.status === 'confirmed' || b.status === 'completed';
  const email = emails?.find((e) => e.subject.includes(p.shortTitle));
  const message = async () => { const c = await api<{ id: string }>('/api/conversations', { body: { propertyId: p.id, kind: 'guest' } }); nav(`/messages/${c.id}`); };

  return (
    <div className="page pb-10">
      <div className="relative overflow-hidden bg-ink px-6 pb-16 pt-[max(env(safe-area-inset-top),28px)] text-center text-white">
        <div className="pointer-events-none absolute -left-10 -top-10 h-48 w-48 rounded-full bg-electric/40 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-20 right-0 h-48 w-48 rounded-full bg-lavender/30 blur-3xl" />
        <div className={`relative mx-auto grid h-16 w-16 place-items-center rounded-2xl animate-pop ${pending ? 'bg-lavender text-ink' : b.status === 'declined' || b.status === 'cancelled' ? 'bg-rose-400 text-white' : 'bg-electric text-white'}`} style={{ transform: 'skewX(-8deg)' }}>
          {pending ? <Hourglass size={30} /> : b.status === 'declined' || b.status === 'cancelled' ? <XCircle size={30} /> : <Check size={34} strokeWidth={3} />}
        </div>
        <h1 className="relative mt-4 text-[28px] font-bold tracking-tight">{pending ? t('Request sent') : b.status === 'declined' ? t('Request declined') : b.status === 'cancelled' ? t('Booking cancelled') : t('You’re all set!')}</h1>
        <p className="relative mt-1 text-[14px] text-ice-200">{longDate(b.date)} · {b.start}–{b.end}</p>
        {pending && <p className="relative mx-auto mt-2 max-w-[300px] text-[13px] text-ice-200">{t('{name} will review your request. You’ll see the update here instantly.', { name: p.partner.name })}</p>}
      </div>

      <div className="relative -mt-10 space-y-4 px-4">
        {confirmed && (
          <div className="card p-5 text-center">
            <div className="flex items-center justify-center gap-2 text-[12px] font-bold uppercase tracking-wider text-ink-500"><KeyRound size={14} /> {t('Door access code')}</div>
            <div className="mt-2 flex justify-center gap-1.5">{b.accessCode.split('').map((d, i) => <span key={i} className="grid h-12 w-10 place-items-center rounded-lg bg-ice-100 text-[26px] font-bold text-ink">{d}</span>)}</div>
            <button onClick={() => { void navigator.clipboard?.writeText(b.accessCode).catch(() => {}); useStore.getState().showToast('Code copied'); }} className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-semibold text-electric-600"><Copy size={14} /> {t('Copy code')}</button>
            <div className="mt-2"><PreviewNote>{t('Preview code — not yet connected to a smart lock. Your Space Partner will confirm access.')}</PreviewNote></div>
          </div>
        )}
        <div className="card overflow-hidden">
          <div className="flex gap-3 p-3">
            <Img src={p.images[0]} alt={p.shortTitle} className="h-16 w-16 shrink-0 rounded-xl" />
            <div className="min-w-0 flex-1">
              <div className="text-[15px] font-bold text-ink">{p.shortTitle}</div>
              <div className="flex items-start gap-1 text-[12.5px] text-ink-500"><MapPin size={12} className="mt-0.5 shrink-0" /> {confirmed && p.address ? p.address : `${p.neighbourhood}, Paris ${p.arrondissement}`}</div>
              <div className="text-[12px] text-ink-500">{t('Managed by {name}', { name: p.partner.name })} · {p.partner.company}</div>
            </div>
          </div>
          <div className="h-36"><MapView center={p} zoom={16} interactive={false} pin={p} /></div>
          <div className="grid grid-cols-3 divide-x divide-ivory-200 border-t border-ivory-200 text-center text-[12px]">
            <div className="p-3"><div className="font-bold text-ink">{fmtHours(b.hours)}</div><div className="text-ink-500">{t('duration')}</div></div>
            <div className="p-3"><div className="font-bold text-ink">{b.guests.adults + b.guests.children}</div><div className="text-ink-500">{t('guests')}</div></div>
            <div className="p-3"><div className="font-bold text-ink">{eur(b.price.guestTotal)}</div><div className="text-ink-500">{t('total')}</div></div>
          </div>
        </div>
        {confirmed && (
          <div className="grid grid-cols-2 gap-3">
            <button className="btn-ghost py-3 text-[14px]" onClick={() => downloadICS(b, p)}><CalendarPlus size={17} /> {t('Apple / .ics')}</button>
            <a className="btn-ghost py-3 text-[14px]" href={googleCalendarUrl(b, p)} target="_blank" rel="noreferrer"><CalendarPlus size={17} /> Google</a>
            <a className="btn-ghost py-3 text-[14px]" href={outlookCalendarUrl(b, p)} target="_blank" rel="noreferrer"><CalendarPlus size={17} /> Outlook</a>
            <button className="btn-ghost py-3 text-[14px]" onClick={message}><MessageCircle size={17} /> {t('Message')}</button>
          </div>
        )}
        {!confirmed && <button className="btn-ghost w-full py-3 text-[14px]" onClick={message}><MessageCircle size={17} /> {t('Message the Space Partner')}</button>}
        {confirmed && (
          <>
            <Info icon={<DoorOpen size={18} />} title={t('Checking in')}><p>{p.checkinInstructions || t('Your Space Partner will send check-in details.')}</p></Info>
            <Info icon={<ScrollText size={18} />} title={t('House rules')}><ul className="list-disc space-y-1 pl-4">{p.rules.map((r) => <li key={r}>{r}</li>)}</ul></Info>
            <Info icon={<LogOut size={18} />} title={t('Checking out by {t}', { t: b.end })}><ul className="list-disc space-y-1 pl-4">{p.checkout.map((r) => <li key={r}>{r}</li>)}</ul></Info>
          </>
        )}
        {email && (
          <Link to="/profile?edit=emails" className="flex items-center gap-3 rounded-xl bg-white p-3 text-[13px] shadow-card">
            <Mail size={18} className="text-electric-600" />
            <span className="flex-1"><b>{t('Confirmation email')}</b> · {email.status === 'sent' ? t('sent') : email.status === 'failed' ? t('not delivered') : t('preview only — not sent')}</span>
          </Link>
        )}
        <div className="grid grid-cols-2 gap-3 pt-1">
          <Link to="/messages?tab=trips" className="btn-primary">{t('My bookings')}</Link>
          <Link to="/discover" className="btn-soft">{t('Keep exploring')}</Link>
        </div>
      </div>
    </div>
  );
}

function Info({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return <div className="card p-4"><h3 className="mb-2 flex items-center gap-2 text-[15px] font-bold text-ink"><span className="text-electric-600">{icon}</span>{title}</h3><div className="text-[13.5px] leading-relaxed text-ink-700">{children}</div></div>;
}
