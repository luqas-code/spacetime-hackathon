import { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import { Send } from 'lucide-react';
import { api, useApi } from '@/lib/api';
import { useStore } from '@/store/useStore';
import { Avatar, PageHeader, StatusPill, partnerColor } from '@/components/ui';
import { Img } from '@/components/Img';
import { dayLabel, isoDate } from '@/lib/time';
import { useT } from '@/i18n';
import type { Booking, Conversation, Message } from '@/types';
import { useStore as useLangStore } from '@/store/useStore';

/** System messages are stored in English; render them in the reader's language. */
function sysText(body: string, lang: string) {
  if (lang !== 'fr') return body;
  return body
    .replace(/^Booking confirmed/, 'Réservation confirmée').replace(/^Booking request declined/, 'Demande de réservation refusée').replace(/^Booking request/, 'Demande de réservation')
    .replace(/^Booking approved by/, 'Réservation approuvée par').replace(/^Booking cancelled by guest/, 'Réservation annulée par le voyageur').replace(/^Booking cancelled by manager/, 'Réservation annulée par le gestionnaire')
    .replace('awaiting approval', 'en attente de validation').replace('no charge', 'sans frais').replace(/late cancellation, (.+) due/, 'annulation tardive, $1 dû');
}

type Thread = { conversation?: Conversation; property: { id: string; shortTitle: string; images: string[]; neighbourhood: string }; booking: Booking | null; messages: Message[] };

const QUICK: Record<string, string[]> = {
  guest: ['Can I arrive 15 minutes early?', 'Is there somewhere to leave luggage?', 'What is the Wi‑Fi like for video calls?'],
  manager: ['The space is cleaned and ready for you.', 'Yes, that works — see you then.', 'Luggage can stay by the entrance during your booking.'],
  owner: ['Thanks — please keep me posted.', 'Approved, go ahead.'],
};

/** Message thread for guests, managers and owners — messages persist on the shared backend. */
export default function ThreadPage() {
  const t = useT();
  const { convId } = useParams();
  const { pathname } = useLocation();
  const me = useStore((s) => s.user)!;
  const { data, setData } = useApi<Thread>(`/api/conversations/${convId}`);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const back = pathname.startsWith('/owner') ? '/owner/messages' : pathname.startsWith('/manager') ? '/manager/messages' : '/messages';

  useEffect(() => { void api(`/api/conversations/${convId}/read`, { body: {} }).catch(() => {}); }, [convId, data?.messages.length]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [data?.messages.length]);

  const send = async (m: string) => {
    const body = m.trim();
    if (!body || sending) return;
    setSending(true);
    try {
      const msg = await api<Message>(`/api/conversations/${convId}/messages`, { body: { body } });
      setData((d) => (d ? { ...d, messages: [...d.messages, { ...msg, senderName: me.name }] } : d));
      setText('');
    } catch (e) {
      useStore.getState().showToast(e instanceof Error ? e.message : 'Could not send', undefined, 'error');
    } finally {
      setSending(false);
    }
  };

  if (!data) return <div className="flex flex-1 flex-col"><PageHeader back={back} title="…" /></div>;
  const c = data.conversation;
  const propLink = me.role === 'manager' ? `/manager/property/${data.property.id}` : me.role === 'owner' ? `/owner/property/${data.property.id}` : `/space/${data.property.id}`;
  let lastDay = '';
  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      <PageHeader back={back} title={<span className="flex items-center gap-2"><Avatar name={c?.title ?? ''} src={c?.counterpartAvatar || undefined} color={partnerColor(c?.title ?? '')} size={30} /> {c?.title}</span>} sub={me.role === 'guest' ? t('Space Partner · {p}', { p: data.property.shortTitle }) : c?.kind === 'owner' ? t('Owner · {p}', { p: data.property.shortTitle }) : t('Guest · {p}', { p: data.property.shortTitle })} />
      <Link to={data.booking && me.role === 'manager' ? `/manager/booking/${data.booking.id}` : data.booking && me.role === 'guest' ? `/confirmed/${data.booking.id}` : propLink} className="mx-4 mb-2 flex items-center gap-3 rounded-xl bg-white p-2.5 shadow-card">
        <Img src={data.property.images[0]} alt="" className="h-11 w-11 rounded-lg" />
        <div className="min-w-0 flex-1">
          <div className="truncate text-[13.5px] font-bold text-ink">{data.property.shortTitle}</div>
          <div className="truncate text-[12px] text-ink-500">{data.booking ? `${dayLabel(data.booking.date)} ${data.booking.start}–${data.booking.end}` : t('No booking linked')}</div>
        </div>
        {data.booking && <StatusPill tone={data.booking.status === 'confirmed' ? 'ok' : data.booking.status === 'pending' ? 'warn' : 'muted'}>{t(data.booking.status === 'pending' ? 'Awaiting approval' : data.booking.status[0].toUpperCase() + data.booking.status.slice(1))}</StatusPill>}
      </Link>
      <div className="flex-1 space-y-2 overflow-y-auto px-4 py-3">
        {data.messages.length === 0 && <p className="py-10 text-center text-[14px] text-ink-500">{t('Say hello 👋 or ask a question below.')}</p>}
        {data.messages.map((m) => {
          const day = isoDate(new Date(m.at));
          const showDay = day !== lastDay;
          lastDay = day;
          const mine = m.senderId === me.id;
          const time = new Date(m.at).toLocaleTimeString(document.documentElement.lang === 'fr' ? 'fr-FR' : 'en-GB', { hour: '2-digit', minute: '2-digit' });
          return (
            <div key={m.id}>
              {showDay && <div className="my-3 text-center text-[12.5px] font-semibold text-ink-500">{dayLabel(day)}</div>}
              {m.senderRole === 'system' ? (
                <div className="my-2 flex justify-center"><span className="rounded-md bg-ice-100 px-3 py-1.5 text-center text-[12px] font-semibold text-ink-600">{sysText(m.body, useLangStore.getState().lang)}</span></div>
              ) : (
                <div className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[78%] rounded-2xl px-4 py-2.5 text-[14.5px] leading-snug ${mine ? 'rounded-br-md bg-ink text-white' : 'rounded-bl-md bg-white text-ink shadow-card'}`}>
                    {!mine && <div className="mb-0.5 text-[11px] font-bold text-electric-600">{m.senderName}</div>}
                    {m.body}
                    <div className={`mt-1 text-[11.5px] ${mine ? 'text-ice-200' : 'text-ink-500'}`}>{time}</div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
        <div ref={endRef} />
      </div>
      <div className="border-t border-ivory-200 bg-white px-3 pb-[max(env(safe-area-inset-bottom),10px)] pt-2">
        <div className="no-scrollbar mb-2 flex gap-2 overflow-x-auto">
          {(QUICK[me.role] ?? []).map((q) => <button key={q} onClick={() => send(t(q))} className="chip-off py-1.5 text-[12.5px]">{t(q)}</button>)}
        </div>
        <form onSubmit={(e) => { e.preventDefault(); void send(text); }} className="flex items-center gap-2">
          <input value={text} onChange={(e) => setText(e.target.value)} placeholder={t('Write a message…')} className="input flex-1 rounded-full py-3" aria-label={t('Message')} />
          <button type="submit" aria-label={t('Send')} disabled={!text.trim() || sending} className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-electric text-white transition active:scale-90 disabled:opacity-40"><Send size={19} /></button>
        </form>
      </div>
    </div>
  );
}
