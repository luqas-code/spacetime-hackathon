import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Accessibility as AccIcon, Bell, Camera, ChevronRight, Globe, LogOut, Mail, MapPin, Pencil, RotateCcw, SlidersHorizontal, Sparkles, User, Building2, FileCheck2 } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { Logo } from '@/components/Logo';
import { Avatar, Sheet, Toggle, StatusPill, LanguageOptions } from '@/components/ui';
import { AccessibilityPicker, HouseholdEditor, InterestPicker, LocationsEditor } from '@/components/PreferenceEditors';
import { BookingCard, type GuestBooking } from '@/components/BookingCard';
import { ACCESSIBILITY, ACTIVITIES } from '@/data/vocab';
import { uploadImage, useApi } from '@/lib/api';
import { useT } from '@/i18n';
import type { EmailRecord, UserPrefs } from '@/types';
import { timeAgo } from './InboxList';

type EditKey = 'personal' | 'locations' | 'interests' | 'needs' | 'prefs' | 'settings' | 'emails' | 'language' | null;
const ROLE: Record<string, string> = { guest: 'Guest', owner: 'Space Owner', manager: 'Space Manager', reviewer: 'Compliance reviewer' };

export default function ProfilePage() {
  const t = useT();
  const nav = useNavigate();
  const [params, setParams] = useSearchParams();
  const { user, updateMe, logout, lang, setLang } = useStore();
  const u = user!;
  const isGuest = u.role === 'guest';
  const { data: bookings } = useApi<GuestBooking[]>(isGuest ? '/api/bookings/mine' : null);
  const { data: emails } = useApi<EmailRecord[]>('/api/emails');
  const [edit, setEdit] = useState<EditKey>(null);
  const [prefs, setPrefs] = useState<UserPrefs>(u.prefs);
  const [info, setInfo] = useState({ name: u.name, phone: u.phone, bio: u.bio, company: u.company });
  const [uploading, setUploading] = useState(false);
  const [langDraft, setLangDraft] = useState(lang);
  const [langSaving, setLangSaving] = useState(false);
  const saveLang = async () => {
    setLangSaving(true);
    try { await updateMe({ lang: langDraft, prefs: { langChosen: true } }); setLang(langDraft); setEdit(null); useStore.getState().showToast('Language saved'); }
    catch { useStore.getState().showToast('Could not save. Check your connection and try again.', undefined, 'error'); }
    finally { setLangSaving(false); }
  };
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const e = params.get('edit') as EditKey;
    if (e) { open(e); setParams({}, { replace: true }); }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const open = (k: EditKey) => { const cur = useStore.getState().user!; setPrefs(cur.prefs); setInfo({ name: cur.name, phone: cur.phone, bio: cur.bio, company: cur.company }); setEdit(k); };
  const savePrefs = async () => { await updateMe({ prefs }); setEdit(null); useStore.getState().showToast('Preferences saved'); };
  const saveInfo = async () => { await updateMe(info); setEdit(null); useStore.getState().showToast('Profile saved'); };
  const onPhoto = async (f?: File) => {
    if (!f) return;
    setUploading(true);
    try { const url = await uploadImage(f, 600); await updateMe({ avatarUrl: url }); useStore.getState().showToast('Photo updated'); } finally { setUploading(false); }
  };
  const home = u.prefs.locations.find((l) => l.tag === 'home');
  const work = u.prefs.locations.find((l) => l.tag === 'work');

  return (
    <div className="page">
      <div className="relative overflow-hidden bg-ink px-5 pb-16 pt-[max(env(safe-area-inset-top),20px)] text-white">
        <div className="pointer-events-none absolute -right-10 top-0 h-40 w-40 rounded-full bg-electric/40 blur-3xl" />
        <div className="relative"><Logo light size={24} /></div>
        <h1 className="relative mt-4 text-[24px] font-bold">{t('Profile')}</h1>
        <div className="relative mt-4 flex items-center gap-4">
          <button className="relative" onClick={() => fileRef.current?.click()} aria-label={t('Change photo')}>
            <Avatar name={u.name} src={u.avatarUrl || undefined} size={72} />
            <span className="absolute -bottom-1 -right-1 grid h-7 w-7 place-items-center rounded-full bg-electric ring-2 ring-ink">{uploading ? <span className="h-3 w-3 animate-spin rounded-full border-2 border-white border-t-transparent" /> : <Camera size={14} />}</span>
          </button>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => onPhoto(e.target.files?.[0])} />
          <div className="min-w-0 flex-1">
            <div className="truncate text-[20px] font-bold">{u.name}</div>
            <div className="truncate text-[13px] text-ice-200">{u.email}</div>
            <div className="mt-1 flex items-center gap-2"><StatusPill tone="info">{t(ROLE[u.role])}</StatusPill>{u.company && <span className="truncate text-[12px] text-ice-200">{u.company}</span>}</div>
          </div>
          <button aria-label={t('Edit')} onClick={() => open('personal')} className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-white/15"><Pencil size={17} /></button>
        </div>
      </div>

      <div className="relative -mt-8 space-y-6 px-5">
        <Group title={t('About you')}>
          <Item icon={<User size={18} />} title={t('Personal information')} sub={[u.phone, u.bio].filter(Boolean).join(' · ') || t('Name, phone, bio')} onClick={() => open('personal')} />
          {isGuest && <>
            <Item icon={<MapPin size={18} />} title={t('Home, work & places')} sub={[home && `${t('Home')}: ${home.label}`, work && `${t('Work')}: ${work.label}`].filter(Boolean).join(' · ') || t('Add your areas')} onClick={() => open('locations')} />
            <Item icon={<Sparkles size={18} />} title={t('Preferred activities')} sub={u.prefs.interests.map((i) => t(ACTIVITIES[i].label)).join(', ') || '—'} onClick={() => open('interests')} />
            <Item icon={<AccIcon size={18} />} title={t('Household & accessibility')} sub={[u.prefs.household.kids && t('Kids'), u.prefs.household.pets && t('Pets'), ...u.prefs.accessibility.map((a) => t(ACCESSIBILITY[a].label))].filter(Boolean).join(', ') || t('No specific needs')} onClick={() => open('needs')} />
            <Item icon={<SlidersHorizontal size={18} />} title={t('Saved preferences')} sub={t('Budget up to €{b}/h · {w} min walk', { b: u.prefs.budgetMax, w: u.prefs.walkingMins })} onClick={() => open('prefs')} />
          </>}
          {u.role === 'owner' && <Item icon={<FileCheck2 size={18} />} title={t('Verified compliance file')} sub={t('Documents verified by SpaceTime Compliance')} onClick={() => nav('/owner/listings')} />}
          {u.role === 'manager' && <Item icon={<Building2 size={18} />} title={t('Company')} sub={u.company} onClick={() => open('personal')} />}
        </Group>

        {isGuest && (
          <Group title={t('Booking history')} action={<Link to="/messages?tab=trips" className="text-[13px] font-bold text-electric-600">{t('See all')}</Link>}>
            <div className="space-y-3 p-3">{(bookings ?? []).slice(0, 3).map((b) => <BookingCard key={b.id} b={b} />)}{bookings && bookings.length === 0 && <p className="p-2 text-[14px] text-ink-500">{t('No bookings yet.')}</p>}</div>
          </Group>
        )}

        <Group title={t('Settings')}>
          <Item icon={<Globe size={18} />} title={t('Language')} sub={lang === 'fr' ? 'Français' : 'English'} onClick={() => { setLangDraft(lang); setEdit('language'); }} />
          <Item icon={<Bell size={18} />} title={t('Notifications')} sub={u.prefs.pushNotifications ? t('On') : t('Off')} onClick={() => open('settings')} />
          <Item icon={<Mail size={18} />} title={t('Emails')} sub={t('{n} transactional emails', { n: emails?.length ?? 0 })} onClick={() => open('emails')} />
        </Group>
        <Group title={t('Account')}>
          {isGuest && <Item icon={<RotateCcw size={18} />} title={t('Replay onboarding')} sub={t('Update your purposes and places')} onClick={() => { void updateMe({ prefs: { onboarded: false } }).then(() => nav('/onboarding')); }} />}
          <Item icon={<LogOut size={18} />} title={t('Sign out')} sub={t('Switch to another demo account')} onClick={() => { void logout().then(() => nav('/login')); }} />
        </Group>
        <div className="h-6" />
      </div>

      <Sheet open={edit === 'personal'} onClose={() => setEdit(null)} title={t('Personal information')} footer={<button className="btn-primary w-full" onClick={saveInfo}>{t('Save')}</button>}>
        <div className="space-y-4 pb-4">
          <Field label={t('Full name')}><input className="input" value={info.name} onChange={(e) => setInfo({ ...info, name: e.target.value })} /></Field>
          <Field label={t('Phone')}><input className="input" value={info.phone} onChange={(e) => setInfo({ ...info, phone: e.target.value })} /></Field>
          {!isGuest && <Field label={t('Company')}><input className="input" value={info.company} onChange={(e) => setInfo({ ...info, company: e.target.value })} /></Field>}
          <Field label={t('About you')}><textarea className="input resize-none" rows={3} value={info.bio} onChange={(e) => setInfo({ ...info, bio: e.target.value })} /></Field>
          <button className="btn-ghost w-full" onClick={() => fileRef.current?.click()}><Camera size={16} /> {t('Upload a profile photo')}</button>
        </div>
      </Sheet>
      <Sheet open={edit === 'locations'} onClose={() => setEdit(null)} title={t('Home, work & places')} full footer={<button className="btn-primary w-full" onClick={savePrefs}>{t('Save places')}</button>}>
        <LocationsEditor value={prefs.locations} onChange={(locations) => setPrefs({ ...prefs, locations })} />
      </Sheet>
      <Sheet open={edit === 'interests'} onClose={() => setEdit(null)} title={t('Preferred activities')} footer={<button className="btn-primary w-full" onClick={savePrefs}>{t('Save')}</button>}>
        <InterestPicker value={prefs.interests} onChange={(interests) => setPrefs({ ...prefs, interests })} />
      </Sheet>
      <Sheet open={edit === 'needs'} onClose={() => setEdit(null)} title={t('Household & accessibility')} footer={<button className="btn-primary w-full" onClick={savePrefs}>{t('Save')}</button>}>
        <div className="space-y-5 pb-4"><HouseholdEditor value={prefs.household} onChange={(household) => setPrefs({ ...prefs, household })} /><AccessibilityPicker value={prefs.accessibility} onChange={(accessibility) => setPrefs({ ...prefs, accessibility })} /></div>
      </Sheet>
      <Sheet open={edit === 'prefs'} onClose={() => setEdit(null)} title={t('Saved preferences')} footer={<button className="btn-primary w-full" onClick={savePrefs}>{t('Save')}</button>}>
        <div className="space-y-5 pb-4">
          <div><div className="mb-1 flex justify-between text-[14px]"><span className="font-semibold">{t('Usual budget')}</span><b>€{prefs.budgetMax}/h</b></div><input type="range" min={10} max={60} value={prefs.budgetMax} onChange={(e) => setPrefs({ ...prefs, budgetMax: +e.target.value })} className="w-full accent-electric" /></div>
          <div><div className="mb-1 flex justify-between text-[14px]"><span className="font-semibold">{t('Happy to walk')}</span><b>{prefs.walkingMins} min</b></div><input type="range" min={5} max={30} step={5} value={prefs.walkingMins} onChange={(e) => setPrefs({ ...prefs, walkingMins: +e.target.value })} className="w-full accent-electric" /></div>
          <div className="flex items-center justify-between rounded-xl bg-white px-4 py-3.5 shadow-card"><span className="text-[15px] font-semibold">{t('Instant book only')}</span><Toggle label={t('Instant book only')} checked={prefs.instantBookOnly} onChange={(instantBookOnly) => setPrefs({ ...prefs, instantBookOnly })} /></div>
        </div>
      </Sheet>
      <Sheet open={edit === 'settings'} onClose={() => setEdit(null)} title={t('Notifications')} footer={<button className="btn-primary w-full" onClick={savePrefs}>{t('Save')}</button>}>
        <div className="space-y-3 pb-4">
          <div className="flex items-center justify-between rounded-xl bg-white px-4 py-3.5 shadow-card"><span className="text-[15px] font-semibold">{t('In-app alerts')}</span><Toggle label="push" checked={prefs.pushNotifications} onChange={(pushNotifications) => setPrefs({ ...prefs, pushNotifications })} /></div>
          <div className="flex items-center justify-between rounded-xl bg-white px-4 py-3.5 shadow-card"><span className="text-[15px] font-semibold">{t('Email updates')}</span><Toggle label="email" checked={prefs.emailUpdates} onChange={(emailUpdates) => setPrefs({ ...prefs, emailUpdates })} /></div>
        </div>
      </Sheet>
      <Sheet open={edit === 'language'} onClose={() => setEdit(null)} title={t('Language')} footer={<button className="btn-primary w-full" disabled={langSaving || langDraft === lang} onClick={saveLang}>{langSaving ? t('Saving…') : t('Save')}</button>}>
        <div className="space-y-3 pb-4">
          <p className="text-[14px] text-ink-500">{t('Used across the app and in your emails. Saved to your account, so it follows you on every device.')}</p>
          <LanguageOptions value={langDraft} onChange={setLangDraft} />
        </div>
      </Sheet>
      <Sheet open={edit === 'emails'} onClose={() => setEdit(null)} title={t('Transactional emails')} full>
        <div className="space-y-3 pb-6">
          <p className="text-[12.5px] text-ink-500">{t('Emails are sent through the configured provider. Without credentials they are kept as previews and are not delivered.')}</p>
          {(emails ?? []).map((e) => (
            <details key={e.id} className="card overflow-hidden">
              <summary className="flex cursor-pointer items-center gap-2 p-3">
                <StatusPill tone={e.status === 'sent' ? 'ok' : e.status === 'failed' ? 'bad' : 'muted'}>{t(e.status === 'sent' ? 'Sent' : e.status === 'failed' ? 'Failed' : 'Preview — not sent')}</StatusPill>
                <span className="min-w-0 flex-1 truncate text-[13px] font-semibold">{e.subject}</span>
                <span className="text-[11px] text-ink-500">{timeAgo(e.at)}</span>
              </summary>
              <div className="border-t border-ivory-200 bg-ivory-50 p-2 text-[11px] text-ink-500">{t('To')}: {e.to}</div>
              <iframe title={e.subject} srcDoc={e.html} className="h-80 w-full border-0 bg-ivory-50" sandbox="" />
            </details>
          ))}
          {emails && emails.length === 0 && <p className="text-[14px] text-ink-500">{t('No emails yet.')}</p>}
        </div>
      </Sheet>
    </div>
  );
}

function Group({ title, children, action }: { title: string; children: ReactNode; action?: ReactNode }) {
  return <section><div className="mb-2 flex items-center justify-between px-1"><h2 className="text-[13px] font-bold uppercase tracking-[0.1em] text-ink-500">{title}</h2>{action}</div><div className="card divide-y divide-ivory-200 overflow-hidden">{children}</div></section>;
}
function Item({ icon, title, sub, onClick }: { icon: ReactNode; title: string; sub: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex w-full items-center gap-3 px-4 py-3.5 text-left hover:bg-ivory-50">
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-ice-100 text-ink">{icon}</span>
      <span className="min-w-0 flex-1"><span className="block text-[15px] font-semibold text-ink">{title}</span><span className="block truncate text-[13.5px] text-ink-500">{sub}</span></span>
      <ChevronRight size={18} className="shrink-0 text-ink-500" />
    </button>
  );
}
function Field({ label, children }: { label: string; children: ReactNode }) { return <label className="block"><span className="label">{label}</span>{children}</label>; }
