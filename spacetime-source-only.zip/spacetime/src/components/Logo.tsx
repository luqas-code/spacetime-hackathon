import { useId } from 'react';
import { MARK_S, WORDMARK_VIEWBOX, WORD_IDOT, WORD_SPACE, WORD_TIME } from './logoPaths';

/**
 * SpaceTime identity — custom angular letterforms (20-unit grid, 45° leading cuts, 12° forward lean),
 * two-tone "space" / "time", with the dot of the i as a single point in time.
 * Static SVG versions live in public/brand/ (see public/brand/index.html).
 *
 * Change BRAND_VARIANT to try the alternatives everywhere at once:
 *   'velocity' — clean letterforms (default)
 *   'horizon'  — one continuous horizontal cut through the word, like a timeline
 *   'track'    — three fine motorsport stripes through "time"
 */
export type BrandVariant = 'velocity' | 'horizon' | 'track';
export const BRAND_VARIANT: BrandVariant = 'velocity';

const C = { ink: '#161D35', electric: '#4062E8', ivory: '#F8F6F0', electricLight: '#6A85EE', lavender: '#B5A5EC', lavenderDark: '#7C66D4' };
const [VX, VY, VW, VH] = WORDMARK_VIEWBOX.split(' ').map(Number);

export function Wordmark({ light = false, height = 22, variant = BRAND_VARIANT, className = '' }: { light?: boolean; height?: number; variant?: BrandVariant; className?: string }) {
  const id = useId().replace(/:/g, '');
  const masked = variant !== 'velocity';
  return (
    <svg viewBox={WORDMARK_VIEWBOX} height={height} width={(height * VW) / VH} role="img" aria-label="SpaceTime" className={`block shrink-0 ${className}`}>
      {masked && (
        <defs>
          <mask id={id} maskUnits="userSpaceOnUse" x={VX} y={VY} width={VW} height={VH}>
            <rect x={VX} y={VY} width={VW} height={VH} fill="#fff" />
            {variant === 'horizon' && <rect x={VX} y={9.2} width={VW} height={1.6} fill="#000" />}
            {variant === 'track' && [6.4, 9.4, 12.4].map((y) => <rect key={y} x={86} y={y} width={VW} height={1.2} fill="#000" />)}
          </mask>
        </defs>
      )}
      <g fillRule="evenodd" mask={masked ? `url(#${id})` : undefined}>
        <path fill={light ? C.ivory : C.ink} d={WORD_SPACE} />
        <path fill={light ? C.electricLight : C.electric} d={WORD_TIME} />
        <path fill={light ? C.lavender : C.lavenderDark} d={WORD_IDOT} />
      </g>
    </svg>
  );
}

/** Compact standalone icon: the custom "s" on a rounded tile (also the favicon). */
export function LogoMark({ size = 32, light = false }: { size?: number; light?: boolean }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden className="block shrink-0">
      <rect width="64" height="64" rx="15" fill={light ? C.ivory : C.ink} />
      <g transform="translate(11.5 12) scale(2)">
        <path fill={light ? C.ink : C.ivory} d={MARK_S} />
        <path fill={light ? C.electric : C.electricLight} d="M18.6 -3.8 L22.4 -3.8 L21.6 0 L17.8 0 Z" />
      </g>
    </svg>
  );
}

/** Header logo: the wordmark alone keeps headers compact. `size` is the approximate visual height in px. */
export function Logo({ size = 28, light = false }: { size?: number; light?: boolean }) {
  return <Wordmark light={light} height={Math.round(size * 0.82)} />;
}
