import { useEffect, useState } from 'react';
import { MARK_S } from './logoPaths';

/**
 * Image with lazy loading, a shimmer while loading, one automatic retry, and a calm branded
 * placeholder (no broken-image icon) if the photo still can't be fetched.
 * Size and aspect ratio come from the caller's className; photos are always cropped (object-cover), never stretched.
 */
export function Img({ src, alt, className = '', seed = 0 }: { src: string; alt: string; className?: string; seed?: number }) {
  const [state, setState] = useState<'loading' | 'ok' | 'error'>(src ? 'loading' : 'error');
  const [attempt, setAttempt] = useState(0);
  useEffect(() => { setState(src ? 'loading' : 'error'); setAttempt(0); }, [src]);
  const gradients = ['from-ice-200 via-ice-100 to-lavender-100', 'from-lavender-100 via-ice-100 to-ice-200', 'from-ice-100 via-electric-50 to-ice-200', 'from-ivory-100 via-ice-100 to-lavender-100'];
  const url = attempt && src && !src.startsWith('data:') ? `${src}${src.includes('?') ? '&' : '?'}retry=${attempt}` : src;
  return (
    <div className={`relative overflow-hidden bg-ice-100 ${className}`}>
      {state !== 'error' && (
        <img
          key={url}
          src={url}
          alt={alt}
          loading="lazy"
          decoding="async"
          onLoad={() => setState('ok')}
          onError={() => (attempt < 1 ? setAttempt(attempt + 1) : setState('error'))}
          className={`h-full w-full object-cover transition-opacity duration-500 motion-reduce:transition-none ${state === 'ok' ? 'opacity-100' : 'opacity-0'}`}
        />
      )}
      {state === 'loading' && <div className="skeleton absolute inset-0" aria-hidden />}
      {state === 'error' && (
        <div className={`absolute inset-0 grid place-items-center bg-gradient-to-br ${gradients[seed % gradients.length]}`} role={alt ? 'img' : undefined} aria-label={alt || undefined}>
          <svg viewBox="-2 -4 26 26" className="h-1/3 max-h-12 w-1/3 max-w-12 opacity-25" aria-hidden><path fill="#161D35" d={MARK_S} /></svg>
        </div>
      )}
    </div>
  );
}
