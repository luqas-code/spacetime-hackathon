import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CalendarX, KeyRound } from 'lucide-react';
import type { Booking, Property } from '@/types';
import { Img } from './Img';
import { Sheet, StatusPill } from './ui';
import { dayLabel } from '@/lib/time';
import { eur } from '@/lib/pricing';
import { api } from '@/lib/api';
import { useStore } from '@/store/useStore';
import { CANCELLATION } from '@/data/vocab';
import { useT } from '@/i18n';

export type GuestBooking = Booking & { property: Property | null };

export const statusTone = (s: Booking['status']) => (s === 'confirmed' ? 'ok' : s === 'pending' ? 'warn' : s === 'completed' ? 'info' : 'muted') as 'ok' | 'warn' | 'info' | 'muted';

/** Guest-facing booking summary with cancellation (free until 2 h before). */
export function BookingCard({ b }: { b: GuestBooking }) {
  const t = useT();
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const p = b.property;
  const active = b.status === 'confirmed' || b.status === 'pending';
  const startAt = new Date(`${b.date}T${b.start}:00`);
  const late = (startAt.getTime() - Date.now()) / 3600000 < 2;
  const cancel = async () => {
    setBusy(true);
    try {
      await api(`/api/bookings/${b.id}/cancel`, { body: {} });
      useStore.getState().bump();
      useStore.getState().showToast('Booking cancelled');
    } finally {
      setBusy(false);
      setConfirm(false);
    }
  };
  return (
    <div className={`card overflow-hidden ${b.status === 'cancelled' || b.status === 'declined' ? 'opacity-60' : ''}`}>
      <Link to={active ? `/confirmed/${b.id}` : p ? `/space/${p.id}` : '#'} className="flex gap-3 p-3">
        {p && <Img src={p.images[0]} alt={p.shortTitle} className="h-20 w-20 shrink-0 rounded-xl" />}
        <div className="min-w-0 flex-1">
          <StatusPill tone={statusTone(b.status)}>{t(b.status === 'pending' ? 'Awaiting approval' : b.status[0].toUpperCase() + b.status.slice(1))}</StatusPill>
          <div className="mt-1 truncate text-[15px] font-bold text-ink">{p?.shortTitle}</div>
          <div className="text-[12.5px] text-ink-500">{dayLabel(b.date)} · {b.start}–{b.end}</div>
          <div className="text-[12.5px] text-ink-500">{t('{n} guests', { n: b.guests.adults + b.guests.children })} · {eur(b.price.guestTotal)}{b.cancelFee ? ` · ${t('late cancellation {x}', { x: eur(b.cancelFee) })}` : ''}</div>
        </div>
      </Link>
      {active && (
        <div className="flex items-center justify-between border-t border-ivory-200 px-4 py-2.5">
          {b.status === 'confirmed' ? <span className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-ink"><KeyRound size={14} className="text-electric-600" /> {t('Code')} {b.accessCode}</span> : <span className="text-[12.5px] text-ink-500">{t('The Space Partner will confirm shortly')}</span>}
          <button onClick={() => setConfirm(true)} className="inline-flex items-center gap-1 text-[13px] font-semibold text-ink-500"><CalendarX size={14} /> {t('Cancel')}</button>
        </div>
      )}
      <Sheet open={confirm} onClose={() => setConfirm(false)} title={t('Cancel booking?')} footer={<button className="btn-primary w-full" disabled={busy} onClick={cancel}>{t('Yes, cancel this booking')}</button>}>
        <p className="pb-4 text-[14px] leading-relaxed text-ink-700">
          <b>{t(CANCELLATION.label)}.</b> {t(CANCELLATION.detail)}<br /><br />
          {b.status === 'confirmed' && late ? <b className="text-rose-700">{t('Your booking starts in less than 2 hours, so the full amount ({x}) would be due. No card is charged in this preview.', { x: eur(b.price.guestTotal) })}</b> : t('This cancellation is free.')}
        </p>
      </Sheet>
    </div>
  );
}
