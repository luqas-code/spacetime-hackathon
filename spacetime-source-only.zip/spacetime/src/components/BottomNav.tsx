import { NavLink } from 'react-router-dom';
import { Compass, Heart, Search, MessageCircle, User, LayoutDashboard, Building2, Inbox, Sparkles, SprayCan, type LucideIcon } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { useApi } from '@/lib/api';
import { useT } from '@/i18n';
import type { Conversation, Role } from '@/types';

type Item = { to: string; label: string; icon: LucideIcon; primary?: boolean; badge?: 'messages' | 'favs'; end?: boolean };
const NAV: Record<Role, Item[]> = {
  guest: [
    { to: '/discover', label: 'nav:Discover', icon: Compass },
    { to: '/favourites', label: 'nav:Favourites', icon: Heart, badge: 'favs' },
    { to: '/search', label: 'nav:Search', icon: Search, primary: true },
    { to: '/messages', label: 'nav:Messages', icon: MessageCircle, badge: 'messages' },
    { to: '/profile', label: 'nav:Profile', icon: User },
  ],
  owner: [
    { to: '/owner', label: 'nav:Dashboard', icon: LayoutDashboard, end: true },
    { to: '/owner/listings', label: 'nav:Listings', icon: Building2 },
    { to: '/owner/messages', label: 'nav:Messages', icon: Inbox, badge: 'messages' },
    { to: '/owner/profile', label: 'nav:Profile', icon: User },
  ],
  manager: [
    { to: '/manager', label: 'nav:Today', icon: LayoutDashboard, end: true },
    { to: '/manager/portfolio', label: 'nav:Portfolio', icon: Building2 },
    { to: '/manager/insights', label: 'nav:Opportunities', icon: Sparkles, primary: true },
    { to: '/manager/cleaning', label: 'nav:Cleaning', icon: SprayCan },
    { to: '/manager/messages', label: 'nav:Messages', icon: Inbox, badge: 'messages' },
  ],
  reviewer: [{ to: '/review', label: 'nav:Review', icon: LayoutDashboard }, { to: '/review/profile', label: 'nav:Profile', icon: User }],
};

export function BottomNav() {
  const t = useT();
  const user = useStore((s) => s.user);
  const { data: convs } = useApi<Conversation[]>(user ? '/api/conversations' : null);
  if (!user) return null;
  const unread = (convs ?? []).reduce((n, c) => n + c.unread, 0);
  const favs = user.prefs.favourites.length;
  const items = NAV[user.role];
  return (
    <nav className="absolute inset-x-0 bottom-0 z-[900] border-t border-ivory-200 bg-white/95 pb-[max(env(safe-area-inset-bottom),8px)] shadow-nav backdrop-blur" aria-label="Main">
      <ul className="flex px-1 pt-1.5">
        {items.map(({ to, label, icon: Icon, primary, badge, end }) => (
          <li key={to} className={`min-w-0 ${primary ? 'flex-[1.35]' : 'flex-1'}`}>
            <NavLink to={to} end={end} aria-label={badge === 'messages' && unread > 0 ? `${t(label)} (${unread})` : undefined} className="group flex min-w-0 flex-col items-center gap-0.5 py-1">
              {({ isActive }) => (
                <>
                  <span className={`relative grid h-10 w-12 place-items-center rounded-xl transition ${primary ? (isActive ? 'bg-electric text-white' : 'bg-ink text-white') : isActive ? 'bg-ice-100 text-ink' : 'text-ink-500'}`} style={primary ? { transform: 'skewX(-8deg)' } : undefined}>
                    <span style={primary ? { transform: 'skewX(8deg)' } : undefined}>
                      <Icon size={21} strokeWidth={isActive ? 2.4 : 2} className={badge === 'favs' && isActive ? 'fill-electric text-electric' : ''} />
                    </span>
                    {badge === 'messages' && unread > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-electric px-1 text-[10px] font-bold text-white">{unread}</span>}
                    {badge === 'favs' && favs > 0 && !isActive && <span className="absolute right-2.5 top-1.5 h-2 w-2 rounded-full bg-lavender-600" />}
                  </span>
                  <span className={`max-w-full truncate text-[11px] tracking-[-0.01em] max-[360px]:text-[10px] ${isActive ? 'font-bold text-ink' : 'font-medium text-ink-500'}`}>{t(label)}</span>
                </>
              )}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}
