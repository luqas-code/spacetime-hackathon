import { useEffect, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Circle, useMap, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import type { Property } from '@/types';

export interface MapMarker {
  property: Property;
  label?: string;
}

interface Props {
  center: { lat: number; lng: number };
  zoom?: number;
  markers?: MapMarker[];
  activeId?: string | null;
  favIds?: string[];
  onMarkerClick?: (id: string) => void;
  onMapClick?: () => void;
  circle?: { lat: number; lng: number; radiusKm: number } | null;
  pin?: { lat: number; lng: number } | null;
  onCenterChange?: (c: { lat: number; lng: number }) => void;
  fit?: boolean;
  interactive?: boolean;
  className?: string;
  zoomControl?: boolean;
}

const TILE = 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
const ATTR = '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>';

const priceIcon = (label: string, active: boolean, fav: boolean) =>
  L.divIcon({ className: `price-marker${active ? ' active' : ''}${fav ? ' fav' : ''}`, html: `<div>${label}</div>`, iconSize: [0, 0] });

const pinIcon = L.divIcon({
  className: 'place-marker',
  html: `<div><svg width="34" height="42" viewBox="0 0 34 42"><path d="M17 1C8.2 1 1 8 1 16.6 1 28.4 17 41 17 41s16-12.6 16-24.4C33 8 25.8 1 17 1z" fill="#4062E8" stroke="#fff" stroke-width="2"/><circle cx="17" cy="16" r="6" fill="#fff"/></svg></div>`,
  iconSize: [0, 0],
});

function Recenter({ center, zoom }: { center: { lat: number; lng: number }; zoom?: number }) {
  const map = useMap();
  useEffect(() => {
    map.setView([center.lat, center.lng], zoom ?? map.getZoom(), { animate: true });
  }, [center.lat, center.lng]); // eslint-disable-line react-hooks/exhaustive-deps
  return null;
}

function FitBounds({ markers, circle }: { markers: MapMarker[]; circle?: Props['circle'] }) {
  const map = useMap();
  const key = markers.map((m) => m.property.id).join(',');
  useEffect(() => {
    const pts: L.LatLngExpression[] = markers.map((m) => [m.property.lat, m.property.lng]);
    if (circle) pts.push([circle.lat, circle.lng]);
    if (pts.length > 1) map.fitBounds(L.latLngBounds(pts), { padding: [40, 40], maxZoom: 15 });
    else if (pts.length === 1) map.setView(pts[0], 15);
  }, [key]); // eslint-disable-line react-hooks/exhaustive-deps
  return null;
}

function PanToActive({ activeId, markers }: { activeId?: string | null; markers: MapMarker[] }) {
  const map = useMap();
  useEffect(() => {
    const m = markers.find((x) => x.property.id === activeId);
    if (m) map.panTo([m.property.lat, m.property.lng], { animate: true });
  }, [activeId]); // eslint-disable-line react-hooks/exhaustive-deps
  return null;
}

function CenterTracker({ onChange, onClick }: { onChange?: Props['onCenterChange']; onClick?: () => void }) {
  const map = useMapEvents({
    moveend: () => {
      const c = map.getCenter();
      onChange?.({ lat: c.lat, lng: c.lng });
    },
    click: () => onClick?.(),
  });
  return null;
}

function InvalidateOnResize() {
  const map = useMap();
  useEffect(() => {
    const ro = new ResizeObserver(() => map.invalidateSize());
    ro.observe(map.getContainer());
    return () => ro.disconnect();
  }, [map]);
  return null;
}

export function MapView({ center, zoom = 14, markers = [], activeId, favIds = [], onMarkerClick, onMapClick, circle, pin, onCenterChange, fit, interactive = true, className = '', zoomControl = false }: Props) {
  const icons = useMemo(
    () => Object.fromEntries(markers.map((m) => [m.property.id, priceIcon(m.label ?? `€${m.property.pricePerHour}`, m.property.id === activeId, favIds.includes(m.property.id))])),
    [markers, activeId, favIds],
  );
  return (
    <MapContainer
      center={[center.lat, center.lng]}
      zoom={zoom}
      zoomControl={zoomControl}
      dragging={interactive}
      scrollWheelZoom={interactive}
      doubleClickZoom={interactive}
      touchZoom={interactive}
      keyboard={interactive}
      attributionControl
      className={`h-full w-full ${className}`}
    >
      <TileLayer url={TILE} attribution={ATTR} subdomains="abcd" maxZoom={19} />
      <InvalidateOnResize />
      {!fit && <Recenter center={center} zoom={zoom} />}
      {fit && <FitBounds markers={markers} circle={circle} />}
      <PanToActive activeId={activeId} markers={markers} />
      {(onCenterChange || onMapClick) && <CenterTracker onChange={onCenterChange} onClick={onMapClick} />}
      {circle && (
        <Circle center={[circle.lat, circle.lng]} radius={circle.radiusKm * 1000} pathOptions={{ color: '#4062E8', weight: 2, fillColor: '#4062E8', fillOpacity: 0.08, dashArray: '6 6' }} />
      )}
      {pin && <Marker position={[pin.lat, pin.lng]} icon={pinIcon} interactive={false} />}
      {markers.map((m) => (
        <Marker
          key={m.property.id}
          position={[m.property.lat, m.property.lng]}
          icon={icons[m.property.id]}
          zIndexOffset={m.property.id === activeId ? 1000 : 0}
          eventHandlers={{ click: () => onMarkerClick?.(m.property.id) }}
          keyboard
          title={m.property.shortTitle}
        />
      ))}
    </MapContainer>
  );
}
